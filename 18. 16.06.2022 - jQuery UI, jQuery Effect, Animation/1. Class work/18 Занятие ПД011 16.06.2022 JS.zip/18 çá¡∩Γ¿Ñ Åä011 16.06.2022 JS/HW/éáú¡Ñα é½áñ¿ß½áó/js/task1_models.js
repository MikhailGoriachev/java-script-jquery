//region Студенты
//Заявка
class Student {


    //region Геттеры. Сеттеры
    get gender() {
        return this._gender;
    }

    set gender(value) {
        this._gender = value;
    }

    get performance() {
        return this._performance;
    }

    set performance(value) {
        this._performance = value.length===5?value:generateMarks();
    }

    get studentSNP() {
        return this._studentsSNP;
    }

    set studentSNP(value) {
        this._studentsSNP = value;
    }

    get photoFile() {
        return this._photoFile;
    }
    //endregion

    get avgMark()
    {
        let avg = this._performance.reduce((acc,m) => acc+m.grade,0)/this._performance.length;

        if (avg>5)
        {
            console.log(`Avg incorrect\r\nМассив: ${this.performance.map(p => p.grade)}
            \r\nСумма: ${this._performance.reduce((acc,m) => acc+m.grade,0)}
            \r\nДелитель: ${this._performance.length}`);
        }
        return avg;
    }

    //Свойства
    constructor(id,group,gender,marks) {
        this.studentId = id;
        this.studentSNP = generateSNP(gender);
        this.groupName = group;

        //В зависимости от пола задаём разные фото + ставим ограничитель на максимальный индекс фото
        this._photoFile = gender.toLowerCase().includes('муж')?`man_0${id<10 ? (`0${id}`) : id<11?(`${id}`):(`0${ getRandom(1,10) }`)}.jpg`:
                                                               `woman_0${id<10 ? (`0${id}`) : id<11?(`${id}`):(`0${ getRandom(1,10) }`)}.jpg`;
        this.performance = marks;
        this.gender = gender;
    }


    //Вывод
    toHtml () {
        return `<div float: left id="${this.studentId}" class="student-block">
                        <div><img class="student-photo" src="../images/students/${this._photoFile}" alt=""></div>
                        <div><span>ФИО студента: <b>${this._studentsSNP}</b></div>
                        <div><span>Пол: <b>${this._gender}</b></div>
                        <div><span>Название группы: <b>${this.groupName}</b></div>
                        <details class="marks">
                            <summary>Успеваемость</summary>
                                <div class="performance-block">
                                      <ol>
                                        <li>${this._performance[0].subject} - <b>${this._performance[0].grade}</b> </li>
                                        <li>${this._performance[1].subject} - <b>${this._performance[1].grade}</b> </li>
                                        <li>${this._performance[2].subject} - <b>${this._performance[2].grade}</b> </li>
                                        <li>${this._performance[3].subject} - <b>${this._performance[3].grade}</b> </li>
                                        <li>${this._performance[4].subject} - <b>${this._performance[4].grade}</b> </li>
                                      </ol>
                                      
                                </div>
                            </details>
                        <div>
                            Средний бал: ${this.avgMark.toFixed(1)}
                        </div>
                        <div>
                            <input class="btn-change" id="change_${this.studentId}" type="button" value="Изменить">
                            <input class="btn-delete" id="delete_${this.studentId}" type="button" value="Удалить">
                         
                        </div>
                </div>`
    }

    assign(student){
        Object.assign(this,student)
        this.performance = this.performance.map(p => new Mark().assign(p));
        return this;
    }
}

//Управление заявками
class StudentsCollection {
    constructor(studentsArr) {
        this.students = studentsArr;
    }

    //Генерация массива данных для обработки
    static generateStudent() {
        let array = [];

        for (let i = 0; i < 10; i++) {
            array[i] = new Student(i+1,generateGroup(),getGender(),generateMarks())
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(studentsArr) {

        let str = studentsArr.reduce((acc,student) => acc+student.toHtml(),'');

        return str;
    }
    //Запись в localStore
    writeToLocal(){
        window.localStorage.studentsCollection = JSON.stringify(this);
    }

    //Чтение из LocalStore
    getFromLocal(){
        this.students = []
        let collection = JSON.parse(window.localStorage.studentsCollection);

        this.students = collection.students.map(s => new Student(0,'','',[]).assign(s))

    }
}

class Mark {
    get subject() {
        return this._subject;
    }

    set subject(value) {
        this._subject = value;
    }

    get grade() {
        return this._mark;
    }

    set grade(value) {

        this._mark = value<=5 || value>=1 ? value : getRandom(2,6);
    }
    constructor(subject,grade) {
        this.subject = subject;
        this.grade = grade;
    }
    assign(mark){
        Object.assign(this,mark)
        return this;
    }
}
//endregion