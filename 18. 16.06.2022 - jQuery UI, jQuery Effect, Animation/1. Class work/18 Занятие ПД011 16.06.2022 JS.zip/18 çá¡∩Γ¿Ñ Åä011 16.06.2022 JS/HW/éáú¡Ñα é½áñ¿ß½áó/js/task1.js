
//region Сортировки, обработчики

//Упорядочить по среднему балу
function orderByAvgMark(blockObject, students) {
    //Копия массива
    let copy = students.map(c => c).sort((s1,s2) => s1.avgMark - s2.avgMark);
    blockObject.html(StudentsCollection.createMarkup(copy));
    return copy;
}//orderByAvgMark

//Упорядочить по фамилиям
function orderBySurname(blockObject, students) {
    //Копия массива
    let copy = students.map(c => c).sort((s1,s2) => s1.studentSNP.localeCompare(s2.studentSNP));
    blockObject.html(StudentsCollection.createMarkup(copy));
    return copy;
}//orderBySurname

//Упорядочить по названию группы
function orderByGroup(blockObject, students) {
    //Копия массива
    let copy = students.map(c => c).sort((s1,s2) => s1.groupName.localeCompare(s2.groupName));
    blockObject.html(StudentsCollection.createMarkup(copy));
    return copy;
}//orderByGroup




//endregion

//Функция с самовызовом
$(function (){

    let mainBlock = $('#mainDiv');

    //Работники
    let studentsCollection = new StudentsCollection([]);
    let students = [];

    //region Чтение и запись в локальное хранилище
    if (window.localStorage.studentsCollection) {
        studentsCollection.getFromLocal();
        students = studentsCollection.students;
    }
    else {
        studentsCollection.students = StudentsCollection.generateStudent();
        studentsCollection.writeToLocal();
        students = studentsCollection.students;
    }
    //endregion


    let title = $('#taskTitle');

    let inputField = $("#inputGroupName");
    let btnSearch =  $("#highlightByGroupName");
    let message =    $("#messageText");
    let lastFormedCollection = students;

    //Обект таймера
    let timer = 0;

    //Обработчик кнопки вывода исходного массива
    let showDefaultArr = function () {
        mainBlock.html(StudentsCollection.createMarkup(students));
        title.html(`<span>Исходный массив</span>`);
        lastFormedCollection = students;

        addOnCardBtnHandlers();
    }
    showDefaultArr();

    //Вывести любую коллекцию студентов
    function showCollection(studentsArr) {
        mainBlock.html(StudentsCollection.createMarkup(studentsArr));
    }

    //region Сортировки + выделение

    //Обработчик кнопки сортировки по среднему баллу
    $("#orderByAvgMark").click(() => {

        //Сортировка
        lastFormedCollection = orderByAvgMark(mainBlock,students);

        addOnCardBtnHandlers();

        title.html(`<span>Сортировка по возрастанию среднего бала</span>`);
    });

    //Обработчик кнопки сортировки по фамилиям
    $("#orderBySurname").click(() => {

        //Сортировка
        lastFormedCollection = orderBySurname(mainBlock,students);

        addOnCardBtnHandlers();

        title.html(`<span>Сортировка по фамилиям</span>`);
    });
    //Обработчик кнопки сортировки по учебным группам
    $("#orderByGroupName").click(() => {

        //Сортировка
        lastFormedCollection = orderByGroup(mainBlock,students);

        addOnCardBtnHandlers();

        title.html(`<span>Сортировка по учебной группе</span>`);
    });

    //endregion

    $('#defaultArr').on('click',showDefaultArr);
    $('#cleanLocalStore').click(() => {
        console.log('Очистка локального хранилища')
        window.localStorage.removeItem('studentsCollection')
    });


    //region Поведение кнопки поиска
    //При выходе из поля ввода убираем записи и кнопку

    function focusMouseOutHandler(field) {
        let pattern = new RegExp('([0-9]+|[А-Яа-я]+)')
        let inputValue = field.value;

        //Если поле пустое или состоит из пробелов
        if (inputValue === "" || !pattern.test(inputValue)) {
            message.text('');

            btnSearch.css('visibility','hidden');
            btnSearch.prop('disabled',false);
        }

    }

    //Обработчики на покидание мыши и выход из фокуса
    inputField.focusout((e) => focusMouseOutHandler(e.target));
    inputField.mouseout((e) => focusMouseOutHandler(e.target));

    //endregion

    //Валидация при вводе
    function keyDownHandler(e,btnAccept) {
        let key = e.key;
        let pattern = new RegExp(`([0-9]+|[A-Za-zА-Яа-я-]+)`);

        //Коды системных клавиш (space, enter и т.д)
        let conductiveKeysCodes = [8,32,13,16,17,18];

        btnAccept.css('visibility','visible');
        btnAccept.prop('disabled',false);

        //Если ведённый символ не соответствует регулярке и если не нажаты системные клавиши
        if (!pattern.test(key) && !conductiveKeysCodes.includes(e.keyCode))
        {
            message.text('Разрешены только числа и буквы!');
            btnAccept.prop('disabled',true);
            e.preventDefault();
            return;
        }

        message.text('');
        btnAccept.prop('disabled',false);
    }

    inputField.keydown((e) => keyDownHandler(e,btnSearch));

    //region Выделение через JQuery

    let highlight4and5 = $('#highlightByMarks');
    let highlight2 = $('#highlightByMark2');

    function highlightMarkTwo() {
        showCollection(lastFormedCollection);
        //Находим таблицы с определённым содержанием
        let foundCard = $(`div[class*=performance] li:contains('2')`,'.student-block').parents('.student-block');

        foundCard.addClass('highlightRow');

        clearTimeout(timer);

        //После истечения таймера перепишем коллекцию
        timer = setTimeout(() => foundCard.toggleClass('highlightRow'),10_000)
    }

    function highlightGroup(group) {
        showCollection(lastFormedCollection);
        //Находим таблицы с определённым содержанием
        let foundCard = $(`div:nth-of-type(4):contains('${group}')`,'.student-block').parents('.student-block');

        foundCard.addClass('highlightRow');

        clearTimeout(timer);

        //После истечения таймера перепишем коллекцию
        timer = setTimeout(() => foundCard.toggleClass('highlightRow'),10_000)
    }

    function highlightFewConditions(str1,str2) {
        showCollection(lastFormedCollection);
        //Находим таблицы с определённым содержанием
        let foundCard = $(`div[class*=performance]:has(li:contains('${str1}')):has(li:contains('${str2}'))`,'.student-block').parents('.student-block');

        foundCard.addClass('highlightRow');


        clearTimeout(timer);

        //После истечения таймера перепишем коллекцию
        timer = setTimeout(() => foundCard.toggleClass('highlightRow'),10_000)
    }

    btnSearch.click(() => highlightGroup(inputField.val()));
    highlight4and5.click(() =>highlightFewConditions(5,4));
    highlight2.click(() => highlightMarkTwo());


    //endregion

    //region Редактировани и удаление
    //Обработчик для кнопки удалить
    function deleteWorkerHandler(e) {

        /*console.log(`Удаление вызвано: ${++amount}`);*/
        let button = e.target;

        //Получаем id нужного студента
        let idStudent = getNumFromStr(button.id);

        let index =  students.findIndex((s) => s.studentId === idStudent);

        students.splice(index,1);

        showDefaultArr();

        //Переписываем коллекцию в локальное хранилище + загружаем drop down списки
        studentsCollection.writeToLocal();

        //Если удаляется редактируемый элемент, то очищаем поля формы
        if (parseInt(form.getAttribute('data-selected-student-id')) === idStudent)
            resetFormHandler(bottomLbl,fields);

        loadPhotoFile(studentGender);
    }//deleteWorkerHandler

    //Обработчик для кнопки удалить
    function editWorkerHandler(e) {
        let button = e.target;
        //Получаем id нужного студента
        let idStudent = getNumFromStr(button.id);

        let index =  students.findIndex((s) => s.studentId === idStudent);

        changeFormToEditing(students[index])

        showDefaultArr();

    }//editWorkerHandler

    //Задание обработчиков для кнопок удаления и изменения на карточках
    function addOnCardBtnHandlers () {

        $(`input[id*=delete]`).click((e) => deleteWorkerHandler(e));

        //Перехват события на этапе всплытия
        mainBlock.on('click',(e) =>{

            let element = e.target;

            //Если нажата кнопка удаления
           /* if (element.id.toLowerCase().includes('delete')) {
                deleteWorkerHandler(e);
                return;
            }*/

            //Если нажата кнопка изменения
            if (element.id.toLowerCase().includes('change')) {
                editWorkerHandler(e);
            }
        })
    };


    //endregion

    //region Форма

    //Форма
    let form = document.addChangeForm;

    //Нижнний текст
    let bottomLbl = $('#formPrompt');

    //Кнопка добавить/изменить
    let btnAddChange = $('#btnAdd');
    let btnReset = $('#resetBtn');


    //Массив полей вода для итоговой валидации
    let fields = [];
    for (let i = 0; i < form.elements.length; i++) {
        let element = form.elements[i];

        //Выбираем поля с текстовым вводом
        if (element.type === 'text')
            fields.push(element)
    }


    //Поля формы для задания валидаторов
    let studentSnp =  $('#studentSnp');
    let groupName = $('#groupName');
    let studentGender = $('#genderList');
    let photoFile =  $('#photoFile');


    //region Выпатающие списки: предмет + оценка
    let subjectLists = $('select[id*=subject]','#formAddChange');
    let markLists = $('select[id*=mark]','#formAddChange');
    //endregion

    //region Обработчики на форме
    //Обработчик изменения данных в поле
    function onChangeHandler(e,predicate,ifWrongMessage) {
        //Получаем поле ввода
        let field = e.target;
        let value = field.value;


        //Находим подсказку справа
        let label = field.parentElement.getElementsByTagName('label')[0];

        field.classList.remove('inValid-field');
        label.textContent = `Введите ${field.getAttribute('data-field-name')}`


        if (!predicate(value) && value.length>0) {
            label.textContent = `${ifWrongMessage}`
            field.classList.add('inValid-field');
        }
    }

    //region Обработчик кнопок добавления или изменения
    function okClickHandler(bottomLbl,inputFields) {

        //Сообщение снизу
        bottomLbl.css('visibility','visible');

        //Невалидна ли форма
        let inValid = false;

        //Находим поля ввода с некорректными значениями
        for (let field of inputFields) {

            let classContains = field.classList.contains('inValid-field');
            let fieldEmpty = field.value.length === 0;

            //Если в поле задан стиль сигнализирующий о некорректном значени или данные отсутвуют
            //Или если нет класса, но поле пустое
            inValid = classContains || !classContains && fieldEmpty || inValid;

        }//for

        //Если есть невалидные поля в форме
        if(inValid) {
            bottomLbl.textContent = '*В введённых данных есть ошибки или пустые поля!';
            return;
        }

        //Если меняем объект
        let changing = btnAddChange.val().toLowerCase().includes('изменить');

        //region Создание объекта
        //Создать объект студента
        let student = new Student(
            changing ? parseInt(form.getAttribute('data-selected-student-id')):
                students.length>0 ? Math.max(...students.map(s => s.studentId))+1:1,//id - если меняем объект, тогда задаём сущетсвующий id
            groupName.val(),
            studentGender.val(),
            getMarks()
        );

        //Автогенерируемые поля изменяем отдельно, поскольку в консруткоре происходит их генерация
        student.studentSNP = studentSnp.val();
        student.photoFile = photoFile.val();
        //endregion

        //Взависимости от действия поразному работаем с коллекцией
        if (changing)
            changingWorker(student);
        else
            addingWorker(student);

        loadPhotoFile(studentGender);
        //Запись в локальное хранилище
        studentsCollection.writeToLocal();

    }

    //Получение оценок и предметов из выпадающих списков
    function getMarks() {
        let marks = [];


        for (let i = 0; i < subjectLists.length && i < markLists.length; i++) {
            marks.push(new Mark(subjectLists[i].value,+markLists[i].value))
        }
        return marks;
    }
    //Запись оценок и предметов в выпадающие списки
    function setMarks(student) {

        for (let i = 0; i < subjectLists.length && i < markLists.length; i++) {
            subjectLists[i].value = student.performance[i].subject;
            markLists[i].value = student.performance[i].grade;
        }

    }

    function changingWorker(student) {
        //Мнеяем запись по индексу
        students[student.studentId-1] = student;
        //Вывод по умолчанию
        showDefaultArr();

        //Выделение реализовать на следующей итерации
        /*bottomLbl.text(`Студент изменён . Карточка выделена синим.`);*/

        title.html(`<span>Студент с id: ${student.studentId} изменён</span>`);
        btnReset.trigger('click');
    }
    function addingWorker(worker) {
        //Добавление в массивы. Либо редактирование
        students.push(worker)

        let temp = [...students];
        //Выводим массив реверсированно, чтобы сначала были добавленные элементы
        mainBlock.html(StudentsCollection.createMarkup(temp.reverse()));

        //Добавляем обработчик для возможности удаления
        addOnCardBtnHandlers();

        bottomLbl.text('Студент успешно добавлен.');
        title.html(`<span>Добавленные элементы впереди</span>`);
    }
    //endregion

    //Обработчик сброса формы
    function resetFormHandler(bottomLbl,inputFields) {

        //Убираем запись снизу
        bottomLbl.textContent = '';
        bottomLbl.css('visibility','hidden');
        btnAddChange.val(btnAddChange.val().toLowerCase().includes('изменить')?'Добавить':btnAddChange.val());

        //Находим текстовые поля ввода с некорректными значениями
        for (let field of inputFields) {
            if (field.classList.contains('inValid-field')) {
                field.classList.remove('inValid-field');

                //Меняем значение в подсказаках на начальное
                field.parentElement.getElementsByTagName('label')[0].textContent = `Введите ${field.getAttribute('data-field-name')}`;
            }//if

            if (!field.id.toLowerCase().includes('photo'))
                field.value = '';
        }//for

        //Убираем атрибут id студента на форме если он задан
        if (form.getAttribute('data-selected-student-id'))
            form.removeAttribute('data-selected-student-id')

        //Меняем имя файла для добавления
        loadPhotoFile(studentGender);

    }//resetFormHandler

    //Заполнение
    function loadDropDown() {


        [...new Set(students.map(s =>s.groupName))].forEach(group => groupName.append(`<option>${group}</option>`));


        let subjectsCollection = getSubjects();


        //Добавление всех вовзможных предметов и оценок в списки
        for (let i = 0; i < subjectLists.length && i < markLists.length; i++) {

            /*subjectsCollection.forEach(s => subjectLists[i].append('<option>${s}</option>'));*/

            /*subjectsCollection.forEach(s => subjectLists[i].append($('<option>',{value: s}).text(s)));*/

            let markUp = subjectsCollection.reduce((acc,s) => acc += `<option>${s}</option>`,'');
            subjectLists[i].innerHTML = markUp;

            markUp = '';

            for (let j = 1; j <= 5; j++)
                markUp += `<option>${j}</option>`;

            markLists[i].innerHTML = markUp;
        }

    }

    //Заполнение поля имени файла
    function loadPhotoFile(fieldList) {
        let value = fieldList.val();

        //В зависимости от режима работы формы меняем id
        let id = btnAddChange.val().toLowerCase().includes('изменить')?
            parseInt(form.getAttribute('data-selected-student-id')):
            students.length>0 ? Math.max(...students.map(s => s.studentId))+1:1;

        photoFile.val( value.toLowerCase().includes('муж')?`man_0${id<10?(`0${id}`):(`${id}`)}.jpg`:`woman_0${id<10?(`0${id}`):(`${id}`)}.jpg`);

    }

    //Задание обработчиков на элементы формы
    (function addHandlers() {

        //Загрузка выпадающего списка должностей
        loadDropDown();

        loadPhotoFile(studentGender);

        //region Текстовые поля

        // Условие предиката: мин 5 символов + отсутвие цифр + заглвная буква в начале
        studentSnp.change((e) =>
                onChangeHandler(e,
                    (value) => value.length >= 5 && !/[0-9]/g.test(value) && /^[A-ZА-Я]/.test(value)
                    , 'ФИО должно содержать >= 5 символов. Обязательно заглавная бува в начале'
                )
        );

        //Обработчики на изменение данных в поле имени файла.
        photoFile.change((e) =>
            onChangeHandler(e,
                (value) => /(\w+)_([0-9]+)\.(jpg|png|jpeg)/.test(value),
                'Имя файла должно быть вида: \'men_001.(jpg|png|jpeg)\'')
        );



        //endregion

        //При изименении пола в выпадающем списке меняем имя файла
        studentGender.change(() => loadPhotoFile(studentGender))

        //Добавить работника
        btnAddChange.click(() => okClickHandler(bottomLbl,fields));

        //Отменить
        btnReset.click(() => resetFormHandler(bottomLbl,fields));

        //Если поле пустое. Костыль, но без него не появляется запись с имненм файла файла
        btnReset.mousemove(() => {
            if (photoFile.val() === '')
                loadPhotoFile(studentGender);
        });

    })();
    //endregion

    //Изменение вида формы для редактирования
    function changeFormToEditing(selectedStudent) {
        btnAddChange.val('Изменить');

        //region Запись свойств объекта в поля формы
        studentSnp.val(selectedStudent.studentSNP);

        //Переписываем список для корректного задания selected для нужного элемента
        loadDropDown();

        //Настроить список оценок
        setMarks(selectedStudent);

        studentGender.val(selectedStudent.gender);

        groupName.val(selectedStudent.groupName);

        //Файл с фотографией
        photoFile.val(selectedStudent.photoFile);

        //endregion

        //Передаём id работника в атрибут формы
        form.setAttribute('data-selected-student-id',selectedStudent.studentId);

        $('#detailsForm').attr('open','');

        //Перевод фокуса на форму
        studentSnp.focus();

    }

    //endregion

});

