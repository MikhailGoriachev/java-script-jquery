
//Получение случайного значения
function getRandom(lo,hi) {
    return Math.trunc((hi-lo) * Math.random() + lo);
}

//region Фильмы

function generateMovieName() {
    let names = [
        'Люди в черном',
        'Гладиатор',
        'Форрест гамп',
        'Побег из Шоушенка',
        'Аватар',
        '1+1',
        'Интерстеллар',
    ];
    return names[getRandom(0,names.length)]
}
function generateMovieGenre() {
    let genres = [
        'Документальный',
        'Художественный',
        'Биографичесий',
        'Фантастика',
    ];
    return genres[getRandom(0,genres.length)]
}

//Функция возвращает объект
function generatePerson() {

    //Список персон
    let people = [
        'Мартин Скорсезе',
        'Вуди Аллен',
        'Джеймс Кэмерон',
        'Ридли Скотт',
        'Тим Бёртон',
        'Дэвид Финчер',
        'Фрэнк Дарабонт',];

    return people[getRandom(0,people.length)];
}//generatePerson


//endregion


function generateSNP(gender) {

    //Список мужских фамилий
    let men = [
        'Михалков А.В.',
        'Пелых М.У.',
        'Пономаренко Л.А.',
        'Хавалджи В.Д.',
        'Пархоменко И.В.',
        'Чмыхало О.Т.',    ];

    //Список женских фамилий
    let women = [
        'Лосева И.С.',
        'Пелых А.С.',
        'Пономаренко Л.А.',
        'Хавалджи В.Д.',
        'Пархоменко И.В.',
        'Демидова А.А.',
        'Лапотникова О.Т.',
        'Чмыхало О.Т.',];

    if (gender.toLowerCase().includes('муж'))
        return men[getRandom(0,men.length)]

    return women[getRandom(0,women.length)];
}//generatePerson

//region Студенты

function generateGroup() {

    //Список приставок
    let prefix = [
        'АМ',
        'ВМИ',
        'АП',
        'ФТ',
    ];

    let groupNum = getRandom(1,99);
    let truncNum = groupNum>10?Math.trunc(groupNum/10)*10:groupNum;

    return `${prefix[getRandom(0,prefix.length)]}${truncNum%10===0?`0${groupNum}`:`00${groupNum}`}`;
}//generatePerson

function getSubjects() {
    return  [
        'Entity framework',
        'C# .net',
        'Алгоритмы',
        'Основы C++',
        'Основы WPF',
        'Основы ASP.NET',
        'SQL Server',
        'Теория БД',
    ];
}

//Оценки
function generateMarks() {
    let collection = getSubjects();
    let subjects = new Set();

    while (subjects.size < 5) {
        subjects.add(collection[getRandom(0,collection.length)]);
    }

    let marks = [...subjects].map(s => new Mark(s,getRandom(2,6)));
    return marks;
}

//Должности
function getGender() {
    let gender = [
        "Мужской",
        "Женский",,
    ];

    return gender[getRandom(0,gender.length-1)];
}


//endregion


function getNumFromStr(str) {

    if (/\D+/.test(str))
        str = str.replace(/\D+/,'');

    if (!isNaN(parseInt(str)))
        return parseInt(str);

    //Если ничего не найдено
    return 1e-10
}

