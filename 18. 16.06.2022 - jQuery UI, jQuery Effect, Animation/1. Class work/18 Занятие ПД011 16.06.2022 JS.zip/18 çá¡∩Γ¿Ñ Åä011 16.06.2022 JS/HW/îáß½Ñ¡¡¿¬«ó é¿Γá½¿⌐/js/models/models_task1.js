/*
Описать класс Student, содержащий поля:
•	фамилия и инициалы;
•	пол студента;
•	фотография студента (заранее подготовленные файлы, с именами man001, woman001 и т.д. Имя файла генерируется в зависимости от пола студента);
•	название группы;
•	успеваемость (массив из пяти элементов типа Mark)
•	Mark – класс: название предмета, оценка
*/

class Mark {
    constructor(subject= "", grade = 0) {
        this.subject = subject;
        this.grade = grade;
    }
    assign(m) {
        Object.assign(this, m);
        return this;
    }
}

class Student {
    constructor(id, fullName = "", gender = "", photo = "", group = "", marks = []) {
        this.id = id;
        this.fullName = fullName;
        this.gender = gender;
        this.photo = photo;
        this.group = group;
        this.marks = marks;
    }

    get avgGrade() {
        return this.marks.map(m => m.grade).reduce((acc, cur) => acc + cur, 0) / this.marks.length;
    }

    toTableRow(row) {
        let marksList =
            this.marks.reduce((acc, m) =>
                acc += `<li>${m.subject}: <div class="grade">${m.grade}</div></li>`, "<ul>") + "</ul>";

        return `<li class="t-li table-row" id="st${this.id}">
                    <div class="col-1">${row}</div>
                    <div class="col-2">
                        <img class="photo" src="../images/photos/${this.photo}" alt="${this.photo}">
                    </div>
                    <div class="col-3">${this.fullName}</div>
                    <div class="col-4">${this.gender.slice(0,3)}.</div>
                    <div class="col-5"><span class="st-group">${this.group}</span></div>
                    <div class="col-6 st-marks">${marksList}</div>
                    <div class="col-7">
                        <button data-edt="${this.id}" title="Редактирование данных студента">
                            <i data-edt="${this.id}" class="fa fa-edit fa-2x"></i>
                        </button>
                        <button data-del="${this.id}" title="Удаление данных студента">
                            <i data-del="${this.id}" class="fa fa-recycle fa-2x"></i>
                        </button>
                    </div>
                </li>`
    }

    assign(s) {
        Object.assign(this, s);
        this.marks = this.marks.map(m => new Mark().assign(m));
        return this;
    }
}

class Academy {
    constructor(title = "Компьютерная академия", students = []) {
        this.title = title;
        this.students = students;
    }

    // получить студента по id
    getById(id) {
        return this.students.filter(s => +s.id === +id)[0];
    }

    // добавить студента
    addStudent(fullName, gender, group, marks) {
        let id = this.students.length ? Math.max(...this.students.map(s => s.id)) + 1 : 1;
        let photoImg = gender === "Мужской" ? StudentFactory.randomMaleImg() : StudentFactory.randomFemaleImg();
        let student = new Student(id, fullName, gender, photoImg, group, marks);
        this.students.push(student);
        //this.saveToLocalStorage();
        return student;
    }

    // изменить данные студента
    updateStudent(id, fullName, gender, group, marks) {
        let index = this.students.findIndex(s => +s.id === +id);
        this.students[index].fullName = fullName;
        this.students[index].gender = gender;
        this.students[index].group = group;
        this.students[index].marks = marks;

        //this.saveToLocalStorage();
    }

    // удалить студента по id
    deleteStudent(id){
        let index = this.students.findIndex(s => +s.id === +id);
        if(index > -1)
            this.students.splice(index, 1);

        //this.saveToLocalStorage();
    }

    // Список групп студентов
    getGroupsList() {
        return this.students.map(s => s.group)
            .filter((value, ind, self) => ind === self.indexOf(value)).sort();
    }

    // копия, упорядоченная по фамилии
    orderBySurname() {
        return [...this.students].sort((a,b) => a.fullName.localeCompare(b.fullName));
    }

    // копия, упорядоченная по возрастанию среднего бала
    orderByAvgGrade() {
        return [...this.students].sort((a,b) => a.avgGrade - b.avgGrade);
    }

    // копия, упорядоченная по названию группы
    orderByGroup() {
        return [...this.students].sort((a,b) => a.group.localeCompare(b.group));
    }


    show(header) {
        $("#title").text(header);
        $("#students").html(this.students.reduce((acc, s, i) => acc + s.toTableRow(i + 1), Academy.header));
    }

    static show(header, students) {
        $("#title").text(header);
        $("#students").html(students.reduce((acc, s, i) => acc + s.toTableRow(i + 1), Academy.header));
    }

    static header = `<li class="t-li table-header">
                    <div class="col-1">№</div>
                    <div class="col-2">Фото</div>
                    <div class="col-3">Фамилия И.О.</div>
                    <div class="col-4">Пол</div>
                    <div class="col-5">Группа</div>
                    <div class="col-6">Оценки</div>
                    <div class="col-7">Управление</div>
                </li>`;

    store() {
        window.localStorage.academy = JSON.stringify(this);
    }

    load() {
        let parsed = JSON.parse(window.localStorage.academy);

        this.title = parsed.title;
        this.students =  parsed.students.map(s => new Student().assign(s));
    }
}


// Фабрика генерации студента
class StudentFactory {
    static generateCollection(amount) {
        return [...Array(amount)].map((w,i) => this.generateStudent(i + 1));
    }

    static generateStudent(id) {
        return [this.generateMale, this.generateFemale].random()(id);
    }

    static generateMale(id) {
        return new Student(id, StudentFactory.randomMaleName(), "мужской", StudentFactory.randomMaleImg(),
            StudentFactory.randomGroup(),  StudentFactory.randomMarks(5) );
    }

    static generateFemale(id) {
        return new Student(id, StudentFactory.randomFemaleName(), "женский", StudentFactory.randomFemaleImg(),
            StudentFactory.randomGroup(),  StudentFactory.randomMarks(5) );
    }

    static randomMaleImg() { return `man_${getRandomInt(1,20)}.jpg`; }
    static randomFemaleImg() { return `woman_${getRandomInt(1,20)}.jpg`; }

    static randomMaleName() {
        return [ "Рябинин А.А.", "Николаев Ф.А.", "Федоров М.М.", "Семенов М.Д.", "Федоров Д.М.",
            "Кузнецов Г.Д.", "Коновалов И.Ф.", "Титов В.М.", "Андреев А.И.", "Никитин Л.Г.",
            "Чесноков Д.Т.", "Комаров Д.А.", "Антонов В.И.", "Баранов М.А.", "Новиков А.Р.",
            "Сорокин Д.Д.", "Никольский Д.Г.", "Дорофеев А.М.", "Булгаков М.Р.", "Васильев А.М.",
            "Осипов А.Б.", "Руднев А.Л.", "Соколов З.Ф.", "Ершов Б.С.", "Макаров А.А.",
            "Киселев М.А.", "Гаврилов И.Д.", "Белов П.И.", "Моисеев А.Г.", "Яковлев Д.А."].random();
    }

    static randomFemaleName() {
        return [ "Осипова В.Д.", "Крылова А.А.", "Глухова М.О.", "Филатова С.А.", "Яковлева Е.П.",
            "Михайлова В.К.", "Ерофеева С.С.", "Жданова Е.Т.", "Демина Е.И.", "Панова М.С.",
            "Тарасова Е.И.", "Коровина В.М.", "Сазонова М.Д.", "Иванова К.М.", "Королева Е.М.",
            "Пирогова С.М.", "Тимофеева В.М.", "Козырева М.С.", "Волкова В.Т.", "Коновалова К.А.",
            "Беликова В.В.", "Романова С.А.", "Суркова К.К.", "Мещерякова В.М.", "Васильева А.З.",
            "Ситникова Д.Н.", "Васильева А.М.", "Васильева С.Е.", "Булгакова А.Я.", "Ушакова К.Д."].random();
    }

    static groups = [ "СУ 1-35", "ППС 31-01", "ИСВ 33-03", "ПСД 2-23", "ИСД 3-17", "ЕКО 18П-86" ];
    static randomGroup() {
        return StudentFactory.groups.random();
    }

    static subjects = [ "IT Essential",  "C Starter", "ООП C++", "C# Essential", "Design UML", "Паттерны",
        "Теория БД", "Windows 10", "Illustrator", "Photoshop", "3D Max", "Maya 3D",
        "HTML/CSS", "JavaScript", "PHP", "ADO.NET", "ASP.NET" ];
    static randomSubject() {
        return StudentFactory.subjects.random();
    }

    static randomMarks(amount) {
        let subjects = new Set();
        while(subjects.size !== amount) {
            subjects.add(StudentFactory.randomSubject());
        }
        return [...subjects].map(m => new Mark(m, getRandomInt(2, 5)))
            .sort((a, b) => a.subject.localeCompare(b.subject));
    }
}
