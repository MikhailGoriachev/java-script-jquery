
// фильм описывается названием, фамилией и инициалами режиссера, жанром, годом выпуска
class Movie {
    constructor(id = 0, title = "", director = "", genre = "", year = 1900) {
        this.id = id;
        this.title = title;
        this.director = director;
        this.genre = genre;
        this.year = year;
    }

    toTableRow(row){
        return `<tr id="t${this.id}">
                    <td>${row}</td>
                    <td class="align-left m-title">${this.title}</td>
                    <td class="align-left m-dir">${this.director}</td>
                    <td class="align-left m-genre">${this.genre}</td>
                    <td class="m-year">${this.year}</td>
                </tr>`;
    }

    assign(o) {
        Object.assign(this, o);
        return this;
    }
}

class MovieLibrary {
    constructor(movies = []) {
        this.movies = movies;
    }

    getGenresList() {
        return this.movies.map(s => s.genre)
            .filter((v, i, s) => i === s.indexOf(v))
            .sort();
    }

    getDirectorsList() {
        return this.movies.map(s => s.director)
            .filter((v, i, s) => i === s.indexOf(v))
            .sort();
    }


    toTable(caption = 'Список фильмов'){
        let table = `<table class="table-tickets">
                        <caption>${caption}</caption>
                        <thead><tr>
                            <th>№ </th>
                            <th>Название</th>
                            <th>Режиссер</th>
                            <th>Жанр</th>
                            <th>Год выхода</th>
                        </tr></thead>`;
        this.movies.forEach((m, i) => table += m.toTableRow(i + 1));
        table += '</table>';
        return table;
    }

    store() {
        window.localStorage.movies = JSON.stringify(this.movies);
    }

    load() {
        this.movies = JSON.parse(window.localStorage.movies).map(m => new Movie().assign(m));
    }
}

