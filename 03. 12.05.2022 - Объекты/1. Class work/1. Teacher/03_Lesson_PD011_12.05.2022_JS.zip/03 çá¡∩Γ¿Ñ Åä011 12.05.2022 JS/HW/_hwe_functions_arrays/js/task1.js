/*
* функции для задач Proc36 и Recur9
* */
// Вычисление числа Фибоначчи по его номеру n
function fib(n) {
    return n <= 2?1:fib(n-1) + fib(n-2);
} // fib


// вычисление наибольшего общего делителя по алгоритму Евклида
// для двух чисел a, b
function nod(a, b) {
    return b === 0?a:nod(b, a % b);
} // nod


// код вычислений по решению задачи Proc36
function proc36() {
    // количество чисел Фибоначчи
    const n1 = 5;

    for (let i = 0; i < n1; i++) {
        // номер очередного числа Фибоначчи, вычисление
        // числа Фибоначчи с этим номером
        let nf = getIntRand(1, 40);
        let f = fib(nf);

        document.write(`<tr><td>${i+1}</td><td>${nf}</td><td>${f}</td></tr>`)
    } // for i
} // proc36


// код вычислений по решению задачи Recur9
function recur9() {
    // количество чисел для вычисления наибольшего общего делителя
    const n2 = 3, lo = 12, hi = 300;
    let a = getIntRand(lo, hi);

    for (let i = 0; i < n2; i++) {
        let x = getIntRand(lo, hi);
        let result = nod(a, x);

        document.write(`<tr><td>${i+1}</td><td>${a}</td><td>${x}</td><td>${result}</td></tr>`)
    } // for i
} // recur9