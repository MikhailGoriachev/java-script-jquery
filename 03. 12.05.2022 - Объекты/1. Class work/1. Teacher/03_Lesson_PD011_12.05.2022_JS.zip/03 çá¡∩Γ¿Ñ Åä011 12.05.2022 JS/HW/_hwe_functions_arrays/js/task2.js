/* функции для решения задачи 2 */
// Вычислить сумму элементов массива, расположенных между первым
// и последним положительными элементами
function doSumma(arr) {
    /*
    // вложенная функция, проверка элемента на положительность
    function isPositive(item) { return item >= 0; }

    // индекс первого положительного элемента
    let index1 = arr.indexOf(isPositive);
    if (index1 < 0) return undefined;

    // индекс последнего положительного элемента
    let index2 = arr.lastIndexOf(isPositive);
    if (index2 < 0) return undefined;

    // вырезать кусок массива между этими элементами
    // просуммировать элементы вырезанного куска массива
    return arr
        .slice(index1, arr.length - index2 + 1)
        .reduce(function(acc, item) { return acc + item}, 0);
     */

    // одним циклом ищем первый и последний положительные
    // элементы массива
    let firstPositive = -1;
    let lastPositive = -1;
    for (let i = 0; i < arr.length; i++) {
        if (firstPositive < 0 && arr[i] >= 0) {
            firstPositive = i;
            continue;
        } // if

        if (firstPositive >= 0 && arr[i] >= 0) {
            // кандидат на последний положительный
            lastPositive = i;
        } // if
    } // for i

    // недостаточное количество положительных элементов - возвращаем
    // undefined
    if (firstPositive < 0 || lastPositive < 0 || lastPositive - firstPositive === 1) return undefined;

    // если хватает положительных элементов - суммирование
    let sum = 0;
    for (let i = firstPositive+1; i < lastPositive; i++) {
        sum += arr[i];
    } // for i
    return sum;
} // doSumma

// Вычислить произведение элементов массива, расположенных между первым и вторым
// нулевыми элементами
function doProduct(arr) {
    // одним циклом ищем первый и второй нулевые
    // элементы массива
    let firstZero = -1;
    let secondZero = -1;
    for (let i = 0; i < arr.length; i++) {
        if (firstZero < 0 && arr[i] === 0) {
            firstZero = i;
            continue;
        } // if

        if (firstZero >= 0 && arr[i] === 0) {
            secondZero = i;
            break;
        } // if
    } // for i

    // недостаточное количество нулевых элементов - возвращаем
    // undefined
    if (firstZero < 0 || secondZero < 0 || secondZero - firstZero === 1) return undefined;

    // если хватает нулевых элементов - произведение
    let prod = 1;
    for (let i = firstZero+1; i < secondZero; i++) {
        prod *= arr[i];
    } // for i
    return prod;
} // doProduct

// сортировка массива по правилу: сначала все элементы,
// модуль которых не превышает единицу, а потом — все остальные
function orderByAbsLessOne(arr, bound = 1) {
    for (let i = 0; i < arr.length; i++) {
        for (let j = 0; j < arr.length - i - 1; j++) {
            if (Math.abs(arr[j]) > bound && Math.abs(arr[j+1]) <= bound) {
                // т.н. деструктирующее присваивание ES6+
                [arr[j], arr[j+1]] = [arr[j+1], arr[j]];
            } // if
        } // for j
    } // for i
} // orderByAbsLessOne


// сортировка массива по правилу: элементы, равные нулю, расположить
// после всех остальных
function orderByZeroLast(arr) {
    for (let i = 0; i < arr.length; i++) {
        for (let j = 0; j < arr.length - i - 1; j++) {
            if (arr[j] === 0 && arr[j+1] !== 0) {
                // т.н. деструктирующее присваивание
                [arr[j], arr[j+1]] = [arr[j+1], arr[j]];
            } // if
        } // for j
    } // for i
} // orderByAbsLessOne