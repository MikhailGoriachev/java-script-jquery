/*
* Функции для работы с массивами в задачах 2, 3 и 4
* */

// заполнение массива arr случайными числами
// в диапазоне значений от [lo, hi]
function fillArray(arr, lo = -10, hi = 10) {
    for (let i = 0; i < arr.length; ++i) {
        let temp = getRand(lo, hi);
        if (Math.abs(temp) < 0.6) temp = 0;
        arr[i] = temp;
    } // for i
} // fillArray


// заполнение массива arr случайными целыми числами
// в диапазоне значений от [lo, hi]
function fillIntArray(arr, lo = -10, hi = 10) {
    for (let i = 0; i < arr.length; ++i) {
        arr[i] = getIntRand(lo, hi);
    } // for i
} // fillIntArray


// вывод массива вещественных чисел в строку таблицы
// с заданной точностью (что исключает использование join())
function toTableRow(arr, prec= 0) {
    let row = '';
    for (const datum of arr) {
        row += `<td>${datum.toFixed(prec)}</td>`
    } // for datum

    return '<tr>' + row + '</tr>';
} // toTableRow


// вывод очереди для задачи 4
function showQueue(data, title, width) {
    // в первую ячейку строки выводим название очереди
    document.write(`<table class='${width}'><tbody><tr><th>${title}</th>`);

    // в оставшиеся ячейки выводим элементы массива/очереди
    for (let i = 0; i < data.length; i++) {
        document.write(`<td>${data[i]}</td>`)
    } // for i
    document.write(`</tr></tbody></table>`);
} // showQueue