// возвращает количество элементов со значением value в массиве arr
function totalValueArray(arr, value) {
    let counter = 0;

    for (const item of arr) {
        if (item === value) ++counter;
    } // for item

    return counter;
} // totalValueArray


// удалить из массива arr все элементы со значением value
function deleteValue(arr, value) {
    for (let i = arr.length-1; i >= 0 ; i--) {
        if (arr[i] === value) {
            arr.splice(i, 1);
        } // if
    }  // for i
} // deleteValue


// Удалить из массива arr все элементы, встречающиеся более numbers раз
function deleteValueDupNumbers(arr, numbers) {
    let n = arr.length;
    for (let i = 0; i < n; i++) {
        let value = arr[i];
        let counter = totalValueArray(arr, value);
        if (counter > numbers) {
            deleteValue(arr, value);
            n = arr.length;
        } // if
    } // for i
} // deleteValueDupNumbers


// Перед каждым положительным элементом массива вставить элемент с нулевым
// значением
function insertValueBeforeEveryPositive(arr, value) {
    for (let i = arr.length-1; i >= 0; --i) {
        if (arr[i] >= 0) {
            arr.splice(i, 0, value);
        } // if
    } // for i
} // insertValueBeforeEveryPositive


function task3() {
    const prec = 0;

    // создать массив заданного размера
    let arr = new Array(getIntRand(8, 13));
    fillIntArray(arr);

    // вывод массива, суммы и произведения
    document.write(
        `<h2>Массив для обработки, элементов: ${arr.length}</h2>
                <table class="width-800">${toTableRow(arr, prec)}</table>
            `);

    // Перед каждым положительным элементом массива вставить элемент с нулевым
    // значением
    let value = 0;
    insertValueBeforeEveryPositive(arr, value);
    document.write(
        `<h2>Перед каждым положительным элементом вставлен ${value},
                 теперь элементов: ${arr.length}</h2>
                <table class="width-800">${toTableRow(arr, prec)}</table>
            `);

    // Удалить из массива все элементы, встречающиеся более двух раз, и вывести
    // размер полученного массива и его содержимое
    let numbers = 2;
    deleteValueDupNumbers(arr, numbers);
    document.write(
        `<h2>Удалить из массива все элементы, встречающиеся более, чем ${numbers} раз(а),
                     осталось элементов: ${arr.length}</h2>
                <table class="width-800">${toTableRow(arr, prec)}</table>
            `);
}