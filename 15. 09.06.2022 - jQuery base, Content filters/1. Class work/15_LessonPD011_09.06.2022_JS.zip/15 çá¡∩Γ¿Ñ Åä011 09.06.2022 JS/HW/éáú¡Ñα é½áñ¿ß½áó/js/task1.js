//Обработчик изменения данных в поле
function onChangeHandler(e,label,predicate,predicateCondition,) {
    let value = e.target.value;
    let field = e.target;

    field.classList.remove('inValid-field');
    label.textContent = `${label.getAttribute('data-param-name')}`

    if (!predicate(value) && value.length > 0)
    {
        field.classList.add('inValid-field');
        label.textContent = predicateCondition;
    }

}

//Обработчик кнопок ОК
function okClickHandler(e,form,messageLbl,context,canvas) {

    let formInputs = form.getElementsByTagName('input');

    let isInvalid = false;

    for (let input of formInputs) {
        isInvalid = input.classList.contains('inValid-field') || input.value.length === 0 || isInvalid;
    }

    messageLbl.style.display = 'inline-block';
    //Если в поле задан стиль сигнализирующий о некорректном значении
    if (isInvalid){
        messageLbl.textContent = '*В заданных значениях есть ошибка'
        e.preventDefault();
        return;
    }
    messageLbl.style.display = 'none';

    console.log('Обработка продолжается')

    if (form.name.toLowerCase().includes('rect')) {

        let width = parseInt($('rectWidth').value);
        let height =  parseInt($('rectHeight').value);
        let color = $('rectColor').value;

        drawRect(context, canvas, width,height, color);

        writeFieldsToLocal(form)
    }
    else if (form.name.toLowerCase().includes('triangle')) {

        let width = parseInt($('triangleWidth').value);
        let height =  parseInt($('triangleHeight').value);
        let color = $('triangleColor').value;

        drawTriangle(context, canvas, width,height, color);

        writeFieldsToLocal(form)
    }
    else if (form.name.toLowerCase().includes('circle')) {

        let radius = parseInt($('circleRadius').value);
        let color = $('circleColor').value;

        drawCircle(context, canvas, radius,color);

        writeFieldsToLocal(form)
    }
}

//Обработчик сброса формы
function resetFormHandler(outPutZ1,outPutZ2,bottomLbl,prompt,inputField) {

    //Убираем записи
    outPutZ1.textContent = '';
    outPutZ2.textContent = '';
    bottomLbl.textContent = '';

    //Если в поле задан стиль сигнализирующий о некорректном значении
    if (inputField.classList.contains('inValid-field')) {
        inputField.classList.remove('inValid-field');
        prompt.textContent = `Введите значение переменной ${inputField.getAttribute('data-var-name')}`;
    }
}

//Отрисовать фигуры
function drawRect(rectContext,rectCanvas,width,height,color,borderColor) {

    let startPosX = (rectCanvas.width-width)/2;
    let startPosY = (rectCanvas.height-height)/2;


    rectContext.fillStyle = color;
    rectContext.strokeStyle = borderColor
    rectContext.strokeWidth = 5;
    rectContext.fillRect(startPosX,startPosY,width,height);
    rectContext.restore();
}
function drawTriangle(triangleContext,triangleCanvas,width,height,color,borderColor) {

    let startPosX = triangleCanvas.width/2/*(triangleCanvas.width-width)/2  */;
    let startPosY = (triangleCanvas.height-height)/2;

    triangleContext.beginPath();
    triangleContext.fillStyle = color;
    triangleContext.moveTo(startPosX,startPosY);
    triangleContext.lineTo(startPosX-width,startPosY+height);
    triangleContext.lineTo(startPosX+width,startPosY+height);
    triangleContext.lineTo(startPosX,startPosY);

    triangleContext.fill();
    triangleContext.restore();

}
//circle
function drawCircle(circleContext,circleCanvas,radius,color,startAngle = 0,endAngle = Math.PI*2) {

    let startPosX =  (circleCanvas.width/*-radius*/)/2 ;
    let startPosY = (circleCanvas.height/*-radius*/)/2;


    circleContext.beginPath();
    circleContext.fillStyle = color;

    circleContext.arc(startPosX,startPosY,radius,startAngle,endAngle,true)

    circleContext.fill();
    circleContext.restore();
}

//Функция с самовызовом
(function (){


    let loadHandler = function () {

        //region Canvas
        let rectCanvas = $('rectangle');
        let rectContext = rectCanvas.getContext('2d');
        let triangleCanvas = $('triangle');
        let triangleContext = triangleCanvas.getContext('2d');
        let circleCanvas = $('circle');
        let circleContext = circleCanvas.getContext('2d');
        //endregion

        drawRect(rectContext,rectCanvas,250,200,'gray','black');
        drawTriangle(triangleContext,triangleCanvas,150,170,'gray');
        drawCircle(circleContext,circleCanvas,50,0,);


        //region Форма 1

        let formRect = document.formRect;
        let rectWidth = $('rectWidth');
        let rectHeight = $('rectHeight');
        let rectColor = $('rectColor');
        let rectBorders = $('rectLine');
        let btnSubmitRect= $('btnOkRect');

        //Если есть предыдущие днанные в локальном хранилище
        fillFromLocalStore(formRect);

        //Событие изменения данных в поле ввода
        rectWidth.addEventListener('change',(e) =>
            onChangeHandler(e,$('labelRectWidth'),(value) => parseInt(value)>=100 && !/\D+/.test(value),'Значение должно быть >= 100. Только числа'));
        rectHeight.addEventListener('change',(e) =>
            onChangeHandler(e,$('labelRectHeight'),(value) => parseInt(value)>=80 && !/\D+/.test(value),'Значение должно быть >= 80. Только числа'));

        //Клик на кнопку формы 1
        btnSubmitRect.addEventListener('click',(e) =>
            okClickHandler(e,formRect,$('messageLblRect'),rectContext,rectCanvas));

        //При нажатии отмены исчезают все связанные с предыдущим вычислением записи
        formRect.addEventListener('reset',() => resetFormHandler());

        //endregion

        //region Форма 2


        let formTriangle = document.formTriangle;
        let triangleWidth =  $('triangleWidth');
        let triangleHeight = $('triangleHeight');
        let triangleColor =  $('triangleColor');
        let btnSubmitTriangle= $('btnOkTriangle');

        //Если есть предыдущие днанные в локальном хранилище
        fillFromLocalStore(formTriangle);

        //Событие изменения данных в поле ввода
        triangleWidth.addEventListener('change',(e) =>
            onChangeHandler(e,$('labelTriangleWidth'),(value) => parseInt(value)>=100 && !/\D+/.test(value),'Значение должно быть >= 100. Только числа'));

        triangleHeight.addEventListener('change',(e) =>
            onChangeHandler(e,$('labelTriangleHeight'),(value) => parseInt(value)>50 && !/\D+/.test(value),
                'Высота должна быть > 50. Только числа')
        );

        //Клик на кнопку формы 1
        btnSubmitTriangle.addEventListener('click',(e) =>
            okClickHandler(e,formTriangle,$('messageLblTr'),triangleContext,triangleCanvas));

        //При нажатии отмены исчезают все связанные с предыдущим вычислением записи
        formTriangle.addEventListener('reset',() => resetFormHandler());

        //endregion

        //region Форма 3


        let formCircle = document.formCircle;
        let circleRadius =  $('circleRadius');
        let circleColor =  $('circleColor');
        let btnSubmitCircle= $('btnOkCircle');

        //Если есть предыдущие днанные в локальном хранилище
        fillFromLocalStore(formCircle);

        //Событие изменения данных в поле ввода
        circleRadius.addEventListener('change',(e) =>
            onChangeHandler(e,$('labelCircleRadius'),(value) => parseInt(value)>=50 && !/\D+/.test(value),'Значение должно быть >= 50. Только числа'));


        //Клик на кнопку формы 3
        btnSubmitCircle.addEventListener('click',(e) =>
            okClickHandler(e,formCircle,$('messageLblCircle'),circleContext,circleCanvas));

        //При нажатии отмены исчезают все связанные с предыдущим вычислением записи
        formCircle.addEventListener('reset',() => resetFormHandler());

        //endregion

    }//loadHandler
    window.addEventListener('load',loadHandler,false)
})();

