//Заявка
class Ticket {
    //Свойства
    constructor(id,destination, flightNum, passenger, ticketPrice) {
        this.destination = destination;
        this.flightNum = flightNum;
        this.passenger = passenger;
        this.ticketPrice = ticketPrice;
        this.ticketId = id;
    }


    //region Геттеры и сеттеры

    //region Пункт назаняения
    get destination() {
        return this._destination;
    }

    set destination(value) {
        this._destination = value;
    }
    //endregion

    //region Номер рейса
    get flightNum() {
        return this._number;
    }

    set flightNum(value) {

        this._number = value;
    }
    //endregion

    //region Фамилия и инициалы пассажира
    get passenger() {
        return this._passenger;
    }

    set passenger(value) {
        this._passenger = value;
    }
    //endregion

    //region Стоимость билета
    get ticketPrice() {
        return this._price;
    }

    set ticketPrice(value) {
        this._price = value<0?getRandom(2500,30000):value;
    }
    //endregion

    //endregion

    //Вывод
    toTableRow () {
        return `<div id="d_${this.ticketId}">
                    <table>
                        <tr><td><span>Пункт назначения: <b>${this._destination}</b></span></td></tr>
                        <tr><td><span>Номер рейса: <b>${this._number}</b></span></td></tr>
                        <tr><td><span>Пассажир: <b>${this._passenger}</b></span></td></tr>
                        <tr><td><span>Стоимость билета: <b>${this._price}</b></span></td></tr>
                    </table>
                </div>`
    }

    //Выделение элемента
    highlightElement(cardId,predicate){
        if (!predicate(this))
            return;

        $(`d_${cardId}`).getElementsByTagName("table")[0].className = "highlightClaim";
        setTimeout(() => this.resetStyle(cardId),10_000);
    }

    //Сброс выделения элемента
    resetStyle(cardId){
        $(`d_${cardId}`).getElementsByTagName("table")[0].classList.remove("highlightClaim");
    }

}

//Управление заявками
class TicketsView{
    constructor(ticketsArr) {
        this.tickets = ticketsArr;
    }

    //Генерация массива заявок
    static generateTickets() {
        let array = [];

        for (let i = 0; i < 10; i++) {
            array[i] = new Ticket(i+1,generateDestination(),generateFlightNumber(),generatePerson(),generatePrice())
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(claimsArr) {
        let n = 0;
        let str = claimsArr.reduce((acc,claim) => acc+claim.toTableRow(n++),'');

        return str;
    }

    //Запись в localStore
    writeToLocal(){
        window.localStorage.ticketsView = JSON.stringify(this);
    }

    getFromLocal(){
        this.tickets = []
        let view = JSON.parse(window.localStorage.ticketsView);

        for (let elem of view.tickets) {
            let ticket = new Ticket('','',0,'',0);
            Object.assign(ticket,elem);
            this.tickets.push(ticket);
        }
    }
}


//region Сортировки, обработчики

//Упорядочить представление по пунктам назначения
function orderDescByDestination(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c1.destination.localeCompare(c2.destination));
    blockObject.innerHTML = TicketsView.createMarkup(copy)
    titleObject.innerHTML = `<span>Сортировка массива по пунктам назначения</span>`;
    return copy;
}//orderDescByTemperature

//Упорядочить представление по стоимости билета
function orderByPrice(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c2.ticketPrice-c1.ticketPrice);
    blockObject.innerHTML = TicketsView.createMarkup(copy)
    titleObject.innerHTML = `<span>Сортировка массива по стоимости билета</span>`;

    return copy;
}//orderByPrice

//Упорядочить представление по стоимости билета
function orderByFlightNum(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c2.flightNum-c1.flightNum);
    blockObject.innerHTML = TicketsView.createMarkup(copy);
    titleObject.innerHTML = `<span>Сортировка массива по стоимости билета</span>`;

    return copy;
}//orderByFlightNum


//endregion


//Функция с самовызовом
(function (){

    //Массив заявок
    let ticketsList = [];

    let ticketView = new TicketsView([]);

    //region Чтение и запись в локальное хранилище
    if (window.localStorage.ticketsView) {
        ticketView.getFromLocal();
        ticketsList = ticketView.tickets;
    }
    else {
        ticketView.tickets = TicketsView.generateTickets();
        ticketView.writeToLocal();
        ticketsList = ticketView.tickets;
    }
    //endregion


    let mainBlock = $("mainDiv");

    mainBlock.innerHTML = TicketsView.createMarkup(ticketsList);



    //region Вставка заголовка
    let title = document.createElement("p");
    title.setAttribute("id", "taskTitle");
    title.setAttribute("class", "title-style");

    title.innerHTML = `<span>Исходный массив</span>`;
    mainBlock.parentNode.insertBefore(title, mainBlock);
    //endregion

    title = $('taskTitle');

    let loadHandler = function () {

        //Последняя сформированная коллекция
        let lastFormedCollection = ticketsList;

        //Обработчик кнопки вывода исходного массива
        let showDefaultArr = function () {

            mainBlock.innerHTML = TicketsView.createMarkup(ticketsList);
            title.innerHTML = `<span>Исходный массив</span>`;
            lastFormedCollection = ticketsList;
        }

        let showTickets = function (collection) {

            mainBlock.innerHTML = TicketsView.createMarkup(collection);
        }

        $("defaultArr").addEventListener("click",showDefaultArr,false);

        //Очистка локального хранилища
        $('cleanLocalStore').addEventListener('click',() => {
            window.localStorage.removeItem('ticketsView');
        })

        //region Сортировки

        //Обработчик кнопки сортировки по пункту на назначения
        $("orderByDest").addEventListener("click",() => lastFormedCollection = orderDescByDestination(mainBlock, title,ticketsList),false);

        //Обработчик кнопки сортировки по стоимости билета
        $("orderByPrice").addEventListener("click",() => lastFormedCollection = orderByPrice(mainBlock, title,ticketsList),false);

        //Обработчик кнопки сортировки по номеру рейса
        $("orderByFlightN").addEventListener("click",() => lastFormedCollection = orderByFlightNum(mainBlock, title,ticketsList),false);


        //endregion

        let inputField = $("inputPrice");
        let btnSearch = $("highlightCommand");
        let message = $("messageText");


        //Обект таймера
        let timer = 0;

        //region Поведение при покидании поля ввода
        //При выходе из поля ввода убираем записи и кнопку

        function focusMouseOutHandler(field) {
            let pattern = new RegExp('[0-9]+')
            let inputValue = field.value;

            //Если поле пустое или состоит из пробелов
            if (inputValue === "" || !pattern.test(inputValue)) {
                message.textContent = '';

                btnSearch.style.visibility = 'hidden';
                btnSearch.disabled = false;
            }

        }

        inputField.addEventListener("focusout",(e) => focusMouseOutHandler(e.target),false);
        inputField.addEventListener("mouseout",(e) => focusMouseOutHandler(e.target),false);

        //endregion

        //region Выделение элементов

        //Выделение элементов по редикату
        let highlightTickets = function (predicate,notFound = "значения не найдены") {

            //Получаем массив дочерних элементов общего блока
            let childNodes = getBlockChildren(mainBlock);

            //Проверка работы предиката
            let isData = 0;

            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {
                let data = getNumFromStr(childNode.getElementsByTagName("span")[3].getElementsByTagName("b")[0].innerHTML)

                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (predicate(data)) {
                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                    isData++;
                }
            }//for

            if (isData<=0)
                message.innerHTML = notFound;

            clearTimeout(timer);

            //После истечения таймера перепишем коллекцию
            timer = setTimeout(() => showTickets(lastFormedCollection),10_000)

        }//highlightTickets

        //Выделение одного элемента
        let highlightSingleTicket = function (ticket) {

            //Получаем массив дочерних элементов общего блока
            let childNodes = getBlockChildren(mainBlock);

            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {

                //region Получение полей
                let destination = childNode.getElementsByTagName("span")[0].getElementsByTagName("b")[0].innerHTML;
                let flightNum = getNumFromStr(childNode.getElementsByTagName("span")[1].getElementsByTagName("b")[0].innerHTML);
                let snp = childNode.getElementsByTagName("span")[2].getElementsByTagName("b")[0].innerHTML;
                let ticketPrice = getNumFromStr(childNode.getElementsByTagName("span")[3].getElementsByTagName("b")[0].innerHTML);
                //endregion

                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (ticket.destination === destination &&
                    ticket.flightNum === flightNum &&
                    ticket.passenger === snp &&
                    ticket.ticketPrice === ticketPrice) {

                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                }
            }//for


            //После истечения таймера перепишем коллекцию
            setTimeout(() => showTickets(lastFormedCollection),10_000)



        }//highlightTickets

        //Проверка ввода
        let keyDownHandler = function (e) {

            /*let regExpr = new RegExp('[а-яА-Яa-zA-Z ]');*/
            let regExpr = new RegExp('[0-9]');

            //Флаг enter и backspace
            let enterPressed = e.key.toLowerCase().includes("enter");
            let backSpacePressed = e.key.toLowerCase().includes("backspace");
            let tabPressed = e.key.toLowerCase().includes("tab");

            //Вклюсчаем кнопку
            btnSearch.style.visibility = 'visible';

            //Если есть хоть одна буква - блокировка ввода
            if (!regExpr.test(e.key) && !backSpacePressed && !tabPressed && !enterPressed) {
                message.innerHTML = "введите число"

                btnSearch.disabled = true;

                e.preventDefault();
                return false;
            }

            message.innerHTML = "";
            btnSearch.disabled = false;

        }

        //Обработчик клика на кнопку поиска и выделения элементов
        function highlightClickHandler() {

            let inputValue = inputField.value;

            //Получение введённого значения
            let number = parseInt(inputValue);

            //Переписать массив билетов, чтобы снять выделение
            showTickets(lastFormedCollection);

            highlightTickets((data) => data > number);
        }

        //Блокировка задания любых символов кроме цифр
        inputField.addEventListener("keydown",keyDownHandler,false);

        btnSearch.addEventListener('click',highlightClickHandler,false);

        //endregion

        //region Форма

        //Форма
        let form = document.addForm;
        let btnSubmit = $('btnAdd');
        let btnReset = $('resetBtn');

        let fieldset = $('fieldsetForm');
        let fieldsetWidth = fieldset.offsetWidth;

        //Кнопки изменения режимов работы формы
        let changeToAddingBtn= $('btnAddingMode');
        let changeToChangingBtn= $('btnChangingMode');
        let changeToDeletionBtn= $('btnDeletionMode');

        //Выпадающий список ID
        let idList = $('divIdList');
        let dropDownList = $('ticketsIdList');

        //Нижнний текст
        let bottomLbl = $('formPrompt');

        //Массив полей вода
        let fields = [];
        for (let i = 0; i < form.elements.length; i++) {
            let element = form.elements[i];
            if (element.type === 'text')
                fields.push(element)
        }


        //Поля
        let destinationField = $('destination');
        let flightNumField = $('flightNum');
        let passengerField = $('passengerSnp');
        let ticketPriceField = $('ticketPrice');



        //Обработчик изменения данных в поле
        function onChangeHandler(e,predicate,ifWrongMessage) {
            //Получаем поле ввода
            let field = e.target;
            let value = field.value;


            //Находим подсказку справа
            let label = field.parentElement.getElementsByTagName('label')[0];

            field.classList.remove('inValid-field');
            label.textContent = `Введите ${field.getAttribute('data-field-name')}`

            //Если ширина != стартовой
            if (fieldset.offsetWidth !== fieldsetWidth)
                fieldset.style.width = `${fieldsetWidth}px`;

            if (!predicate(value) && value.length>0) {
                label.textContent = `${ifWrongMessage}`
                field.classList.add('inValid-field');

                fieldset.style.width = `${fieldsetWidth + ifWrongMessage.length*3.85}px`;
            }
        }

        //region Добавление изменение и удаление

        //Обработчик кнопок ОК
        function okClickHandler(bottomLbl,inputFields) {

            //Сообщение снизу
            bottomLbl.style.visibility = 'visible';

            //Невалидна ли форма
            let inValid = false;

            //Находим поля ввода с некорректными значениями
            for (let field of inputFields) {

                let classContains = field.classList.contains('inValid-field');
                let fieldEmpty = field.value.length === 0;

                //Если в поле задан стиль сигнализирующий о некорректном значени или данные отсутвуют
                //Если нет класса, но поле пустое
                inValid = classContains || !classContains && fieldEmpty || inValid;


            }//for


            //Если есть невалидные поля в форме
            if(inValid) {
                bottomLbl.textContent = '*В данных есть ошибка!';
                return;
            }

            let isChanging = btnSubmit.value.toLowerCase().includes('изменить');
            let isDeleting = btnSubmit.value.toLowerCase().includes('удалить');

            if (isChanging)
                changeTicket();
            else if (isDeleting)
                deleteTicket();
            else
                addTicket();

            //Добавляем имзенённую коллекцию в локальное хранилище
            ticketView.writeToLocal();
        }

        //Работа с коллекцией при добавлении
        function addTicket(inputFields) {
            //Создать объект
            let claim = new Ticket(
                Math.max(...ticketsList.map(c => c.ticketId))+1,
                $('destination').value,
                parseInt($('flightNum').value),
                $('passengerSnp').value,
                parseInt($('ticketPrice').value),
            );

            //Если билет создать не удалось
            if (!claim) {
                bottomLbl.textContent = '*Не удалось создать билет!';
                console.log(`obj:\r\n${claim.destination}\
                \r\n${claim.flightNum}\
                \r\n${claim.passenger}\
                \r\n${claim.ticketPrice}\
                `)
            }

            //Добавление в массивы
            let tickets = ticketsList
            tickets.push(claim);
            showDefaultArr();
            highlightSingleTicket(tickets[tickets.length-1])

            bottomLbl.textContent = 'Билет успешно добавлен. Элемент выделен синим.';

            //Очистка формы
            setTimeout(() => resetFormHandler(bottomLbl,inputFields),5_000) ;
        }

        //Работа с коллекцией при изменении
        function changeTicket() {
            //Создать объект
            let claim = new Ticket(
                parseInt(form.getAttribute('data-selected-worker-id')),
                $('destination').value,
                parseInt($('flightNum').value),
                $('passengerSnp').value,
                parseInt($('ticketPrice').value),
            );

            //Если билет создать не удалось
            if (!claim) {
                bottomLbl.textContent = '*Не удалось изменить билет!';
                console.log(`obj:\r\n${claim.destination}\
                \r\n${claim.flightNum}\
                \r\n${claim.passenger}\
                \r\n${claim.ticketPrice}\
                `)
            }

            let ind = ticketsList.findIndex(c => c.ticketId === claim.ticketId);
            let indCopy = lastFormedCollection.findIndex(c => c.ticketId === claim.ticketId);
            //Изменяем объект в массиве
            ticketsList[ind] = claim;
            lastFormedCollection[indCopy] = claim;

            /*showDefaultArr();*/
            showTickets(lastFormedCollection);
            highlightSingleTicket(claim);


        }

        //Работа с коллекцией при удалении
        function deleteTicket() {
            //Индекс для удаления
            let indToRemove = ticketsList.findIndex(c => c.ticketId === parseInt(form.getAttribute('data-selected-worker-id')))

            //Если билет найти не удалось
            if (indToRemove < 0) {
                bottomLbl.textContent = '*Не удалось найти билет!';
                return;
            }

            //Удаляем из массива
            ticketsList.splice(indToRemove,1);
            changeIdsAfterDel(ticketsList,indToRemove);
            showDefaultArr();

            //Для изменения заданных полей в форме
            changeFormToDeletion(form,btnSubmit);

        }

        //Изменение массива после удаления
        function changeIdsAfterDel(tickets,delInd) {

            //Уменьшить все id идущие после удалённого
            for (let i = delInd; i < tickets.length; i++) {
                tickets[i].ticketId--;
            }

        }
        //endregion

        //Обработчик сброса формы
        function resetFormHandler(bottomLbl,inputFields) {

            //Убираем запись снизу
            bottomLbl.textContent = '';
            bottomLbl.style.visibility = 'hidden';

            //Находим поля ввода с некорректными значениями
            for (let field of inputFields) {
                if (field.classList.contains('inValid-field')) {
                    field.classList.remove('inValid-field');

                    //Меняем значение в подсказаках на начальное
                    field.parentElement.getElementsByTagName('label')[0].textContent = `Введите ${field.getAttribute('data-field-name')}`;
                    field.value = '';
                }//if
            }//for

        }//resetFormHandler

        //Загрузить список ID
        function loadDropDown() {
            let str = ticketsList.reduce((acc,claim) => acc+`<option>${claim.ticketId}</option>`,'')
            dropDownList.innerHTML = str;

            //По умолчанию 1-й элемент будет выбран
            dropDownList.children[0].setAttribute('selected','selected');
        }

        //Обработчик выбора данных в выпадающем списке
        function selectionChangedHandler(e) {
            let chosenId = parseInt(e.target.value);

            let chosenTicket = ticketsList[ticketsList.findIndex(c => c.ticketId === chosenId)];
            if (chosenTicket)
            {
                form.setAttribute('data-selected-worker-id',chosenId.toString());
                //Заполняем поля
                destinationField.value = chosenTicket.destination;
                flightNumField.value = chosenTicket.flightNum;
                passengerField.value = chosenTicket.passenger;
                ticketPriceField.value = chosenTicket.ticketPrice;
            }
        }

        //endregion

        //Задание обработчиков на элементы формы
        (function addHandlers() {

            //region Обработчики на изменение данных в поле
            destinationField.addEventListener('change',(e) =>
                onChangeHandler(e,(value) => value.length>=3,'Пункт назначения должен содержать >= 3 символов'));

            flightNumField.addEventListener('change',(e) =>
                onChangeHandler(e,(value)=> /([A-Za-z]+)(\s|\w)([0-9]+)/.test(value),'Номер рейса должен вида \'SU 1111\''));

            passengerField.addEventListener('change',(e) =>
                onChangeHandler(e,(value)=> value.length>=5 && !/[0-9]/g.test(value),'ФИО должно содержать >= 5 символов без чисел'));

            ticketPriceField.addEventListener('change',(e) =>
                onChangeHandler(e,(value)=> parseInt(value)>=2000 && !/[A-Za-zА-Яа-я]/g.test(value),'Стоимость билета должна быть >= 2 000, только числа'));
            //endregion

            //region Кнопки формы
            //Кнопка одобрения формы
            btnSubmit.addEventListener('click',() => okClickHandler(bottomLbl,fields))

            //Отменить
            form.addEventListener('reset',() => resetFormHandler(bottomLbl,fields))
            //endregion


            //region Изменение режима формы
            changeToAddingBtn.addEventListener('click',() => changeFormToAdding(form,btnSubmit))
            changeToDeletionBtn.addEventListener('click',() => changeFormToDeletion(form,btnSubmit))
            changeToChangingBtn.addEventListener('click',() => changeFormToChanging(form,btnSubmit))
            //endregion

            dropDownList.addEventListener('change',selectionChangedHandler);

        })();


        //region Изменение состояний формы

        //Элементы, которые не должны изменяться при изменении формы
        function untouchedElem(element) {
            return  element.id &&
                    (element.id === idList.id ||
                    element.id === 'formLegend'||
                    element.id === 'formBtnsBlock'||
                    element.id === 'formPromptBlock')
        }



        //Форма в режим добавления
        function changeFormToAdding(form,submitBtn) {
            changeToAddingBtn.disabled = true;
            changeToDeletionBtn.disabled = false;
            changeToChangingBtn.disabled = false;
            submitBtn.value = 'Добавить билет'

            //Отключаем видимость блока с выпадающим списом id
            idList.style.display = 'none';
            btnReset.style.display = 'inline-block';

            //Если поля ввода отключены после удаления
            if (fieldset.children[2].getElementsByTagName('input')[0].disabled)
            {
                let childElements = fieldset.children;
                for (let child of childElements) {
                    //Если элемент не должен менятся
                    if  (untouchedElem(child))
                        continue;

                    let input = child.getElementsByTagName('input')[0];
                    input.disabled = false;
                    input.style.width = '40%';
                    input.value = '';
                    btnReset.style.display = 'inline-block';
                    child.getElementsByTagName('label')[0].style.display = 'inline-block';
                }
            }

            if (form.getAttribute('data-selected-worker-id'))
                form.removeAttribute('data-selected-worker-id');

        }

        //Форма в режим удаления
        function changeFormToDeletion(form,submitBtn) {
            //Отключаем кнопку перехода на текущий режим
            changeToAddingBtn.disabled = false;
            changeToDeletionBtn.disabled = true;
            changeToChangingBtn.disabled = false;
            submitBtn.value = 'Удалить билет'

            //Отключаем видимость блока с выпадающим списом id
            idList.style.display = 'block';

            //Если поля ввода включены после редактирования или добавления
            if (fieldset.children[1].style.display === 'block')
            {
                let childElements = fieldset.children;
                for (let child of childElements) {

                    //Если текущий элемент соответствует элементу, который не должен менятся
                    if (untouchedElem(child))
                        continue;

                    //Отключаем остальные поля ввода кроме id
                    let input = child.getElementsByTagName('input')[0];

                    //Отключаем поляя ввода
                    input.disabled = true;

                    //Меняем ширину полей
                    input.style.width = '70%';
                    input.value = ' ';

                    //Отключаем кнопку отмены
                    btnReset.style.display = 'none';
                    child.getElementsByTagName('label')[0].style.display = 'none';
                }
            }
            //Загружаем список Id
            loadDropDown();

            //Задаём стартовые значения
            let chosenTicket = ticketsList[parseInt(dropDownList.value)-1]
            //Изменяем атрибут
            form.setAttribute('data-selected-worker-id',dropDownList.value);

            destinationField.value = chosenTicket.destination;
            flightNumField.value = chosenTicket.flightNum;
            passengerField.value = chosenTicket.passenger;
            ticketPriceField.value = chosenTicket.ticketPrice;

        }

        //Форма в режим изменения
        function changeFormToChanging(form,submitBtn) {
            changeToAddingBtn.disabled = false;
            changeToDeletionBtn.disabled = false;
            changeToChangingBtn.disabled = true;
            submitBtn.value = 'Изменить билет'

            //Отключаем видимость блока с выпадающим списом id
            idList.style.display = 'block';
            //Отключаем кнопку отмены
            btnReset.style.display = 'none';

            //Если поля ввода отключены после удаления
            if (fieldset.children[2].getElementsByTagName('input')[0].disabled)
            {
                let childElements = fieldset.children;
                for (let child of childElements) {
                    //Если ID задан и равен id блока со списокм ticketsId
                    if  (untouchedElem(child))
                        continue;

                    let input = child.getElementsByTagName('input')[0];
                    input.disabled = false;
                    input.style.width = '40%';
                    input.value = '';


                    child.getElementsByTagName('label')[0].style.display = 'inline-block';
                }
            }
            //Загружаем список Id
            loadDropDown();

            //Задаём стартовые значения в поля
            let chosenTicket = ticketsList[parseInt(dropDownList.value)-1]

            //Изменяем атрибут
            form.setAttribute('data-selected-worker-id',dropDownList.value);

            destinationField.value = chosenTicket.destination;
            flightNumField.value = chosenTicket.flightNum;
            passengerField.value = chosenTicket.passenger;
            ticketPriceField.value = chosenTicket.ticketPrice;

        }
        //endregion


    }

    window.addEventListener("load",loadHandler,false);
})();