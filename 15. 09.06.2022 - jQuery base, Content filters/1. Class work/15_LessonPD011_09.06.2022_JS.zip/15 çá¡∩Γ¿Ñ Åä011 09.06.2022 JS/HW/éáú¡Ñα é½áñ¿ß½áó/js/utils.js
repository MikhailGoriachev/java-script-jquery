
//Получение случайного значения
function getRandom(lo,hi) {
    return Math.trunc((hi-lo) * Math.random() + lo);
}

//Получение элемента по ID
function $(id) {
    return document.getElementById(id);
}

//region Билеты

function generateDestination() {
    let destinations = [
        "Дюссельдорф",
        "Гамбург",
        "Варшава",
        "Стамбул",
        "Брюссель",
        "Даллас",
        "Денвер",
    ];
    return destinations[getRandom(0,destinations.length)];
}
function generatePrice() {
    return getRandom(2000,5_000);
}
function generateFlightNumber() {
    let prefixes1 = [
        'A', 'B','C','D','P','S'
    ];
    let prefixes2 = [
        'E', 'F','G','H','K','N'
    ];
    return `${prefixes1[getRandom(0,prefixes1.length)]}${prefixes2[getRandom(0,prefixes2.length)]}${getRandom(100,1000)}`;
}

//Функция возвращает объект
function generatePerson() {

    //Список персон
    let people = [
        'Лосева И.С.',
        'Михалков А.В.',
        'Пелых М.У.',
        'Пономаренко Л.А.',
        'Хавалджи В.Д.',
        'Пархоменко И.В.',
        'Демидова А.А.',
        'Лапотникова О.Т.',
        'Чмыхало О.Т.',    ];

    return people[getRandom(0,people.length)];
}//generatePerson


//endregion

//region Работники


function generateSNP(gender) {

    //Список мужских фамилий
    let men = [
        'Михалков А.В.',
        'Пелых М.У.',
        'Пономаренко Л.А.',
        'Хавалджи В.Д.',
        'Пархоменко И.В.',
        'Чмыхало О.Т.',    ];

    //Список женских фамилий
    let women = [
        'Лосева И.С.',
        'Пелых А.С.',
        'Пономаренко Л.А.',
        'Хавалджи В.Д.',
        'Пархоменко И.В.',
        'Демидова А.А.',
        'Лапотникова О.Т.',
        'Чмыхало О.Т.',];

    if (gender.toLowerCase().includes('муж'))
        return men[getRandom(0,men.length)]

    return women[getRandom(0,women.length)];
}//generatePerson

//Должности
function generatePosition() {
    let positions = [
        "Проджект менеджер",
        "Junior developer",
        "Middle developer",
        "Team lead",
        "Traffic manager",
        "Дизайнер",
    ];
    return positions[getRandom(0,positions.length)];
}
function generatePositions() {
    let positions = [
        "Проджек менеджер",
        "Junior developer",
        "Middle developer",
        "Team lead",
        "Traffic manager",
        "Бугхалтер",
    ];
    return positions;
}

//Должности
function getGender() {
    let gender = [
        "Мужской",
        "Женский",,
    ];

    return gender[getRandom(0,gender.length-1)];
}

//Зар.плата
function generateSalary() {
    return getRandom(800,8000);
}
//Год начала работы
function generateEntryYear() {
    return getRandom(2000,2021);
}

//endregion


function getNumFromStr(str) {

    if (/\D+/.test(str))
        str = str.replace(/\D+/,'');

    if (!isNaN(parseInt(str)))
        return parseInt(str);

    //Если ничего не найдено
    return 1e-10
}

function getBlockChildren(block) {
    //Получаем массив дочерних элементов общего блока
    let childNodes = [];
    block.childNodes.forEach(c => {

        if (c.nodeType == 1)
            childNodes.push(c);
    });

    return childNodes;
}

//Получение определённого cookie по имени
function getCookieValue(cookieName) {
    let documentCookies = document.cookie;
    //Создаём массив cookies
    let cookiesCollection = documentCookies.split(';')
        .filter(s => s.length > 0)
        .map(s => s.startsWith(' ')?s.substring(1,s.length):s);

    /*console.log(`Массив: ${cookiesCollection}`);*/

    for (let cookie of cookiesCollection) {
        if (!cookie.startsWith(cookieName))
            continue;
        let ind = cookie.indexOf('=');
        return decodeURIComponent(cookie.substring(ind+1,cookie.length));
    }
}

function fillFromLocalStore(form) {
    let formInputs = form.getElementsByTagName('input');

    //Запись в поля если есть данны
    for (let input of formInputs) {
        if (window.localStorage[input.id])
            input.value = window.localStorage[input.id];
    }
}

function writeFieldsToLocal(form) {
    for (let input of form.getElementsByTagName('input')) {
        if(input.type === 'text')
            window.localStorage[`${input.id}`] = input.value;
    }
}
