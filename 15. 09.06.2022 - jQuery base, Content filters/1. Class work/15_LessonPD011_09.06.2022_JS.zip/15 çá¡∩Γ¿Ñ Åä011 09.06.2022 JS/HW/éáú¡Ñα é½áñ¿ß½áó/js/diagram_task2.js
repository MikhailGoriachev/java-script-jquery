function createPricesDiagram(collection,width,height,color) {

    let container = $('container');
    container.style.width = `${width}px`;
    container.style.height = `${height}px`;
    container.style.position = 'relative';


    console.log(`Стоимости: ${collection}`);

    let maxPrice = Math.max(...collection);

    //Коэфициент масщтабирования
    let scale = height/maxPrice;

    //Ширина стообца диаграммы
    let colWidth = Math.floor(width/collection.length);

    //Создание
    for (let i = 0; i < collection.length; i++) {
        let col = document.createElement('div');

        col.style.height = `${collection[i]*scale}px`;
        col.style.width = `${colWidth-4}px`;

        col.style.position = 'absolute';
        col.style.marginLeft = '4px'
        col.style.marginRight = '4px'

        //Позиционирование столбца
        col.style.bottom = '0px';

        //Каждую итерацию переход влево на ширину элемента
        col.style.left = `${colWidth*i}px`

        col.style.backgroundColor = color;

        col.innerHTML = `<span>${collection[i]}</span>`
        col.style.textAlign = 'center'
        container.appendChild(col);
    }
}

function loadHandler() {

    let ticketPrices = [];
    //Получить коллекцию из хранилища
    if (window.localStorage.ticketsView) {
        let view = JSON.parse(window.localStorage.ticketsView);

        // for (let elem of view.tickets) {
        //     ticketPrices.push(parseInt(elem._price))
        // }

        ticketPrices = JSON.parse(window.localStorage.ticketsView).tickets.map(t => t._price);
    }

    createPricesDiagram(ticketPrices,900,400,'rgb(53,140,101)')
}

window.addEventListener('load',loadHandler,false);