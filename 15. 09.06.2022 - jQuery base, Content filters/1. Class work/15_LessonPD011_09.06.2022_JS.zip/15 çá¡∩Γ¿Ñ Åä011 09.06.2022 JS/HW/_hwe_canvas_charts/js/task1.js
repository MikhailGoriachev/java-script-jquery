/*
* Задача 1
* Разместите на странице три элемента canvas. Выведите в элементы
* прямоугольник, равнобедренный треугольник и круг, выравнивание
* элементов – по центру областей вывода. При помощи элементов
* управления изменяйте размеры фигур (высоту и ширину прямоугольника,
* высоту и основание треугольника, радиус круга), цвет заливки
* и цвет рамки фигур.
*
* */

// обработчик загрузки страницы
window.addEventListener('load', () => {
    // прямоугольник
    let rectangle = {
        width: 180,
        height: 90,
        strokeColor: 'darkgreen',
        fillColor: 'lightgreen'
    };

    // равнобедренный треугольник
    let triangle = {
        base: 100,
        height: 60
    }

    // круг
    let circle = {
        x: 160,  // ???
        y:  80,  // ???
        radius: 60
    }

    // начальная отрисовка изображений

    // рисуем прямоугольник
    drawRect("rectangle", rectangle);

    // рисуем треугольник
    drawTriangle("triangle", triangle);

    // рисуем круг
    drawCircle("circle", circle);

    // слушатели кликов по кнопкам

    // управление прямоугольником
    $("btnWidthUp").addEventListener('click',e => {
        rectangle.width += 5;
        drawRect("rectangle", rectangle);
    } , false);

    $("btnWidthDn").addEventListener('click',e => {
        rectangle.width -= (rectangle.width >= 10?5:0);
        drawRect("rectangle", rectangle);
    } , false);

    $("btnHeightUp").addEventListener('click',e => {
        rectangle.height += 5;
        drawRect("rectangle", rectangle);
    } , false);

    $("btnHeightDn").addEventListener('click',e => {
        rectangle.height -= (rectangle.height >= 10?5:0);
        drawRect("rectangle", rectangle);
    } , false);

    // управление треугольником
    $("btnBaseUp").addEventListener('click',e => {
        triangle.base += 5;
        drawTriangle("triangle", triangle);
    } , false);

    $("btnBaseDn").addEventListener('click',e => {
        triangle.base -= (triangle.base >= 10?5:0);
        drawTriangle("triangle", triangle);
    } , false);

    $("btnTrHeightUp").addEventListener('click',e => {
        triangle.height += 5;
        drawTriangle("triangle", triangle);
    } , false);

    $("btnTrHeightDn").addEventListener('click',e => {
        triangle.height -= (triangle.height >= 10?5:0);
        drawTriangle("triangle", triangle);
    } , false);

    // управление кругом
    $("btnRadiusUp").addEventListener('click',e => {
        circle.radius += 5;
        drawCircle("circle", circle);
    } , false);

    $("btnRadiusDn").addEventListener('click',e => {
        circle.radius -= (circle.radius >= 10?5:0);
        drawCircle("circle", circle);
    } , false);
}, false);


// рисуем прямоугольник
function drawRect(canvasId, rectangle) {
    let canvas = $(canvasId);
    let context = canvas.getContext("2d");

    context.save();
    context.clearRect(0, 0, context.canvas.width, context.canvas.height);

    // Меняем цвет рамки и заливки
    context.fillStyle = rectangle.fillColor;
    context.strokeStyle = rectangle.strokeColor;
    context.lineWidth = 2;

    // Закрашенный прямоугольник
    context.fillRect(0, 0, rectangle.width, rectangle.height);
    context.strokeRect(0, 0, rectangle.width, rectangle.height);
    context.restore();
} // drawRect


// рисуем равнобедренный треугольник
function drawTriangle(canvasId, triangle) {
    let canvas = $(canvasId);
    let context = canvas.getContext("2d");

    context.save();

    // Меняем цвет рамки и заливки
    context.fillStyle = "lightskyblue";
    context.strokeStyle = "darkblue";
    context.lineWidth = 4;

    // Определяем форму вершин, в которых сходятся линии
    // round, bevel, miter
    context.lineJoin = "round";

    // отрисовка треугольника
    context.save();
    context.clearRect(0, 0, context.canvas.width, context.canvas.height);

    // начало пути.
    context.beginPath();
    let y = context.canvas.height-20;
    context.moveTo(10, y);
    context.lineTo(10 + triangle.base, y);
    context.lineTo(triangle.base/2, y - triangle.height);
    context.closePath();

    context.fill();
    context.stroke();
    context.restore();
} // drawTriangle


// рисуем окружность
function drawCircle(canvasId, circle) {
    let canvas = $(canvasId);
    let context = canvas.getContext("2d");

    // толщина линий
    context.lineWidth = 4;

    // отрисовка круга
    context.clearRect(0, 0, context.canvas.width, context.canvas.height);
    context.beginPath();

    // arc(x,y,radius,startAgle,endAngle,clockwise)
    // Метод arc() принимает 6 аргументов:
    // x, y - центр рисования дуги
    // radius -радиус
    // startAngle -начальный угол окружности
    // endAngle - конечный угол окружности
    // clockwise - направление прорисовки. false - по часовой стрелке
    context.arc(circle.x, circle.y, circle.radius, 0, Math.PI*2, true);

    // Меняем цвет рамки и заливки
    context.fillStyle = "linen";
    context.fill();
    context.strokeStyle = "darkorange";
    context.stroke();
    context.closePath();
} // drawCircle