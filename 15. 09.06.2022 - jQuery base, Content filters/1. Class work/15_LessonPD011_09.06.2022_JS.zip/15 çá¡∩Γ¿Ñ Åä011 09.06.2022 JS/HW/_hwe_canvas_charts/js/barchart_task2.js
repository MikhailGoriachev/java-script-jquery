﻿window.addEventListener("load", function () {
    // формирование объекта
    let booking = new Booking();

    // получить контейнер для вывода гистограммы или сообщения об ошибке
    let container = $("chartCostContainer");

    // если объект есть в хранилище - читаем данные из хранилища,
    // иначе - сообщить об ошибке, отсутствия данных
    if (window.localStorage.booking) {
        booking.load();
    } else {
        // сообщить об ошибке - отсутствие данных
        container.innerHTML = '<h3>Нет данных для построения гистограммы</h3>';
    } // if

    let chart = createBarChartDiv(
        booking.tickets.map(t => t.cost).sort((t1, t2) => t1 - t2), // данные для построения гистограммы
        800,               // ширина поля вывода
        600,               // высота поля вывода
        "lightseagreen");  // цвет прямоугольников

    // добавить гистограмму в этот контейнер
    container.appendChild(chart);

    // построение гистограммы при помощи div
    // data   - массив данных для визуализации
    // width  - ширина поля вывода гистограммы
    // height - высота поля вывода гистограммы
    // color  - цвет прямоугольников
    function createBarChartDiv(data, width, height, color) {

        // создаем контейнер для диаграммы
        let chart = document.createElement("div");
        chart.style.width = width + "px";
        chart.style.height = height + "px";
        chart.style.position = "relative";

        // находим максимальное значение в массиве данных
        let max = Math.max(...data);

        // масштаб по вертикалы и ширина
        let scale = height / max;
        let barWidth = Math.floor(width / data.length);

        // поэлементное создание гистограммы
        for (let i = 0; i < data.length; i++) {
            // создаем отдельный элемент диаграммы
            let bar = document.createElement("div");

            // формируем высоту div в зависимости от данных - высотой показываем значение
            bar.style.height = data[i] * scale + "px";
            bar.style.width = barWidth - 4 + "px";   // 4px для отступа

            bar.style.position = "absolute";
            bar.style.margin = "4px";
            bar.style.bottom = "0px";
            bar.style.left = barWidth * i + "px";

            bar.style.backgroundColor = color;

            chart.appendChild(bar);
        } // for i

        return chart;
    } // createBarChartDiv

});
