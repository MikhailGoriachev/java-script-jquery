class Worker {
    constructor(id, fullName, position, gender, startYear, photo, salary) {
        this.id = id;
        this.fullName = fullName;
        this.position = position;
        this.gender = gender;
        this.startYear = startYear;
        this.photo = photo;
        this.salary = salary;
    } // constructor

    // формирование строки с данными объекта для вывода в разметку
    // идентификаторы кнопок управления содержат маркеры действия (btnEdit или btnRemove) и
    // собственно идентификатор записи
    toTableRow(row) {return `
        <tr id="wrkr${row}">
        <td>${this.id}</td>
        <td><img src="../images/task3/${this.photo}" alt="${this.photo}"</td>
        <td class="align-left">${this.fullName}</td>
        <td class="align-left">${this.position}</td>
        <td class="align-left">${this.gender?'муж.':'жен.'}</td>
        <td class="align-right">${this.startYear}</td>
        <td class="align-right">${this.getExperience()}</td>
        <td class="align-right">${this.salary}</td>
        <td class="align-left">
            <button data-edt="${this.id}" title="Редактирование данных работника">
                <i data-edt="${this.id}" class="fa fa-edit fa-2x"></i>
            </button>
            <button data-del="${this.id}" title="Удаление данных работника">
                <i data-del="${this.id}" class="fa fa-recycle fa-2x"></i>
            </button>
        </td>
        </tr>`;
    } // toTableRow

    // для элемента массива формируем идентификатор, находим соответствующую строки таблицы
    // и меняем ее оформление, если на элементе массива сработает предикат
    toTableRowMark(row, predicate) {
        // можно работать с коллекцией классов CSS через свойство classList или напрямую
        // со свойствами стиля
        // predicate(this)?item.classList.add("selected-tr"):item.classList.remove("selected-tr");
        if (predicate(this))
            $(`wrkr${row}`).style.backgroundColor = "linen";
    } // toTableRowMark

    // вычисление стажа в полных годах для текущей даты
    getExperience() { return new Date().getFullYear() - this.startYear;}

    // присваивание одноименных полей объекта w, используем при десериализации из JSON
    assign(w) {
        Object.assign(this, w);
        return this;
    } // assign
} // class Worker


// Предприятие - коллекция работников
class Enterprise {
    constructor(title, workers) {
        this.title = title;
        this.workers = workers;
    }

    // вывод название предприятия и коллекции сведений о его работниках в разметку по кликам на кнопки
    show(header) {
        $("title").innerText = header;
        let row = 1;
        $("workers").innerHTML = this.workers.reduce((acc, w) => acc + w.toTableRow(row++), "");
    } // show

    // вывод коллекции сведений о сотрудниках в разметку
    static show(header, workers) {
        $("title").innerText = header;
        let row = 1;
        $("workers").innerHTML = workers.reduce((acc, w) => acc + w.toTableRow(row++), "");
    } // show

    // изменение стиля в строках таблицы, для которых сработает предикат
    static showOrderedMarked(title, enterprise, predicate, comparison, timeOut = 10_000) {
        // создадим упорядоченную по компаратору копию массива
        let workers = [...enterprise.workers].sort(comparison);

        // вывод без выделения - просто чистим вывод :)
        Enterprise.show(title, workers);

        let row = 1;
        workers.forEach(t => t.toTableRowMark(row++, predicate));

        // снятие выделения, вывод исходного массива через timeOut мс
        setTimeout(() => enterprise.show(title), timeOut);
    } // showOrderedMarked

    // упорядочивание массива сведений о работниках по фамилиям, по алфавиту
    orderByFullName() {
        return [...this.workers].sort((w1, w2) => w1.fullName.localeCompare(w2.fullName));
    } // orderByFullName

    // возвращает минимальный оклад
    minSalary() { return Math.min(...this.workers.map(w => w.salary))}

    // возвращает максимальный оклад
    maxSalary() { return Math.max(...this.workers.map(w => w.salary))}

    // удаление сведений о работнике по его id
    removeById(id) {
        let index = this.workers.findIndex(w => w.id === id);
        if (index < 0) return;
        this.workers.splice(index, 1);
    } // removeById

    // сохранение данных в локальном хранилище, если данных там еще нет
    store() {
        window.localStorage.enterprise = JSON.stringify(this);
    } // store

    // загрузка данных из локального хранилища
    load() {
        // прочитать строку из хранилища и распарсить ее в объект
        let temp = JSON.parse(window.localStorage.enterprise);

        // сохранить название предприятия
        this.title = temp.title;

        // сформировать коллекцию сведений о работниках из сохраненных данных
        this.workers = [];
        temp.workers.forEach(w => this.workers.push(new Worker().assign(w)));
    } // load
} // class Enterprise