
// Класс, представляющий заявку на авиабилет с полями:
//     фамилию и инициалы пассажира,
//     пункт назначения,
//     номер рейса,
//     стоимость билета
class Ticket  {
    constructor(id, fullName, destination, flight, cost) {
        this.id = id;
        this.fullName = fullName;
        this.destination = destination;
        this.flight = flight;
        this.cost = cost;
    } // constructor


    // переопределение метода Object
    toString() { return `
        <td>${this.id}</td>
        <td>${this.fullName}</td>
        <td>${this.destination}</td>
        <td>${this.flight}</td>
        <td>${this.cost}</td>`;
    } // toString


    // формирование строки с данными объекта для вывода в разметку
    toTableRow(row) {return `
        <tr id="cln${row}">
        <td>${row}</td>
        <td>${this.id}</td>
        <td class="align-left">${this.fullName}</td>
        <td class="align-left">${this.destination}</td>
        <td class="align-left">${this.flight}</td>
        <td class="align-right">${this.cost}</td>
        <td class="align-left tdw-100">
            <button data-edt="${this.id}" title="Редактирование данных заявки">
                <i data-edt="${this.id}" class="fa fa-edit fa-2x"></i>
            </button>
            <button data-del="${this.id}" title="Удаление данных заявки">
                <i data-del="${this.id}" class="fa fa-recycle fa-2x"></i>
            </button>
        </td>
        </tr>`;
    } // toTableRow

    // для элемента массива формируем идентификатор, находим соответствующую строки таблицы
    // и меняем ее оформление, если на элементе массива сработает предикат
    toTableRowMark(row, predicate) {
        // можно работать с коллекцией классов CSS через свойство classList или напрямую
        // со свойствами стиля
        // predicate(this)?item.classList.add("selected-tr"):item.classList.remove("selected-tr");
        if (predicate(this))
            $("cln" + row).style.backgroundColor = "linen";
    } // toTableRowMark


    // присваивание одноименных полей объекта t, используем при десериализации из JSON
    assign(t) {
        Object.assign(this, t);
        return this;
    } // assign
} // class Ticket


// класс для работы с коллекцией заказов на авиабилеты
class Booking {
    constructor(title, tickets) {
        this.title = title;
        this.tickets = tickets;
    }

    // вывод название авиакомпании и коллекции заявок в разметку по кликам на кнопки
    show(header) {
        $("title").innerText = header;
        let row = 1;
        $("tickets").innerHTML = this.tickets.reduce((acc, t) => acc + t.toTableRow(row++), "");
    } // show

    // вывод коллекции заявок в разметку
    static show(header, tickets) {
        $("title").innerText = header;
        let row = 1;
        $("tickets").innerHTML = tickets.reduce((acc, t) => acc + t.toTableRow(row++), "");
    } // show

    // изменение стиля в строках таблицы, для которых сработает предикат
    static showMarked(title, booking, predicate, timeOut = 10_000) {
        // вывод без выделения - просто чистим вывод :)
        booking.show(title);

        let row = 1;
        booking.tickets.forEach(t => t.toTableRowMark(row++, predicate));

        // снятие выделения через 10_000 мс
        setTimeout(() => booking.show(title), timeOut);
    } // showMarked

    // сортировка копии массива заявок на авиабилеты по пунктам назначения
    orderByDestination() {
        return [...this.tickets].sort((t1, t2) => t1.destination.localeCompare(t2.destination));
    } // orderByDestination

    // сортировка копии массива заявок на авиабилеты упорядоченного по стоимости
    orderByCost() {
        return [...this.tickets].sort((t1, t2) => t1.cost - t2.cost);
    } // orderByCost

    // сортировка копии массива заявок на авиабилеты по номеру рейса
    orderByFlight() {
        return [...this.tickets].sort((t1, t2) => t1.flight.localeCompare(t2.flight));
    } // orderByFlight

    // сохранение данных в локальном хранилище, если данных там еще нет
    store() {
        window.localStorage.booking = JSON.stringify(this);
    } // store

    // загрузка данных из локального хранилища
    load() {
        // прочитать строку из хранилища и распарсить ее в объект
        let temp = JSON.parse(window.localStorage.booking);

        // сохранить название авиакомпании
        this.title = temp.title;

        // сформировать коллекцию заявок из сохраненных данных
        this.tickets = [];
        temp.tickets.forEach(t => this.tickets.push(new Ticket().assign(t)));
    } // load

    // удаление сведений о заявке на авиабилет по id этой заявки
    removeById(id) {
        let index = this.tickets.findIndex(t => t.id === id);
        if (index < 0) return;
        this.tickets.splice(index, 1);
    } // removeById
} // class Booking