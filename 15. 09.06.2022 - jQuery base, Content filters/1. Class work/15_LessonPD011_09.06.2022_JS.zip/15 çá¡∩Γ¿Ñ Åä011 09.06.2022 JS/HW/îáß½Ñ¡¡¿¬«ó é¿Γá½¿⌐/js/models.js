// конструктор объектов заявки на билет
class Ticket {
    constructor(id = 0, {flight = "", destination = ""} = {}, paxFullName = "", price = 0) {

        this._id = id;
        // пункт назначения
        this._destination = destination;
        // номер рейса
        this._flight = flight;
        // фамилия и инициалы пассажира
        this._paxFullName = paxFullName;
        // стоимость билета
        this._price = price;
    }


    get id() { return this._id; }
    set id(value) { this._id = value; }

    get destination() { return this._destination; }
    set destination(value) { this._destination = value || 'не указано'; }

    get flight() { return this._flight; }
    set flight(value) { this._flight = value || 'не указано';}

    get paxFullName() { return this._paxFullName; }
    set paxFullName(value) { this._paxFullName = value || 'не указано'; }

    get price() { return this._price; }
    set price(value) { this._price = value >= 0 ? value : 0; }

    assign(ticket) {
        Object.assign(this, ticket);
        return this;
    }

    toTableRow(row){
        return `<tr id="t${this._id}">
                    <td>${row}</td>
                    <td class="align-left">${this._paxFullName}</td>
                    <td class="align-left">${this._flight}</td>
                    <td class="align-left">${this._destination}</td>
                    <td>${this._price}</td>
                    <td>
                        <button data-ticket-edit-id="${this._id}" title="Редактирование данных заявки">
                            <i data-ticket-edit-id="${this._id}" class="fa fa-edit fa-2x"></i></button>
                        <button data-ticket-delete-id="${this._id}" title="Удаление данных заявки">
                            <i data-ticket-delete-id="${this._id}"  class="fa fa-remove fa-2x"></i></button>
                </tr>`;
    }
}

// Фабрика генерации заявок на билет
class TicketFactory{
    static generate(amount){
        return [...Array(amount)].map((t,i) =>
            new Ticket(i + 1, this.randomFlightInfo(), this.randomFullName(), getRandomInt(1000, 5_000)));
    }

    static randomFullName(){
        return ["Гущин Ф. А.", "Симонов Н.А.", "Молчанов А.А.", "Емельянов Ц.И.", "Беляков К.В.",
            "Доронин У.И.", "Несвитайло Д.П.", "Кондратьев М.Ю.", "Симонов Ч.В.", "Тягай С.В.",
            "Василенко В.Ю.", "Дзюба Д.Д.", "Константинов Д.П.", "Лукин А.В.", "Марков Й.В.",
            "Несвитайло Р.В.", "Титов П.Ф.", "Анисимов Е.В.", "Миклашевский Д.В.", "Зыков Э.Б.",
            "Комаров С.Л.", "Рогов Э.Э.", "Королёв О.В.", "Воронцов И.А.", "Семенов Р.М.",
            "Дунаев В.Б.",   "Харламова Ю.В.", "Олегова И.В.", "Янковский В.В.", "Абалкин Л.Ж.",
            "Горбовски Д.В.", "Каммерер М.А.", "Романова П.В.",  "Воликова И.А.", "Жукова Р.Б.",
            "Денисова Д.А.", "Соколов Д.В.",   "Лебедев К.К."].random();
    }

    static randomFlightInfo(){
        return[
            {flight: "АФ4567", destination: "Сочи"},                   {flight: "FL91AS", destination: "Геленджик"},
            {flight: "PB9812", destination: "Воронеж"},                {flight: "ALF081", destination: "Берлин"},
            {flight: "PB9231", destination: "Саратов"},                {flight: "AFL002", destination: "Иваново"},
            {flight: "PB1233", destination: "Шарм-эш-Шейх"},           {flight: "FL98AS", destination: "Ростов-на-дону"},
            {flight: "AFL033", destination: "Париж, шарль де-Голль"},  {flight: "АФ9811", destination: "Москва, Внуково"},
            {flight: "АФ0011", destination: "Владивосток"},            {flight: "AFL021", destination: "Париж, Орли"},
            {flight: "АФ9821", destination: "Москва, Домодедово"},     {flight: "PB0911", destination: "Симферополь"},
            {flight: "PB7812", destination: "Ярославль"},              {flight: "PB2271", destination: "Астрахань"}
        ].random();
    }
}

// конструктор объекта управления заявками
class BookOffice {

    constructor(tickets = null) {
        this.tickets = tickets;
    }

    get tickets() { return this._tickets; }
    set tickets(value) {
        this._tickets = value;
        this.saveToLocalStorage();
    }

    // получить заявки по id
    getById(id) {
        return this._tickets.filter(w => +w.id === +id)[0];
    }

    // добавить заявку на билет
    addTicket(flight, destination, paxFullName, price) {
        let id = this._tickets.length ? Math.max(...this._tickets.map(t => t.id)) + 1 : 1;

        let ticket = new Ticket(id, {flight, destination}, paxFullName, price);
        this._tickets.push(ticket);

        this.saveToLocalStorage();
        return ticket;
    }

    // изменить данные заявки
    updateTicket(id, fullName, flight, destination, price) {
        let index = this._tickets.findIndex(t => +t.id === +id);

        if(index === -1 )
            return;

        this._tickets[index].paxFullName = fullName;
        this._tickets[index].destination = destination;
        this._tickets[index].flight = flight;
        this._tickets[index].price = price;

        this.saveToLocalStorage();
    }

    // удалить заявку по id
    deleteTicket(id){
        let index = this._tickets.findIndex(w => +w.id === +id);
        if(index > -1)
            this._tickets.splice(index, 1);

        this.saveToLocalStorage();
    }

    // копия коллекции билетов, сортированная по пункту назначения
    orderByDestination() {
        return [...this._tickets].sort((a, b) => a.destination.localeCompare(b.destination));
    }

    // копия коллекции билетов, сортированная по стоимости
    orderByPrice() {
        return [...this._tickets].sort((a, b) => a.price - b.price );
    }

    // копия коллекции билетов, сортированная по рейсу
    orderByFlight() {
        return [...this._tickets].sort((a, b) => a.flight.localeCompare(b.flight));
    }

    // выборка билетов по условию
    selectWhere(predic) {
        return this._tickets.filter(predic);
    }

    toTable(caption) { return BookOffice.toTable(this.tickets, caption); }

    static toTable(tickets, caption = 'Заявки на авиабилеты'){
        let table = `<table class="table-tickets">
                        <caption>${caption}</caption>
                      <thead><tr>
                        <td>№ п/п</td>
                        <td>Фамилия И.О.</td>
                        <td>Номер рейса</td>
                        <td>Пункт назначения</td>
                        <td>Стоимость, р.</td>
                        <td>Управление</td>
                        </tr></thead>`;
        tickets.forEach((t, i) => table += t.toTableRow(i + 1));
        table += '</table>';
        return table;
    }

    saveToLocalStorage() {
        window.localStorage.tickets = JSON.stringify(this._tickets);
    }

    loadFromLocalStorage() {
        this._tickets = BookOffice.loadFromLocalStorage();
    }

    static loadFromLocalStorage() {
        return JSON.parse(window.localStorage.tickets).map(t => new Ticket().assign(t));
    }

}


//////////// Task3

/* класс Worker
•	идентификатор работника
•	фамилия и инициалы работника;
•	название занимаемой должности;
•	пол (мужской\женский);
•	год поступления на работу;
•	имя файла с фотографией работника
•	величина оклада работника;
•	метод вычисления стажа работника для текущей даты.
*/

class Worker {
    constructor(id = 0, fullName = "", position = "", sex = "",
                admissionYear = "", photoImg = "", salary = 0) {
        this._id = id;
        this._fullName = fullName;
        this._sex = sex;
        this._admissionYear = admissionYear;
        this._photoImg = photoImg;
        this._salary = salary;
        this._position = position;
    }

    get id() { return this._id; }
    set id(value) { this._id = value; }

    get fullName() { return this._fullName; }
    set fullName(value) { this._fullName = value; }

    get position() { return this._position; }
    set position(value) { this._position = value; }

    get sex() { return this._sex; }
    set sex(value) { this._sex = value; }

    get admissionYear() { return this._admissionYear; }
    set admissionYear(value) { this._admissionYear = value; }

    get photoImg() { return this._photoImg; }
    set photoImg(value) { this._photoImg = value; }

    get salary() { return this._salary; }
    set salary(value) { this._salary = value; }

    get lengthOfService() {return new Date().getFullYear() - this._admissionYear; }

    toHtml() {
        return `<div id="emp${this._id}" class="person-block">
                      <img class="person-img" src='../images/photos/${this._photoImg}' alt ="pic"/>
                      <div class="field-container">
                        <div class="w-name">${this._fullName}</div>
                        <div><div class="desc">Пол:</div> ${this._sex}</div>
                        <div><div class="desc">Должность:</div> ${this._position}</div>
                        <div><div class="desc">Год поступления:</div> ${this._admissionYear}</div>
                        <div><div class="desc">Стаж:</div> ${this.lengthOfService} ${declOfNum(this.lengthOfService, ['год', 'года', 'лет'])}</div>
                        <div><div class="desc">Оклад:</div> ${this._salary} р.</div>
                      </div>
                      <div class="buttons">
                        <button name="editWorker" class="block-btn btn-blue" >Изменить</button>
                        <button name="deleteWorker" class="block-btn btn-blue">Удалить</button>
                      </div>
                    </div>`;
    }

    assign(worker) {
        Object.assign(this, worker);
        return this;
    }
}

// Фабрика создания работников
class WorkerFactory {
    static generateCollection(amount) {
        return [...Array(amount)].map((w,i) => this.generateWorker(i + 1));
    }

    static generateWorker(id) {
        return [this.generateMale, this.generateFeMale].random()(id);
    }

    static generateMale(id) {
        return new Worker(id, WorkerFactory.randomMaleName(), WorkerFactory.randomPosition(), "Мужской",
            WorkerFactory.randomAdmissionYear(), WorkerFactory.randomMaleImg(), WorkerFactory.randomSalary() );
    }

    static generateFeMale(id) {
        return new Worker(id, WorkerFactory.randomFemaleName(), WorkerFactory.randomPosition(), "Женский",
            WorkerFactory.randomAdmissionYear(), WorkerFactory.randomFemaleImg(), WorkerFactory.randomSalary() );
    }

    static randomMaleImg() { return `man_${getRandomInt(1,20)}.jpg`; }
    static randomFemaleImg() { return `woman_${getRandomInt(1,20)}.jpg`; }
    static randomSalary() { return getRandomInt(10_000, 30_000); }
    static randomAdmissionYear() { return getRandomInt(2010, 2021); }

    static randomMaleName() {
        return [ "Рябинин А.А.", "Николаев Ф.А.", "Федоров М.М.", "Семенов М.Д.", "Федоров Д.М.",
            "Кузнецов Г.Д.", "Коновалов И.Ф.", "Титов В.М.", "Андреев А.И.", "Никитин Л.Г.",
            "Чесноков Д.Т.", "Комаров Д.А.", "Антонов В.И.", "Баранов М.А.", "Новиков А.Р.",
            "Сорокин Д.Д.", "Никольский Д.Г.", "Дорофеев А.М.", "Булгаков М.Р.", "Васильев А.М.",
            "Осипов А.Б.", "Руднев А.Л.", "Соколов З.Ф.", "Ершов Б.С.", "Макаров А.А.",
            "Киселев М.А.", "Гаврилов И.Д.", "Белов П.И.", "Моисеев А.Г.", "Яковлев Д.А."].random();
    }

    static randomFemaleName() {
        return [ "Осипова В.Д.", "Крылова А.А.", "Глухова М.О.", "Филатова С.А.", "Яковлева Е.П.",
            "Михайлова В.К.", "Ерофеева С.С.", "Жданова Е.Т.", "Демина Е.И.", "Панова М.С.",
            "Тарасова Е.И.", "Коровина В.М.", "Сазонова М.Д.", "Иванова К.М.", "Королева Е.М.",
            "Пирогова С.М.", "Тимофеева В.М.", "Козырева М.С.", "Волкова В.Т.", "Коновалова К.А.",
            "Беликова В.В.", "Романова С.А.", "Суркова К.К.", "Мещерякова В.М.", "Васильева А.З.",
            "Ситникова Д.Н.", "Васильева А.М.", "Васильева С.Е.", "Булгакова А.Я.", "Ушакова К.Д."].random();
    }

    static positions = [ "Технический писатель", "Официант", "Кладовщик", "Почтальон", "Геолог" , "Реабилитолог",
        "Космонавт", "Косметолог" , "Спортивный врач", "Бульдозерист", "Пекарь", "Холодильщик",
        "Археолог", "Строитель" , "Бизнес-аналитик", "Штурман", "Генетик", "Бизнес-тренер", "Швея",
        "Наладчик", "Биоинженер", "Менеджер по рекламе", "Кинодраматург", "Логопед", "Пастух", "Дорожный инспектор",
        "Воспитатель", "Травматолог", "Философ", "Лоцман", "Проходчик", "Зубной техник", "Заведующий складом",
        "Уборщик", "Судебный пристав", "Фальцовщик", "Вирусолог", "Невролог", "Проректор" ,"Администратор сайта",
        "Программист", "Блогер", "Консультант по туризму", "Таксист", "Логист", "Пожарный", "Лоббист","Дерматовенеролог",
        "Инженер-технолог", "Официант"];

    static randomPosition() {
        return WorkerFactory.positions.random();
    }
}

// Класс компании для работы с коллекцией работников
class Company {
    constructor(workers = null) {
        this.workers = workers;
    }

    get workers() { return this._workers; }
    set workers(value) {
        this._workers = value;
        this.saveToLocalStorage();
    }

    // получить работника по id
    getById(id) {
        return this._workers.filter(w => +w.id === +id)[0];
    }

    // добавить работника
    addWorker(fullName, position, sex, admissionYear, salary){
        let id = this._workers.length ? this._workers.max(...this._workers.map(t => t.id)) + 1 : 1;
        let photoImg = sex === "Мужской" ? WorkerFactory.randomMaleImg() : WorkerFactory.randomFemaleImg();
        let worker = new Worker(id, fullName, position, sex, admissionYear, photoImg, salary);

        this._workers.push(worker);
        this.saveToLocalStorage();
        return worker;
    }

    // изменить работника
    updateWorker(id, fullName, position, sex, admissionYear, salary) {
        let index = this._workers.findIndex(w => +w.id === +id);
        this._workers[index].fullName = fullName;
        this._workers[index].position = position;
        this._workers[index].sex = sex;
        this._workers[index].admissionYear = admissionYear;
        this._workers[index].salary = salary;

        this.saveToLocalStorage();
    }

    // удалить работника по id
    deleteWorker(id){
        let index = this._workers.findIndex(w => +w.id === +id);
        if(index > -1)
            this._workers.splice(index, 1);

        this.saveToLocalStorage();
    }

    // получить копию, упорядоченную по фамилии
    orderBySurname() {
        return [...this._workers].sort((a,b) => a.fullName.localeCompare(b.fullName));
    }
    // получить копию, упорядоченную по должности
    orderByPosition() {
        return [...this._workers].sort((a,b) => a.position.localeCompare(b.position));
    }
    // получить копию, упорядоченную по окладу
    orderBySalary() {
        return [...this._workers].sort((a,b) => a.salary - b.salary);
    }

    // получить выборку с минимальными окладами
    selectWhereMinSalaries() {
        let minSalary = Math.min(...this._workers.map(w => w.salary));
        return this._workers.filter(w => +w.salary === +minSalary);
    }
    // получить выборку с максимальными окладами
    selectWhereMaxSalaries() {
        let maxSalary = Math.max(...this._workers.map(w => w.salary));
        return this._workers.filter(w => +w.salary === +maxSalary);
    }
    // получить выборку работников со стажем более чем
    selectWhereAdmissionYearsMoreThan(years) {
        return this._workers.filter(w => w.lengthOfService > years);
    }

    toHtml(){
        return this._workers.reduce((prev, cur) => prev += cur.toHtml(), "");
    }

    static toHtml(workers){
        return workers.reduce((prev, cur) => prev += cur.toHtml(), "");
    }

    render(elemId) {
        $(elemId).innerHTML = this.toHtml();
    }

    saveToLocalStorage() {
        window.localStorage.workers = JSON.stringify(this._workers);
    }

    loadFromLocalStorage() {
        this._workers = Company.loadFromLocalStorage();
    }

    static loadFromLocalStorage() {
        return JSON.parse(window.localStorage.workers).map(w => new Worker().assign(w));
    }
}
