
// ссылки на объекты для работы
const Task3 = {
    company: null,
    timer: null,
    delay: 15_000,
    $emp: null,
    $modalWindow: null,
    $workersForm: null
};

const keyMap = {
    "KeyQ": onNewWorker,
    "KeyW": outputSourceData,
    "KeyE": orderBySurname,
    "KeyA": markMinSalaries,
    "KeyS": markMaxSalaries,
    "KeyD": markSalariesGreater,
}

window.addEventListener('load', loadHandler, false);
function loadHandler() {
    // начальная инициация
    Task3.$emp = $('employees');
    Task3.$modalWindow =  $('modalWindow');
    Task3.$workersForm = $('workerForm');
    // заполнение списка должностей на форме
    WorkerFactory.positions.forEach(p => Task3.$workersForm.position.add(new Option(p)))
    // установка обработчиков

    window.addEventListener("click", onClick);
    window.addEventListener("keypress", onKeyPress);
    Task3.$workersForm.addEventListener("submit", onSubmitHandler);
    Task3.$workersForm.cancel.addEventListener("click", onCancel);
    Task3.$emp.addEventListener("click", onClickEmployee);
    $('btnMarkSalariesGreater').addEventListener("click",markSalariesGreater);
    $('btnMarkMinSalaries').addEventListener("click", markMinSalaries);
    $('btnMarkMaxSalaries').addEventListener("click", markMaxSalaries);
    $('btnOrderBySurname').addEventListener("click", orderBySurname);
    $('btnSrcData').addEventListener("click", outputSourceData);
    $("btnNewWorker").addEventListener("click", onNewWorker);
    $('closeModal').addEventListener("click", closeModalWindow);

    Task3.company = new Company(!window.localStorage.workers
        ? WorkerFactory.generateCollection(12)
        : Company.loadFromLocalStorage());

    Task3.company.render('employees');
}

// обработчик нажатия кнопки мыши
function onClick(e) {
    // "закрытие" модального окна с формой
    if (e.target === Task3.$modalWindow) {
        closeModalWindow();
    }
}

function onClickEmployee(e) {
    if(e.target.name === "editWorker")
        onEdit(e.target);
    if(e.target.name === "deleteWorker")
        onDelete(e.target);
}

function onKeyPress(e) {
    keyMap[e.code]();
}

// вывести исходные данные
function outputSourceData() {
    Task3.company.render('employees');
}

// упорядочить по фамилии
function orderBySurname() {
    Task3.$emp.innerHTML = Company.toHtml(Task3.company.orderBySurname());
}

// выделить со стажем свыше
function markSalariesGreater(ev) {
    let value = +$('inpMarkAdmYears').value;
    if(!value) return;

    Task3.$emp.innerHTML = Company.toHtml(Task3.company.orderBySalary());
    Task3.company.workers.forEach(w => $(`emp${w.id}`).classList.remove('marked'));

    Task3.company.selectWhereAdmissionYearsMoreThan(value)
        .forEach(w => $(`emp${w.id}`)
            .classList.add('marked'));

    clearTimeout(Task3.timer);
    Task3.timer = setTimeout(() => Task3.company.render(Task3.$emp), Task3.delay);
}

// Выделить с мин. окладами
function markMinSalaries(ev) {

    Task3.$emp.innerHTML = Company.toHtml(Task3.company.orderBySurname());
    clearMarked();

    Task3.company.selectWhereMinSalaries().forEach(w => $(`emp${w.id}`).classList.add('marked'));

    clearTimeout(Task3.timer);
    Task3.timer = setTimeout(() => Task3.$emp.innerHTML = Task3.company.toHtml(), Task3.delay);
}

// Выделить с макс. окладами
function markMaxSalaries(ev) {
    Task3.$emp.innerHTML = Company.toHtml(Task3.company.orderByPosition());
    clearMarked();
    Task3.company.selectWhereMaxSalaries().forEach(w => $(`emp${w.id}`).classList.add('marked'));

    clearTimeout(Task3.timer);
    Task3.timer = setTimeout(() => Task3.$emp.innerHTML = Task3.company.toHtml(), Task3.delay);
}

// обработчик подтверждения на форме
function onSubmitHandler(event){
    let fullName = this.fullName.value;
    let sex = this.sex.value;
    let position = this.position.value;
    let admYear = this.admYear.value;
    let salary = this.salary.value;
    let id = this.idWorker.value;

    if(this.submit.value === "Добавить") {
        let worker = Task3.company.addWorker(fullName, position, sex, admYear, salary);
        Task3.$emp.innerHTML += (worker.toHtml());
    }

    if(this.submit.value === "Изменить") {
        Task3.company.updateWorker(id, fullName, position, sex, admYear, salary);
        $(`emp${id}`).innerHTML = Task3.company.getById(id).toHtml();
    }

    Task3.$modalWindow.style.display = "none";

    event.preventDefault();
}

// вызов добавления нового сотрудника
function onNewWorker() {
    clearWorkersForm();
    $('formTitle').innerHTML = "Добавить данные сотрудника";
    Task3.$workersForm.submit.value = "Добавить";
    Task3.$modalWindow.style.display = "block";
}


// обработчик удаления сотрудника
function onDelete(e) {
    let id = e.parentElement.parentElement.id;
    Task3.company.deleteWorker(id.substring(3));
    e.parentElement.parentElement.remove();
}

// вызов редактирования данных сотрудника
function onEdit(e) {
    let id = e.parentElement.parentElement.id;

    let worker = Task3.company.getById(id.substring(3));

    Task3.$workersForm.fullName.value = worker.fullName;
    Task3.$workersForm.sex.value = worker.sex;
    Task3.$workersForm.position.value = worker.position;
    Task3.$workersForm.admYear.value = worker.admissionYear;
    Task3.$workersForm.salary.value = worker.salary;
    Task3.$workersForm.idWorker.value = worker.id;

    $('formTitle').innerHTML = "Изменить данные сотрудника";
    Task3.$workersForm.submit.value = "Изменить";

    Task3.$modalWindow.style.display = "block"
}

// Отмена формы
function onCancel() {
    clearWorkersForm();
    closeModalWindow();
}

// убрать выделения работников
function clearMarked() {
    Task3.company.workers.forEach(w => $(`emp${w.id}`).classList.remove('marked'));
}

// очистка формы
function clearWorkersForm() {
    Task3.$workersForm.fullName.value = "";
    Task3.$workersForm.admYear.value = "";
    Task3.$workersForm.salary.value = "";
    Task3.$workersForm.idWorker.value = "";
    Task3.$workersForm.sex.selectedIndex = 0;
    Task3.$workersForm.position.selectedIndex = 0;
}

// спрятать окно с формой
function closeModalWindow() {
    Task3.$modalWindow.style.display = "none";
}