
const keyMap = {
    "KeyQ": orderByDestination,
    "KeyW": orderByPrice,
    "KeyE": orderByFlight,
    "KeyR": markPriceGreater,
    "KeyA": onNewTicket,
    "KeyS": outputSourceData,
}

const Task2 = {
    office: null,
    $tickets: null,
    $ticketForm: null,
    $modalWindow: null,
    delay: 10_000,
    timer: null,
    $inpMarkPrice: null
};

window.addEventListener('load', loadHandler);
function loadHandler() {
    Task2.$modalWindow =  $('modalWindow');
    Task2.$ticketForm = $('ticketForm');
    Task2.$tickets = $('tickets');
    Task2.$inpMarkPrice = $('inpMarkPrice');

    window.addEventListener("click", onClick);
    window.addEventListener("keypress", onKeyPress);
    Task2.$ticketForm.addEventListener("submit", onSubmitTicketForm);
    Task2.$tickets.addEventListener("click", onClickTickets);
    $('btnSortByDest').addEventListener("click", orderByDestination);
    $('btnSortByPrice').addEventListener("click", orderByPrice);
    $('btnSortByFlight').addEventListener("click", orderByFlight);
    $('btnMarkPriceGreater').addEventListener("click", markPriceGreater);
    $("btnSrcData").addEventListener("click", outputSourceData);
    $('closeModal').addEventListener("click", closeModalWindow);
    $('btnNewTicket').addEventListener("click", onNewTicket);

    Task2.office = new BookOffice( !window.localStorage.tickets
        ? TicketFactory.generate(12)
        : BookOffice.loadFromLocalStorage());

    outputSourceData();
}



// сортировка по пункту назначения
function orderByDestination () {
    Task2.$tickets.innerHTML =
        BookOffice.toTable(Task2.office.orderByDestination('Заявки на авиабилеты - отсортированы по пункту' +
        ' назначения'));
}
// сортировка по стоимости
function orderByPrice() {
    Task2.$tickets.innerHTML =
        BookOffice.toTable(Task2.office.orderByPrice('Заявки на авиабилеты - отсортированы по стоимости билета'))
}
// сортировка по рейсу
function orderByFlight() {
    Task2.$tickets.innerHTML =
        BookOffice.toTable(Task2.office.orderByFlight('Заявки на авиабилеты - отсортированы по рейсу'));
}
// вывести исходные данные
function outputSourceData() {
    Task2.$tickets.innerHTML = Task2.office.toTable();
}
// выделение заявок стоимостью более
function markPriceGreater() {
    let value = Task2.$inpMarkPrice.value;
    if(!value) return;

    Task2.office.tickets.forEach(t => $(`t${t.id}`).classList.remove('hl-row'));
    Task2.office.selectWhere(t => t.price > value).forEach(t => $(`t${t.id}`).classList.add('hl-row'));

    clearTimeout(Task2.timer);
    Task2.timer = setTimeout(() => $('tickets').innerHTML = Task2.office.toTable(), Task2.delay);
}

// обработчик нажатия на клавишу
function onKeyPress(e) {
    keyMap[e.code]();
}

// обработчик нажатия кнопки мыши по всей странице
function onClick(e) {
    // "закрытие" модального окна с формой
    if (e.target === Task2.$modalWindow) {
        closeModalWindow();
    }
}

// обработка кликов по таблице с заявками
function onClickTickets(e) {
    if(e.target.dataset.ticketEditId)
        onEditTicket(e.target.dataset.ticketEditId);
    if(e.target.dataset.ticketDeleteId)
        onDeleteTicket(e.target.dataset.ticketDeleteId);
}
// обработчик добавления заявки
function onSubmitTicketForm(event){
    let fullName = this.fullName.value;
    let flight = this.flight.value;
    let destination = this.destination.value;
    let price = this.price.value;
    let id = this.idTicket.value;

    if(this.submit.value === "Добавить") {
        let ticket = Task2.office.addTicket(flight,destination,fullName,price);
    }

    if(this.submit.value === "Изменить") {
        Task2.office.updateTicket(id, fullName, flight, destination, price);
    }

    $('tickets').innerHTML = Task2.office.toTable();
    Task2.$modalWindow.style.display = "none";
    event.preventDefault();
}

// вызов добавления нового сотрудника
function onNewTicket() {
    clearTicketForm();
    $('formTitle').innerHTML = "Добавить данные о заявке";
    Task2.$ticketForm.submit.value = "Добавить";
    Task2.$modalWindow.style.display = "block";
}

// обработчик удаления заявки
function onDeleteTicket(id) {
    Task2.office.deleteTicket(id);
    $('tickets').innerHTML = Task2.office.toTable();
}

// вызов редактирования данных заявки
function onEditTicket(id) {
    let ticket = Task2.office.getById(id);

    Task2.$ticketForm.fullName.value = ticket.paxFullName;
    Task2.$ticketForm.destination.value = ticket.destination;
    Task2.$ticketForm.flight.value = ticket.flight;
    Task2.$ticketForm.price.value = ticket.price;
    Task2.$ticketForm.idTicket.value = ticket.id;

    $('formTitle').innerHTML = "Изменить данные заявки";
    Task2.$ticketForm.submit.value = "Изменить";

    Task2.$modalWindow.style.display = "block"
}

function clearTicketForm(){
    Task2.$ticketForm.fullName = Task2.$ticketForm.flight =
        Task2.$ticketForm.destination = Task2.$ticketForm.price = String;
}

// спрятать окно с формой
function closeModalWindow() {
    Task2.$modalWindow.style.display = "none";
}



