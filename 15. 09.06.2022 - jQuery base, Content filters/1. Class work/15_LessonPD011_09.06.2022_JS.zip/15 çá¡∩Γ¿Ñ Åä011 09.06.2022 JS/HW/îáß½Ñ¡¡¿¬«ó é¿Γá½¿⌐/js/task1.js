// базовый класс объекта для рендеринга фигуры
class Shape {
    constructor(id, color, strokeColor, strokeWidth) {
        this.canvas = $(id);
        this.context = this.canvas.getContext("2d");

        this.cW = +this.canvas.width;
        this.cH = +this.canvas.height;

        this.context.fillStyle = color;
        this.context.strokeStyle = strokeColor;
        this.context.lineWidth = +strokeWidth;
    }

    draw() {}

    set color(value) {
        this.context.fillStyle = value;
        this.draw();
    }

    set strokeColor(value) {
        this.context.strokeStyle = value;
        this.draw();
    }
}
// класс для рендеринга прямоугольника
class Rectangle extends Shape{
    constructor(id, w, h, color, strokeColor, strokeWidth) {
        super(id, color, strokeColor, strokeWidth)
        this.w = +w;
        this.h = +h;
    }

    draw() {
        this.context.clearRect(0, 0, this.cW, this.cH);
        this.context.fillRect(this.cW / 2 - this.w / 2, this.cH / 2 - this.h / 2, this.w, this.h);
        this.context.strokeRect(this.cW / 2 - this.w / 2, this.cH / 2 - this.h / 2, this.w, this.h);
    }

    set width(value) {
        this.w = value;
        this.draw();
    }

    set height(value) {
        this.h = value;
        this.draw();
    }
}
// класс для рендеринга треугольника
class Triangle extends Rectangle {
    constructor(id, w, h, color, strokeColor, strokeWidth) {
        super(id, w, h, color, strokeColor, strokeWidth)
    }

    draw() {
        this.context.clearRect(0, 0, this.cW, this.cH);
        let triangle = new Path2D();
        triangle.moveTo(this.cW / 2,this.cH / 2 - this.h / 2);
        triangle.lineTo(this.cW / 2 + this.w / 2, this.cH / 2 + this.h / 2);
        triangle.lineTo(this.cW / 2 - this.w / 2, this.cH / 2 + this.h / 2);
        triangle.lineTo(this.cW / 2,this.cH / 2 - this.h / 2);
        this.context.fill(triangle);
        this.context.stroke(triangle);
    }
}
// класс для рендеринга круга
class Circle extends Shape{
    constructor(id, r, color, strokeColor, strokeWidth) {
        super(id, color, strokeColor, strokeWidth)
        this.r = +r;
    }

    draw() {
        this.context.clearRect(0, 0, this.cW, this.cH);
        this.context.beginPath();
        this.context.arc(this.cW / 2,this.cH / 2, this.r, 0, 2 * Math.PI, false);
        this.context.fill();
        this.context.stroke();
    }

    set radius(value) {
        this.r = value;
        this.draw();
    }
}

const shapes = {};

window.addEventListener('load', loadHandler);
function loadHandler() {

    shapes.rectangle = new Rectangle("rectangle", $('inpRectWidth').value, $('inpRectHeight').value,
        $('inpRectColor').value, $('inpRectStrokeColor').value, 3);

    shapes.triangle = new Triangle("triangle", $('inpTriangleWidth').value, $('inpTriangleHeight').value,
        $('inpTriangleColor').value, $('inpTriangleStrokeColor').value, 3);

    shapes.circle = new Circle("circle", $('inpCircleRadius').value, $('inpCircleColor').value,
        $('inpCircleStrokeColor').value, 3);

    shapes.rectangle.draw();
    shapes.triangle.draw();
    shapes.circle.draw();

    document.addEventListener("input", (e) => {
        // запрет ввода недопустимых значений
        if(+e.target.value > +e.target.max)
            e.target.value = e.target.max;
        if(+e.target.value < +e.target.min)
            e.target.value = e.target.min;

        // изменение свойства фигуры
        shapes[e.target.dataset.shape][e.target.dataset.prop] = e.target.value;
    })
}

