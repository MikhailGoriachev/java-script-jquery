/*
* Задача 2.
* Сформировать массив фильмов в фильмотеке (использовать классы, фильмов
* не менее 10, хранить в локальном хранилище, фильм описывается названием,
* фамилией и инициалами режиссера, жанром, годом выпуска).
* Вывести фильмы в таблицу.
* По командным кнопкам, при помощи функции css() выделить строки таблицы с заданными:
*     • жанрам
*     • режиссера
*     • году выпуска
* */

// при загрузке страницы
$(() => {
    // создать объект-фильмотеку
    const filmLibrary = new FilmLibrary('Фантастические фильмы Бартковой Кристины', []);

    // если объект есть в хранилище - читаем данные из хранилища,
    // иначе - создать массив данных, сохранить его в хранилище
    if (window.localStorage.filmLibrary) {
        filmLibrary.load();
    } else {
        filmLibrary.movies = [
            new Movie( 1, 'Терминатор', 'Джеймс Кэмерон', 'триллер', 1984),
            new Movie( 2, 'Терминатор 2', 'Джеймс Кэмерон', 'триллер', 1991),
            new Movie( 3, 'Супермен', 'Ричард Доннер', 'фантастика', 1978),
            new Movie( 4,'Чужие', 'Джеймс Кэмерон', 'триллер', 1986),
            new Movie( 5, 'Супермен 2', 'Ричард Лестер', 'триллер', 1980),
            new Movie( 6, 'Чужой 4: Воскрешение', 'Жан-Пьер Жёне', 'триллер', 1997),
            new Movie( 7, 'Чужой', 'Риддли Скотт', 'триллер', 1979),
            new Movie( 8, 'Чужой 3', 'Дэвид Финчер', 'триллер', 1992),
            new Movie( 9, 'Люди в черном 2', 'Барри Зонненфельд', 'комедия', 2002),
            new Movie(10, 'Хищник', 'Джон Мактирнан', 'ужасы', 1987),
            new Movie(11, 'Хищник 2', 'Стивен Хопкинс', 'боевик', 1990),
            new Movie(12, 'Люди в черном', 'Барри Зонненфельд', 'комедия', 1997),
        ];
        filmLibrary.store();
    } // if

    // начальный вывод фильмотеки
    filmLibrary.show();

    // По клику на кнопку выводим данные фильмотеки без выделения
    $("#btnSrcData").click( () => filmLibrary.show() );


    // По клику на кнопку выделить фильмы с заданным жанром
    // при помощи фильтра контента jQuery), снимайте выделение через 10 с
    $("#btnSelectByGenre").click(() => {
        let genre = $("#navGenre").val();

        $("#title").html(`${filmLibrary.name}, выделены фильмы с жанром <u>${genre}</u>`);
        // $(`tr:contains('${genre}')`).toggleClass("mark-row");
        $(`tr:contains('${genre}')`).css("background-color", "linen");

        // снятие выделения, вывод исходного массива через timeOut мс
        let timeOut = 10_000;
        setTimeout(() => restore(genre), timeOut);
    });

    // По клику на кнопку выделить фильмы с заданным режиссером
    // при помощи фильтра контента jQuery), снимайте выделение через 10 с
    $("#btnSelectByProducer").click(() => {
        let producer = $("#navProducer").val();

        $("#title").html(`${filmLibrary.name}, выделены фильмы режиссера <u>${producer}</u>`);
        // $(`tr:contains('${producer}')`).toggleClass("mark-row");
        $(`tr:contains('${producer}')`).css("background-color", "linen");

        // снятие выделения, вывод исходного массива через timeOut мс
        let timeOut = 10_000;
        setTimeout(() => restore(producer), timeOut);
    });

    // По клику на кнопку выделить фильмы с заданным годом выпуска
    // при помощи фильтра контента jQuery), снимайте выделение через 10 с
    $("#btnSelectByYear").click(() => {
        let year = $("#navYear").val();

        $("#title").html(`${filmLibrary.name}, выделены фильмы с годом выпуска <u>${year}</u>`);
        // $(`tr:contains('${year}')`).toggleClass("mark-row");
        $(`tr:contains('${year}')`).css("background-color", "linen");

        // снятие выделения, вывод исходного массива через timeOut мс
        let timeOut = 10_000;
        setTimeout(() => restore(year), timeOut);
    });

    // снятие класса mark-row
    function restore(value) {
        $("#title").html(`${filmLibrary.name}`);
        // $(`tr:contains('${value}')`).toggleClass("mark-row");
        $(`tr:contains('${value}')`).css("background-color", "transparent");
    } // restore
});