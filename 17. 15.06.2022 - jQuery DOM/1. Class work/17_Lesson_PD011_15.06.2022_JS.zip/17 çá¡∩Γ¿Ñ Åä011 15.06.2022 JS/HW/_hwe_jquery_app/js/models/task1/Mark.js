/*
* Задача 1.
* Описать класс Mark, содержащий поля:
*     • название предмета, оценка
*     • оценка (1, ..., 5)
*
* */
class Mark {
    constructor(subject = 'FP', value= 5) {
        this._subject = subject;
        this._value = value;
    } // constructor


    //region Аксессоры класса
    get subject() { return this._subject;   }
    set subject(value) {
        this._subject = value >= 1 && value <= 5?value:this._subject;
    }

    get value() { return this._value; }
    set value(value) {
        this._value = value.length > 0?value:this._value;
    }
    //endregion
} // class Mark