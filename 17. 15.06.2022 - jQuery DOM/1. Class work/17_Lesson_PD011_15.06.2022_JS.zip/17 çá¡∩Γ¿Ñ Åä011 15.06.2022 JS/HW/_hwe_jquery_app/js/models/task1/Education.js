/* Класс, описывающий учебное заведение */

class Education {
    constructor(name, students) {
        this._name = name;
        this._students = students;
    } // constructor


    //region Аксессоры класса
    get name() { return this._name; }
    set name(value) {
        this._name = value;
    }

    get students() { return this._students; }
    set students(value) {
        this._students = value;
    }
    //endregion
} // class Education