/*
* Задача 1.
* Описать класс Student, содержащий поля:
*     • фамилия и инициалы;
*     • пол студента;
*     • фотография студента (заранее подготовленные файлы, с именами man001,
*       woman001 и т.д. Имя файла генерируется в зависимости от пола студента);
*     • название группы;
*     • успеваемость (массив из пяти элементов типа Mark)
*     • Mark – класс: название предмета, оценка
*
* */
class Student {
    constructor(id, fullName = 'Иванов И.И.', gender = true, group = 'ПУ011',
                marks = [new Mark(), new Mark(), new Mark(), new Mark(), new Mark()]) {
        this._id = id;
        this._fullName = fullName;
        this._gender = gender;
        this._group = group;
        this._marks = marks;

        this._photo = this._generatePhoto();
    } // constructor

    // сгенерировать имя файла с фотографией в зависимости от пола студента
    _generatePhoto() {
        let suffix = `${getIntRand(1, 10)}`.padStart(3, '0');
        return `${this.gender?'':'wo'}man${suffix}.jpg`;
    } // _generatePhoto

    // присваивание одноименных полей объекта s, используем при десериализации из JSON
    assign(s) {
        Object.assign(this, s);
        return this;
    } // assign


    //region Аксессоры для свойств класса
    get fullName() {  return this._fullName; }
    set fullName(value) {
        this._fullName = value;
    }

    get gender() { return this._gender; }
    set gender(value) {
        this._gender = value;
        this._photo = _generatePhoto();
    }

    get group() { return this._group; }
    set group(value) {
        this._group = value;
    }

    get marks() { return this._marks;  }
    set marks(value) {
        this._marks = value;
    }
    //endregion

    // формирование строки с данными объекта для вывода в разметку
    // идентификаторы кнопок управления содержат маркеры действия (btnEdit или btnRemove) и
    // собственно идентификатор записи
    toTableRow(row) {return `
        <tr id="stdn${row}">
        <td>${this._id}</td>
        <td><img src="../images/task1/${this._photo}" alt="${this._photo}"</td>
        <td class="align-left">${this._fullName}</td>
        <td class="align-left">${this._gender?'муж.':'жен.'}</td>
        <td class="align-left">${this._group}</td>
        ${this.marksToCells()}</td>
        <td class="align-left">
            <button data-edt="${this.id}" title="Редактирование данных студента">
                <i data-edt="${this.id}" class="fa fa-edit fa-2x"></i>
            </button>
            <button data-del="${this.id}" title="Удаление данных студента">
                <i data-del="${this.id}" class="fa fa-recycle fa-2x"></i>
            </button>
        </td>
        </tr>`;
    } // toTableRow

    // формирование ячеек таблицы с оценками
    marksToCells() { return this._marks.reduce((acc, mark) => `<td>${mark.value}</td>`, ''); }

    // для элемента массива формируем идентификатор, находим соответствующую строки таблицы
    // и меняем ее оформление, если на элементе массива сработает предикат
    toTableRowMark(row, predicate) {
        if (predicate(this))
            $(`#stdn${row}`).addClass("mark-row");
    } // toTableRowMark
} // class Student