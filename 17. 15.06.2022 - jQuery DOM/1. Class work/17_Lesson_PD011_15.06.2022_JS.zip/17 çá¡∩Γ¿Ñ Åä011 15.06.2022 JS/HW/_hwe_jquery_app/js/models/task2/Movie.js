/* Класс, описывающий фильм:
*     • название фильма,
*     •  фамилия и инициалЫ режиссера
*     •  жанр
*     •  год выпуска
* */
class Movie {
    constructor(id, title, producer, genre, year) {
        this.id       = id;
        this.title    = title;
        this.producer = producer;
        this.genre    = genre;
        this.year     = year;
    } // constructor


    //region Аксессоры класса
    get id() { return this._id; }
    set id(value) { this._id = value; }

    get title() { return this._title; }
    set title(value) {
        this._title = value;
    }

    get producer() { return this._producer; }
    set producer(value) {
        this._producer = value;
    }

    get genre() { return this._genre; }
    set genre(value) {
        this._genre = value;
    }

    get year() { return this._year; }
    set year(value) {
        this._year = value <= new Date().getFullYear()?value:this._year;
    }
    //endregion

    // вывод в строку таблицы, номер строки передаем параметром
    toTableRow(row) { return `
        <tr id="movie${row}">
            <td>${row}</td>
            <td>${this.id}</td>
            <td class="align-left">${this.title}</td>
            <td class="align-left">${this.producer}</td>
            <td class="align-left">${this.genre}</td>
            <td class="align-right">${this.year}</td>
       </tr>`
    } // toTableRow

    // присваивание одноименных полей объекта m, используем при десериализации из JSON
    assign(m) {
        Object.assign(this, m);
        return this;
    } // assign
} // class Movie