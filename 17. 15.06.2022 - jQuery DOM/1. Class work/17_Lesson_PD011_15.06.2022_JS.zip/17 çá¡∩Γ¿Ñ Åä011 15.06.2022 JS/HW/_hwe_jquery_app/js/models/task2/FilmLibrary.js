/* Класс, описывающий фильмотеку
*     • название фильмотеки
*     • коллекция фильмов
*  */
class FilmLibrary {
    constructor(name = 'Коллекция фильмов Юрчихина А.В.', movies = []) {
        this.name = name;
        this.movies = movies;
    } // constructor


    //region Аксессоры класса
    get name() { return this._name; }
    set name(value) {
        this._name = value;
    }

    get movies() { return this._movies; }
    set movies(value) {
        this._movies = value;
    }
    //endregion

    // вывод названия фильмотеки и коллекции фильмов в разметку по кликам на кнопки
    show() {
        $("#title").text(this._name);
        let row = 1;
        $("#movies").html(this._movies.reduce((acc, f) => acc + f.toTableRow(row++), ""));
    } // show

    // сохранение данных в локальном хранилище, если данных там еще нет
    store() {
        window.localStorage.filmLibrary = JSON.stringify(this);
    } // store

    // загрузка данных из локального хранилища
    load() {
        // прочитать строку из хранилища и распарсить ее в объект
        let temp = JSON.parse(window.localStorage.filmLibrary);

        // сохранить название авиакомпании
        this._name = temp._name;

        // сформировать коллекцию фильмов из сохраненных данных
        this._movies = [];
        temp._movies.forEach(m => this._movies.push(new Movie().assign(m)));
    } // load
} // class FilmLibrary