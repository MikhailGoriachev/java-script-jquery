//region Студенты
//Заявка
class Student {


    //region Геттеры. Сеттеры
    get gender() {
        return this._gender;
    }

    set gender(value) {
        this._gender = value;
    }

    get performance() {
        return this._performance;
    }

    set performance(value) {
        this._performance = value.length===5?value:generateMarks();
    }

    get studentSNP() {
        return this._studentsSNP;
    }

    set studentSNP(value) {
        this._studentsSNP = value;
    }

    get photoFile() {
        return this._photoFile;
    }
    //endregion

    get avgMark()
    {
        let avg = this._performance.reduce((acc,m) => acc+m.mark,0)/this._performance.length;
        return avg;
    }

    //Свойства
    constructor(id,group,gender,marks) {
        this.studentId = id;
        this.studentSNP = generateSNP(gender);
        this.groupName = group;

        this._photoFile = gender.toLowerCase().includes('муж')?`man_0${id<10?(`0${id}`):(`${id}`)}.jpg`:`woman_0${id<10?(`0${id}`):(`${id}`)}.jpg`;
        this.performance = marks;
        this.gender = gender;
    }


    //Вывод
    toHtml () {
        return `<div float: left id="${this.studentId}" class="student-block">
                        <div><img class="student-photo" src="../images/students/${this._photoFile}" alt=""></div>
                        <div><span>ФИО студента: <b>${this._studentsSNP}</b></div>
                        <div><span>Пол: <b>${this._gender}</b></div>
                        <div><span>Название группы: <b>${this.groupName}</b></div>
                        <details class="marks">
                            <summary>Успеваемость</summary>
                                <div class="performance-block">
                                      <ol>
                                        <li>${this._performance[0].subject} - <b>${this._performance[0].mark}</b> </li>
                                        <li>${this._performance[1].subject} - <b>${this._performance[1].mark}</b> </li>
                                        <li>${this._performance[2].subject} - <b>${this._performance[2].mark}</b> </li>
                                        <li>${this._performance[3].subject} - <b>${this._performance[3].mark}</b> </li>
                                        <li>${this._performance[4].subject} - <b>${this._performance[4].mark}</b> </li>
                                      </ol>
                                      
                                </div>
                            </details>
                        <div>
                            Средний бал: ${this.avgMark.toFixed(1)}
                        </div>
                        <div>
                            <input class="btn-change" id="change_${this.studentId}" type="button" value="Изменить">
                            <input class="btn-delete" id="delete_${this.studentId}" type="button" value="Удалить">
                         
                        </div>
                </div>`
    }

    assign(student){
        Object.assign(this,student)
        return this;
    }
}

//Управление заявками
class StudentsCollection {
    constructor(studentsArr) {
        this.students = studentsArr;
    }

    //Генерация массива заявок
    static generateWorkers() {
        let array = [];

        for (let i = 0; i < 10; i++) {
            array[i] = new Student(i+1,generateGroup(),getGender(),generateMarks())
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(studentsArr) {

        let str = studentsArr.reduce((acc,worker) => acc+worker.toHtml(),'');

        return str;
    }
    //Запись в localStore
    writeToLocal(){
        window.localStorage.studentsCollection = JSON.stringify(this);
    }

    //Чтение из LocalStore
    getFromLocal(){
        this.students = []
        let collection = JSON.parse(window.localStorage.studentsCollection);

        let n = 0;
        for (let elem of collection.students) {
            let student = new Student('','','',[]);
            Object.assign(student,elem);

            //Почему-то объект JSON не может спарсить коллекцию оценок, так что задаём новые значения
            student.performance = generateMarks();

            this.students.push(student);
        }
    }
}

class Mark {
    get subject() {
        return this._subject;
    }

    set subject(value) {
        this._subject = value;
    }

    get mark() {
        return this._mark;
    }

    set mark(value) {
        this._mark = value>=5 && value<=1 ? value : getRandom(2,6);
    }
    constructor(subject,mark) {
        this.subject = subject;
        this.mark = mark;
    }
}
//endregion