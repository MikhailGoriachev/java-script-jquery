
//region Фильмы
//Фильм
class Movie {
    //Свойства
    constructor(id,name,directorSnp,genre,prodYear) {
        this.movieId = id;
        this.name = name;
        this.director = directorSnp;
        this.genre = genre;
        this.prodYear = prodYear;
    }


    //Вывод
    toTableRow () {
        return `
                <tr>
                    <td>${this.name}</td>
                    <td>${this.genre}</td>
                    <td>${this.director}</td>
                    <td>${this.prodYear}</td>
                </tr>`
    }

}

//Управление заявками
class MoviesCollection{
    constructor(moviesArr) {
        this.movies = moviesArr;
    }

    //Генерация массива заявок
    static generateMovies() {
        let array = [];

        for (let i = 0; i < 10; i++) {
            array[i] = new Movie(i+1,generateMovieName(),generatePerson(),generateMovieGenre(),getRandom(1980,2020))
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(moviesArr) {
        let n = 0;
        let str = `
        <table>
        <tr>
            <th>Название</th>
            <th>Жанр</th>
            <th>Режессер</th>
            <th>Год выпуска</th>
        </tr>`;
        str += moviesArr.reduce((acc,claim) => acc+claim.toTableRow(n++),'');
        str += `</table>`

        return str;
    }

    //Запись в localStore
    writeToLocal(){
        window.localStorage.moviesCollection = JSON.stringify(this);
    }

    getFromLocal(){
        this.movies = []
        let collection = JSON.parse(window.localStorage.moviesCollection);

        for (let elem of collection.movies) {
            let movie = new Movie('','',0,'',0);

            //Присваем свойтсва из локальной записи обекту
            Object.assign(movie,elem);
            this.movies.push(movie);
        }
    }
}
//endregion
