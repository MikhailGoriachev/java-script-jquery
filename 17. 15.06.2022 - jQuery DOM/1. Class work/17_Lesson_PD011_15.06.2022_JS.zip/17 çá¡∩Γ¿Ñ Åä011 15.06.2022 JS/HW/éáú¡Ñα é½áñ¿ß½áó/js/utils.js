
//Получение случайного значения
function getRandom(lo,hi) {
    return Math.trunc((hi-lo) * Math.random() + lo);
}

//region Фильмы

function generateMovieName() {
    let names = [
        'Люди в черном',
        'Мирный воин',
        'В погоне за счастьем',
        'Империя соблазна',
        'Игры разума',
    ];
    return names[getRandom(0,names.length)]
}
function generateMovieGenre() {
    let genres = [
        'Документальный',
        'Жудожественный',
        'Биографичесий',
        'Науч-поп',
    ];
    return genres[getRandom(0,genres.length)]
}

//Функция возвращает объект
function generatePerson() {

    //Список персон
    let people = [
        'Лосева И.С.',
        'Михалков А.В.',
        'Пелых М.У.',
        'Пономаренко Л.А.',
        'Хавалджи В.Д.',
        'Пархоменко И.В.',
        'Демидова А.А.',
        'Лапотникова О.Т.',
        'Чмыхало О.Т.',    ];

    return people[getRandom(0,people.length)];
}//generatePerson


//endregion


function generateSNP(gender) {

    //Список мужских фамилий
    let men = [
        'Михалков А.В.',
        'Пелых М.У.',
        'Пономаренко Л.А.',
        'Хавалджи В.Д.',
        'Пархоменко И.В.',
        'Чмыхало О.Т.',    ];

    //Список женских фамилий
    let women = [
        'Лосева И.С.',
        'Пелых А.С.',
        'Пономаренко Л.А.',
        'Хавалджи В.Д.',
        'Пархоменко И.В.',
        'Демидова А.А.',
        'Лапотникова О.Т.',
        'Чмыхало О.Т.',];

    if (gender.toLowerCase().includes('муж'))
        return men[getRandom(0,men.length)]

    return women[getRandom(0,women.length)];
}//generatePerson

//region Студенты

function generateGroup() {

    //Список приставок
    let prefix = [
        'АМ',
        'ВМИ',
        'АП',
        'ФТ',
    ];

    let groupNum = getRandom(1,99);
    let truncNum = groupNum>10?Math.trunc(groupNum/10)*10:groupNum;

    return `${prefix[getRandom(0,prefix.length)]}${truncNum%10===0?`0${groupNum}`:`00${groupNum}`}`;
}//generatePerson

//Оценки
function generateMarks() {
    let marks = [
        new Mark('Матан',getRandom(2,5)),
        new Mark('Английский',getRandom(2,6)),
        new Mark('Алгоритмы',getRandom(2,6)),
        new Mark('Основы C++',getRandom(2,6)),
        new Mark('Основы WPF',getRandom(2,6)),
    ];
    return marks;
}

//Должности
function getGender() {
    let gender = [
        "Мужской",
        "Женский",,
    ];

    return gender[getRandom(0,gender.length-1)];
}

//Зар.плата
function generateSalary() {
    return getRandom(800,8000);
}


//endregion


function getNumFromStr(str) {

    if (/\D+/.test(str))
        str = str.replace(/\D+/,'');

    if (!isNaN(parseInt(str)))
        return parseInt(str);

    //Если ничего не найдено
    return 1e-10
}

function getBlockChildren(block) {
    //Получаем массив дочерних элементов общего блока
    let childNodes = [];

    let elements = block.find('div');
    for (let elem of elements) {
        childNodes.push(elem);
    }

    return childNodes;
}

function fillFromLocalStore(form) {
    let formInputs = form.getElementsByTagName('input');

    //Запись в поля если есть данны
    for (let input of formInputs) {
        if (window.localStorage[input.id])
            input.value = window.localStorage[input.id];
    }
}

function writeFieldsToLocal(form) {
    for (let input of form.getElementsByTagName('input')) {
        if(input.type !== 'button' && input.type !== 'reset')
            window.localStorage[`${input.id}`] = input.value;
    }
}
