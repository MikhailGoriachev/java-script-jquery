
//Функция с самовызовом
$(function (){

    let mainBlock = $('#mainDiv');

    //Работники
    let moviesCollection = new MoviesCollection([]);
    let movies = [];

    //region Чтение и запись в локальное хранилище
    if (window.localStorage.moviesCollection) {
        moviesCollection.getFromLocal();
        movies = moviesCollection.movies;
    }
    else {
        moviesCollection.movies = MoviesCollection.generateMovies();
        moviesCollection.writeToLocal();
        movies = moviesCollection.movies;
    }
    //endregion
    let title = $('#taskTitle');


    let inputField = $("#inputProdYear");
    let btnSearch =  $("#highlightByProdYear");
    let lastFormedCollection = movies;

    //Обект таймера
    let timer = 0;

    //Обработчик кнопки вывода исходного массива
    let showDefaultArr = function () {
        mainBlock.html(MoviesCollection.createMarkup(movies));
        title.html(`<span>Исходный массив</span>`);
        lastFormedCollection = movies;

    }
    showDefaultArr();

    $('#cleanLocalStore').click(() => window.localStorage.removeItem('moviesCollection'));


    //region Поведение кнопки поиска
    //При выходе из поля ввода убираем записи и кнопку

    function focusMouseOutHandler(field) {

        let inputValue = field.value;

        //Если поле пустое или состоит из пробелов
        if (inputValue === "" ) {

            btnSearch.css('visibility','hidden');
            btnSearch.prop('disabled',false);
        }

    }

    //Обработчики на покидание мыши и выход из фокуса
    inputField.focusout((e) => focusMouseOutHandler(e.target));
    inputField.mouseout((e) => focusMouseOutHandler(e.target));

    //endregion

    //Валидация при вводе

    //Включить кнопку поиска
    inputField.change((e) => {
        btnSearch.css('visibility','visible');
        btnSearch.prop('disabled',false);
    })

    //region Выделение через JQuery

    let selectGenre = $('#selectGenre');
    let selectDirector = $('#selectDirector');

    function loadSearchSelections() {

        //Выбираем уникальные значения должностей и лет поступления
        let strGenres = [...new Set(movies.map(m =>m.genre))].reduce((acc,genre) => acc + `<option>${genre}</option>`,'');
        let strDirectors = [...new Set(movies.map(m =>m.director))].sort().reduce((acc,director) => acc + `<option>${director}</option>`,'');

        selectGenre.html(strGenres);
        selectDirector.html(strDirectors);
    }


    loadSearchSelections();

    function highlightByJquery(strToHighlight,colNumber) {

        showDefaultArr();
        //Находим таблицы с определённым содержанием
        let foundRow = $(`tr:has(td:nth-child(${colNumber}):contains('${strToHighlight}'))`);


        console.log(`Найденная строка (содержит ${strToHighlight}): ${foundRow.html()}`);

        foundRow.addClass('highlightRow');

        clearTimeout(timer);

        //После истечения таймера перепишем коллекцию
        timer = setTimeout(() => foundRow.toggleClass('highlightRow')/*showDefaultArr()*/,10_000)
    }


    selectGenre.change((e) => highlightByJquery(e.target.value,2));
    selectDirector.change((e) => highlightByJquery(e.target.value,3));
    btnSearch.click(() => highlightByJquery(inputField.val(),4));

    //endregion


});
