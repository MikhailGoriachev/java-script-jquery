

$(function(){
    let $studentForm = $("#studentForm");
    let $modalWindow =  $("#modalWindow");
    let $selMarkGroup = $("#selMarkGroup");
    let $subjectSelects = $("[name^='subject']");

    // установка обработчиков
    $("#btnSrcData").click(outputSourceData);
    $("#btnCancel").click(closeModalWindow);
    $("#closeModal").click(closeModalWindow);
    $(this).click(onClick);
    $studentForm.on("submit", onSubmitHandler);
    $("#btnNewStudent").click(onNewStudent);

    // выделения
    $("#btnMarkGrade2").click(markGrade2);
    $("#btnMarkGrades4and5").click(markGrades4and5);
    $("#btnMarkGroup").click(markGroup);

    // сортировки
    $("#btnOrderByFullName").click(orderByFullName);
    $("#btnOrderByAvgGrade").click(orderByAvgGrade);
    $("#btnOrderByGroup").click(orderByGroup);

    let academy = new Academy();

    // инициализация
    if(window.localStorage.academy) {
        academy.load();
    } else {
        academy.students = StudentFactory.generateCollection(10);
        academy.store();
    }

    // рендеринг
    academy.show("Список студентов")

    // заполнение списка  выбора группы
    academy.getGroupsList().forEach(g => $selMarkGroup.append($('<option>', {value: g}).text(g)));
    // заполнение списков выбора предметов на форме
    StudentFactory.subjects.sort().forEach(s => $subjectSelects.append($('<option>', {value: s}).text(s)));


    //region  Функции

    // вывести исходные данные
    function outputSourceData() {
        academy.show("Список студентов")
    }
    // упорядочить по возрастанию среднего балла
    function orderByAvgGrade() {
        Academy.show("Список студентов, упорядочен по возрастанию среднего балла", academy.orderByAvgGrade());
    }
    // упорядочить по названию группы
    function orderByGroup() {
        Academy.show("Список студентов, упорядочен по названию группы", academy.orderByGroup());
    }
    // упорядочить по фамилии и инициалам
    function orderByFullName() {
        Academy.show("Список студентов, упорядочен по фамилии и инициалам", academy.orderBySurname());
    }

    // выделение студентов, имеющих хотя бы одну оценку 2
    function markGrade2() {
        clearMarked();
        $(`li[id^='st']:has(div[class='grade']:contains('2'))`, "#students").addClass('hl-row');
    }
    // выделение студентов, имеющих оценки 4 и 5
    function markGrades4and5() {
        clearMarked();

        $(`li[id^='st']:has(div[class='grade']:contains('5')):has(div[class='grade']:contains('4'))`, "#students")
            .addClass('hl-row');

        // разбитая фильтрация
        //$(`li[id^='st']`, "#students")
        //    .has("div[class='grade']:contains('5')")
        //    .has("div[class='grade']:contains('4')")
        //    .addClass('hl-row');
    }

    // выделение студентов заданной группы
    function markGroup() {
        let value = $selMarkGroup.val();
        if(!value) return;

        clearMarked();
        $(`li[id^='st']:has(div[class*='st-group']:contains(${value}))`, "#students").addClass('hl-row');
    }

    // убрать выделение
    function clearMarked() {
        $(".hl-row", "#students").removeClass('hl-row');
    }

    // обработчик нажатия кнопки мыши
    function onClick(e) {
        if (e.target === $modalWindow[0])
            closeModalWindow();
        if(e.target.dataset.edt)
            onEditStudent(e.target.dataset.edt);
        if(e.target.dataset.del)
            onDeleteStudent(e.target.dataset.del);
    }

    // спрятать окно с формой
    function closeModalWindow() {
        $modalWindow.hide();
    }

    // вызов добавления нового сотрудника
    function onNewStudent() {
        $studentForm.trigger("reset");
        $("#formTitle").html("Добавить данные студента");
        $("#btnAddStudent").val("Добавить");
        $modalWindow.show();
    }

    // обработчик удаления данных о студенте
    function onDeleteStudent(id) {
        let name = academy.getById(id).fullName;
        academy.deleteStudent(id);
        academy.show(`Удалены данные студента ${name}`);
        academy.store();
    }

    // вызов редактирования данных студента
    function onEditStudent(id) {
        let student = academy.getById(id);

        $("#idStudent").val(id);
        $("#inpName").val(student.fullName);
        $("#selGender").val(student.gender);
        $("#inpGroup").val(student.group);

        let subjects = $subjectSelects;
        let grades = $("[name$='Grade']");
        for(let i = 0; i < student.marks.length; i++) {
            subjects[i].value = student.marks[i].subject;
            grades[i].value = student.marks[i].grade;
        }

        $("#formTitle").html("Изменить данные студента");
        $("#btnAddStudent").val("Изменить");

        $modalWindow.show();
    }

    // обработчик подтверждения на форме
    function onSubmitHandler(event){
        let fullName = this.fullName.value;
        let gender = this.gender.value;
        let group = this.group.value;
        let id = this.idStudent.value;

        let subjects = $subjectSelects;
        let grades = $("[name$='Grade']");
        let marks = [];
        for(let i = 0; i < subjects.length; i++)
            marks.push(new Mark(subjects[i].value, grades[i].value));

        if(this.submit.value === "Добавить") {
            academy.addStudent(fullName, gender, group, marks);
            academy.show(`Студент ${fullName} добавлен в конец списка`);
            academy.store();
        }

        if(this.submit.value === "Изменить") {
            academy.updateStudent(id, fullName, gender, group, marks);
            academy.show(`Данные студента ${fullName} обновлены`);
            academy.store();
        }

        closeModalWindow()
        event.preventDefault();
    }
    //endregion
})
