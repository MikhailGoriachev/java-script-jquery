

$(function(){
    // цвет для выделения строк
    let hlColor = "rgba(147, 112, 219, .4)";

    let library = new MovieLibrary();

    // инициализация
    if(window.localStorage.movies) {
        library.load();
    } else {
        library.movies = [
            new Movie(1,"Брат-2",                		"Балабанов А.О.", "боевик", 	2000),
            new Movie(2,"Дюна",                  		"Вильнев Д."  	 , "фантастика", 2021),
            new Movie(3,"Сестры",                		"Бодров С.С."   , "драма", 		2001),
            new Movie(4,"Амнезия",               		"Черняев А.И."  , "триллер", 	2019),
            new Movie(5,"Довод",                 		"Нолан К."    	 , "фантастика", 2020),
            new Movie(6,"Майор Гром: Чумной Доктор", 	"Трофим О.Б." 	 , "боевик", 	2021),
            new Movie(7,"Огонь",                     	"Нужный А.Н."	 , "драма", 		2020),
            new Movie(8,"Воспоминание",              	"Джой Л."		 , "фантастика", 2021),
            new Movie(9,"Догвиль",                   	"Триер Л."		 , "триллер",	2003),
            new Movie(10,"Револьвер",                 	"Ричи Г."		 , "боевик", 	2005),
            new Movie(11,"Большой куш",               	"Ричи Г."		 , "криминал", 	2005),
        ];
        library.store();
    }


    // заполнение списка жанров
    library.getGenresList().forEach(g => $("#selGenre").append($('<option>', {value: g}).text(g)));

    // рендеринг таблицы
    $('#movies').html(library.toTable());

    // выделить строки таблицы с заданными жанрами
    $('#btnMarkGenre').click(() => {
        clearMarked();
        $(`tr:has(td[class*='m-genre']:contains(${$('#selGenre').val()}))`, "#movies")
            .css("background-color", `${hlColor}`);
    })

    // выделить строки таблицы: с заданным режиссером
    $('#btnMarkDirector').click(() => {
        let value = $('#inpDirector').val();
        if(!value) return;

        clearMarked();
        $(`tr:has(td[class*='m-dir']:contains(${value}))`, "#movies")
            .css("background-color", `${hlColor}`);
    })

    // выделить строки таблицы с заданным годом выпуска
    $('#btnMarkYear').click(() => {
        let value = $('#inpYear').val();
        if(!value) return;

        clearMarked();
        $(`tr:has(td[class*='m-year']:contains(${value}))`, "#movies")
            .css("background-color", `${hlColor}`);
    })

    // убрать выделение
    function clearMarked() {
        $("tr", "#movies").even().css("background-color", "aliceblue")
        $("tr", "#movies").odd().css("background-color", "white")
    }
})