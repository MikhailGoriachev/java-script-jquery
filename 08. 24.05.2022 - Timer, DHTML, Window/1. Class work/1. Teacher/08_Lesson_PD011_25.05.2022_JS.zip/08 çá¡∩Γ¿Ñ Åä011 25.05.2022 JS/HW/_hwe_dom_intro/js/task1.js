/*
* Задача 1.
* Разработайте иерархию классов в синтаксисе ES6+ для представления объемных
* тел - сферы, конуса, цилиндра, куба. Разработайте методы для вычисления
* площади поверхности, объема фигуры, вывода данных по фигуре и сравнения
* объемных тел по объему. Разработайте геттеры и сеттеры с контролем
* корректности присваиваемых данных. Некорректные данные заменяйте значениями
* по умолчанию, сообщения об ошибках не нужны, исключения пока не используем.
* Выводите также изображения объемных фигур.
* Сформируйте массив объектов этих классов - по 2 объекта каждого типа.
* По командам, назначенным на кнопки, отсортируйте копию массива по убыванию
* объемов, по возрастанию площадей поверхности, выводите исходный массив
* объемных тел.
*
* */

// сфера - играет роль базового класса
class Sphere {
    constructor(r) {
        // радиус
        this.r = r;
    }

    // геттер и сеттер для радиуса
    get r() { return this._r; }
    set r(value) {
        this._r = value <= 0?1:value;
    } // set

    // объем шара
    // https://www-formula.ru/2011-09-21-10-52-47
    getVolume() { return 4 * Math.PI * this.r**3 / 3; }

    // площадь поверхности сферы
    // https://www-formula.ru/2011-09-21-04-30-33
    getArea() { return  4 * Math.PI * this.r**2; }

    // компаратор для сравнения тел по объему
    compareTo(s1, s2) { return s1.getVolume() - s2.getVolume(); }

    // представление объекта в формате HTML
    toTableRow(row) { return `
        <tr>
            <td>${row}</td>
            <td class="align-center"><img src="../images/task1/sphere.png" alt="Сфера" width="90"/></td>
            <td class="align-left">r: ${this.r.toFixed(3)}</td>
            <td>${this.getArea().toFixed(3)}</td>
            <td>${this.getVolume().toFixed(3)}</td>
        </tr>`;
    }
} // Sphere


// конус
class Cone extends Sphere {
    constructor(r, h) {
        super(r);

        // собственное свойство класса - высота конуса
        this.h = h;
    }

    // высота конуса
    get h() { return this._h; }
    set h(value) {
        this._h = value <= 0?1:value;
    }

    // объём конуса
    // https://www-formula.ru/2011-09-21-10-55-09
    getVolume() { return Math.PI * this.r**2 * this.h / 3; }

    // площадь поверхности конуса
    // https://www-formula.ru/2011-09-21-04-34-19
    getArea() { return  Math.PI * this.r * (this.r + Math.sqrt(this.r**2 + this.h**2)); }

    // компаратор для сравнения тел по объему
    compareTo(s1, s2) { return s1.getVolume() - s2.getVolume(); }

    // для полиморфизма реализуем представление объекта в формате HTML
    // в функции с тем же именем, что и базового класса
    toTableRow(row) { return `
        <tr>
            <td>${row}</td>
            <td class="align-center"><img src="../images/task1/cone.png" alt="Конус" width="90"/></td>
            <td class="align-left">r: ${this.r.toFixed(3)}; h: ${this.h.toFixed(3)}</td>
            <td>${this.getArea().toFixed(3)}</td>
            <td>${this.getVolume().toFixed(3)}</td>
        </tr>`;
    }
    
} // Cone


// цилиндр 
// https://www-formula.ru/2011-09-21-10-54-43
class Cylinder extends Sphere {
    constructor(r, h) {
        super(r);

        // собственное свойство класса - высота цилиндра
        this.h = h;
    }

    // высота цилиндра
    get h() { return this._h; }
    set h(value) {
        this._h = value<= 0?1:value;
    }

    // объем цилиндра
    // https://www-formula.ru/2011-09-21-10-54-43
    getVolume() { return Math.PI * this.r**2; }

    // площадь поверхности цилиндра
    // https://www-formula.ru/2011-09-21-04-33-30
    getArea() { return 2 * Math.PI * this.r * (this.h + this.r); }

    // компаратор для сравнения тел по объему
    compareTo(s1, s2) { return s1.getVolume() - s2.getVolume(); }

    // для полиморфизма реализуем представление объекта в формате HTML
    // в функции с тем же именем, что и базового класса
    toTableRow(row) { return `
        <tr>
            <td>${row}</td>
            <td class="align-center"><img src="../images/task1/cylinder.png" alt="Цилиндр" width="90"/></td>
            <td class="align-left">r: ${this.r.toFixed(3)}; h: ${this.h.toFixed(3)}</td>
            <td>${this.getArea().toFixed(3)}</td>
            <td>${this.getVolume().toFixed(3)}</td>
        </tr>`;
    }
} // Cylinder


// куб
class Cube extends Sphere {
    constructor(r) {
        // сторона куба
        super(r);
    } // constructor


    // объем куба
    // https://www-formula.ru/2011-09-21-10-51-48
    getVolume() { return this.r**3; }

    // площадь поверхности куба
    // https://www-formula.ru/2011-09-21-04-28-37
    getArea() { return  6 * this.r**2; }

    // компаратор для сравнения тел по объему
    compareTo(s1, s2) { return s1.getVolume() - s2.getVolume(); }

    // представление объекта в формате HTML
    toTableRow(row) { return `
        <tr>
            <td>${row}</td>
            <td class="align-center"><img src="../images/task1/cube.png" alt="Куб" width="90"/></td>
            <td class="align-left">a: ${this.r.toFixed(3)}</td>
            <td>${this.getArea().toFixed(3)}</td>
            <td>${this.getVolume().toFixed(3)}</td>
        </tr>`;
    }
} // Cube


// класс для работы с коллекцией фигур
class Bodies {
    constructor(title, bodies) {
        // название коллекции
        this.title = title;

        // коллекция фигур
        this.bodies = bodies;
    }

    // формирование массива объемных тел
    static generate() {
        return [
            new Cone(getIntRand(5, 10), getIntRand(5, 10)),
            new Cone(getIntRand(5, 10), getIntRand(5, 10)),
            new Cylinder(getIntRand(5, 10), getIntRand(5, 10)),
            new Cylinder(getIntRand(5, 10), getIntRand(5, 10)),
            new Sphere(getIntRand(5, 10)),
            new Sphere(getIntRand(5, 10)),
            new Cube(getIntRand(5, 10)),
            new Cube(getIntRand(5, 10)),
        ];
    }

    // вывод коллекции фигур в табличном формате в документ
    // при загрузке страницы
    writeToDocument() {
        let row = 1;
        this.bodies.forEach(body => document.write(body.toTableRow(row++)));
    } // writeToDocument

    // вывод массива объемных тел после вывода страницы, по командам,
    // назначенным на кнопки
    static show(title, bodies) {
        $("title").innerText = title;
        let row = 1;
        $("result").innerHTML = bodies.reduce((acc, body) => acc + body.toTableRow(row++), "");
    } // show

    // оболочка для сортировки коллекции
    sort(compareTo) {
        this.bodies.sort(compareTo);
    } // sort

    // сортировка копии массива объемных тел по убыванию объемов
    orderByVolumeDesc() {
        // получение копии массива
        // [...массив]     - глубокое копирование
        // массив.slice(0) - неглубокое копирование (т.е. копирование ссылок на объекты)
        return [...this.bodies].sort((b1, b2) => b2.getVolume() - b1.getVolume());
    } // orderByVolumeDesc

    // сортировка копии массива объемных тел по возрастанию площадей поверхности
    orderByArea() {
        return [...this.bodies].sort((b1, b2) => b1.getArea() - b2.getArea());
    } // orderByVolumeDesc
} // Bodies


// задача на обработку массива классов - начальное формирование массива тел
(function (){
    let listBodies = new Bodies("Коллекция объемных тел", Bodies.generate());

    // вывод сформированного массива объемных тел
    let row = 1;
    listBodies.writeToDocument();

    // при завершении загрузки страницы - назначить обработчики кликов по кнопкам
    window.onload = function() {
        // вывод массива по клику на кнопке
        $("btnSrcArray").onclick = () =>
            Bodies.show("Массив объемных тел для обработки", listBodies.bodies);


        // сортировка копии массива по убыванию объема и вывод этой копии
        $("btnOrderByVolumeDesc").onclick = () => {
            let bodies = listBodies.orderByVolumeDesc();
            Bodies.show("Копия массива объемных тел упорядочена по убыванию объемов", bodies);
        } // onclick


        // сортировка копии массива объемных тел по возрастанию площадей поверхности
        // и вывод этой копии
        $("btnOrderByArea").onclick = () => {
            let bodies = listBodies.orderByArea();
            Bodies.show("Копия массива объемных тел упорядочена по возрастанию площадей поверхности", bodies);
        } // onclick
    } // onload

})();
