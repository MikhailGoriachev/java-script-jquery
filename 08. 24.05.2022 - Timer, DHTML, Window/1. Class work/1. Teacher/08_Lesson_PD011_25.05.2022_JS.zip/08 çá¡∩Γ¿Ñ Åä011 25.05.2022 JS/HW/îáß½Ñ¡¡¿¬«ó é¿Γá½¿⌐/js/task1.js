// Модуль первой задачи
const Task1 = (function () {
    // Сфера - играет роль базового класса
    class Sphere {
        constructor(r) {
            this.name = 'Сфера';
            this.img = 'sphere.png';
            this._r = r;
        }

        get r() {
            return this._r;
        }

        set r(value) {
            this._r = value > 0 ? value : 3;
        }

        // Объем сферы
        getVolume() {
            return 4 * Math.PI * this._r ** 3 / 3;
        }

        // Площадь поверхности
        getArea() {
            return 4 * Math.PI * this._r * this._r;
        }

        compareTo(other) {
            return this.getVolume() - other.getVolume();
        }

        sidesToString() {
            return `r: ${this._r.toFixed(2)}`
        }

        toTableRow(row) {
            return `
            <tr>
                <td>${row}</td>
                <td class="align-left">${this.name}</td>
                <td><img src='../images/figures/${this.img}' alt="pic" style="width: 150px;height: 150px "/></td>
                <td>${this.sidesToString()}</td>
                <td>${this.getVolume().toFixed(2)}</td>
                <td>${this.getArea().toFixed(2)}</td>
            </tr>
        `;
        }
    }

    // Конус
    class Cone extends Sphere {
        constructor(r, h) {
            super(r);
            this.name = 'Конус';
            this.img = 'cone.png';
            this._r = r;
            this._h = h;
        }

        get h() {
            return this._h;
        }

        set h(value) {
            this._h = value > 0 ? value : 3;
        }

        getVolume() {
            return Math.PI * this.r * this.r * this._h / 3;
        }

        getArea() {
            return Math.PI * this.r * (this.r + Math.sqrt(this.r ** 2 + this._h ** 2))
        }

        sidesToString() {
            return `${super.sidesToString()} h: ${this._h.toFixed(2)}`
        }
    }

    // Цилиндр
    class Cylinder extends Sphere {
        constructor(r, h) {
            super(r);
            this.name = 'Цилиндр';
            this.img = 'cylinder.png';
            this._h = h;
        }

        get h() {
            return this._h;
        }

        set h(value) {
            this._h = value > 0 ? value : 3;
        }

        getVolume() {
            return Math.PI * this.r * this.r * this._h;
        }

        getArea = function () {
            return 2 * Math.PI * this.r * this._h;
        }

        sidesToString() {
            return `${super.sidesToString()} h: ${this._h.toFixed(2)}`
        }
    }

    class Cube extends Sphere {
        constructor(a) {
            super(a);
            this.name = 'Куб';
            this.img = 'cube.png';
        }

        getVolume() {
            return this.r ** 3;
        }

        getArea = function () {
            return 6 * this.r * this.r;
        }

        sidesToString() {
            return `a: ${this.r.toFixed(2)}`
        }
    }

    // Класс для работы с коллекцией фигур
    class Shapes {
        constructor(shapes) {
            this.shapes = shapes;
        }

        sortByVolumeDesc() {
            this.shapes.sort((a, b) => b.compareTo(a));
        }

        sortByArea() {
            this.shapes.sort((a, b) => a.getArea() - b.getArea());
        }

        toTable(prompt) {
            let table = `<table>
                        <caption>${prompt}</caption>
                      <thead>
                      <tr>
                        <td>№</td>
                        <td>Название</td>
                        <td>Изображение</td>
                        <td>Параметры тела</td>
                        <td>Объем тела</td>
                        <td>Площадь поверхности</td>
                      </tr></thead>`;
            this.shapes.forEach((item, index) => table += item.toTableRow(index + 1));
            table += '</table>';

            return table;
        }
    }

    return {
        // Публичные свойства модуля

        shapes: new Shapes([
            new Sphere(getRandom(1, 10)),
            new Sphere(getRandom(1, 10)),
            new Cube(getRandom(1, 10)),
            new Cube(getRandom(1, 10)),
            new Cone(getRandom(1, 10), getRandom(1, 10),),
            new Cone(getRandom(1, 10), getRandom(1, 10),),
            new Cylinder(getRandom(1, 10), getRandom(1, 10),),
            new Cylinder(getRandom(1, 10), getRandom(1, 10),),
        ]),

        renderShapes: function() {
            document.write(this.shapes.toTable('Коллекция фигур:'));
        }
    }
})();


window.onload = function () {

    // Назначение обработчиков кнопок
    document.getElementById('sortByVolumeDesc').onclick = function () {
        Task1.shapes.sortByVolumeDesc();
        document.getElementById('shapes').innerHTML = Task1.shapes.toTable('Коллекция отсортирована по убыванию объемов:');
    }

    document.getElementById('sortByArea').onclick = function () {
        Task1.shapes.sortByArea();
        document.getElementById('shapes').innerHTML = Task1.shapes.toTable('Коллекция отсортирована по возрастанию площадей' +
            ' поверхности:');
    }

};


// Рендеринг при загрузке скрипта
(function () {
    Task1.renderShapes();
})();



