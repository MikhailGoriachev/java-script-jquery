
// Модуль второй задачи
const Task2 = (function () {
    // Конструктор объекта данных о погоде
    class Weather {
        constructor(t, press, humid, windSpeed, windDirection, climate) {
            this.temperature = t;
            this.pressure = press;
            this.humidity = humid;
            this.wind = {
                speed: windSpeed,
                direction: windDirection
            };
            this.climate = {
                description: climate.description,
                img: climate.img
            }
        }

        toHtml() {
            return `<div class="weather-block"><img src='../images/weather/${this.climate.img}' alt ="pic" width="75" height="75"/>
                    <div>${this.climate.description}</div>
                    <div>Температура: ${this.temperature}°С</div>
                    <div>Давление: ${this.pressure} мм рт.ст.</div>
                    <div>Влажность: ${this.humidity}%</div>
                    <div>Ветер: ${this.wind.speed} м/с, ${this.wind.direction}</div></div>`;
        }

        toString() {
            return `${this.climate.description} 
                Температура: ${this.temperature}°С
                Давление: ${this.pressure} мм рт.ст.
                Влажность: ${this.humidity}%
                Ветер: ${this.wind.speed} м/с, ${this.wind.direction}`;
        }

        static climates = {
            cloudy: {
                description: 'Пасмурно',
                img: 'cloudy.svg'
            },
            partlyCloudy: {
                description: 'Облачно',
                img: 'partly-cloudy.svg'
            },
            fair: {
                description: 'Ясно',
                img: 'fair.svg'
            },
            thunder: {
                description: 'Гроза',
                img: 'thunder.svg'
            },
            heavyRain: {
                description: 'Сильный дождь',
                img: 'heavy-rain.svg'
            }
        };

        // Генерация объекта
        static getRandom() {
            let directions = ['C', 'Ю', 'В', 'З', 'Ю-В', 'Ю-З', 'С-В', 'С-З'];
            let climateNames = Object.keys(Weather.climates);
            let climateName = climateNames[getRandomInt(0, climateNames.length - 1)];
            return new Weather(getRandomInt(15, 30),
                getRandomInt(600, 900),
                getRandomInt(20, 80),
                getRandomInt(0, 30), directions[getRandomInt(0, directions.length - 1)],
                Weather.climates[climateName])
        }
    }

    // Конструктор коллекции прогноза погоды на несколько дней
    class Forecast {
        constructor(n, days = null) {
            this.days = days ?? [...Array(n)].map((item, index) => ({day: Forecast.dayNames[index], weather: Weather.getRandom()}));
        }

        static dayNames = [
            {ru: 'Понедельник', en: 'monday'}, {ru: 'Вторник', en: 'tuesday'},
            {ru: 'Среда', en: 'wednesday'}, {ru: 'Четверг', en: 'thursday'},
            {ru: 'Пятница', en: 'friday'}, {ru: 'Суббота', en: 'saturday'},
            {ru: 'Воскресенье', en: 'sunday'}
        ]

        // Копия коллекции, отсортированная по уменьшению температуры
        getSortedByTemperatureDesc() {
            return new Forecast(0, [...this.days].sort((a, b) => b.weather.temperature - a.weather.temperature));
        }

        // Копия коллекции, отсортированная по увеличению давления
        getSortedByPressure() {
            return new Forecast(0, [...this.days].sort((a, b) => a.weather.pressure - b.weather.pressure));
        }

        // Копия коллекции, отсортированная по уменьшению скорости ветра
        getSortedByWindSpeedDesc() {
            return new Forecast(0, [...this.days].sort((a, b) => b.weather.wind.speed - a.weather.wind.speed));
        }

        getWindiestDays() {
            let lowestWind = Math.min(...this.days.map(i => i.weather.wind.speed));
            return this.days.filter(item => item.weather.wind.speed === lowestWind).map(i => i.day.en);
        }

        getCalmDays() {
            let highestWind = Math.max(...this.days.map(i => i.weather.wind.speed));
            return this.days.filter(item => item.weather.wind.speed === highestWind).map(i => i.day.en);
        }

        toHtml() {
            return this.days.reduce((prev, cur) =>
                prev += `<div class="day" id="${cur.day.en}">
                         <div class="hl"><b>${cur.day.ru}</b></div>
                         ${cur.weather.toHtml()}</div>`, '')
        }
    }

    return {
        // Публичные свойства модуля

        weekForecast: new Forecast(7),
    }
})();


window.onload = function () {

    // Назначение обработчиков кнопок

    document.getElementById('sortByTempDesc').onclick = () =>
        document.getElementById('weather').innerHTML = Task2.weekForecast.getSortedByTemperatureDesc().toHtml();

    document.getElementById('sortByPressure').onclick = () =>
        document.getElementById('weather').innerHTML = Task2.weekForecast.getSortedByPressure().toHtml();

    document.getElementById('sortByWindDesc').onclick = () =>
        document.getElementById('weather').innerHTML = Task2.weekForecast.getSortedByWindSpeedDesc().toHtml();

    document.getElementById('highlightWindy').onclick = () =>
        Task2.weekForecast.getWindiestDays().forEach(day => document.getElementById(day).classList.add('hl-windy'))

    document.getElementById('highlightCalm').onclick = () =>
        Task2.weekForecast.getCalmDays().forEach(day => document.getElementById(day).classList.add('hl-calm'))

    document.getElementById('reset').onclick = () =>
        document.getElementById('weather').innerHTML = Task2.weekForecast.toHtml();

};

// Рендеринг при загрузке скрипта
(function () {
    document.write(Task2.weekForecast.toHtml());
})();
