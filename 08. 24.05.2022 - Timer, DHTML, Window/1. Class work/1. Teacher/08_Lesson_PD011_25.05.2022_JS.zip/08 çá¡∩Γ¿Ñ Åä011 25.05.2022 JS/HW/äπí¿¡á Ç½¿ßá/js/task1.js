// Задача 1. Разработайте иерархию классов в синтаксисе ES6+для представления объемных тел - сферы, конуса,
// цилиндра, куба. Разработайте методы для вычисления площади поверхности, объема фигуры, вывода данных по фигуре
// и сравнения объемных тел по объему. Разработайте геттеры и сеттеры с контролем корректности присваиваемых данных.
// Некорректные данные заменяйте значениями по умолчанию, сообщения об ошибках не нужны, исключения пока не используем.
// Выводите также изображения объемных фигур.
// Сформируйте массив объектов этих классов - по 2 объекта каждого типа. По командам, назначенным
// на кнопки, отсортируйте копию массива по убыванию объемов, по возрастанию площадей поверхности,
// выводите исходный массив объемных тел.

// Сфера (базовый класс)
class Sphere {
    constructor(radius, img = "sphere.png") {
        this.radius = radius;     // радиус сферы
        this.img = img;           // графическое отображение фигуры
    } // constructor

    // геттеры и сеттеры
    get radius() {return this._radius}
    set radius(value) {this._radius = value > 0? value:1}

    get img() {return this._img}
    set img(value) {this._img = value;}

    // метод для вычисления объема сферы
    volume() { return 4  * Math.PI * this.radius ** 3 / 3; };

    // метод для вычисления площади поверхности сферы
    area() { return 4 * Math.PI * this.radius * this.radius; };

    // метод для сравнения фигур по объему
    compareTo(obj) {
        return this.volume() - obj.volume();
    } // compareTo

    partialToShow(){
        return` Площадь: ${this.area().toFixed(2)} м<sup><small>2</small></sup><br>
                Объем: ${this.volume().toFixed(2)} м<sup><small>3</small></sup><br>`;
    } //

    // формирование строки для вывода
    toShow() {
        return`<div class="object-block"><h3>Сфера</h3>
                <img src='../img/task1/${this.img}' height='120'/><br><p><br>
                Радиус: ${this.radius} м<br>
                ${this.partialToShow()}
                </p></div>`;
    }; // toShow
} // Sphere

// Куб (производный класс)
class Cube extends Sphere{
    constructor(side, img = "cube.png") {
        super(side, img);
    } // constructor

    // геттеры и сеттеры
    get side() {return this.radius}
    set side(value) {this.radius = value > 0? value:1}

    // метод для вычисления объема куба
    volume() { return this.side ** 3; };

    // метод для вычисления площади поверхности куба
    area() { return 6 * this.side ** 2; };

    // формирование строки для вывода
    toShow() {
        return`<div class="object-block"><h3>Куб</h3>
                <img src='../img/task1/${this.img}' height='120'/><br><p><br>
                Сторона: ${this.side} м<br>
                ${this.partialToShow()}
                </p></div>`;
    }; // toString
} // Sphere

// Конус (производный класс)
class Cone extends Sphere{
    constructor(radius, height, img = "cone.png") {
        super(radius, img);
        // поля производного класса
        this.height = height; // высота конуса
        this.l = Math.sqrt(this.radius * this.radius + this.height * this.height); // образующая конуса
    } // constructor

    // геттер и сеттер
    get height() {return this._height}
    set height(value) {this._height = value > 0? value:1}

    // метод для вычисления объема конуса
    volume() { return this.height / 3 * Math.PI * this.radius * this.radius; };

    // метод для вычисления площади поверхности конуса
    area() { return Math.PI * this.radius * this.l + Math.PI * this.radius *this.radius; };

    // формирование строки для вывода
    toShow() {
        return`<div class="object-block"><h3>Конус</h3>
                <img src='../img/task1/${this.img}' height='120'/><br><p>
                Высота: ${this.height} м<br>
                Радиус: ${this.radius} м<br>
                ${this.partialToShow()}
                </p></div>`;
    }; // toString
} // Cone

// Цилиндр (производный класс)
class Cylinder extends Sphere{
    // получение доступа к полям базового класса
    constructor(radius, height, img = "cylinder.png") {
        super(radius, img);
        // поля производного класса
        this.height = height; // высота цилиндра
    } // constructor

    // геттер и сеттер
    get height() {return this._height}
    set height(value) {this._height = value > 0? value:1}

    // метод для вычисления объема цилиндра
    volume() { return Math.PI * this.radius * this.radius * this.height; };

    // метод для вычисления площади поверхности цилиндра
    area() { return 2 * Math.PI * this.radius * this.radius + 2 * Math.PI * this.radius * this.height; };


    // формирование строки для вывода)
    toShow() {
        return`<div class="object-block"><h3>Цилиндр</h3>
                <img src='../img/task1/${this.img}' height='120'/><br><p>
                Высота: ${this.height} м<br>
                Радиус: ${this.radius} м<br>
                ${this.partialToShow()}
                </p></div>`;
    }; // toString
} // Cylinder

const lo = 0.1, hi = 5;
// массив фигур
let figures = [
    new Sphere(getRand(lo, hi)),
    new Sphere(getRand(lo, hi)),
    new Cube(getRand(lo, hi)),
    new Cube(getRand(lo, hi)),
    new Cone(getRand(lo, hi), getRand(lo, hi)),
    new Cone(getRand(lo, hi), getRand(lo, hi)),
    new Cylinder(getRand(lo, hi), getRand(lo, hi)),
    new Cylinder(getRand(lo, hi), getRand(lo, hi)),
];

// вывод массива фигур
function show(){
    let titleElem = document.getElementById("title");
    let divElem = document.getElementById("figures");
    titleElem.innerText = `Фигуры в исходном порядке`;

    // формирование строки для вывода
    let str = "";
    figures.forEach(f => str += f.toShow());

    // вывод
    divElem.innerHTML = str;
} // show

// сортировка массива фигур по убыванию объемов
function sortByVolumeDesc(){
    let titleElem = document.getElementById("title");
    let divElem = document.getElementById("figures");
    titleElem.innerText = "Фигуры по убыванию объемов";

    let temp = figures.slice(0); // копия массива
    // сортировка
    temp.sort((x, y) => y.volume() - x.volume());

    // формирование строки для вывода
    let str = "";
    temp.forEach(f => str += f.toShow());

    // вывод
    divElem.innerHTML = str;
} // sortByVolumeDesc

// сортировка массива фигур по возрастанию площадей
function sortByArea(){
    let titleElem = document.getElementById("title");
    let divElem = document.getElementById("figures");
    titleElem.innerText = "Фигуры по возрастанию площадей";

    let temp = figures.slice(0); // копия массива
    // сортировка
    temp.sort((x, y) => x.area() - y.area());

    // формирование строки для вывода
    let str = "";
    temp.forEach(f => str += f.toShow());

    // вывод
    divElem.innerHTML = str;
} // sortByArea

(function (){
    // вывод
    document.write('<hr><h2 id="title"></h2><div class="for-blocks" id="figures"></div><hr>');
    show();
    document.write('<input type="button" onClick="show()" value="Исходный порядок"/>');
    document.write('<input type="button" onClick="sortByVolumeDesc()" value="Сортировать по убыванию объемов"/>');
    document.write('<input type="button" onClick="sortByArea()" value="Сортировать по возрастанию площадей"/>');
})();