// Задача 2. Спроектировать класс в синтаксисе ES6+ для представления данных о погоде: температура, давление,
// влажность, скорость и направление ветра, графическое отображение атмосферных явлений (ясно, облачно, дождь,
// и т.д. – не более 5). Определите метод формирования строки для вывода данных в разметку. Переопределите
// метод toString() для простой вывода в консоль. Создайте массив данных о погоде за неделю, выведите его на страницу.
// По командам от кнопок выводите данные о погоде, упорядоченные (только при выводе, порядок элементов в исходном
// массиве не менять): по убыванию температуры, по возрастанию давления, по убыванию скорости ветра.
// По командам от кнопок выделяйте самые ветреные и самые тихие дни.
// Также должна быть кнопка для вывода исходного массива без выделений элементов.

class Weather {
    constructor(number, temperature, pressure, humidity, wind, weatherImg) {
        this.number = number;          // номер дня недели
        this.temperature = temperature;// температура
        this.pressure = pressure;      // давление
        this.humidity = humidity;      // влажность
        this.wind = {
            speed: wind.speed,         // скорость ветра
            direction: wind.direction, // направление ветра
        };
        this.weatherImg = weatherImg;  // графическое отображение атмосферного явлений
    } // constructor

    // геттеры и сеттеры
    get temperature() { return this._temperature }
    set temperature(value) { this._temperature = value }

    get pressure() { return this._pressure }
    set pressure(value) { this._pressure = value < 1200 ? value : 1000; }

    get humidity() { return this._humidity }
    set humidity(value){ this._humidity = value > 0 ? value : 68; }

    get weatherImg() { return this._weatherImg }
    set weatherImg(value){ this._weatherImg = value }

    // формирование строки для вывода
    toShow() {
        return `<div class="object-block" id="weather${this.number}"><h3>День ${this.number}:</h3><p>
            <img src='../img/task2/${this.weatherImg}' height='120'/><br>
            Температура: ${this.temperature}&#176;C<br>
            Давление: ${this.pressure} гПа<br>
            Влажность: ${this.humidity}%<br>
            Скорость ветра: ${this.wind.speed} ми/ч<br>
            Направление ветра: ${this.wind.direction}</p></div>`
    } // toShow

    // вывод объекта в строку
    toString() {
        return `День ${this.number}: температура: ${this.temperature}&#176;C,
            давление: ${this.pressure} гПа, влажность: ${this.humidity}%, 
            скорость ветра: ${this.wind.speed} ми/ч, направление ветра: ${this.wind.direction}`
    }// toString
} // Weather

// массив данных о погоде
let weatherForecast = [
    new Weather(1, getIntRand(20,27),1012,82,{speed:4, direction:"З"}, "sunny.gif"),
    new Weather(2, getIntRand(14,17),getIntRand(1000,1100),getIntRand(40,100),{speed:7, direction:"З"}, "cloudy.gif"),
    new Weather(3, getIntRand(10,12),getIntRand(1000,1160),getIntRand(80,100),{speed:10, direction:"С-В"}, "rainy.gif"),
    new Weather(4, getIntRand(8,10),getIntRand(1000,1160),getIntRand(80,100),{speed:10, direction:"С"}, "storm.gif"),
    new Weather(5,getIntRand(10,12),getIntRand(1000,1160),getIntRand(80,100),{speed:10, direction:"В"}, "rainy.gif"),
    new Weather(6,getIntRand(14,17),getIntRand(1000,1100),getIntRand(40,100),{speed:7, direction:"C-З"}, "cloudy.gif"),
    new Weather(7,getIntRand(20,27),1012,82,{speed:4, direction:"З"}, "sunny.gif"),
];

// вывод массива
function showWeathers(){
    let titleElem = document.getElementById("title");
    let divElem = document.getElementById("weathers");
    titleElem.innerText = `Исходный массив`;

    // формирование строки для вывода
    let str = "";
    weatherForecast.forEach(f => str += f.toShow());

    // вывод
    divElem.innerHTML = str;
}// showWeathers

// сортировка массива по убыванию температуры
function sortByTemperatureDesc(){
    let titleElem = document.getElementById("title");
    let divElem = document.getElementById("weathers");
    titleElem.innerText = `Массив по убыванию температуры`;

    let temp = weatherForecast.slice(0);// копия массива
    // сортировка
    temp.sort((x, y) => y.temperature - x.temperature);
    // формирование строки для вывода
    let str = "";
    temp.forEach(f => str += f.toShow());

    // вывод
    divElem.innerHTML = str;
}// sortByTemperatureDesc

// сортировка массива по возрастанию давления
function sortByPressure(){
    let titleElem = document.getElementById("title");
    let divElem = document.getElementById("weathers");
    titleElem.innerText = `Массив по возрастанию давления`;

    let temp = weatherForecast.slice(0);// копия массива
    // сортировка
    temp.sort((x, y) => x.pressure - y.pressure);
    // формирование строки для вывода
    let str = "";
    temp.forEach(f => str += f.toShow());

    // вывод
    divElem.innerHTML = str;
}// sortByPressure

// сортировка массива по убыванию скорости ветра
function sortWindSpeedDesc(){
    let titleElem = document.getElementById("title");
    let divElem = document.getElementById("weathers");
    titleElem.innerText = `Массив по убыванию скорости ветра`;

    let temp = weatherForecast.slice(0);// копия массива
    // сортировка
    temp.sort((x, y) => y.wind.speed - x.wind.speed);
    // формирование строки для вывода
    let str = "";
    temp.forEach(f => str += f.toShow());

    // вывод
    divElem.innerHTML = str;
}// sortWindSpeedDesc

// выделение самых ветреных дней
function showWindiest(){
    let maxWindSpeed = Math.max(...weatherForecast.map(x => x.wind.speed));
    let temp = weatherForecast.filter(x => x.wind.speed === maxWindSpeed);
    temp.forEach(x=>{
        let weatherElem = document.getElementById(`weather${x.number}`);
        weatherElem.style.borderBottom = weatherElem.style.borderTop ="3px solid dodgerblue";
    });
} // showWindiest

// выделение самых тихих дней
function showQuietest(){
    let minWindSpeed = Math.min(...weatherForecast.map(x => x.wind.speed));
    let temp = weatherForecast.filter(x => x.wind.speed === minWindSpeed);
    temp.forEach(x=>{
        let weather = document.getElementById(`weather${x.number}`);
        weather.style.borderBottom = weather.style.borderTop = "3px solid red";
    });
} // showQuietest


(function (){
    document.write(`<hr><h2 id="title">Исходный массив</h2><div class="for-blocks" id="weathers"></div><hr>`);
    showWeathers();
    // кнопки
    document.write('<input type="button" onClick="showWeathers()" value="Исходный массив"/>');
    document.write('<input type="button" onClick="sortByTemperatureDesc()" value="Сортировать по убыванию температуры"/>');
    document.write('<input type="button" onClick="sortByPressure()" value="Сортировать по возрастанию давления"/>');
    document.write('<input type="button" onClick="sortWindSpeedDesc()" value="Сортировать по убыванию скорости ветра"/>');
    document.write('<input type="button" onClick="showWindiest()" value="Самые ветреные дни"/>');
    document.write('<input type="button" onClick="showQuietest()" value="Самые тихие дни"/>');
})();