
//Исполнение кода при загрузке страницы
window.onload = function () {
    let figures = generateFigures();

    //Вывод разметки в блок
    outputToBlock("mainDiv",createMarkup('Исходный массив',figures));

    //Обработчик кнопки вывода исхоного массива
    document.getElementById("defaultArr").onclick = function () {

        /*document.getElementById("mainDiv").innerHTML = createMarkup('Исходный массив',figures);*/
        outputToBlock("mainDiv",createMarkup('Исходный массив',figures));
    }

    //Отсортированный по убыванию объемов
    document.getElementById("sortedByV").onclick = function () {
        //Копия массива
        let tempArr = figures.map(f => f);
        tempArr.sort((f1,f2) => f2.getVolume - f1.getVolume);

        //Вывод в разметку блока
        outputToBlock("mainDiv",createMarkup('Отсортированный массив по убыванию V',tempArr));

        /*document.getElementById("mainDiv").innerHTML = createMarkup('Отсортированный массив по убыванию V',tempArr);*/
    }

    //Отсортированный по возрастанию площадей
    document.getElementById("sortedByS").onclick = function () {
        //Копия массива
        let tempArr = figures.map(f => f);

        tempArr.sort((f1,f2) => f1.getSquare - f2.getSquare);

        //Вывод в разметку блока
        outputToBlock("mainDiv",createMarkup('Отсортированный массив по возрастанию S',tempArr));

        /*document.getElementById("mainDiv").innerHTML = createMarkup('Отсортированный массив по возрастанию S',tempArr);*/
    }

}

//Вывод в блок
function outputToBlock(blockId,markup) {

    if (typeof blockId != "string")
        return;
    //Вывод разметки в блок
    document.getElementById(blockId).innerHTML = markup;
}

//Сформировать разметку
function createMarkup(title,arr) {

    let str = `<table> <caption>${title}</caption>`;

    //Строки таблицы
    arr.forEach(f => str += f.toString());
    str += `</table></details>`;

    return str;
}

//region Классы
//Базовый класс
class Figure{

    constructor(radius,icon) {
        this.icon = icon;
        this.radius = radius;
    }

    //region Геттеры и сеттеры
    get icon() {
        return this._icon;
    }

    //Если заданный путь иконки некорректен, тогда установим иконку по умолчнию
    set icon(value) {
        if (typeof value != 'string') {
            this._icon = 'incorrect';
            return;
        }
        this._icon = value;
    }

    get radius() {
        return this._radius;
    }

    //Если значение некорректно - значение по умолчанию
    set radius(value) {
        if (value<=0) {
            this._radius = 5;
            return;
        }
        this._radius = value;
    }
    //endregion

    //Площадь (вычисляемое свойтсво)
    get getSquare() {}

    //Объём (вычисляемое свойтсво)
    get getVolume () {}

    //Вывод
    toString() {}

    //Сравнение
    compareTo(comparedFigure) {}
}//Figure

//сфера
class Sphere extends Figure{
    constructor(radius,icon) {
        super(radius,icon);
    }

    //Площадь (вычисляемое свойтсво)
    get getSquare () {
    return 4*Math.PI*this.radius**2;
  }
    //Объём (вычисляемое свойтсво)
    get getVolume () {
    return 4/3*Math.PI*this.radius**3;
  }

    //Вывод
    toString () {
    return `
        <tr  class="separator-style">
            <td rowspan="3" class="image-cell">
                <img src="../images/figures/${this.icon}.png" alt="">
            </td>
            <td>
                Радиус
            </td>
            <td>
                ${this._radius}
            </td>
        </tr>
        <tr>
            <td>
                Площадь
            </td>
            <td>
                ${Math.floor(this.getSquare.toFixed(0))}
            </td>
        </tr>
        <tr>
             <td>
                 Объем
             </td>
             <td>
                 ${Math.floor(this.getVolume.toFixed(0))}
             </td>
       </tr>`;
  }//toString

    //Сравнение
    compareTo (comparedFigure) {
        return this.getVolume-comparedFigure.getVolume;
    }

}//Sphere

//Конус
class Cone extends Figure{
    constructor(radius,height,l,icon) {
        super(radius,icon);
        this.height = height;
        this.l = l;
    }

    //region Геттеры и сеттеры
    get height() {
        return this._height;
    }

    set height(value) {
        if (value<=0) {
            this._height = 10;
            return;
        }
        this._height = value;
    }

    get l() {
        return this._l;
    }

    set l(value) {
        if (value<=0) {
            this._height = 12;
            return;
        }
        this._l = value;
    }
    //endregion

    //Площадь (вычисляемое свойтсво)
    get getSquare () {
      return Math.PI*this.radius**2+Math.PI*this.radius*this.l;
    }
    //Объём (вычисляемое свойтсво)
    get getVolume () {
      return (Math.PI*this.radius**2)/3*this.height;
    }

    //Вывод
    toString () {
      return `
          <tr class="separator-style">
              <td rowspan="5" class="image-cell">
                  <img src="../images/figures/${this.icon}.png" alt="">
              </td>
              <td>
                  Радиус
              </td>
              <td>
                  ${this._radius}
              </td>
          </tr>
          <tr>
              <td>
                  Высота
              </td>
              <td>
                  ${this._height}
              </td>
          </tr>
          <tr>
              <td>
                  Образующая
              </td>
              <td>
                  ${this._l}
              </td>
          </tr>
          <tr>
              <td>
                  Площадь
              </td>
              <td>
                  ${this.getSquare.toFixed(0)}
              </td>
          </tr>
          <tr>
               <td>
                   Объем
               </td>
               <td>
                   ${this.getVolume.toFixed(0)}
               </td>
         </tr>`;
    }//toString

    //Сравнение
    compareTo (comparedFigure) {
        return this.getVolume-comparedFigure.getVolume;
    }

}//cone

//Цилиндр
class Cylinder extends Figure{

    constructor(radius,height,icon) {
        super(radius,icon);
        this.height = height;
    }

    //region Геттеры и сеттеры
    get height() {
        return this._height;
    }

    //Защита от задания некорректного значения
    set height(value) {
        if (value<=0) {
            this._height = 10;
            return;
        }
        this._height = value;
    }
    //endregion

    //Площадь (вычисляемое свойтсво)
    get getSquare () {
    return 2*Math.PI*this.radius**2+2*Math.PI*this.radius*this._height;
    }
    //Объём (вычисляемое свойтсво)
    get getVolume() {
    return Math.PI*this.radius**2*this._height;
    }

    //Вывод
    toString() {
    return `
        <tr class="separator-style">
            <td rowspan="4" class="image-cell">
                <img src="../images/figures/${this.icon}.png" alt="">
            </td>
            <td>
                Радиус
            </td>
            <td>
                ${this._radius}
            </td>
        </tr>
        <tr>
            <td>
                Высота
            </td>
            <td>
                ${this._height}
            </td>
        </tr>
        <tr>
            <td>
                Площадь
            </td>
            <td>
                ${this.getSquare.toFixed(0)}
            </td>
        </tr>
        <tr>
             <td>
                 Объем
             </td>
             <td>
                 ${this.getVolume.toFixed(0)}
             </td>
       </tr>`;
  }//toString

    //Сравнение
    compareTo (comparedFigure) {
      return this.getVolume-comparedFigure.getVolume;
  }

}//Cylinder
//endregion



