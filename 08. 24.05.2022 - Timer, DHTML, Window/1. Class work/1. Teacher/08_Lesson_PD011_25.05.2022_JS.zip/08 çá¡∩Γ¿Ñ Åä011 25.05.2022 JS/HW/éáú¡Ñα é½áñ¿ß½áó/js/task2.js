//Представление погоды
class Weather {
    //Свойства
    constructor(temperature, pressure, humidity, wind, icon,day) {
        this.weatherIcon = icon;
        this.dayOfWeek = day;
        this.temperature = temperature;
        this.pressure = pressure;
        this.humidity = humidity;
        this.wind = wind;
    }


    //region Геттеры и сеттеры

    //region Температура
    get temperature() {
        return this._temperature;
    }

    set temperature(value) {
        if (value<-70 || value>70){
            this._temperature = 15;
            return;
        }
        this._temperature = value;
    }
    //endregion

    //region Давление
    get pressure() {
        return this._pressure;
    }

    set pressure(value) {
        if (value<0)
        {
            this._pressure = 0;
            return;
        }
        this._pressure = value;
    }
    //endregion

    //region Влажность
    get humidity() {
        return this._humidity;
    }

    set humidity(value) {
        if (value<0){
            this._humidity = 10;
            return;
        }
        this._humidity = value;
    }
    //endregion

    //region Ветер
    get wind() {
        return this._wind;
    }

    set wind(value) {
        this._wind = value;
    }
    //endregion

    set weatherIcon(value) {
        this._weatherIcon = value;
    }

    //region День недели
    get dayOfWeek() {
        return this._dayOfWeek;
    }

    set dayOfWeek(value) {
        //Если данные некорретны, то задаём понедельник по умолчанию
        if (value <= 0 || value > 7)
        {
            this._dayOfWeek = getDayOfWeek(1);
            return;
        }
        this._dayOfWeek = getDayOfWeek(value);
    }
    //endregion

    //endregion

    //Вывод
    toString () {
        return `<div>
                    <table style="border-radius: 5px">
                        <tr><td><img class="weather-type-icon" src="../images/weather/${this._weatherIcon}"></td></tr>
                        <tr><td><span>День недели: <b>${this._dayOfWeek}</b></span></td></tr>
                        <tr><td><span>Температура: <b>${this._temperature}</b></span></td></tr>
                        <tr><td><span>Давление: <b>${this._pressure}</b></span></td></tr>
                        <tr><td><span>Влажность: <b>${this._humidity}</b>%</span></td></tr>
                        <tr>
                        <td>
                            <span>Скорость ветра: <b>${this._wind.speed}</b> м/с</span><br>
                            <span>Нарпавление ветра: <b>${this._wind.direction}</b></span>
                        </td>
                    </table>
                </div>`
    }

}

window.onload = function () {

    //Массив представлений погоды
    let weathers = generateWeathers();

    let mainBlock = document.getElementById("mainDiv");

    mainBlock.innerHTML = createMarkup(weathers);


    //region Вставка заголовка
    let title= document.createElement("p");
    title.setAttribute("id","taskTitle");
    title.setAttribute("class","title-style");

    title.innerHTML = `<span>Исходный массив</span>`;
    mainBlock.parentNode.insertBefore(title,mainBlock);
    //endregion

    title = document.getElementById('taskTitle');

    //Обработчик кнопки вывода исходного массива
    document.getElementById("defaultArr").onclick = function () {
        mainBlock.innerHTML = createMarkup(weathers);
        title.innerHTML = `<span>Исходный массив</span>`;
    }

    //region Сортировки

    //Обработчик кнопки сортировки представления по убыванию температуры
    document.getElementById("orderByT").onclick = orderDescByTemperature(mainBlock,title);

    //Обработчик кнопки сортировки представления по возрастанию давления
    document.getElementById("orderByP").onclick = orderAscByPressure(mainBlock,title);

    //Обработчик кнопки сортировки представления по убванию скорости ветра
    document.getElementById("orderByWind").onclick = orderDescByWindSpeed(mainBlock,title);

    //endregion

    //region Выборки

    //Получить самые ветреные дни
    document.getElementById("findTheWindiest").onclick = function () {

        let windSpeeds = weathers.map(w => w.wind.speed);
        let maxWindSpeed = Math.max(...windSpeeds);

        let theWindiest = weathers.filter(w => w.wind.speed == maxWindSpeed);

        //Вывод разметки
        mainBlock.innerHTML = createMarkup(theWindiest);
        title.innerHTML = `<span>Самые ветреные дни</span>`;
    }

    //Получить самые тихие дни
    document.getElementById("findNoWind").onclick = function () {

        let windSpeeds = weathers.map(w => w.wind.speed);
        let minWindSpeed = Math.min(...windSpeeds);

        let windless = weathers.filter(w => w.wind.speed == minWindSpeed);

        //Вывод разметки
        mainBlock.innerHTML = createMarkup(windless);
        title.innerHTML = `<span>Самые тихие дни</span>`;
    }

    //endregion

}

//Сформировать разметку
function createMarkup(weatherArr) {

    let str = ``;
    weatherArr.forEach(w => str += w.toString());
    return str;
}

//region Сортировки, обработчики

//Упорядочить представление по убыванию температуры
function orderDescByTemperature(blockObject,titleObject) {
    return () => {
        //Компаратор: находим блок span под нужным номером и получаем из него строку для парсинга числанаходим блок span под нужным номером и получаем из него строку для парсинга числа
        sortArr(blockObject,(c1,c2) => {
            let t1 = getNumFromStr(c1.getElementsByTagName("span")[1].getElementsByTagName("b")[0].innerHTML);
            let t2 = getNumFromStr(c2.getElementsByTagName("span")[1].getElementsByTagName("b")[0].innerHTML);
            return t2-t1;
        });

        titleObject.innerHTML = `<span>Сортировка представления по убыванию температуры</span>`;
    }
}//orderDescByTemperature

//Упорядочить представление по возрастанию давления
function orderAscByPressure(blockObject,titleObject) {
    return () => {

        //Компаратор: находим блок span под нужным номером и получаем из него строку для парсинга числанаходим блок span под нужным номером и получаем из него строку для парсинга числа
        sortArr(blockObject,(c1,c2) => {
            let p1 = getNumFromStr(c1.getElementsByTagName("span")[2].getElementsByTagName("b")[0].innerHTML);
            let p2 = getNumFromStr(c2.getElementsByTagName("span")[2].getElementsByTagName("b")[0].innerHTML);
            return p1-p2;
        });

        titleObject.innerHTML = `<span>Сортировка представления по возрастанию давления</span>`;
    }
}//orderAscByPressure

//Упорядочить по убыванию скорости ветра
function orderDescByWindSpeed(blockObject,titleObject) {
    return () => {

        //Компаратор: находим блок span под нужным номером и получаем из него строку для парсинга числа
        sortArr(blockObject,(c1,c2) => {
            let ws1 = getNumFromStr(c1.getElementsByTagName("span")[4].getElementsByTagName("b")[0].innerHTML);
            let ws2 = getNumFromStr(c2.getElementsByTagName("span")[4].getElementsByTagName("b")[0].innerHTML);
            return ws2-ws1;
        });

        titleObject.innerHTML = `<span>Сортировка представления по убыванию скорости ветра</span>`;

    }
}//orderDescByWindSpeed

//endregion

//Сортировка и запись представления
function sortArr(mainNode,comparator) {
    //Получаем массив дочерних элементов общего блока
    let childNodes = [];
    mainNode.childNodes.forEach(c => {
        if (c.nodeType == 1)
            childNodes.push(c);
    });

    //Сортировка по компаратору
    childNodes.sort(comparator);

    //Добавление отсортированного массива надзад
    for (let child of childNodes) {
        mainNode.append(child);
    }
}

