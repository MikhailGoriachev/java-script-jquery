
//Получение случайного значения
function getRandom(lo,hi) {
    return Math.trunc((hi-lo) * Math.random() + lo);
}

//Создание массива фигур
function generateFigures() {
    return [
        new Sphere(getRandom(5,20),'sphere'),
        new Sphere(getRandom(5,20),'sphere'),
        new Cone(getRandom(5,15),getRandom(15,25),getRandom(15,25),'cone'),
        new Cone(getRandom(5,15),getRandom(15,25),getRandom(15,25),'cone'),
        new Cylinder(getRandom(5,15),getRandom(15,25),'cylinder'),
        new Cylinder(getRandom(5,15),getRandom(15,25),'cylinder'),

    ];
}

//region Задача 2

//Сформировать объект представления о погоде
function getViewWeather() {
    let rainfall1 = {
            temperature: generateTemperature(),
            pressure: generatePressure(),
            humidity: generateHumidity(),
            windObj: generateWind(),
        },
        sunny = {
            temperature: generateTemperature(),
            pressure: generatePressure(),
            humidity: generateHumidity(),
            windObj: generateWind(),
            typeIcon: "sunny.png"
        },
        partlyCloudy = {
            temperature: generateTemperature(),
            pressure: generatePressure(),
            humidity: generateHumidity(),
            windObj: generateWind(),
            typeIcon: "partly-cloudy.png"
        },
        rainfall2 = {
            temperature: generateTemperature(),
            pressure: generatePressure(),
            humidity: generateHumidity(),
            windObj: generateWind(),
        },
        cloudy = {
            temperature: generateTemperature(),
            pressure: generatePressure(),
            humidity: generateHumidity(),
            windObj: generateWind(),
            typeIcon: "clouds.png"
        }

    //Условное задание отображения иконки осадков
    rainfall1.typeIcon = rainfall1.temperature<=0?"snow.png":"rainy.png";
    rainfall2.typeIcon = rainfall2.temperature<=0?"snow.png":rainfall2.temperature>=27?"lightning.png":"rainy.png";

    //Сформировать массив
    let weather = [rainfall2,rainfall1,sunny,cloudy,partlyCloudy];

    return weather[getRandom(0,weather.length)];
}

function generateTemperature() {
    return getRandom(5,30);
}
function generatePressure() {
    return getRandom(700,1050);
}
function generateHumidity() {
    return getRandom(10,99);
}

//Функция возвращает объект
function generateWind() {

    //Направления ветра
    let windDirections = [
        "С",
        "С-В",
        "В",
        "Ю-В",
        "Ю",
        "Ю-З",
        "З",
        "С-З"
    ];

    return {
        direction: windDirections[getRandom(0, windDirections.length)],
        speed: getRandom(0, 5)
    };
}//generateWind

//Сформировать массив представлений погоды
function generateWeathers() {
    let array = new Array();

    for (let i = 0; i < 7; i++) {
        let w = getViewWeather();
        array[i] = new Weather(w.temperature,w.pressure,w.humidity,w.windObj,w.typeIcon,i+1)
    }

    return array;
}

function getDayOfWeek(n) {
    let days = [
        'ПН','ВТ','СР','ЧТ','ПТ','СБ','ВС'
    ];

    return days[n-1];
}

function getNumFromStr(str) {
    let temp = str.split(" ").filter(s => s.length>0);

    //При нахождении первого же числового значения возвращаем его
    for (let elem of temp) {
        if (!isNaN(parseInt(elem)))
            return parseInt(elem);
    }

    //Если ничего не найдено
    return 1e-10
}

//endregion