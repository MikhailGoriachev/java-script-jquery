/*
* Задача 3
* Реализуйте анимацию – перемещение произвольного небольшого изображения (изображение должно быть фоном блока div) в ограни-ченном прямоугольнике, по замкнутой траектории. Предусмотрите кнопки для запуска и останова движения, подберите задержку для равномерного движения изображения.
* */

window.onload = function() {
    // ссылка на объект, работающий с интервалом
    let intervalHandler;

    // период анимации в миллисекундах
    const period = 30;

    // объект для представления позиции изображения
    let position = {
        left: 20,
        top: 10
    }

    // направление движения, начинаем движение вправо
    let direction = 'right';

    // элемент для анимации перемещения
    let sun = $("sun");
    [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];

    // обработчик кнопки запуска анимации
    $("btnStart").onclick = function() {
        // останавливаем таймер, по которому вызывается функция animateCallback
        clearInterval(intervalHandler);

        // запуск периодической работы, получение ссылки на объект таймера
        intervalHandler = setInterval(() => animateMovement(sun), period);
        $("header").innerText = "Анимация работает";
    } // btnStart


    // обработчик кнопки останова анимации
    $("btnStop").onclick = function () {
        // останавливаем таймер, по которому вызывается функция animateCallback
        clearInterval(intervalHandler);

        let header = $("header");
        header.innerText = "Анимация остановлена";

        // переместить объект анимации в начальную точку
        position = {left: 20, top: 10};
        [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];
        direction = 'right';

        // через period миллисекунд после окончания анимации восстановим исходный текст
        // заголовка
        setTimeout(() => header.innerText="Блок для анимации - перемещение изображения", 5_000);
    } // btnStop


    // реализация анимации перемещения
    function animateMovement(item) {
        // область вывода для анимации элемента
        let animationArea = $("animationArea");

        switch (direction) {
            // движение вправо по горизонтали, по достижении ограничения
            // начинаем движение вниз по вертикали
            case 'right':
                position.left += 5;

                if (position.left >= animationArea.offsetWidth - item.offsetWidth - 30) {
                    position.left = animationArea.offsetWidth - item.offsetWidth - 30
                    direction = 'down';
                } // if
                break;

            // движение влево по горизонтали, по достижении ограничения (левой границы)
            // начинаем движение вверх
            case 'left':
                position.left -= 5;

                if ((position.left <= 20)) {
                    position.left = 20;
                    direction = 'up';
                } // if
                break;

            // движение объекта вверх по вертикали, по достижении верхнего
            // ограничения, начинаем движение вправо
            case 'up':
                position.top -= 3;

                if (position.top <= 10) {
                    position.top = 10;
                    direction = 'right';
                } // if
                break;

            // движение вниз по вертикали, по достижении нижнего ограничения
            // начинаем движение влево по горизонтали
            case 'down':
                position.top+=5;

                if (position.top >= animationArea.offsetHeight - item.offsetHeight - 20) {
                    position.top = animationArea.offsetHeight - item.offsetHeight - 20;
                    direction = 'left';
                } // if
                break;
        } // switch

        [item.style.left, item.style.top] = [`${position.left}px`, `${position.top}px`];
    } // animateMovement
} // onload