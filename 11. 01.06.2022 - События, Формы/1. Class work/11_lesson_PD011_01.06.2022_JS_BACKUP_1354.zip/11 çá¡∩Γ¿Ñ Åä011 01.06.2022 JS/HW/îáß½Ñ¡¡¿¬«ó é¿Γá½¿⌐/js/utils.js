/* Набор общих функций */

// Добавление функционала объекту массива - возврат случайного элемента
Array.prototype.random = function () {
    return this[Math.floor((Math.random()*this.length))];
}


// функция-оболочка для быстрого доступа к элементу DOM по идентификатору
function $(id) { return document.getElementById(id); }

// Генерация случайного вещественного числа
function getRandom(min,max){
    return Math.random() * (max - min) + min;
}

// Генерация случайного целого числа
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

// Генерация массива вещественных значений
function createArray(n, min, max) {
    return [...Array(n)].map(_ => getRandom(min, max));
}

// Генерация массива целочисленных значений
function createIntArray(n, min, max) {
    return [...Array(n)].map(_ => getRandomInt(min, max));
}

// Вывод массива с описанием на страницу
function renderArray(array, promt, highlightPredic = null, precision = 0) {
    let toRender = `<div class="indented"><div class="promt">${promt}</div><table><tr>`;
    array.forEach((item, index) => {
        let tdStyle = highlightPredic == null ? '' : highlightPredic(item, index) ? 'highlight' : '';
        toRender += `<td class="${tdStyle}">${+item.toFixed(precision)}</td>`;
    });
    toRender += '</table></tr></div>';
    document.write(toRender);
}
