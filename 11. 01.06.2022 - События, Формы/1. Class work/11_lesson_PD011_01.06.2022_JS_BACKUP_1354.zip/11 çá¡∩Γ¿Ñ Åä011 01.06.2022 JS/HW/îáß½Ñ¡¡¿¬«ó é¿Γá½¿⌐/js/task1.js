
// Даны строки S и S0. Удалить из строки S последнюю подстроку, совпадающую с S0.
// Если совпадающих подстрок нет, то вывести строку S без изменений
function point01(source = 'корабли лавировали лавировали, да не вылавировали',
                 subStr = 'лавир'){

    // Определяется подстрока subStr, после которой идет негативная опережающая проверка на
    // эту же подстроку, окруженную либо нет любыми последовательностями любых символов: (?!.*${subStr}.*),
    // что определяет условие отсутствия повторения подстроки в продолжении.
    // Всё, что после искомой подстроки, взято в скобочную группу для дальнейшего доступа к ней,
    // в методе replace вся найденная последовательность "подстрока + остаток, взятый в скобочную группу"
    // заменяется на данную скобочную группу.
    let pattern = new RegExp(`${subStr}((?!.*${subStr}.*))`, "g");
    let result = source.replace(pattern, '$1');


    /*
    // Способ с получением результатов найденных вхождений посредством matchAll
    let pattern = new RegExp(`${subStr}`, "g");
    let occurrences = Array.from(source.matchAll(pattern));
    let lastOccurIndex = occurrences[occurrences.length - 1].index;
    let result = source.substring(0, lastOccurIndex) + source.substring(lastOccurIndex + subStr.length);
    */

    return `<div><b>Исходная строка:</b> ${source}</div>
                <div><b>Подстрока для удаления:</b> ${subStr}</div>
                <div><b>Результат:</b> ${result}</div>`;
}

// Даны строки S, S1 и S2. Заменить в строке S все вхождения строки S1 на строку S2
function point02(source = 'корабли лавировали лавировали, да не вылавировали',
                 subStr1 = 'лавировали',
                 subStr2 = 'дрейфуют'){

    let pattern = new RegExp(subStr1, "g")
    let result = source.replace(pattern, subStr2);

    return `<div><b>Cтрока S:</b> ${source}</div>
                <div><b>Строка S1:</b> ${subStr1}</div>
                <div><b>Строка S2:</b> ${subStr2}</div>
                <div><b>Результат:</b> ${result}</div>`;
}

// Дана строка S, слова в которой разделяются одним пробелом. Найти количество слов,
// начинающихся на гласную букву, без учета регистра, вывести найденные слова
function point03(source = 'Изредка над изумрудным озером гордо пролетал одинокий орёл'){

    let pattern = /^[ауоыэяюёие][а-яё]+/i; // паттерн для проверки слова в строке состоящей лишь из него
    let words = source.split(/\s/).filter(w => pattern.test(w));

    // Выбор слов, начинающихся с гласных, перед которыми пробельный символ или начало строки,
    // с дальнейшим вычленением "чистых" слов по скобочной группе из результата matchAll
    //let pattern = /(?:^|\s)([ауоыэяюёие][а-яё]+)/gi;
    //let words = Array.from(source.matchAll(pattern)).map(i => i[1]);

    let result = words.join(', ');
    return `<div><b>Исходная строка:</b> ${source}</div>
            <div><b>Слова</b> (${words.length}): ${result}</div>`;
}

// Дана строка, состоящая из слов, разделенных одним пробелом. Сформировать строку, состоящую
// из этих же слов в порядке, обратном алфавитному. Вывести исходную и преобразованную строки
function point04(source = 'Изредка над изумрудным озером гордо пролетал одинокий орёл'){

    //let result = source.split(/\s/).sort((a, b) => b.localeCompare(a)).join(' ');
    let result =  source.match(/[а-яё]+/gi).sort((a, b) => b.localeCompare(a)).join(' ');

    return `<div><b>Исходная строка:</b> ${source}</div>
            <div><b>Преобразованная строка:</b> ${result}</div>`;
}

// Дана строка, состоящая из слов, разделенных одним пробелом. Сформировать строку, состоящую
// из этих же слов, размещенных в обратном порядке. Вывести исходную и преобразованную строки
function point05(source = 'Изредка над изумрудным озером гордо пролетал одинокий орёл'){

    //let result = source.split(/\s/).reverse().join(' ');
    let result =  source.match(/[а-яё]+/gi).reverse().join(' ');

    return `<div><b>Исходная строка:</b> ${source}</div>
            <div><b>Преобразованная строка:</b> ${result}</div>`;
}


window.onload = function () {
    $('point01').innerHTML = point01();
    $('point02').innerHTML = point02();
    $('point03').innerHTML = point03();
    $('point04').innerHTML = point04();
    $('point05').innerHTML = point05();
};

