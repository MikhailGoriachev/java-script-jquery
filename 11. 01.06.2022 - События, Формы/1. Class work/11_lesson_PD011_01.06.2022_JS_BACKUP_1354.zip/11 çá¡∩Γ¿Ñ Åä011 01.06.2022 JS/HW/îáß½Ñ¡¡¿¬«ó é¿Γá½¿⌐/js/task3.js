
// Коллекция объектов для работы с направлениями движения
let directions = [
    {name: "up",        dX:  0, dY: -1, checkBounds: (x, y) => y >= 0,               isGliding: (x, y) => x === 0 || x === 100},
    {name: "down",      dX:  0, dY:  1, checkBounds: (x, y) => y <= 100,             isGliding: (x, y) => x === 0 || x === 100},
    {name: "left",      dX: -1, dY:  0, checkBounds: (x, y) => x >= 0,               isGliding: (x, y) => y === 0 || y === 100},
    {name: "right",     dX:  1, dY:  0, checkBounds: (x, y) => x <= 100,             isGliding: (x, y) => y === 0 || y === 100},
    {name: "upLeft",    dX: -1, dY: -1, checkBounds: (x, y) => x >= 0 && y >= 0,     isGliding: () => false},
    {name: "upRight",   dX:  1, dY: -1, checkBounds: (x, y) => x <= 100 && y >= 0,   isGliding: () => false},
    {name: "downLeft",  dX: -1, dY:  1, checkBounds: (x, y) => x >= 0 && y <= 100,   isGliding: () => false},
    {name: "downRight", dX:  1, dY:  1, checkBounds: (x, y) => x <= 100 && y <= 100, isGliding: () => false },
];


window.onload = function () {
    // ссылка на объект, работающий с интервалом
    let interval;

    // скорость анимации
    let delay = 15;
    $('delay').innerHTML = `${delay} мс`;

    // ссылка на элемент разметки, в котором производится анимация
    let $box = $('box');

    // параметры позиции анимируемого фона
    let x = 50, y = 50;

    // текущее направление движения
    let direction = directions.random();

    // процесс изменения параметров позиционирования
    function processMove() {
        // обработка допустимости дальнейшего движения
        while (!direction.checkBounds(x + direction.dX, y + direction.dY))
            direction = directions.random();

        x += direction.dX;
        y += direction.dY;

        // при скольжении вдоль границ шанс сменить направление движения
        let changeDirectionChance = 5;
        if(direction.isGliding(x, y) && changeDirectionChance > getRandomInt(1, 100)){
            do {
                direction = directions[getRandomInt(4,7)];
            } while (!direction.checkBounds(x + direction.dX, y + direction.dY));
        }
    }

    //
    function animate() {
        processMove();
        $box.style.backgroundPosition = `${x}% ${y}%`
    }

    function startAnimation() {
        clearInterval(interval);
        interval = setInterval(animate, delay);
    }

    // Обработчики кнопок

    // запуск анимации
     $('btnMoveOn').onclick = () => startAnimation();
    // остановка анимации
     $('btnMoveOff').onclick = () => clearInterval(interval);
    // увеличить задержку
     $('btnDelayUp').onclick = () => {
         delay++;
         $('delay').innerHTML = `${delay} мс`;
         startAnimation();
     };
    // уменьшить задержку
    $('btnDelayDown').onclick = () => {
        if(delay > 0)
            delay--;
        $('delay').innerHTML = `${delay} мс`;
        startAnimation();
    };
}