
//Получение случайного значения
function getRandom(lo,hi) {
    return Math.trunc((hi-lo) * Math.random() + lo);
}

//Получение элемента по ID
function $(id) {
    return document.getElementById(id);
}

//region Заявки

function generateDestination() {
    let destinations = [
        "Дюссельдорф",
        "Гамбург",
        "Варшава",
        "Стамбул",
        "Брюссель",
        "Даллас",
        "Денвер",
    ];
    return destinations[getRandom(0,destinations.length)];
}
function generatePrice() {
    return getRandom(2000,5_000);
}
function generateFlightNumber() {
    return getRandom(100,1000);
}

//Функция возвращает объект
function generatePerson() {

    //Список персон
    let people = [
        'Лосева И.С.',
        'Михайлович А.В.',
        'Пелых М.У.',
        'Пономаренко Л.А.',
        'Хавалджи В.Д.',
        'Пархоменко И.В.',
        'Демидова А.А.',
        'Лапотникова О.Т.',
        'Чмыхало О.Т.',    ];

    return people[getRandom(0,people.length)];
}//generatePerson



function getNumFromStr(str) {
    let temp = str.split(" ").filter(s => s.length>0);

    //При нахождении первого же числового значения возвращаем его
    for (let elem of temp) {
        if (!isNaN(parseInt(elem)))
            return parseInt(elem);
    }

    //Если ничего не найдено
    return 1e-10
}

//endregion

function generateStr() {
    let objArr = [
        {
            s: "Каждая задача должна размещаться на собственной странице, на главной странице разместите задание на разработку",
            s0: "на",
            s1: "на",
        },
        {
            s: "Все действия по инициализации происходят в методе Seed, а сама инициализация БД предполагает простое сохранение данных в БД",
            s0: "БД",
            s1: "БД",
        },
        {
            s: "Скрипты должны выполняться при загрузке страниц , не используйте формы ввода, слушатели событий страниц",
            s0: "страниц",
            s1: "страниц",
        }];

    return objArr[getRandom(0,objArr.length)];
}


function getNumFromStr(str) {
    let temp = str.split(" ").filter(s => s.length>0);

    //При нахождении первого же числового значения возвращаем его
    for (let elem of temp) {
        if (!isNaN(parseInt(elem)))
            return parseInt(elem);
    }

    //Если ничего не найдено
    return 1e-10
}