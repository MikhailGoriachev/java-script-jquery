
//Функция с самовызовом
(function (){

    let position = {
        left: 15,
        top: 15
    }

    //Объект таймера
    let timer = 0;

    //Направление движения - для замкнутости траектории
    let direction = 0;


    window.onload = function () {

        //Анимируемый объект
        let pic = $("pic");
        pic.style.left = `${position.left}px`;
        pic.style.top = `${position.top}px`;

        //Начать анимацию
        $("startAnimation").onclick = function () {

            if (timer)
                clearInterval(timer);

            timer = setInterval(() => animation(),10)

        }

        //Остановить анимацию
        $("stopAnimation").onclick = function () {
            clearInterval(timer);

            smoothReturn();

        }

        //Аниманиция
        function animation() {
            pic.style.left = `${position.left}px`;
            pic.style.top = `${position.top}px`;

            //direction - примтивный флаг задания направлений
            if (direction >= 0) {
                position.top+=2;
                position.left+=2;
            }
            else{
                position.top-=2;
                position.left-=2;
            }

            if (position.left > 330)
                direction = -1;
            else if (position.left < 15)
                direction = 0;
        }

        //Мягкое возвращение блока
        function smoothReturn() {
            let interval = 0;

            //Изменение положения бока
            function returning() {
                pic.style.left = `${position.left}px`;
                pic.style.top = `${position.top}px`;

                //Пока не будет достигнута нужная позиция
                if (position.left > 15){
                    position.top-=2;
                    position.left-=2;
                    return;
                }

                //Отключить интервальный вызов
                clearInterval(interval);
            }

            interval = setInterval(() => returning(),4);
        }


    }
})();