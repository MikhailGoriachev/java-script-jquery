//Заявка
class Claim {
    //Свойства
    constructor(destination, flightNum, passenger, ticketPrice) {
        this.destination = destination;
        this.flightNum = flightNum;
        this.passenger = passenger;
        this.ticketPrice = ticketPrice;
    }


    //region Геттеры и сеттеры

    //region Пункт назаняения
    get destination() {
        return this._destination;
    }

    set destination(value) {
        this._destination = value;
    }
    //endregion

    //region Номер рейса
    get flightNum() {
        return this._number;
    }

    set flightNum(value) {

        this._number = value<0?getRandom(200,900):value;
    }
    //endregion

    //region Фамилия и инициалы пассажира
    get passenger() {
        return this._passenger;
    }

    set passenger(value) {
        this._passenger = value;
    }
    //endregion

    //region Стоимость билета
    get ticketPrice() {
        return this._price;
    }

    set ticketPrice(value) {
        this._price = value<0?getRandom(2500,30000):value;
    }
    //endregion

    //endregion

    //endregion

    //Вывод
    toTableRow (n) {
        return `<div id="d_${n}">
                    <table>
                        <tr><td><span>Пункт назначения: <b>${this._destination}</b></span></td></tr>
                        <tr><td><span>Номер рейса: <b>${this._number}</b></span></td></tr>
                        <tr><td><span>Пассажир: <b>${this._passenger}</b></span></td></tr>
                        <tr><td><span>Стоимость билета: <b>${this._price}</b></span></td></tr>
                    </table>
                </div>`
    }

    //Выделение элемента
    highlightElement(cardId,predicate){
        if (!predicate(this))
            return;

        $(`d_${cardId}`).getElementsByTagName("table")[0].className = "highlightClaim";
        setTimeout(() => this.resetStyle(cardId),10_000);
    }

    //Сброс выделения элемента
    resetStyle(cardId){
        $(`d_${cardId}`).getElementsByTagName("table")[0].classList.remove("highlightClaim");
    }

}

//Управление заявками
class ClaimsView{
    constructor(claimsArr) {
        this.claims = claimsArr;
    }

    //Генерация массива заявок
    static generateClaims() {
        let array = [];

        for (let i = 0; i < 8; i++) {
            array[i] = new Claim(generateDestination(),generateFlightNumber(),generatePerson(),generatePrice())
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(claimsArr) {
        let n = 0;
        let str = claimsArr.reduce((acc,claim) => acc+claim.toTableRow(n++),'');

        return str;
    }
}


//region Сортировки, обработчики

//Упорядочить представление по пунктам назначения
function orderDescByDestination(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c1.destination.localeCompare(c2.destination));

    return () => {
        blockObject.innerHTML = ClaimsView.createMarkup(copy)
        titleObject.innerHTML = `<span>Сортировка массива по пунктам назначения</span>`;
    }
}//orderDescByTemperature

//Упорядочить представление по стоимости билета
function orderAscByPrice(blockObject,titleObject,claimsArr,sortedCollection) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c2.ticketPrice-c1.ticketPrice);

    return () => {
        sortedCollection = copy
        blockObject.innerHTML = ClaimsView.createMarkup(copy)
        titleObject.innerHTML = `<span>Сортировка массива по стоимости билета</span>`;
    }
}//orderAscByPrice


//endregion


//Функция с самовызовом
(function (){

    //Массив заявок
    let claimView = new ClaimsView(ClaimsView.generateClaims());

    let mainBlock = $("mainDiv");

    //Для выделения элементов в отсортированных коллекциях
    let collectionHighlight = [];

    mainBlock.innerHTML = ClaimsView.createMarkup(claimView.claims);


    //region Вставка заголовка
    let title = document.createElement("p");
    title.setAttribute("id", "taskTitle");
    title.setAttribute("class", "title-style");

    title.innerHTML = `<span>Исходный массив</span>`;
    mainBlock.parentNode.insertBefore(title, mainBlock);
    //endregion

    title = $('taskTitle');

    window.onload = function () {
        //Обработчик кнопки вывода исходного массива
        $("defaultArr").onclick = function () {

            collectionHighlight = claimView.claims;

            mainBlock.innerHTML = ClaimsView.createMarkup(claimView.claims);
            title.innerHTML = `<span>Исходный массив</span>`;
        }

        //region Сортировки

        //Обработчик кнопки сортировки по пункту на назначения
        $("orderByDest").onclick = orderDescByDestination(mainBlock, title,claimView.claims,collectionHighlight);

        //Обработчик кнопки сортировки по стоимости билета
        $("orderByPrice").onclick = orderAscByPrice(mainBlock, title,claimView.claims,collectionHighlight);


        //endregion


        //Выделить заявки со стоимостью > 3к руб.
        /*$("highlightClaims").onclick = function () {


            let n = 0;

            //Сброс предыдущих выделений
            collectionHighlight.forEach(с => с.resetStyle(n++));


            function predicate(claim) {
                return claim.ticketPrice > 3000;
            }

            n = 0;

            //Выделение элемента для которого отработает предикат
            collectionHighlight.forEach(c => c.highlightElement(n++, predicate));

            title.innerHTML = `<span>Заявки со стоимостью > 3к руб.</span>`;
        }*/

        //Изменение оформления элементов представления
        $("highlightClaims").onclick = function () {

            //Получаем массив дочерних элементов общего блока
            let childNodes = [];
            mainBlock.childNodes.forEach(c => {
                if (c.nodeType == 1)
                    childNodes.push(c);
            });

            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {
                let data = getNumFromStr(childNode.getElementsByTagName("span")[3].getElementsByTagName("b")[0].innerHTML)

                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (data > 3000) {
                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                    setTimeout(() => childNode.getElementsByTagName("table")[0].classList.remove("highlightClaim"),10_000);
                }

            }

        }


    }
})();