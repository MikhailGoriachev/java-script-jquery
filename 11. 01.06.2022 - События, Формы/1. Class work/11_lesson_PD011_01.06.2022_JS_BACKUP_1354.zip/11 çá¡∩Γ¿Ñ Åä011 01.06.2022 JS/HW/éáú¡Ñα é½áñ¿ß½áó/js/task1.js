
//Вывод в блок
function outputToBlock(blockId,markup) {
    //Вывод разметки в блок
    $(blockId).innerHTML = markup;
}


//Функция с самовызовом
(function (){

    //Вывод разметки в блок
    outputToBlock("mainDiv",  point1());

    window.onload = function () {

        //Обработчик кнопки пункта 1
        $("point_1").onclick = function () {

            outputToBlock("mainDiv", point1());
        }
        //Обработчик кнопки пункта 2
        $("point_2").onclick = function () {

            outputToBlock("mainDiv", point2());
        }
        //Обработчик кнопки пункта 3
        $("point_3").onclick = function () {

            outputToBlock("mainDiv", point3());
        }
        //Обработчик кнопки пункта 4
        $("point_4").onclick = function () {

            outputToBlock("mainDiv", point4());
        }
        //Обработчик кнопки пункта 5
        $("point_5").onclick = function () {

            outputToBlock("mainDiv", point5());
        }

    }//window.onload function
})();


//Выполнение пункта 1: удаление последней совпадающей подстроки
function point1() {

    let strObj = generateStr();

    //формирование разметки до
    let createMarkBefore = function () {
        return `
        <table>
            <tr>
                <th class="info-cell">Условие</th>
                <td>
                    <p class="paragraph-settings">
                        Даны строки S и S0. Удалить из строки S последнюю подстроку, совпадающую с S0.
                        Если совпадающих подстрок нет, то вывести строку S без изменений
                    </p>
                </td>
            </tr>
            <tr>
                <th class="info-cell" rowspan="4">Реализация</th>
                <td class="content-cell">Начальная строка: <span class="highlightString">${strObj.s}</span></td>
            </tr>
            <tr>
                <td class="content-cell">Подстрока для удаления: <span class="highlightString">${strObj.s0}</span></td>
            </tr>
            `
    }
    //формирование разметки после обработки
    let createMarkAfter = function () {
        return `
            <tr>
                <td class="content-cell">Строка после удаления: <span class="highlightChangedString">${strObj.s}</span></td>
            </tr>
            </table>
            `
    }

    let markUp = createMarkBefore();

    strObj.s = point1Handle(strObj.s,strObj.s0);

    markUp += createMarkAfter();

    return markUp;

}

//Обработка пункт 1
function point1Handle(s,s0) {
    //Если строка не содержит определённой подстроки
    if (!s.includes(s0))
        return "";

    let pattern = new RegExp(`${s0}`);

    let index = s.search(pattern);

    let lastInd = s.lastIndexOf(s[index])

    console.log(`Последний индекс: ${lastInd}`)

    //Замена последнего вхождения
    return s.substring(0,lastInd)+s.substring(lastInd+s0.length);
}

//Выполнение пункта 2: замена в строке S всех вхождений строки S1 на строку S2
function point2() {

    let strObj = generateStr();
    let s2 = '---'

    //формирование разметки до
    let createMarkBefore = function () {
        return `
        <table>
            <tr>
                <th class="info-cell">Условие</th>
                <td>
                    <p class="paragraph-settings">
                        Даны строки S, S1 и S2. Заменить в строке S все
                        вхождения строки S1 на строку S2.
                    </p>
                </td>
            </tr>
            <tr>
                <th class="info-cell" rowspan="5">Реализация</th>
                <td class="content-cell">Начальная строка: <span class="highlightString">${strObj.s}</span></td>
            </tr>
            <tr>
                <td class="content-cell">Подстрока для удаления S1: <span class="highlightString">${strObj.s1}</span></td>
            </tr>
            <tr>
                <td class="content-cell">Подстрока для замены S2: <span class="highlightString">${s2}</span></td>
            </tr>
            `
    }
    //формирование разметки после обработки
    let createMarkAfter = function () {
        return `
            <tr>
                <td class="content-cell">Строка после обработки: <span class="highlightChangedString">${strObj.s}</span></td>
            </tr>
            </table>
            `
    }

    let markUp = createMarkBefore();

    strObj.s = point2Handle(strObj.s,strObj.s0,s2);

    markUp += createMarkAfter();

    return markUp;

}

//Обработка пункт 2
function point2Handle(s,s1,s2) {
    //Если строка не содержит определённой подстроки
    if (!s.includes(s1))
        return "";

    let pattern = new RegExp(`${s1}`,'g');

    //Замена последнего вхождения
    return s.replace(pattern,s2);
}

//Выполнение пункта 3: поиск количества слов, начинающихся на гласную букву
function point3() {

    let strObj = generateStr();
    let count = 0;
    let words = '';

    //формирование разметки до
    let createMarkBefore = function () {
        return `
        <table>
            <tr>
                <th class="info-cell">Условие</th>
                <td>
                    <p class="paragraph-settings">
                        Дана строка S, слова в которой разделяются одним пробелом. 
                        Найти количество слов, начинающихся на гласную букву, без учета регистра, 
                        вывести найденные слова
                    </p>
                </td>
            </tr>
            <tr>
                <th class="info-cell" rowspan="3">Реализация</th>
                <td class="content-cell">Начальная строка: <span class="highlightString">${strObj.s}</span></td>
            </tr>
            `
    }
    //формирование разметки после обработки
    let createMarkAfter = function () {
        return `
            <tr>
                <td class="content-cell">Количество слов: <span  class="highlightChangedString">${count>0?count:("слова не найдены")}</span></td>
            </tr>
            <tr>
                <td class="content-cell">Найденные слова: <span class="highlightChangedString">${count>0?words:("слова не найдены")}</span></td>
            </tr>
            </table>
            `
    }

    let markUp = createMarkBefore();

    words = point3Handle(strObj.s);
    count = words.length;

    markUp += createMarkAfter();

    return markUp;

}

//Обработка пункт 3
function point3Handle(s) {
    let strArr = s.split(" ").filter(s => s.length>0);

    //Регулярное выражение для поиска в начале слова
    let pattern = new RegExp(`^[аяуюоеёэиыaeiouy]`);

    //Для записи найденных слов
    let words = [];

    for (let i = 0; i < strArr.length; i++) {
        if (pattern.test(strArr[i].toLowerCase()))
            words.push(strArr[i])
    }

    return words;
}

//Выполнение пункта 4: формирование строки, состоящей из собственных слов в порядке, обратном алфавитному
function point4() {

    let strObj = generateStr();

    //формирование разметки до
    let createMarkBefore = function () {
        return `
        <table>
            <tr>
                <th class="info-cell">Условие</th>
                <td>
                    <p class="paragraph-settings">
                    Дана строка, состоящая из слов, разделенных одним пробелом.
                    Сформировать строку, состоящую из этих же слов в порядке, обратном алфавитному. 
                    Вывести исходную и преобразованную строки
                    </p>
                </td>
            </tr>
            <tr>
                <th class="info-cell" rowspan="3">Реализация</th>
                <td class="content-cell">Начальная строка: <span class="highlightString">${strObj.s}</span></td>
            </tr>
            `
    }
    //формирование разметки после обработки
    let createMarkAfter = function () {
        return `
            <tr>
                <td class="content-cell">Строка в обратном порядке: <span  class="highlightChangedString">${strObj.s}</span></td>
            </tr>
            </table>
            `
    }

    let markUp = createMarkBefore();

    strObj.s = point4Handle(strObj.s);

    markUp += createMarkAfter();

    return markUp;

}

//Обработка пункт 4
function point4Handle(s) {

    let strArr = s.split(" ").filter(s => s.length>0);

    return strArr.sort((s1,s2) => s2.localeCompare(s1)).join(" ");
}


//Выполнение пункта 5: формирование строки, состоящей из собственных слов, размещенных в обратном порядке
function point5() {

    let strObj = generateStr();

    //формирование разметки до
    let createMarkBefore = function () {
        return `
        <table>
            <tr>
                <th class="info-cell">Условие</th>
                <td>
                    <p class="paragraph-settings">
                    Дана строка, состоящая из слов, разделенных одним пробелом.
                    Сформировать строку, состоящую из этих же слов, размещенных в обратном порядке. 
                    Вывести исходную и преобразованную строки
                    </p>
                </td>
            </tr>
            <tr>
                <th class="info-cell" rowspan="3">Реализация</th>
                <td class="content-cell">Начальная строка: <span class="highlightString">${strObj.s}</span></td>
            </tr>
            `
    }
    //формирование разметки после обработки
    let createMarkAfter = function () {
        return `
            <tr>
                <td class="content-cell">Строка в обратном порядке: <span  class="highlightChangedString">${strObj.s}</span></td>
            </tr>
            </table>
            `
    }

    let markUp = createMarkBefore();

    strObj.s = point5Handle(strObj.s);

    markUp += createMarkAfter();

    return markUp;

}

//Обработка пункт 5
function point5Handle(s) {

    let strArr = s.split(" ").filter(s => s.length>0);

    return strArr.reverse().join(" ");
}