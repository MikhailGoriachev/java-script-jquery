


//region Функции для работы с куки
function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
        "(?:^|; )" + name.replace(/([.$?*|{}()\[\]\\\/+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
}

function setCookie(name, value, options = {}) {
    options = {
        path: '/',
        ...options
    };

    if (options.expires instanceof Date) {
        options.expires = options.expires.toUTCString();
    }

    let updatedCookie = encodeURIComponent(name) + "=" + encodeURIComponent(value);

    for (let optionKey in options) {
        updatedCookie += `; ${optionKey}=${options[optionKey] ?? ""}`;
    }
    document.cookie = updatedCookie;
}

function deleteCookie(name) {
    setCookie(name, "", {
        'max-age': -1
    })
}

function clearCookies() {
    document.cookie.split(";").forEach(s => deleteCookie(s.split("=")[0].trim()));
}
//endregion



/*
function clearCookies() {
    let cookies = document.cookie.split("; ");
    for (let c = 0; c < cookies.length; c++) {
        let d = window.location.hostname.split(".");
        while (d.length > 0) {
            let cookieBase = encodeURIComponent(cookies[c].split(";")[0].split("=")[0]) +
                '=; expires=Thu, 01-Jan-1970 00:00:01 GMT; domain=' + d.join('.') + ' ;path=';
            let p = location.pathname.split('/');
            document.cookie = cookieBase + '/';
            while (p.length > 0) {
                document.cookie = cookieBase + p.join('/');
                p.pop();
            }
            d.shift();
        }
    }
}
*/

// Добавление функционала объекту массива - возврат случайного элемента
Array.prototype.random = function () {
    return this[Math.floor((Math.random()*this.length))];
}

// случайный ключ объекта
//Object.prototype.random = function(){
//    let keys = Object.keys(this);
//    return this[keys[ keys.length * Math.random() << 0]];
//}


// функция-оболочка для быстрого доступа к элементу DOM по идентификатору
//function $(id) { return document.getElementById(id); }

// Генерация случайного вещественного числа
function getRandom(min,max){
    return Math.random() * (max - min) + min;
}

// Генерация случайного целого числа
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

function declOfNum(number, words) {
    return words[(number % 100 > 4 && number % 100 < 20) ? 2 : [2, 0, 1, 1, 1, 2][(number % 10 < 5) ? Math.abs(number) % 10 : 5]];
}

// Генерация массива вещественных значений
function createArray(n, min, max) {
    return [...Array(n)].map(_ => getRandom(min, max));
}

// Генерация массива целочисленных значений
function createIntArray(n, min, max) {
    return [...Array(n)].map(_ => getRandomInt(min, max));
}

// Вывод массива с описанием на страницу
function renderArray(array, promt, highlightPredic = null, precision = 0) {
    let toRender = `<div class="indented"><div class="promt">${promt}</div><table><tr>`;
    array.forEach((item, index) => {
        let tdStyle = highlightPredic == null ? '' : highlightPredic(item, index) ? 'highlight' : '';
        toRender += `<td class="${tdStyle}">${+item.toFixed(precision)}</td>`;
    });
    toRender += '</table></tr></div>';
    document.write(toRender);
}
