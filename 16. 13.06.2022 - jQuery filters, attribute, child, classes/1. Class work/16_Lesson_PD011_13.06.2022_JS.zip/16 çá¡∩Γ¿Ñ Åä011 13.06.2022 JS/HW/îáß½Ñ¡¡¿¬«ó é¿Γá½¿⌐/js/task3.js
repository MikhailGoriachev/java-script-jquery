
// ссылки на объекты для работы
const Task3 = {
    company: null,
    timer: null,
    delay: 15_000,
    $emp: null,
    $modalWindow: null,
    $workersForm: null
};

const keyMap = {
    "KeyQ": onNewWorker,
    "KeyW": outputSourceData,
    "KeyE": orderBySurname,
    "KeyA": markMinSalaries,
    "KeyS": markMaxSalaries,
    "KeyD": markServiceYears,
    "KeyF": markPositions,
    "KeyG": markAdmissionYear,
}

$(function() {
    // начальная инициация
    Task3.$emp = $("#employees");
    Task3.$modalWindow =  $("#modalWindow");
    Task3.$workersForm = $("#workerForm");

    // заполнение списков должностей
    WorkerFactory.positions.sort().forEach(p => {
        $('#workerForm #selPosition').append($('<option>', {value: p}).text(p));
        $('#selMarkPositions').append($('<option>', {value: p}).text(p));
    });

    // установка обработчиков
    $("#btnOrderBySurname").click(orderBySurname);
    $("#btnSrcData").click(outputSourceData);
    $("#btnMarkServiceYears").click(markServiceYears);
    $("#btnMarkMinSalaries").click(markMinSalaries);
    $("#btnMarkMaxSalaries").click(markMaxSalaries);
    $("#btnMarkPositions").click(markPositions);
    $("#btnMarkAdmYear").click(markAdmissionYear);
    $("#btnNewWorker").click(onNewWorker);
    $("#btnCancel").click(closeModalWindow);
    $("#closeModal").click(closeModalWindow);
    Task3.$workersForm.on("submit", onSubmitHandler);
    $(this).click(onClick).on("keypress", onKeyPress);

    Task3.company = new Company(!window.localStorage.workers
        ? WorkerFactory.generateCollection(12)
        : Company.loadFromLocalStorage());

    outputSourceData();
});

// вывести исходные данные
function outputSourceData() {
    Task3.$emp.html(Task3.company.toHtml());
}

// упорядочить по фамилии
function orderBySurname() {
    Task3.$emp.html(Company.toHtml(Task3.company.orderBySurname()));
}

// выделить с указанной должностью
function markPositions() {
    let value = $("#selMarkPositions").val();
    if(!value)
        return;

    clearMarked();
    $(`div[id^='emp']:has(div[class*='emp-pos']:contains(${value}))`, "#employees").addClass('marked');

    clearTimeout(Task3.timer);
    Task3.timer = setTimeout(outputSourceData, Task3.delay);
}

// выделить с указанным годом поступления
function markAdmissionYear() {
    let value = $("#inpMarkAdmYear").val();
    if(!value)
        return;

    clearMarked();
    $(`div[id^='emp']:has(div[class*='emp-adm-year']:contains(${value}))`, "#employees").addClass('marked');

    clearTimeout(Task3.timer);
    Task3.timer = setTimeout(outputSourceData, Task3.delay);
}

// Выделить с мин. окладами
function markMinSalaries() {
    Task3.$emp.html(Company.toHtml(Task3.company.orderBySurname()));
    Task3.company.selectWhereMinSalaries().forEach(w => $(`#emp${w.id}`).addClass('marked'));

    clearTimeout(Task3.timer);
    Task3.timer = setTimeout(outputSourceData, Task3.delay);
}

// Выделить с макс. окладами
function markMaxSalaries() {
    Task3.$emp.html(Company.toHtml(Task3.company.orderByPosition()));
    Task3.company.selectWhereMaxSalaries().forEach(w => $(`#emp${w.id}`).addClass('marked'));

    clearTimeout(Task3.timer);
    Task3.timer = setTimeout(outputSourceData, Task3.delay);
}

// выделить со стажем свыше
function markServiceYears() {
    clearMarked();
    let value = $("#inpLengthOfService").val();
    if(!value) return;

    Task3.$emp.html(Company.toHtml(Task3.company.orderBySalary()));
    Task3.company.selectWhereAdmissionYearsMoreThan(value)
        .forEach(w => $(`#emp${w.id}`).addClass('marked'));

    clearTimeout(Task3.timer);
    Task3.timer = setTimeout(outputSourceData, Task3.delay);
}

// убрать выделения работников
function clearMarked() {
    $(".marked", "#employees").removeClass('marked');
}

// обработчик нажатия кнопки мыши
function onClick(e) {
    if (e.target === Task3.$modalWindow[0])
        closeModalWindow();

    if(e.target.name === "editWorker")
        onEdit(e.target);
    if(e.target.name === "deleteWorker")
        onDelete(e.target);
}

// спрятать окно с формой
function closeModalWindow() {
    Task3.$modalWindow.hide();
}

// обработчик подтверждения на форме
function onSubmitHandler(event){
    let fullName = this.fullName.value;
    let sex = this.sex.value;
    let position = this.position.value;
    let admYear = this.admYear.value;
    let salary = this.salary.value;
    let id = this.idWorker.value;

    if(this.submit.value === "Добавить") {
        let worker = Task3.company.addWorker(fullName, position, sex, admYear, salary);
        Task3.$emp.append(worker.toHtml());
    }

    if(this.submit.value === "Изменить") {
        Task3.company.updateWorker(id, fullName, position, sex, admYear, salary);
        $(`#emp${id}`).html(Task3.company.getById(id).toHtml());
    }

    closeModalWindow();
    event.preventDefault();
}

// вызов добавления нового сотрудника
function onNewWorker() {
    Task3.$workersForm.trigger("reset");
    $("#formTitle").html("Добавить данные сотрудника");
    $("#workerForm #btnAddTicket").val("Добавить");
    Task3.$modalWindow.show();
}

// вызов редактирования данных сотрудника
function onEdit(e) {
    let id = e.parentElement.parentElement.id;

    let worker = Task3.company.getById(id.substring(3));

    $("#workerForm #inpName").val(worker.fullName);
    $("#workerForm #selSex").val(worker.sex);
    $("#workerForm #selPosition").val(worker.position);
    $("#workerForm #inpAdmYear").val(worker.admissionYear);
    $("#workerForm #inpSalary").val(worker.salary);
    $("#workerForm #idWorker").val(worker.id);

    $("#workerForm #formTitle").html("Изменить данные сотрудника");
    $("#workerForm #btnAddWorker").val("Изменить");
    Task3.$modalWindow.show();
}

// обработчик удаления сотрудника
function onDelete(e) {
    let id = e.parentElement.parentElement.id;
    Task3.company.deleteWorker(id.substring(3));
    e.parentElement.parentElement.remove();
}

function onKeyPress(e) {
    if(e.code in keyMap)
        keyMap[e.code]();
}
