/* класс Worker
•	идентификатор работника
•	фамилия и инициалы работника;
•	название занимаемой должности;
•	пол (мужской\женский);
•	год поступления на работу;
•	имя файла с фотографией работника
•	величина оклада работника;
•	метод вычисления стажа работника для текущей даты.
*/

class Worker {
    constructor(id = 0, fullName = "", position = "", sex = "",
                admissionYear = "", photoImg = "", salary = 0) {
        this._id = id;
        this._fullName = fullName;
        this._sex = sex;
        this._admissionYear = admissionYear;
        this._photoImg = photoImg;
        this._salary = salary;
        this._position = position;
    }

    get id() { return this._id; }
    set id(value) { this._id = value; }

    get fullName() { return this._fullName; }
    set fullName(value) { this._fullName = value; }

    get position() { return this._position; }
    set position(value) { this._position = value; }

    get sex() { return this._sex; }
    set sex(value) { this._sex = value; }

    get admissionYear() { return this._admissionYear; }
    set admissionYear(value) { this._admissionYear = value; }

    get photoImg() { return this._photoImg; }
    set photoImg(value) { this._photoImg = value; }

    get salary() { return this._salary; }
    set salary(value) { this._salary = value; }

    get lengthOfService() { return new Date().getFullYear() - this._admissionYear; }

    toHtml() {
        return `<div id="emp${this._id}" class="person-block">
                      <img class="person-img" src='../images/photos/${this._photoImg}' alt ="pic"/>
                      <div class="field-container">
                        <div class="w-name">${this._fullName}</div>
                        <div class="emp-sex"><div class="desc">Пол:</div> ${this._sex}</div>
                        <div class="emp-pos"><div class="desc">Должность:</div> ${this._position}</div>
                        <div class="emp-adm-year"><div class="desc ">Год поступления:</div> ${this._admissionYear}</div>
                        <div class="emp-length-service"><div class="desc">Стаж:</div> ${this.lengthOfService} ${declOfNum(this.lengthOfService, ['год', 'года', 'лет'])}</div>
                        <div class="emp-salary"><div class="desc ">Оклад:</div> ${this._salary} р.</div>
                      </div>
                      <div class="buttons">
                        <button name="editWorker" class="block-btn btn-blue" >Изменить</button>
                        <button name="deleteWorker" class="block-btn btn-blue">Удалить</button>
                      </div>
                    </div>`;
    }

    assign(worker) {
        Object.assign(this, worker);
        return this;
    }
}

// Фабрика создания работников
class WorkerFactory {
    static generateCollection(amount) {
        return [...Array(amount)].map((w,i) => this.generateWorker(i + 1));
    }

    static generateWorker(id) {
        return [this.generateMale, this.generateFeMale].random()(id);
    }

    static generateMale(id) {
        return new Worker(id, WorkerFactory.randomMaleName(), WorkerFactory.randomPosition(), "Мужской",
            WorkerFactory.randomAdmissionYear(), WorkerFactory.randomMaleImg(), WorkerFactory.randomSalary() );
    }

    static generateFeMale(id) {
        return new Worker(id, WorkerFactory.randomFemaleName(), WorkerFactory.randomPosition(), "Женский",
            WorkerFactory.randomAdmissionYear(), WorkerFactory.randomFemaleImg(), WorkerFactory.randomSalary() );
    }

    static randomMaleImg() { return `man_${getRandomInt(1,20)}.jpg`; }
    static randomFemaleImg() { return `woman_${getRandomInt(1,20)}.jpg`; }
    static randomSalary() { return getRandomInt(10_000, 30_000); }
    static randomAdmissionYear() { return getRandomInt(2010, 2021); }

    static randomMaleName() {
        return [ "Рябинин А.А.", "Николаев Ф.А.", "Федоров М.М.", "Семенов М.Д.", "Федоров Д.М.",
            "Кузнецов Г.Д.", "Коновалов И.Ф.", "Титов В.М.", "Андреев А.И.", "Никитин Л.Г.",
            "Чесноков Д.Т.", "Комаров Д.А.", "Антонов В.И.", "Баранов М.А.", "Новиков А.Р.",
            "Сорокин Д.Д.", "Никольский Д.Г.", "Дорофеев А.М.", "Булгаков М.Р.", "Васильев А.М.",
            "Осипов А.Б.", "Руднев А.Л.", "Соколов З.Ф.", "Ершов Б.С.", "Макаров А.А.",
            "Киселев М.А.", "Гаврилов И.Д.", "Белов П.И.", "Моисеев А.Г.", "Яковлев Д.А."].random();
    }

    static randomFemaleName() {
        return [ "Осипова В.Д.", "Крылова А.А.", "Глухова М.О.", "Филатова С.А.", "Яковлева Е.П.",
            "Михайлова В.К.", "Ерофеева С.С.", "Жданова Е.Т.", "Демина Е.И.", "Панова М.С.",
            "Тарасова Е.И.", "Коровина В.М.", "Сазонова М.Д.", "Иванова К.М.", "Королева Е.М.",
            "Пирогова С.М.", "Тимофеева В.М.", "Козырева М.С.", "Волкова В.Т.", "Коновалова К.А.",
            "Беликова В.В.", "Романова С.А.", "Суркова К.К.", "Мещерякова В.М.", "Васильева А.З.",
            "Ситникова Д.Н.", "Васильева А.М.", "Васильева С.Е.", "Булгакова А.Я.", "Ушакова К.Д."].random();
    }

    static positions = [ "Технический писатель", "Официант", "Кладовщик", "Почтальон", "Геолог" , "Реабилитолог",
        "Космонавт", "Косметолог" , "Спортивный врач", "Бульдозерист", "Пекарь", "Холодильщик",
        "Археолог", "Строитель" , "Бизнес-аналитик", "Штурман", "Генетик", "Бизнес-тренер", "Швея",
        "Наладчик", "Биоинженер", "Менеджер по рекламе", "Кинодраматург", "Логопед", "Пастух", "Дорожный инспектор",
        "Воспитатель", "Травматолог", "Философ", "Лоцман", "Проходчик", "Зубной техник", "Заведующий складом",
        "Уборщик", "Судебный пристав", "Фальцовщик", "Вирусолог", "Невролог", "Проректор" ,"Администратор сайта",
        "Программист", "Блогер", "Консультант по туризму", "Таксист", "Логист", "Пожарный", "Лоббист", "Дерматовенеролог",
        "Инженер-технолог", "Официант"];

    static randomPosition() {
        return WorkerFactory.positions.random();
    }
}

// Класс компании для работы с коллекцией работников
class Company {
    constructor(workers = null) {
        this.workers = workers;
    }

    get workers() { return this._workers; }
    set workers(value) {
        this._workers = value;
        this.saveToLocalStorage();
    }

    // получить работника по id
    getById(id) {
        return this._workers.filter(w => +w.id === +id)[0];
    }

    // добавить работника
    addWorker(fullName, position, sex, admissionYear, salary){
        let id = this._workers.length ? Math.max(...this._workers.map(t => t.id)) + 1 : 1;
        let photoImg = sex === "Мужской" ? WorkerFactory.randomMaleImg() : WorkerFactory.randomFemaleImg();
        let worker = new Worker(id, fullName, position, sex, admissionYear, photoImg, salary);

        this._workers.push(worker);
        this.saveToLocalStorage();
        return worker;
    }

    // изменить работника
    updateWorker(id, fullName, position, sex, admissionYear, salary) {
        let index = this._workers.findIndex(w => +w.id === +id);
        this._workers[index].fullName = fullName;
        this._workers[index].position = position;
        this._workers[index].sex = sex;
        this._workers[index].admissionYear = admissionYear;
        this._workers[index].salary = salary;

        this.saveToLocalStorage();
    }

    // удалить работника по id
    deleteWorker(id){
        let index = this._workers.findIndex(w => +w.id === +id);
        if(index > -1)
            this._workers.splice(index, 1);

        this.saveToLocalStorage();
    }

    // получить копию, упорядоченную по фамилии
    orderBySurname() {
        return [...this._workers].sort((a,b) => a.fullName.localeCompare(b.fullName));
    }
    // получить копию, упорядоченную по должности
    orderByPosition() {
        return [...this._workers].sort((a,b) => a.position.localeCompare(b.position));
    }
    // получить копию, упорядоченную по окладу
    orderBySalary() {
        return [...this._workers].sort((a,b) => a.salary - b.salary);
    }

    // получить выборку с минимальными окладами
    selectWhereMinSalaries() {
        let minSalary = Math.min(...this._workers.map(w => w.salary));
        return this._workers.filter(w => +w.salary === +minSalary);
    }
    // получить выборку с максимальными окладами
    selectWhereMaxSalaries() {
        let maxSalary = Math.max(...this._workers.map(w => w.salary));
        return this._workers.filter(w => +w.salary === +maxSalary);
    }
    // получить выборку работников со стажем более чем
    selectWhereAdmissionYearsMoreThan(years) {
        return this._workers.filter(w => w.lengthOfService > years);
    }

    toHtml(){
        return this._workers.reduce((prev, cur) => prev += cur.toHtml(), "");
    }

    static toHtml(workers){
        return workers.reduce((prev, cur) => prev += cur.toHtml(), "");
    }

    saveToLocalStorage() {
        window.localStorage.workers = JSON.stringify(this._workers);
    }

    loadFromLocalStorage() {
        this._workers = Company.loadFromLocalStorage();
    }

    static loadFromLocalStorage() {
        return JSON.parse(window.localStorage.workers).map(w => new Worker().assign(w));
    }
}
