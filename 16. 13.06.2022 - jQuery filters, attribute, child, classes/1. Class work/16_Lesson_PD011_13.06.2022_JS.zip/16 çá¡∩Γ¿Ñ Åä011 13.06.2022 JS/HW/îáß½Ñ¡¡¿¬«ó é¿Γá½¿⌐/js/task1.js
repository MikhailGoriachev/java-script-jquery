// базовый класс объекта для рендеринга фигуры
class Shape {
    constructor(canvas, color, strokeColor, strokeWidth) {
        this.canvas = canvas;
        this.context = this.canvas.getContext("2d");

        this.cW = +this.canvas.width;
        this.cH = +this.canvas.height;
        this.center = {x: this.cW /2 , y: this.cH / 2};

        this.context.fillStyle = color;
        this.context.strokeStyle = strokeColor;
        this.context.lineWidth = +strokeWidth;
    }

    draw() {}

    clearCanvas() {
        this.context.clearRect(0, 0, this.cW, this.cH);
    }

    set color(value) {
        this.context.fillStyle = value;
        this.draw();
    }

    set strokeColor(value) {
        this.context.strokeStyle = value;
        this.draw();
    }
}
// класс для рендеринга прямоугольника
class Rectangle extends Shape{
    constructor(id, w, h, color, strokeColor, strokeWidth) {
        super(id, color, strokeColor, strokeWidth)
        this.w = +w;
        this.h = +h;
        this.wMiddle = this.w / 2;
        this.hMiddle = this.h / 2;
    }

    draw() {
        this.clearCanvas();
        let rect = {x: this.center.x - this.wMiddle, y: this.center.y - this.hMiddle, w: this.w, h: this.h};
        this.context.fillRect(rect.x, rect.y, rect.w, rect.h);
        this.context.strokeRect(rect.x, rect.y, rect.w, rect.h);
    }

    set width(value) {
        this.w = value;
        this.wMiddle = this.w / 2;
        this.draw();
    }

    set height(value) {
        this.h = value;
        this.hMiddle = this.h / 2;
        this.draw();
    }
}
// класс для рендеринга треугольника
class Triangle extends Rectangle {
    constructor(id, w, h, color, strokeColor, strokeWidth) {
        super(id, w, h, color, strokeColor, strokeWidth)
    }

    draw() {
        this.clearCanvas();

        this.context.beginPath();
        this.context.moveTo(this.center.x,this.center.y - this.hMiddle);
        this.context.lineTo(this.center.x + this.wMiddle, this.center.y + this.hMiddle);
        this.context.lineTo(this.center.x - this.wMiddle, this.center.y + this.hMiddle);
        this.context.closePath();

        this.context.fill();
        this.context.stroke();
    }
}

// класс для рендеринга прямоугольной трапеции
class Trapezium extends Rectangle {
    constructor(id, w, h, color, strokeColor, strokeWidth) {
        super(id, w, h, color, strokeColor, strokeWidth)
        this.topHeight = this.w - this.w * 0.3;
    }

    draw() {
        this.clearCanvas();

        this.context.beginPath();
        this.context.moveTo(this.center.x - this.wMiddle, this.center.y + this.hMiddle);
        this.context.lineTo(this.center.x + this.wMiddle, this.center.y + this.hMiddle);
        this.context.lineTo(this.center.x + this.wMiddle, this.center.y - this.hMiddle);
        this.context.lineTo(this.center.x - this.wMiddle + (this.w - this.topHeight), this.center.y - this.hMiddle);
        this.context.closePath();

        this.context.fill();
        this.context.stroke();
    }

    set width(value) {
        this.w = value;
        this.topHeight = this.w - this.w * 0.3;
        this.wMiddle = this.w / 2;
        this.draw();
    }
}

// класс для рендеринга круга
class Circle extends Shape{
    constructor(id, r, color, strokeColor, strokeWidth) {
        super(id, color, strokeColor, strokeWidth)
        this.r = +r;
    }

    draw() {
        this.clearCanvas();

        this.context.beginPath();
        this.context.arc(this.center.x,this.center.y, this.r, 0, 2 * Math.PI);
        this.context.closePath();

        this.context.fill();
        this.context.stroke();
    }

    set radius(value) {
        this.r = value;
        this.draw();
    }
}

// значения для элементов ввода
const inputData = {
    inpRectWidth: 100,
    inpRectHeight: 100,
    inpRectColor: "#8e17a6",
    inpRectStrokeColor: "#000000",
    inpTriangleWidth: 100,
    inpTriangleHeight: 100,
    inpTriangleColor: "#e66465",
    inpTriangleStrokeColor: "#000000",
    inpCircleRadius: 40,
    inpCircleColor: "#3ca7af",
    inpCircleStrokeColor: "#000000",
    inpTrapeziumWidth: 100,
    inpTrapeziumHeight: 100,
    inpTrapeziumColor: "#3ca7af",
    inpTrapeziumStrokeColor: "#000000"
}

$(function() {
    const shapes = {};

    // загрузка сохраненных данных
    if(window.localStorage.shapesSettings)
        Object.assign(inputData, JSON.parse(window.localStorage.shapesSettings));

    // заполнение элементов управления
    for(const [key, value] of Object.entries(inputData)){
        $(`#${key}`).val(value);
    }

    shapes.rectangle = new Rectangle($("#rectangle")[0], $("#inpRectWidth").val(), $("#inpRectHeight").val(),
        $("#inpRectColor").val(), $("#inpRectStrokeColor").val(), 3);

    shapes.triangle = new Triangle($("#triangle")[0], $("#inpTriangleWidth").val(), $("#inpTriangleHeight").val(),
        $("#inpTriangleColor").val(), $("#inpTriangleStrokeColor").val(), 3);

    shapes.trapezium = new Trapezium($("#trapezium")[0], $("#inpTrapeziumWidth").val(), $("#inpTrapeziumHeight").val(),
        $("#inpTrapeziumColor").val(), $("#inpTrapeziumStrokeColor").val(), 3);

    shapes.circle = new Circle($("#circle")[0], $("#inpCircleRadius").val(), $("#inpCircleColor").val(),
        $("#inpCircleStrokeColor").val(), 3);

    // начальный рендеринг
    for(const [key, value] of Object.entries(shapes)){
        value.draw();
    }

    // обработка изменения ввода в элементах управления
    $(this).on("input", e => {
        // запрет ввода недопустимых значений
        if(+e.target.value > +e.target.max)
            e.target.value = e.target.max;
        if(+e.target.value < +e.target.min)
            e.target.value = e.target.min;

        // изменение свойства фигуры
        shapes[e.target.dataset.shape][e.target.dataset.prop] = e.target.value;

        // сохранение изменений
        inputData[e.target.id] = e.target.value;
        window.localStorage.shapesSettings = JSON.stringify(inputData);
    })
})


