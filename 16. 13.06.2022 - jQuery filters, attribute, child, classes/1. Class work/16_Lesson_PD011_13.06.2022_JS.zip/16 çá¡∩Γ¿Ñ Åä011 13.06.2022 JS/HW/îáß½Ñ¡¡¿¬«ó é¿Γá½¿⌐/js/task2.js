
const keyMap = {
    "KeyQ": orderByDestination,
    "KeyW": orderByPrice,
    "KeyE": orderByFlight,
    "KeyR": markPriceGreater,
    "KeyT": markDestinations,
    "KeyY": markFlights,
    "KeyA": onNewTicket,
    "KeyS": outputSourceData,
}

const Task2 = {
    $tickets: null,
    office: null,
    $ticketForm: null,
    $modalWindow: null,
    delay: 10_000,
    timer: null,
    $inpMarkPrice: null
};

$(function() {

    Task2.$tickets = $("#tickets");
    Task2.$inpMarkPrice = $("#inpMarkPrice");
    Task2.$ticketForm = $("#ticketForm");
    Task2.$modalWindow =  $("#modalWindow");

    $("#btnSrcData").click(outputSourceData);
    $("#btnSortByDest").click(orderByDestination);
    $("#btnSortByPrice").click(orderByPrice);
    $("#btnSortByFlight").click(orderByFlight);
    $("#btnMarkPriceGreater").click(markPriceGreater);
    $("#btnMarkDestination").click(markDestinations);
    $("#btnMarkFlight").click(markFlights);
    $("#btnNewTicket").click(onNewTicket);
    $("#closeModal").click(closeModalWindow);
    $(this).click(onClick).on("keypress", onKeyPress);
    Task2.$ticketForm.on("submit", onSubmitTicketForm);

    Task2.office = new BookOffice( !window.localStorage.tickets
        ? TicketFactory.generate(12)
        : BookOffice.loadFromLocalStorage());

    outputSourceData();
});

// вывести исходные данные
function outputSourceData() {
    Task2.$tickets.html(Task2.office.toTable(), "Заявки на билеты");
}

// сортировка по пункту назначения
function orderByDestination () {
    Task2.$tickets.html(BookOffice
        .toTable(Task2.office.orderByDestination(),'Заявки на авиабилеты - упорядочены по пункту назначения'));
}

// сортировка по стоимости
function orderByPrice() {
    Task2.$tickets.html(BookOffice
        .toTable(Task2.office.orderByPrice(), 'Заявки на авиабилеты - упорядочены по стоимости билета'));
}

// сортировка по рейсу
function orderByFlight() {
    Task2.$tickets.html(BookOffice
        .toTable(Task2.office.orderByFlight(), 'Заявки на авиабилеты - упорядочены по рейсу'));
}

// снять выделение строк таблицы
function removeHighlights() {
    $(".hl-row", "#tickets").removeClass("hl-row");
}

// выделение заявок с указанным пунктом назначения
function markDestinations() {
    let value = $("#inpMarkDestination").val();
    if(!value) return;

    removeHighlights();
    $(`tr:has(td:nth-child(4):contains('${value}'))`, "#tickets").addClass("hl-row");

    clearTimeout(Task2.timer);
    Task2.timer = setTimeout(removeHighlights, Task2.delay);
}

// выделение заявок с указанным номером рейса
function markFlights() {
    let value = $("#inpMarkFlight").val();
    if(!value) return;

    removeHighlights();
    $(`tr:has(td:nth-child(3):contains('${value}'))`, "#tickets").addClass("hl-row");

    clearTimeout(Task2.timer);
    Task2.timer = setTimeout(removeHighlights, Task2.delay);
}

// выделение заявок стоимостью более введенной
function markPriceGreater() {
    let value = Task2.$inpMarkPrice.val();
    if(!value) return;

    removeHighlights();
    Task2.office.selectWhere(t => t.price > value).forEach(t => $(`#t${t.id}`).addClass('hl-row'));

    clearTimeout(Task2.timer);
    Task2.timer = setTimeout(removeHighlights, Task2.delay);
}

// вызов добавления нового сотрудника
function onNewTicket() {
    Task2.$ticketForm.trigger("reset");
    $("#formTitle").html("Добавить данные о заявке");
    $("#ticketForm #btnAddTicket").val("Добавить");
    Task2.$modalWindow.show();
}

// обработчик нажатия кнопки мыши
function onClick(e) {
    if (e.target === Task2.$modalWindow[0])
        closeModalWindow();
    if(e.target.dataset.ticketEditId)
        onEditTicket(e.target.dataset.ticketEditId);
    if(e.target.dataset.ticketDeleteId)
        onDeleteTicket(e.target.dataset.ticketDeleteId);
}

// обработчик удаления заявки
function onDeleteTicket(id) {
    Task2.office.deleteTicket(id);
    outputSourceData();
}

// вызов редактирования данных заявки
function onEditTicket(id) {
    let ticket = Task2.office.getById(id);

    $("#ticketForm #inpName").val(ticket.paxFullName);
    $("#ticketForm #inpDest").val(ticket.destination);
    $("#ticketForm #inpFlight").val(ticket.flight);
    $("#ticketForm #inpPrice").val(ticket.price);
    $("#ticketForm #idTicket").val(ticket.id);

    $("#ticketForm #formTitle").html("Изменить данные заявки");
    $("#ticketForm #btnAddTicket").val("Изменить");

    Task2.$modalWindow.show();
}

// обработчик добавления заявки
function onSubmitTicketForm(event){
    let fullName = this.fullName.value;
    let flight = this.flight.value;
    let destination = this.destination.value;
    let price = this.price.value;
    let id = this.idTicket.value;

    if(this.submit.value === "Добавить")
        Task2.office.addTicket(flight,destination,fullName,price);

    if(this.submit.value === "Изменить")
        Task2.office.updateTicket(id, fullName, flight, destination, price);

    outputSourceData();
    Task2.$modalWindow.hide();
    event.preventDefault();
}

// спрятать окно с формой
function closeModalWindow() {
    Task2.$modalWindow.hide();
}

// обработчик нажатия на клавишу
function onKeyPress(e) {
    if(e.code in keyMap)
        keyMap[e.code]();
}
