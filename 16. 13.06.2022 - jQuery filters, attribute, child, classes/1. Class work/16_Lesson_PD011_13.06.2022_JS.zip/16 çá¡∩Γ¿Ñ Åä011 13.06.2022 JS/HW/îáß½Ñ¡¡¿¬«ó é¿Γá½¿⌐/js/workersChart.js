
window.addEventListener("load", function () {
    let company = new Company(Company.loadFromLocalStorage());

    createBarChart("chartContainer",
        company.workers.map(w => w.lengthOfService).sort((a, b) => a - b),
        700,300,"lightseagreen");
});

function createBarChart(canvas, data, width, height, color) {

    if (typeof canvas == "string") canvas = document.getElementById(canvas);
    canvas.width = width;
    canvas.height = height;
    let context = canvas.getContext("2d");

    // находим максимальное значение в массиве данных
    let max = Math.max(...data);

    let scale = height / max;
    let barWidth = Math.floor(width / data.length);

    // создаем отдельный элемент диаграммы
    for (let i = 0; i < data.length; i++) {

        let barHeight = data[i] * scale,
            x = barWidth * i,
            y = height - barHeight;

        context.fillStyle = color;
        context.fillRect(x, y, barWidth - 2, barHeight);


        context.fillStyle = "black";
        context.font = "bold 12px Arial";
        context.fillText(data[i], x + barWidth / 2 - 6 , y + 12);
    }
}