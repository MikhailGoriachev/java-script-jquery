/*
* Задача 1
* Разместите на странице три элемента canvas. Выведите в элементы
* прямоугольник, равнобедренный треугольник, круг и прямоугольная трапеция,
* выравнивание элементов – по центру областей вывода. При помощи элементов
* управления изменяйте размеры фигур (высоту и ширину прямоугольника, высоту
* и основание треугольника, радиус круга, высоту и основания прямоугольной
* трапеции), цвет заливки и цвет рамки фигур.
* Сохраняйте параметры фигур в локальном хранилище, восстанавливайте параметры
* при загрузке страницы.
* */

// объекты для отрисовки

// прямоугольник
const rectangle = {
    canvasId: "rectangle",

    // TODO: базовая точка для отрисовки
    width: 180,
    height: 90,

    // цвет задаем в hex, т.к. для присваивания в элемент управления требуется
    // именно формат hex
    strokeColor: '#006400',  // darkgreen
    fillColor: '#90ee90',    // lightgreen

    // рисуем прямоугольник
    draw: function() {
        // получить контекст из canvas
        let context = $('#'+this.canvasId)[0].getContext("2d");

        context.save();
        context.clearRect(0, 0, context.canvas.width, context.canvas.height);

        // Меняем цвет рамки и заливки
        context.fillStyle = this.fillColor;
        context.strokeStyle = this.strokeColor;
        context.lineWidth = 2;

        // Закрашенный прямоугольник
        context.fillRect(0, 0, this.width, this.height);
        context.strokeRect(0, 0, this.width, this.height);
        context.restore();
    } // draw
};


// равнобедренный треугольник
const triangle = {
    canvasId: "triangle",
    base: 100,
    height: 60,

    // цвет задаем в hex, т.к. для присваивания в элемент управления требуется
    // именно формат hex
    strokeColor: '#00008b',   // darkblue
    fillColor: '#87cefa',     // lightskyblue

    // рисуем равнобедренный треугольник
    draw: function() {
        let context = $('#' + this.canvasId)[0].getContext("2d");

        context.save();

        // Меняем цвет рамки и заливки
        context.strokeStyle = this.strokeColor;
        context.fillStyle = this.fillColor;

        context.lineWidth = 4;

        // Определяем форму вершин, в которых сходятся линии
        // round, bevel, miter
        context.lineJoin = "round";

        // отрисовка треугольника
        context.save();
        context.clearRect(0, 0, context.canvas.width, context.canvas.height);

        // начало пути.
        context.beginPath();
        let y = context.canvas.height-20;
        context.moveTo(10, y);
        context.lineTo(10 + this.base, y);
        context.lineTo(this.base/2, y - this.height);
        context.closePath();

        context.fill();
        context.stroke();
        context.restore();
    } // draw
}; // triangle


// круг
const circle = {
    canvasId: "circle",
    x: 160,  // центр круга - координата x
    y:  80,  // центр круга - координата y
    radius: 60,

    // цвет задаем в hex, т.к. для присваивания в элемент управления требуется
    // именно формат hex
    strokeColor: '#ff8c00',    // darkorange
    fillColor: '#faf0e6',      // linen

    // рисуем окружность
    draw: function() {
        let context = $('#' + this.canvasId)[0].getContext("2d");

        // толщина линий
        context.lineWidth = 4;

        // отрисовка круга
        context.clearRect(0, 0, context.canvas.width, context.canvas.height);
        context.beginPath();

        // arc(x,y,radius,startAgle,endAngle,clockwise)
        // Метод arc() принимает 6 аргументов:
        // x, y - центр рисования дуги
        // radius -радиус
        // startAngle -начальный угол окружности
        // endAngle - конечный угол окружности
        // clockwise - направление прорисовки. false - по часовой стрелке
        context.arc(this.x, this.y, this.radius, 0, Math.PI*2, true);

        // Меняем цвет рамки и заливки
        context.strokeStyle = this.strokeColor;
        context.stroke();
        context.fillStyle = this.fillColor;
        context.fill();

        context.closePath();
    } // draw
}


// обработчик загрузки страницы
$(() => {

    // начальная отрисовка изображений

    // рисуем прямоугольник, треугольник и круг
    rectangle.draw();
    triangle.draw();
    circle.draw();

    // получить ссылки на элементы выбора цвета
    let rectStrokeChooser     = $("#idRectStroke");
    let rectFillChooser       = $("#idRectFill");
    let triangleStrokeChooser = $("#idTriangleStroke");
    let triangleFillChooser   = $("#idTriangleFill");
    let circleStrokeChooser   = $("#idCircleStroke");
    let circleFillChooser     = $("#idCircleFill");

    // установка начального состояния элементов выбора цвета
    rectStrokeChooser.val(rectangle.strokeColor);
    rectFillChooser.val(rectangle.fillColor);
    triangleStrokeChooser.val(triangle.strokeColor);
    triangleFillChooser.val(triangle.fillColor);
    circleStrokeChooser.val(circle.strokeColor);
    circleFillChooser.val(circle.fillColor);

    // слушатели кликов по кнопкам, изменения поля выбора цвета

    // управление прямоугольником
    $("#btnWidthUp").click(() => {
        rectangle.width += 5;
        rectangle.draw();
    });

    $("#btnWidthDn").click(() => {
        rectangle.width -= (rectangle.width >= 10?5:0);
        rectangle.draw();
    });

    $("#btnHeightUp").click(() => {
        rectangle.height += 5;
        rectangle.draw();
    });

    $("#btnHeightDn").click(() => {
        rectangle.height -= (rectangle.height >= 10?5:0);
        rectangle.draw();
    });

    // обработчик изменения цвета рамки прямоугольника
    rectStrokeChooser.change(e =>  {
        rectangle.strokeColor = e.target.value;
        rectangle.draw();
    });

    // обработчик изменения цвета заливки прямоугольника
    rectFillChooser.change(e =>  {
        rectangle.fillColor = e.target.value;
        rectangle.draw();
    });

    // управление треугольником
    $("#btnBaseUp").click(() => {
        triangle.base += 5;
        triangle.draw();
    });

    $("#btnBaseDn").click(() => {
        triangle.base -= (triangle.base >= 10?5:0);
        triangle.draw();
    });

    $("#btnTrHeightUp").click(() => {
        triangle.height += 5;
        triangle.draw();
    });

    $("#btnTrHeightDn").click(() => {
        triangle.height -= (triangle.height >= 10?5:0);
        triangle.draw();
    });

    // обработчик изменения цвета рамки треугольника
    triangleStrokeChooser.change(e =>  {
        triangle.strokeColor = e.target.value;
        triangle.draw();
    });

    // обработчик изменения цвета заливки треугольника
    triangleFillChooser.change(e =>  {
        triangle.fillColor = e.target.value;
        triangle.draw();
    });

    // управление кругом
    $("#btnRadiusUp").click(() => {
        circle.radius += 5;
        circle.draw();
    });

    $("#btnRadiusDn").click(() => {
        circle.radius -= (circle.radius >= 10?5:0);
        circle.draw();
    });

    // обработчик изменения цвета рамки круга
    circleStrokeChooser.change(e => {
        circle.strokeColor = e.target.value;
        circle.draw();
    });

    // обработчик изменения цвета заливки круга
    circleFillChooser.change(e =>  {
        circle.fillColor = e.target.value;
        circle.draw();
    });
});
