$(function () {
    let errorMsg = $("#errorMsg");
    errorMsg.css('display', 'hide');

    // формирование объекта
    let enterprise = new Enterprise();

    // если объект есть в хранилище - читаем данные из хранилища,
    // иначе - создать массив данных, сохранить его в хранилище
    if (window.localStorage.enterprise) {
        enterprise.load();
    } else {
        // сообщить об ошибке - нет данных
        errorMsg.css('display', 'block');
        errorMsg.text('Нет данных для построения гистограммы');
        return;
    } // if

    createBarChartCanvas("chartExperienceContainer",
        enterprise.workers.map(w => w.getExperience()).sort((w1, w2) => w1 - w2),
        800,
        400,
        "darkblue");

    function createBarChartCanvas(canvas, data, width, height, color) {

        if (typeof canvas == "string") canvas = $('#' + canvas)[0];
        canvas.width = width;
        canvas.height = height;
        let context = canvas.getContext("2d");

        // находим максимальное значение в массиве данных
        let max = Math.max(...data);

        let scale = height / max;
        let barWidth = Math.floor(width / data.length);

        // создаем отдельный элемент диаграммы
        for (let i = 0; i < data.length; i++) {

            let barHeight = data[i] * scale,
                x = barWidth * i,
                y = height - barHeight;

            context.fillStyle = color;
            context.fillRect(x, y, barWidth - 2, barHeight);
        } // for i
    } // createBarChartCanvas
});

