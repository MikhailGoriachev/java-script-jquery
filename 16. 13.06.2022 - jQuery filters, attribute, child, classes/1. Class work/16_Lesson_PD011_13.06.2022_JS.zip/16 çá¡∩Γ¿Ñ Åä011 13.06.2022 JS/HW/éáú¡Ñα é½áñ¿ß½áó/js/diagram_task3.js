function createExperienceDiagram(collection,width,height,color) {

    let canvasContainer = $('#container')[0];
    canvasContainer.width = width;
    canvasContainer.height = height;
    let context = canvasContainer.getContext('2d');

    let maxPrice = Math.max(...collection);

    //Коэфициент масщтабирования
    let scale = height/maxPrice;

    //Ширина стообца диаграммы
    let colWidth = Math.floor(width/collection.length);

    //Создание
    for (let i = 0; i < collection.length; i++) {

        let colHeight = collection[i] * scale;
        let x = colWidth*i;
        let y = height - colHeight;

        context.fillStyle = color;
        context.fillRect(x,y,colWidth-4,colHeight);

    }
}

$(function () {

    let experiences = [];
    //Получить коллекцию из хранилища
    if (window.localStorage.workersView) {
        let view = JSON.parse(window.localStorage.workersView);
        experiences = view.workers.map((v) => new Date().getFullYear() - v._entryYear);
    }

    createExperienceDiagram(experiences,900,400,'rgb(53,140,101)')
});

