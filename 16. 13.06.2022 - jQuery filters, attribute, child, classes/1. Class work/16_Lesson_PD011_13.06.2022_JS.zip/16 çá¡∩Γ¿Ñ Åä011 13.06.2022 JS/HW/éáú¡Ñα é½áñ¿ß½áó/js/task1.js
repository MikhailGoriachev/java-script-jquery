
//region Классы
//Базовый класс
class Shape {
    constructor(canvas,strokeWidth,color,strokeColor) {
        this.canvas = canvas;
        this.context = this.canvas.getContext('2d');
        this.canvasWidth = this.canvas.width;
        this.canvasHeight = this.canvas.height;

        this.context.fillStyle = color;
        this.context.strokeStyle = strokeColor;
        this.context.strokeWidth = strokeWidth;
    }

    draw(){

    }

}

//Прямоугольник
class Rectangle extends Shape{
    constructor(canvas, rectWidth, rectHeight, color, strokeColor, lineWidth) {

        //Контекст будет получен внутри конструктора базовго класса
        super(canvas,lineWidth,color,strokeColor);

        this.width = +rectWidth;
        this.height= +rectHeight;

        this.restrictedWidth = {
            minW: 1,
            maxW: 472};
        this.restrictedHeight = {
            minH: 1,
            maxH: 300};
    }

    draw() {
        let context = this.context;
        let canvasWidth = this.canvasWidth;
        let canvasHeight = this.canvasHeight;


        let startPosX = (canvasWidth-this.width)/2;
        let startPosY = (canvasHeight-this.height)/2;

        context.clearRect(0,0,canvasWidth,canvasHeight)
        context.fillRect(startPosX,startPosY,this.width,this.height);
        context.strokeRect(startPosX,startPosY,this.width,this.height);

        context.restore();
    }
}

//Теругольник
class Triangle extends Shape{
    constructor(canvas, trWidth, trHeight, color, strokeColor, lineWidth = 15) {

        //Контекст будет получен внутри конструктора базовго класса
        super(canvas,lineWidth,color,strokeColor);

        this.width = +trWidth;
        this.height= +trHeight;

        this.restrictedWidth = {
            minW: 1,
            maxW: 465};
        this.restrictedHeight = {
            minH: 1,
            maxH: 296};
    }

    draw() {
        let context = this.context;
        let canvasWidth = this.canvasWidth;
        let canvasHeight = this.canvasHeight;
        let trWidth = this.width;
        let trHeight = this.height;
        
        let startPosX =  canvasWidth/2;
        let startPosY = (canvasHeight-trHeight)/2;


        context.clearRect(0,0,canvasWidth,canvasHeight)

        context.beginPath();

        context.moveTo(startPosX,startPosY);
        context.lineTo(startPosX-trWidth/2,startPosY+trHeight);
        context.lineTo(startPosX+trWidth/2,startPosY+trHeight);
        context.closePath();

        context.fill();
        context.stroke();

        context.restore();
    }
}

//Круг
class Circle extends Shape{
    constructor(canvas, radius, color, strokeColor, lineWidth = 15,startAngle = 0, endAngle = Math.PI*2) {

        //Контекст будет получен внутри конструктора базовго класса
        super(canvas,lineWidth,color,strokeColor);

        this.radius = +radius

        this.startAngle = startAngle;
        this.endAngle = endAngle;

        this.restrictedRadius = {
            minR: 1,
            maxR: 146};
    }

    //Метод отрисовки
    draw() {
        let context = this.context;
        let canvasWidth = this.canvasWidth;
        let canvasHeight = this.canvasHeight;

        let startPosX =  (canvasWidth)/2 ;
        let startPosY = (canvasHeight)/2;

        context.clearRect(0,0,canvasWidth,canvasHeight);
        context.beginPath();

        context.arc(startPosX,startPosY,this.radius,this.startAngle,this.endAngle,true)

        context.fill();
        context.stroke();
        context.restore();
    }
}

//Трапеция
class Trapezium extends Shape{
    constructor(canvas, topBase, bottomBase, trapHeight, color, strokeColor, lineWidth = 15) {

        //Контекст будет получен внутри конструктора базовго класса
        super(canvas,lineWidth,color,strokeColor);

        this.topBase = +topBase;
        this.bottomBase = +bottomBase;
        this.height= +trapHeight;

        //Огранчиения параметров
        this.restrictedTopBase = {
            minTb: 1,
            maxTb: 228};
        this.restrictedBottomBase = {
            minBb: 1,
            maxBb: 228};
        this.restrictedHeight = {
            minH: 1,
            maxH: 294};
    }

    draw() {
        let context = this.context;
        let canvasWidth = this.canvasWidth;
        let canvasHeight = this.canvasHeight;

        //Оснвания и высота
        let topBase = this.topBase;
        let bottomBase = this.bottomBase;
        let trapHeight = this.height;

        let startPosX =  (canvasWidth/*-topBase*/)/2;
        let startPosY = (canvasHeight-trapHeight)/2;


        context.clearRect(0,0,canvasWidth,canvasHeight);

        context.beginPath();

        context.moveTo(startPosX,startPosY);
        context.lineTo(startPosX+topBase,startPosY)
        context.lineTo(startPosX+topBase,startPosY+trapHeight)
        context.lineTo(startPosX-bottomBase,startPosY+trapHeight)
        context.closePath();

        context.fill();
        context.stroke();

        context.restore();
    }
}
//endregion

function $(id) {
    return document.getElementById(id);
}

//Обработчик ввода
function inputHandler(e,shapeObj) {
    let inputId = e.target.id;

    function inputIdIncludes(id) {
        return inputId.toLowerCase().includes(id)
    }

    //Пишем данные в переданный объект фиуры
    if (inputIdIncludes('rect'))
        rectangleChange(shapeObj);
    else if (inputIdIncludes('triangle'))
        triangleChange(shapeObj);
    else if (inputIdIncludes('circle'))
        circleChange(shapeObj);
    else if (inputIdIncludes('trapezium'))
        trapeziumChange(shapeObj);
}

//region Изменение объектов

//Изменение и сохранение параметров прямоугольника
function rectangleChange(shape) {

    //Сохранение данных в локальном ранилище
    writeFieldsToLocal(document.formRect);


    let inputWidth =  $('rectWidth');
    let inputHeight =  $('rectHeight');

    //region Установка ограничений

    //Объекты ограничений
    let restrictWidth = shape.restrictedWidth;
    let restrictHeight = shape.restrictedHeight;

    //Ограничения ширины
    inputWidth.value = inputWidth.value >= restrictWidth.minW ? inputWidth.value : restrictWidth.minW;
    inputWidth.value = inputWidth.value <= restrictWidth.maxW ? inputWidth.value : restrictWidth.maxW;

    //Ограничения высоты
    inputHeight.value = inputHeight.value >= restrictHeight.minH ? inputHeight.value : restrictHeight.minH;
    inputHeight.value = inputHeight.value <= restrictHeight.maxH ? inputHeight.value : restrictHeight.maxH;
    //endregion

    shape.width = inputWidth.value;
    shape.height = inputHeight.value;
    shape.context.fillStyle = $('rectColor').value;
    shape.context.strokeStyle = $('rectStrokeColor').value;
    shape.draw();
}

//Изменение и сохранение параметров окружности
function triangleChange(shape) {
    writeFieldsToLocal(document.formTriangle)

    let inputWidth =  $('triangleWidth');
    let inputHeight =  $('triangleHeight');

    //region Установка ограничений

    //Объекты ограничений
    let restrictWidth = shape.restrictedWidth;
    let restrictHeight = shape.restrictedHeight;

    //Ограничения ширины
    inputWidth.value = inputWidth.value > restrictWidth.minW ? inputWidth.value : restrictWidth.minW;

    //Max
    inputWidth.value = inputWidth.value < restrictWidth.maxW ? inputWidth.value : restrictWidth.maxW;

    //Ограничения высоты
    inputHeight.value = inputHeight.value > restrictHeight.minH ? inputHeight.value : restrictHeight.minH;

    //Max
    inputHeight.value = inputHeight.value < restrictHeight.maxH ? inputHeight.value : restrictHeight.maxH;
    //endregion

    shape.width = +inputWidth.value;
    shape.height = +inputHeight.value;
    shape.context.fillStyle = $('triangleColor').value;
    shape.context.strokeStyle = $('triangleStrokeColor').value;
    shape.draw();
}

//Изменение и сохранение параметров окружности
function circleChange(shape) {

    //Запись изменений в локальное хранилище
    writeFieldsToLocal(document.formCircle)

    let inputRadius =  $('circleRadius');

    //region Установка ограничений

    //Объекты ограничений
    let restrictedRadius = shape.restrictedRadius;

    //Ограничения радиуса
    inputRadius.value = inputRadius.value > restrictedRadius.minR ? inputRadius.value : restrictedRadius.minR;

    //Max
    inputRadius.value = inputRadius.value < restrictedRadius.maxR ? inputRadius.value : restrictedRadius.maxR;
    //endregion

    shape.radius = +inputRadius.value;
    shape.context.fillStyle = $('circleColor').value;
    shape.context.strokeStyle = $('circleStrokeColor').value;
    shape.draw();
}

//Изменение и сохранение параметров окружности
function trapeziumChange(shape) {
    writeFieldsToLocal(document.formTrapezium)

    let inputTopBase =  $('trapeziumTopBase');
    let inputBottomBase =  $('trapeziumBottomBase');
    let inputHeight =  $('trapeziumHeight');

    //region Установка ограничений

    //Объекты ограничений
    let restrictTopBase = shape.restrictedTopBase;
    let restrictBottomBase = shape.restrictedBottomBase;
    let restrictHeight = shape.restrictedHeight;

    //region Ограничения верхнего основания
    inputTopBase.value = inputTopBase.value > restrictTopBase.minTb ? inputTopBase.value : restrictTopBase.minTb;

    //Max
    inputTopBase.value = inputTopBase.value < restrictTopBase.maxTb ? inputTopBase.value : restrictTopBase.maxTb;
    //endregion

    //Ограничения нижнего основания
    inputBottomBase.value = inputBottomBase.value > restrictBottomBase.minBb ? inputBottomBase.value : restrictBottomBase.minBb;

    //Max
    inputBottomBase.value = inputBottomBase.value < restrictBottomBase.maxBb ? inputBottomBase.value : restrictBottomBase.maxBb;

    //Ограничения высоты
    inputHeight.value = inputHeight.value > restrictHeight.minH ? inputHeight.value : restrictHeight.minH;

    //Max
    inputHeight.value = inputHeight.value < restrictHeight.maxH ? inputHeight.value : restrictHeight.maxH;
    //endregion

    shape.topBase = +inputTopBase.value;
    shape.bottomBase = +inputBottomBase.value;
    shape.height = +inputHeight.value;

    shape.context.fillStyle = $('trapeziumColor').value;
    shape.context.strokeStyle = $('trapeziumStrokeColor').value;
    shape.draw();
}

//endregion


//Функция с самовызовом
(function (){


    let loadHandler = function () {

        //region Canvas
        let rectCanvas = $('rectangle');
        let triangleCanvas = $('triangle');
        let circleCanvas = $('circle');
        let trapeziumCanvas  = $('trapeziumCanvas');
        //endregion

        //region Прямоугольник

        let formRect = document.formRect;
        let rectWidth = $('rectWidth');
        let rectHeight = $('rectHeight');
        let rectColor = $('rectColor');
        let rectStrokeColor = $('rectStrokeColor');

        //Если есть предыдущие днанные в локальном хранилище
        fillFromLocalStore(formRect);

        let rectangle = new Rectangle(rectCanvas,rectWidth.value,rectHeight.value,rectColor.value,rectStrokeColor.value,5)
        rectangle.draw();

        //Событие изменения данных в поле ввода
        rectWidth.addEventListener('input',(e) =>  inputHandler(e,rectangle/*rectCanvas*/),false);
        rectHeight.addEventListener('input',(e) => inputHandler(e,rectangle/*rectCanvas*/),false);
        rectColor.addEventListener('input',(e) =>  inputHandler(e,rectangle/*rectCanvas*/),false);
        rectStrokeColor.addEventListener('input',(e) => inputHandler(e,rectangle/*rectCanvas*/),false);

        //endregion

        //region Треугольник

        let formTriangle = document.formTriangle;
        let triangleWidth =  $('triangleWidth');
        let triangleHeight = $('triangleHeight');
        let triangleColor =  $('triangleColor');
        let triangleStrokeColor = $('triangleStrokeColor');

        //Если есть предыдущие днанные в локальном хранилище
        fillFromLocalStore(formTriangle);

        let triangle = new Triangle(triangleCanvas,triangleWidth.value,triangleHeight.value,triangleColor.value,triangleStrokeColor.value);
        triangle.draw();

        //Событие изменения данных в поле ввода
        triangleWidth.addEventListener('input',(e) =>  inputHandler(e,triangle),false);
        triangleHeight.addEventListener('input',(e) => inputHandler(e,triangle),false);
        triangleColor.addEventListener('input',(e) =>  inputHandler(e,triangle),false);
        triangleStrokeColor.addEventListener('input',(e) => inputHandler(e,triangle),false);

        //endregion

        //region Круг

        let formCircle = document.formCircle;
        let circleRadius =  $('circleRadius');
        let circleColor =  $('circleColor');
        let circleStrokeColor =  $('circleStrokeColor');

        //Если есть предыдущие днанные в локальном хранилище
        fillFromLocalStore(formCircle);

        let circle = new Circle(circleCanvas,circleRadius.value,circleColor.value,circleStrokeColor.value);
        circle.draw();

        circleRadius.addEventListener('input',(e) =>  inputHandler(e,circle),false);
        circleColor.addEventListener('input',(e) =>  inputHandler(e,circle),false);
        circleStrokeColor.addEventListener('input',(e) => inputHandler(e,circle),false);


        //endregion


        //region Прямоугольная трапеция
        let formTrapezium = document.formTrapezium;
        let trapeziumTopBase =  $('trapeziumTopBase');
        let trapeziumBottomBase =  $('trapeziumBottomBase');
        let trapeziumHeight = $('trapeziumHeight');
        let trapeziumColor =  $('trapeziumColor');
        let trapeziumStrokeColor = $('trapeziumStrokeColor');

        //Если есть предыдущие днанные в локальном хранилище
        fillFromLocalStore(formTrapezium);

        let trapezium =
            new Trapezium(trapeziumCanvas,trapeziumTopBase.value,trapeziumBottomBase.value,trapeziumHeight.value,trapeziumColor.value,trapeziumStrokeColor.value);
        trapezium.draw();

        //Событие изменения данных в поле ввода
        trapeziumTopBase.addEventListener('input',(e) => inputHandler(e,trapezium),false);
        trapeziumBottomBase.addEventListener('input',(e) => inputHandler(e,trapezium),false);
        trapeziumHeight.addEventListener('input',(e) => inputHandler(e,trapezium),false);
        trapeziumColor.addEventListener('input',(e) =>  inputHandler(e,trapezium),false);
        trapeziumStrokeColor.addEventListener('input',(e) => inputHandler(e,trapezium),false);
        //endregion


    }//loadHandler
    window.addEventListener('load',loadHandler,false)
})();

/*$(function () {

    //region Canvas
    let rectCanvas = $('#rectangle');
    let triangleCanvas = $('#triangle');
    let circleCanvas = $('#circle');
    let trapeziumCanvas  = $('#trapeziumCanvas');
    //endregion

    //region Прямоугольник

    let formRect = document.formRect;
    let rectWidth = $('#rectWidth');
    let rectHeight = $('#rectHeight');
    let rectColor = $('#rectColor');
    let rectStrokeColor = $('#rectStrokeColor');

    //Если есть предыдущие днанные в локальном хранилище
    fillFromLocalStore(formRect);

    let rectangle = new Rectangle(rectCanvas,rectWidth.value,rectHeight.value,rectColor.value,rectStrokeColor.value,5)
    rectangle.draw();

    //Событие изменения данных в поле ввода
    rectWidth.addEventListener('input',(e) =>  inputHandler(e,rectangle/!*rectCanvas*!/),false);
    rectHeight.addEventListener('input',(e) => inputHandler(e,rectangle/!*rectCanvas*!/),false);
    rectColor.addEventListener('input',(e) =>  inputHandler(e,rectangle/!*rectCanvas*!/),false);
    rectStrokeColor.addEventListener('input',(e) => inputHandler(e,rectangle/!*rectCanvas*!/),false);

    //endregion

    //region Треугольник

    let formTriangle = document.formTriangle;
    let triangleWidth =  $('#triangleWidth');
    let triangleHeight = $('#triangleHeight');
    let triangleColor =  $('#triangleColor');
    let triangleStrokeColor = $('#triangleStrokeColor');

    //Если есть предыдущие днанные в локальном хранилище
    fillFromLocalStore(formTriangle);

    let triangle = new Triangle(triangleCanvas,triangleWidth.value,triangleHeight.value,triangleColor.value,triangleStrokeColor.value);
    triangle.draw();

    //Событие изменения данных в поле ввода
    triangleWidth.addEventListener('input',(e) =>  inputHandler(e,triangle),false);
    triangleHeight.addEventListener('input',(e) => inputHandler(e,triangle),false);
    triangleColor.addEventListener('input',(e) =>  inputHandler(e,triangle),false);
    triangleStrokeColor.addEventListener('input',(e) => inputHandler(e,triangle),false);

    //endregion

    //region Круг

    let formCircle = document.formCircle;
    let circleRadius =  $('#circleRadius');
    let circleColor =  $('#circleColor');
    let circleStrokeColor =  $('#circleStrokeColor');

    //Если есть предыдущие днанные в локальном хранилище
    fillFromLocalStore(formCircle);

    let circle = new Circle(circleCanvas,circleRadius.value,circleColor.value,circleStrokeColor.value);
    circle.draw();

    circleRadius.addEventListener('input',(e) =>  inputHandler(e,circle),false);
    circleColor.addEventListener('input',(e) =>  inputHandler(e,circle),false);
    circleStrokeColor.addEventListener('input',(e) => inputHandler(e,circle),false);


    //endregion


    //region Прямоугольная трапеция
    let formTrapezium = document.formTrapezium;
    let trapeziumTopBase =  $('#trapeziumTopBase');
    let trapeziumBottomBase =  $('#trapeziumBottomBase');
    let trapeziumHeight = $('#trapeziumHeight');
    let trapeziumColor =  $('#trapeziumColor');
    let trapeziumStrokeColor = $('#trapeziumStrokeColor');

    //Если есть предыдущие днанные в локальном хранилище
    fillFromLocalStore(formTrapezium);

    let trapezium =
        new Trapezium(trapeziumCanvas,trapeziumTopBase.value,trapeziumBottomBase.value,trapeziumHeight.value,trapeziumColor.value,trapeziumStrokeColor.value);
    trapezium.draw();

    //Событие изменения данных в поле ввода
    trapeziumTopBase.addEventListener('input',(e) => inputHandler(e,trapezium),false);
    trapeziumBottomBase.addEventListener('input',(e) => inputHandler(e,trapezium),false);
    trapeziumHeight.addEventListener('input',(e) => inputHandler(e,trapezium),false);
    trapeziumColor.addEventListener('input',(e) =>  inputHandler(e,trapezium),false);
    trapeziumStrokeColor.addEventListener('input',(e) => inputHandler(e,trapezium),false);
    //endregion


});*/
