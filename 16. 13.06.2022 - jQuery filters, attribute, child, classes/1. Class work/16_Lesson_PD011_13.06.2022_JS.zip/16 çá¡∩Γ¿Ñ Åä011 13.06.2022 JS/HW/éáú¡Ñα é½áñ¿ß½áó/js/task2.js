
//region Сортировки, обработчики

//Упорядочить представление по пунктам назначения
function orderDescByDestination(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c1.destination.localeCompare(c2.destination));
    blockObject.html(TicketsView.createMarkup(copy))
    titleObject.html(`<span>Сортировка массива по пунктам назначения</span>`);

    //Возвращаем копию для запоминания последней сфомрированной коллеции
    return copy;
}//orderDescByTemperature

//Упорядочить представление по стоимости билета
function orderByPrice(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c2.ticketPrice-c1.ticketPrice);
    blockObject.html(TicketsView.createMarkup(copy))
    titleObject.html(`<span>Сортировка массива по стоимости билета</span>`);

    return copy;
}//orderByPrice

//Упорядочить представление по стоимости билета
function orderByFlightNum(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c2.flightNum-c1.flightNum);
    blockObject.html(TicketsView.createMarkup(copy));
    titleObject.html(`<span>Сортировка массива по стоимости билета</span>`);

    return copy;
}//orderByFlightNum


//endregion


//Функция с самовызовом
(function (){

    //Массив заявок
    let ticketsList = [];

    let ticketView = new TicketsView([]);

    //region Чтение и запись в локальное хранилище
    if (window.localStorage.ticketsView) {
        ticketView.getFromLocal();
        ticketsList = ticketView.tickets;
    }
    else {
        ticketView.tickets = TicketsView.generateTickets();
        ticketView.writeToLocal();
        ticketsList = ticketView.tickets;
    }
    //endregion


    let mainBlock = $("#mainDiv");

    mainBlock.html(TicketsView.createMarkup(ticketsList));


    let title = $('#taskTitle');

    $(function () {

        //Последняя сформированная коллекция
        let lastFormedCollection = ticketsList;

        //Обработчик кнопки вывода исходного массива
        let showDefaultArr = function () {

            mainBlock.html(TicketsView.createMarkup(ticketsList));
            title.html(`<span>Исходный массив</span>`);
            lastFormedCollection = ticketsList;
        }

        let showTickets = function (collection) {

            /*mainBlock.innerHTML = TicketsView.createMarkup(collection);*/
            mainBlock.html(TicketsView.createMarkup(collection));
        }

        $("#defaultArr").click(showDefaultArr);

        //Очистка локального хранилища
        $('#cleanLocalStore').click(() => {
            window.localStorage.removeItem('ticketsView');
        })

        //region Сортировки

        //Обработчик кнопки сортировки по пункту на назначения

        $("#orderByDest").click(() => {
            console.log('Сортировка по пунктам назначения');
            lastFormedCollection = orderDescByDestination(mainBlock, title, ticketsList)
        });

        //Обработчик кнопки сортировки по стоимости билета
        $("#orderByPrice").click(() =>
            lastFormedCollection = orderByPrice(mainBlock, title,ticketsList));

        //Обработчик кнопки сортировки по номеру рейса
        $("#orderByFlightN").click(() =>
            lastFormedCollection = orderByFlightNum(mainBlock, title,ticketsList));


        //endregion

        let inputPriceField = $("#inputPrice");
        let btnSearch = $("#highlightCommand");
        let message = $("#messageText");

        let selectDestination = $('#selectDestination');

        let inputFlightField = $('#inputFlightNum')
        let messageFlightNum = $('#messageTextFlightNum');


        //Обект таймера
        let timer = 0;

        //region Поведение при покидании поля ввода
        //При выходе из поля ввода убираем записи и кнопку

        function focusMouseOutHandler(field,button,additionalCondition) {
            let inputValue = field.value;

            //Если поле пустое или состоит из пробелов
            if (inputValue === "" || additionalCondition(inputValue)/*pattern.test(inputValue)*/) {
                message.textContent = '';

                button.css('visibility','hidden');

                button.disabled = false;
            }

        }


        let digitalField = new RegExp('[0-9]+');
        inputPriceField.focusout((e) => focusMouseOutHandler(e.target,btnSearch,(value) => !digitalField.test(value)));
        inputPriceField.mouseout((e) => focusMouseOutHandler(e.target,btnSearch,(value) => !digitalField.test(value)));

        //endregion

        //region Выделение элементов (не через JQuery)

        //Выделение элементов по предикату
        let highlightTickets = function (predicate,notFound = "значения не найдены") {

            //Получаем массив дочерних элементов общего блока
            let childNodes = getBlockChildren(mainBlock);

            //Проверка работы предиката
            let isData = 0;


            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {

                let data = getNumFromStr(childNode.getElementsByTagName('span')[3].getElementsByTagName("b")[0].innerHTML)

                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (predicate(data)) {
                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                    isData++;
                }
            }//for

            if (isData<=0)
                message.html(notFound);

            clearTimeout(timer);

            //После истечения таймера перепишем коллекцию
            timer = setTimeout(() => showTickets(lastFormedCollection),10_000)

        }//highlightTickets

        //Выделение одного элемента
        let highlightSingleTicket = function (ticket) {

            //Получаем массив дочерних элементов общего блока
            let childNodes = getBlockChildren(mainBlock);


            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {


                //region Получение полей
                let destination = childNode.getElementsByTagName("span")[0].getElementsByTagName("b")[0].innerHTML;
                let flightNum = childNode.getElementsByTagName("span")[1].getElementsByTagName("b")[0].innerHTML;
                let snp = childNode.getElementsByTagName("span")[2].getElementsByTagName("b")[0].innerHTML;
                let ticketPrice = getNumFromStr(childNode.getElementsByTagName("span")[3].getElementsByTagName("b")[0].innerHTML);
                //endregion


                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (ticket.destination === destination &&
                    ticket.flightNum === flightNum &&
                    ticket.passenger === snp &&
                    ticket.ticketPrice === ticketPrice) {

                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                }
            }//for


            //После истечения таймера перепишем коллекцию
            setTimeout(() => showTickets(lastFormedCollection),10_000)



        }//highlightTickets

        //Проверка ввода
        let keyDownHandler = function (e) {

            /*let regExpr = new RegExp('[а-яА-Яa-zA-Z ]');*/
            let regExpr = new RegExp('[0-9]');

            //Флаг enter и backspace
            let enterPressed = e.key.toLowerCase().includes("enter");
            let backSpacePressed = e.key.toLowerCase().includes("backspace");
            let tabPressed = e.key.toLowerCase().includes("tab");

            //Вклюсчаем кнопку
            btnSearch.css('visibility','visible')

            //Если есть хоть одна буква - блокировка ввода
            if (!regExpr.test(e.key) && !backSpacePressed && !tabPressed && !enterPressed) {
                message.html("введите число");

                btnSearch.prop('disabled',true);

                e.preventDefault();
                return false;
            }


            message.html("");
            btnSearch.prop('disabled',false);

        }

        //Обработчик клика на кнопку поиска и выделения элементов
        function highlightClickHandler() {

            let inputValue = inputPriceField.val();


            //Получение введённого значения
            let number = parseInt(inputValue);

            //Переписать массив билетов, чтобы снять выделение
            showTickets(lastFormedCollection);

            highlightTickets((data) => data > number);
        }

        //Блокировка задания любых символов кроме цифр
        inputPriceField.keydown(keyDownHandler);

        btnSearch.click(highlightClickHandler);

        //endregion


        //region Выделение через фильтр контента JQuery
        //Загрузить список пунктов назначения
        function loadSearchSelection() {

            //Выбираем уникальные значения
            let strDest = [...new Set(ticketsList.map(t =>t.destination))].reduce((acc,dest) => acc+`<option>${dest}</option>`,'');

            selectDestination.html(strDest);

        };
        loadSearchSelection();


        function highlightByJquery(strToHighlight,notFound = "значения не найдены") {

            //Находим таблицы с определённым содержанием
            let foundTables = $("table:contains("+strToHighlight+")");


            $('table').removeClass('highlightClaim');
            foundTables.addClass('highlightClaim');

            clearTimeout(timer);

            //После истечения таймера перепишем коллекцию
            timer = setTimeout(() => showTickets(lastFormedCollection),10_000)
        }


        //region Обработчики
        inputFlightField.keydown((e) => {
            let regExpr = new RegExp('[a-zа-я+-/*=@#$%^&?]');

            console.log(`Нажата: ${e.key}`);

            //Вклюсчаем кнопку

            //Если есть хоть одна буква - блокировка ввода
            if (regExpr.test(e.key) && e.key.length ===  1) {

                messageFlightNum.html("введите буквенные символы верхнего регистра или числа");

                e.preventDefault();
                return false;
            }

            messageFlightNum.html("");
            highlightByJquery(inputFlightField.val());
        })

        selectDestination.change((e) => highlightByJquery(e.target.value));
        //endregion

        //endregion

        //region Форма

        //Форма
        let form = document.addForm;
        let btnSubmit = $('#btnAdd');
        let btnReset = $('#resetBtn');

        let fieldset = $('#fieldsetForm');
        let fieldsetWidth = fieldset.offsetWidth;

        //Кнопки изменения режимов работы формы
        let changeToAddingBtn= $('#btnAddingMode');
        let changeToChangingBtn= $('#btnChangingMode');
        let changeToDeletionBtn= $('#btnDeletionMode');

        //Выпадающий список ID
        let idList = $('#divIdList');
        let dropDownList = $('#ticketsIdList');

        //Нижнний текст
        let bottomLbl = $('#formPrompt');

        //Массив полей вода
        let fields = [];
        for (let i = 0; i < form.elements.length; i++) {
            let element = form.elements[i];
            if (element.type === 'text')
                fields.push(element)
        }


        //Поля
        let destinationField = $('#destination');
        let flightNumField = $('#flightNum');
        let passengerField = $('#passengerSnp');
        let ticketPriceField = $('#ticketPrice');



        //Обработчик изменения данных в поле
        function onChangeHandler(e,predicate,ifWrongMessage) {
            //Получаем поле ввода
            let field = e.target;
            let value = field.value;


            //Находим подсказку справа
            let label = field.parentElement.getElementsByTagName('label')[0];

            field.classList.remove('inValid-field');
            label.textContent = `Введите ${field.getAttribute('data-field-name')}`

            //Если ширина != стартовой
            if (fieldset.offsetWidth !== fieldsetWidth)
                fieldset.style.width = `${fieldsetWidth}px`;

            if (!predicate(value) && value.length>0) {
                label.textContent = `${ifWrongMessage}`
                field.classList.add('inValid-field');

                fieldset.style.width = `${fieldsetWidth + ifWrongMessage.length*3.85}px`;
            }
        }

        //region Добавление изменение и удаление

        //Обработчик кнопок ОК
        function okClickHandler(bottomLbl,inputFields) {

            //Сообщение снизу
            bottomLbl.css("visibility" ,'visible');

            //Невалидна ли форма
            let inValid = false;

            //Находим поля ввода с некорректными значениями
            for (let field of inputFields) {

                let classContains = field.classList.contains('inValid-field');
                let fieldEmpty = field.value.length === 0;

                //Если в поле задан стиль сигнализирующий о некорректном значени или данные отсутвуют
                //Если нет класса, но поле пустое
                inValid = classContains || !classContains && fieldEmpty || inValid;


            }//for


            //Если есть невалидные поля в форме
            if(inValid) {
                bottomLbl.textContent = '*В данных есть ошибка!';
                return;
            }

            let isChanging = btnSubmit.val().toLowerCase().includes('изменить');
            let isDeleting = btnSubmit.val().toLowerCase().includes('удалить');

            if (isChanging)
                changeTicket();
            else if (isDeleting)
                deleteTicket();
            else
                addTicket();

            //Добавляем имзенённую коллекцию в локальное хранилище
            ticketView.writeToLocal();

            //Перезагружаем список для выделения по пунктам назначения
            loadSearchSelection();
        }

        //Работа с коллекцией при добавлении
        function addTicket(inputFields) {

            let id = Math.max(...ticketsList.map(c => c.ticketId))>0?Math.max(...ticketsList.map(c => c.ticketId))+1:1;

            //Создать объект
            let claim = new Ticket(
                Math.max(...ticketsList.map(c => c.ticketId))+1,
                $('#destination').val(),
                $('#flightNum').val(),
                $('#passengerSnp').val(),
                $('#ticketPrice').val(),
            );

            //Если билет создать не удалось
            if (!claim) {
                bottomLbl.textContent = '*Не удалось создать билет!';
                console.log(`obj:\r\n${claim.destination}\
                \r\n${claim.flightNum}\
                \r\n${claim.passenger}\
                \r\n${claim.ticketPrice}\
                `)
            }

            //Добавление в массивы
            let tickets = ticketsList
            tickets.push(claim);
            showDefaultArr();
            highlightSingleTicket(tickets[tickets.length-1])

            bottomLbl.text('Билет успешно добавлен. Элемент выделен синим.');

            //Очистка формы
            setTimeout(() => resetFormHandler(bottomLbl,inputFields),5_000) ;
        }

        //Работа с коллекцией при изменении
        function changeTicket() {
            //Создать объект
            let claim = new Ticket(
                parseInt(form.getAttribute('data-selected-worker-id')),
                $('#destination').val(),
                $('#flightNum').val(),
                $('#passengerSnp').val(),
                parseInt($('#ticketPrice').val()),
            );

            //Если билет создать не удалось
            if (!claim) {
                bottomLbl.text('*Не удалось изменить билет!');
                console.log(`obj:\r\n${claim.destination}\
                \r\n${claim.flightNum}\
                \r\n${claim.passenger}\
                \r\n${claim.ticketPrice}\
                `)
            }

            let ind = ticketsList.findIndex(c => c.ticketId === claim.ticketId);
            let indCopy = lastFormedCollection.findIndex(c => c.ticketId === claim.ticketId);

            //Изменяем объект в массиве
            ticketsList[ind] = claim;
            lastFormedCollection[indCopy] = claim;


            showTickets(lastFormedCollection);
            highlightSingleTicket(claim);

        }

        //Работа с коллекцией при удалении
        function deleteTicket() {
            //Индекс для удаления
            let indToRemove = ticketsList.findIndex(c => c.ticketId === parseInt(form.getAttribute('data-selected-worker-id')))

            //Если билет найти не удалось
            if (indToRemove < 0) {
                bottomLbl.text('*Не удалось найти билет!');
                return;
            }

            //Удаляем из массива
            ticketsList.splice(indToRemove,1);
            changeIdsAfterDel(ticketsList,indToRemove);
            showDefaultArr();

            //Для изменения заданных полей в форме
            changeFormToDeletion(form,btnSubmit);

        }

        //Изменение массива после удаления
        function changeIdsAfterDel(tickets,delInd) {

            //Уменьшить все id идущие после удалённого
            for (let i = delInd; i < tickets.length; i++) {
                tickets[i].ticketId--;
            }

        }
        //endregion

        //Обработчик сброса формы
        function resetFormHandler(bottomLbl,inputFields) {

            //Убираем запись снизу
            bottomLbl.text('') ;
            bottomLbl.css('visibility','hidden');

            //Находим поля ввода с некорректными значениями
            for (let field of inputFields) {
                if (field.classList.contains('inValid-field')) {
                    field.classList.remove('inValid-field');

                    //Меняем значение в подсказаках на начальное
                    field.parentElement./*getElementsByTagName*/$('label')[0].textContent = `Введите ${field.getAttribute('data-field-name')}`;
                    field.value = '';
                }//if
            }//for

        }//resetFormHandler

        //Загрузить список ID
        function loadDropDown() {
            let str = ticketsList.reduce((acc,claim) => acc+`<option>${claim.ticketId}</option>`,'')
            dropDownList.html(str);

            //По умолчанию 1-й элемент будет выбран
            dropDownList.children()[0].setAttribute('selected','selected');
        }

        //Обработчик выбора данных в выпадающем списке
        function selectionChangedHandler(e) {
            let chosenId = parseInt(e.target.value);

            let chosenTicket = ticketsList[ticketsList.findIndex(c => c.ticketId === chosenId)];

            if (chosenTicket)
            {
                form.setAttribute('data-selected-worker-id',chosenId.toString());
                //Заполняем поля
                destinationField.val(chosenTicket.destination);
                flightNumField.val(chosenTicket.flightNum);
                passengerField.val(chosenTicket.passenger);
                ticketPriceField.val(chosenTicket.ticketPrice);
            }
        }

        //endregion

        //Задание обработчиков на элементы формы
        (function addHandlers() {

            //region Обработчики на изменение данных в поле
            destinationField.change((e) =>
                onChangeHandler(e,(value) => value.length >= 3,'Пункт назначения должен содержать >= 3 символов')
            );

            flightNumField.change((e) =>
                onChangeHandler(e,(value)=> /([A-Za-z]+)(\s|\w)([0-9]+)/.test(value),'Номер рейса должен вида \'SU 1111\'')
            );

            passengerField.change((e) =>
                onChangeHandler(e,(value)=> value.length>=5 && !/[0-9]/g.test(value),'ФИО должно содержать >= 5 символов без чисел')
            );

            ticketPriceField.change((e) =>
                onChangeHandler(e,(value)=> parseInt(value)>=2000 && !/[A-Za-zА-Яа-я]/g.test(value),'Стоимость билета должна быть >= 2 000, только числа'));
            //endregion

            //region Кнопки формы
            //Кнопка одобрения формы
            btnSubmit.click(() => okClickHandler(bottomLbl,fields));

            //Отменить
            form.reset(() => resetFormHandler(bottomLbl,fields));
            //endregion


            //region Изменение режима формы
            changeToAddingBtn.click(() => changeFormToAdding(form,btnSubmit));
            changeToDeletionBtn.click(() => changeFormToDeletion(form,btnSubmit));
            changeToChangingBtn.click(() => changeFormToChanging(form,btnSubmit))
            //endregion

            dropDownList.change(selectionChangedHandler);

        })();


        //region Изменение состояний формы

        //Элементы, которые не должны изменяться при изменении режима формы
        function untouchedElem(element) {
            return  element.id &&
                    (element.id === idList.prop('id') ||
                    element.id === 'formLegend'||
                    element.id === 'formBtnsBlock'||
                    element.id === 'formPromptBlock')
        }


        //Форма в режим добавления
        function changeFormToAdding(form,submitBtn) {
            changeToAddingBtn.prop('disabled',true);
            changeToDeletionBtn.prop('disabled',false);
            changeToChangingBtn.prop('disabled',false);
            submitBtn.val('Добавить билет');

            //Отключаем видимость блока с выпадающим списом id
            idList.css('display','none') ;
            btnReset.css('display','inline-block');

            //Очищаем поля ввода
            let childElements = fieldset.children();

            for (let child of childElements) {
                //Если элемент не должен менятся (элемент управления)
                if  (untouchedElem(child))
                    continue;


                //В контейнере находим элементы ввода
                let input = child.getElementsByTagName('input')[0];

                //Для каждого элемента ввода меняем размер и очищаем поле
                input.disabled = false;
                input.style.width = '40%';
                input.value = '';
                btnReset.css('display','inline-block');

                //Включаем подсказки справа
                child.getElementsByTagName('label')[0].style.display = 'inline-block';
            }//for

            if (form.getAttribute('data-selected-worker-id'))
                form.removeAttribute('data-selected-worker-id');

        }

        //Форма в режим удаления
        function changeFormToDeletion(form,submitBtn) {
            //Отключаем кнопку перехода на текущий режим
            changeToAddingBtn.prop('disabled',false);
            changeToDeletionBtn.prop('disabled',true);
            changeToChangingBtn.prop('disabled',false);
            submitBtn.val('Удалить билет');

            //Отключаем видимость блока с выпадающим списом id
            idList.css('display','block') ;

            //Получение списка дочерних элементов (1-й уровень вложенности). Получаем div'ы
            let childElements = fieldset.children();
                for (let child of childElements) {

                    //Если текущий элемент соответствует элементу, который не должен менятся
                    if (untouchedElem(child))
                        continue;

                    //Отключаем остальные поля ввода кроме id
                    let input = child.getElementsByTagName('input')[0];

                    //Отключаем поляя ввода
                    input.disabled = true;

                    //Меняем ширину полей
                    input.style.width = '70%';
                    input.value = ' ';

                    //Отключаем кнопку отмены
                    btnReset.css('display','none');
                    child.getElementsByTagName('label')[0].style.display = 'none';
                }

            //Загружаем список Id
            loadDropDown();

            //Задаём стартовые значения
            let chosenTicket = ticketsList[parseInt(dropDownList.val())-1]
            //Изменяем атрибут
            form.setAttribute('data-selected-worker-id',dropDownList.val());

            destinationField.val(chosenTicket.destination);
            flightNumField.val(chosenTicket.flightNum);
            passengerField.val(chosenTicket.passenger);
            ticketPriceField.val(chosenTicket.ticketPrice);

        }

        //Форма в режим изменения
        function changeFormToChanging(form,submitBtn) {

            //Отключаем
            changeToAddingBtn.prop('disabled',false);
            changeToDeletionBtn.prop('disabled',false);
            changeToChangingBtn.prop('disabled',true);
            submitBtn.val('Изменить билет');

            //Отключаем видимость блока с выпадающим списом id
            idList.css('display','block') ;
            //Отключаем кнопку отмены
            btnReset.css('display','none');

            //Если поля ввода отключены после удаления
            if (fieldset.children()[2].getElementsByTagName('input')[0].disabled)
            {
                let childElements = fieldset.children();
                for (let child of childElements) {
                    //Если ID задан и равен id блока со списокм ticketsId
                    if  (untouchedElem(child))
                        continue;

                    let input = child.getElementsByTagName('input')[0];
                    input.disabled = false;
                    input.style.width = '40%';
                    input.value = '';


                    child.getElementsByTagName('label')[0].style.display = 'inline-block';
                }
            }
            //Загружаем список Id
            loadDropDown();

            //Задаём стартовые значения в поля
            let chosenTicket = ticketsList[parseInt(dropDownList.val())-1]

            //Изменяем атрибут
            form.setAttribute('data-selected-worker-id',dropDownList.val());

            destinationField.val(chosenTicket.destination);
            flightNumField.val(chosenTicket.flightNum);
            passengerField.val(chosenTicket.passenger);
            ticketPriceField.val(chosenTicket.ticketPrice);

        }
        //endregion


    });

})();
