
//region Билеты
//Заявка
class Ticket {
    //Свойства
    constructor(id,destination, flightNum, passenger, ticketPrice) {
        this.destination = destination;
        this.flightNum = flightNum;
        this.passenger = passenger;
        this.ticketPrice = ticketPrice;
        this.ticketId = id;
    }


    //region Геттеры и сеттеры

    //region Пункт назаняения
    get destination() {
        return this._destination;
    }

    set destination(value) {
        this._destination = value;
    }
    //endregion

    //region Номер рейса
    get flightNum() {
        return this._number;
    }

    set flightNum(value) {

        this._number = value;
    }
    //endregion

    //region Фамилия и инициалы пассажира
    get passenger() {
        return this._passenger;
    }

    set passenger(value) {
        this._passenger = value;
    }
    //endregion

    //region Стоимость билета
    get ticketPrice() {
        return this._price;
    }

    set ticketPrice(value) {
        this._price = value<0?getRandom(2500,30000):value;
    }
    //endregion

    //endregion

    //Вывод
    toTableRow () {
        return `<div id="d_${this.ticketId}">
                    <table>
                        <tr><td><span>Пункт назначения: <b>${this._destination}</b></span></td></tr>
                        <tr><td><span>Номер рейса: <b>${this._number}</b></span></td></tr>
                        <tr><td><span>Пассажир: <b>${this._passenger}</b></span></td></tr>
                        <tr><td><span>Стоимость билета: <b>${this._price}</b></span></td></tr>
                    </table>
                </div>`
    }

    //Выделение элемента
    highlightElement(cardId,predicate){
        if (!predicate(this))
            return;

        $(`d_${cardId}`).getElementsByTagName("table")[0].className = "highlightClaim";
        setTimeout(() => this.resetStyle(cardId),10_000);
    }

    //Сброс выделения элемента
    resetStyle(cardId){
        $(`d_${cardId}`).getElementsByTagName("table")[0].classList.remove("highlightClaim");
    }

}

//Управление заявками
class TicketsView{
    constructor(ticketsArr) {
        this.tickets = ticketsArr;
    }

    //Генерация массива заявок
    static generateTickets() {
        let array = [];

        for (let i = 0; i < 10; i++) {
            array[i] = new Ticket(i+1,generateDestination(),generateFlightNumber(),generatePerson(),generatePrice())
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(claimsArr) {
        let n = 0;
        let str = claimsArr.reduce((acc,claim) => acc+claim.toTableRow(n++),'');

        return str;
    }

    //Запись в localStore
    writeToLocal(){
        window.localStorage.ticketsView = JSON.stringify(this);
    }

    getFromLocal(){
        this.tickets = []
        let view = JSON.parse(window.localStorage.ticketsView);

        for (let elem of view.tickets) {
            let ticket = new Ticket('','',0,'',0);

            //Присваем свойтсва из локальной записи обекту
            Object.assign(ticket,elem);
            this.tickets.push(ticket);
        }
    }
}
//endregion


//region Работники
//Заявка
class Worker {
    //Свойства
    constructor(id,position,gender,salary,started) {
        this.workerId = id;
        this.workerSNP = generateSNP(gender);
        this.workerPosition = position;
        this.entryYear = started
        this.gender = gender;
        /*console.log(`Пол: ${this._gender}. Задан: ${gender}`);*/
        this.photoFile = this._gender.toLowerCase().includes('муж')?`man_0${id<10?(`0${id}`):(`${id}`)}.jpg`:`woman_0${id<10?(`0${id}`):(`${id}`)}.jpg`;
        this.salary = salary;
    }


    //region Геттеры и сеттеры

    get workerSNP() {
        return this._workerSNP;
    }

    set workerSNP(value) {
        this._workerSNP = value;
    }

    get workerPosition() {
        return this._position;
    }

    set workerPosition(value) {
        this._position = value;
    }

    get entryYear() {
        return this._entryYear;
    }

    set entryYear(value) {
        this._entryYear = value;
    }

    get gender() {
        return this._gender;
    }

    set gender(value) {
        this._gender = value;
    }

    get photoFile() {
        return this._photoFile;
    }

    set photoFile(value) {
        this._photoFile = value;
    }

    get salary() {
        return this._salary;
    }

    set salary(value) {
        this._salary = value;
    }

    //endregion

    //Метод вычисления стада
    get experience(){
        let now = new Date().getFullYear();

        return now - this._entryYear;

    }

    //Вывод
    toTableRow () {
        return `<div float: left id="${this.workerId}">
                    <table>
                        <tr><td><span>ФИО работника: <b>${this._workerSNP}</tr>
                        <tr><td><span>Должность: <b>${this._position}</b></span></td></tr>
                        <tr><td><span>Пол: <b>${this._gender}</tr>
                        <tr><td><span>Год поступления на работу: <b>${this._entryYear}</tr>
                        <tr><td><span>Файл с фотографией: <b>${this._photoFile}</b></span></td></tr>
                        <tr><td><span>Оклад: <b>${this._salary}</b></span></td></tr>
                        <tr><td><span>Стаж (лет): <b>${this.experience}</b></span></td></tr>
                        <tr>
                            <td>
                            <input id="change_${this.workerId}" type="button" value="Изменить">
                            <input id="delete_${this.workerId}" type="button" value="Удалить">
                            </td>
                        </tr>
                    </table>
                </div>`
    }

    equal(worker){

    }

    //Выделение элемента
    highlightElement(cardId,predicate){
        if (!predicate(this))
            return;

        $(`d_${cardId}`).getElementsByTagName("table")[0].className = "highlightClaim";
        setTimeout(() => this.resetStyle(cardId),10_000);
    }

    //Сброс выделения элемента
    resetStyle(cardId){
        $(`d_${cardId}`).getElementsByTagName("table")[0].classList.remove("highlightClaim");
    }

}

//Управление заявками
class WorkersView {
    constructor(workersArr) {
        this.workers = workersArr;
    }

    //Генерация массива заявок
    static generateWorkers() {
        let array = [];

        for (let i = 0; i < 10; i++) {
            array[i] = new Worker(i+1,generatePosition(),getGender(),generateSalary(),generateEntryYear())
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(workersArr) {
        let n = 0;
        let str = workersArr.reduce((acc,worker) => acc+worker.toTableRow(n++),'');

        return str;
    }
    //Запись в localStore
    writeToLocal(){
        window.localStorage.workersView = JSON.stringify(this);
    }

    //Чтение из LocalStore
    getFromLocal(){
        this.workers = []
        let view = JSON.parse(window.localStorage.workersView);

        for (let elem of view.workers) {
            let worker = new Worker('','','',0,0);
            Object.assign(worker,elem);
            this.workers.push(worker);
        }
    }
}
//endregion