/*
* Разработайте формы ввода для задания исходных данных и решения следующих
* задач – вариантов из учебника Павловской Т.А. по C#: Проверяйте значения
* на допустимость:
*     в первом выражении: b > -2,
*     во втором: x > 3,
*     в третьем m > 0.
* Данные не передавать на сервер, вести обработку в коде JavaScript этой
* же страницы HTML.  Все формы должны быть размещены на одной странице.
*
* */

// обработчик загрузки страницы
window.addEventListener('load', loadHandler, false);
function loadHandler() {
    $("btnData15").addEventListener('click', () => process('varData15', 'par_15',
        'z1_15', 'z2_15', b => b <= -2, b => calc15(b)), false);
    $("btnData16").addEventListener('click', () => process('varData16', 'par_16',
        'z1_16', 'z2_16', x => x <= 3, x => calc16(x)), false);
    $("btnData17").addEventListener('click', () => process('varData17', 'par_17',
        'z1_17', 'z2_17', m => m <= 0, m => calc17(m)), false);

    function process(idInput, idPar, idZ1, idZ2, validate, calc) {
        // элемент ввода
        let input = $(idInput);

        // элементы для отображения
        let outPar = $(idPar);
        let outZ1 = $(idZ1);
        let outZ2 = $(idZ2);

        // получить данные для обработки из элемента ввода
        let x = parseFloat(input.value);

        // обработка некорректных данных - по заданию
        if (validate(x)) {
            outPar.innerText = `${x}, некорректное значение`;
            outZ1.innerText = '';
            outZ2.innerText = '';
            return;
        } // if

        // вычисления по заданию
        let z1, z2;
        [z1, z2] = calc(x);

        // вывод результатов
        outPar.innerText = input.value;
        outZ1.innerText = z1.toFixed(6);
        outZ2.innerText = z2.toFixed(6);

        // очистить поле ввода
        input.value = '';
    } // process


    // вычисление по варианту 15
    function calc15(b) {
        let z1 = (Math.sqrt(2*b + 2*Math.sqrt(b*b - 4))) / (Math.sqrt(b*b - 4) + b + 2);
        let z2 = 1 / Math.sqrt(b + 2);
        return [z1, z2];
    } // variant15


    // вычисление по варианту 16
    function calc16(x) {
        let t = Math.sqrt(x*x - 9);
        let z1 = (x*x + 2*x - 3 + (x+1)*t) / (x*x - 2*x - 3 + (x - 1) * t);
        let z2 = Math.sqrt((x + 3)/(x - 3));
        return [z1, z2];
    } // calc16


    // вычисление по варианту 17
    function calc17(m) {
        let sm = Math.sqrt(m);
        let z1 = Math.sqrt((3*m + 2)**2 - 24*m) / (3*sm - 2/sm);
        return [z1, sm]
    } // calc17

} // loadHandler
