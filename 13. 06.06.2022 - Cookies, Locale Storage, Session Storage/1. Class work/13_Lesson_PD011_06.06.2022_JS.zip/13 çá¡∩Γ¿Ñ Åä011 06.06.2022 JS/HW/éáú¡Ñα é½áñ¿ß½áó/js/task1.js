
//Классы для вычислений
class Task1 {
    constructor(b) {
        this.b = b;
    }

    countZ1() {
        return Math.sqrt(2*this.b+2*Math.sqrt(this.b*this.b-4))/(Math.sqrt(this.b*this.b-4)+this.b+2);
    }
    countZ2() {
        return 1/Math.sqrt(this.b+2);
    }
}

//Вычисляет некорректно!
class Task2 {
    constructor(x) {
        this.x = x;
    }

    countZ1() {
        let x = this.x;
        return (x*x+2*x-3+(x+1)*Math.sqrt(x*x-9))/(x*x-2*x-3+(x-1)*Math.sqrt(x*x-9));
    }
    countZ2() {
        let x = this.x;
        return Math.sqrt((x+3)/(x-3));
    }
}

class Task3 {
    constructor(m) {
        this.m = m;
    }

    countZ1() {
        return Math.sqrt(Math.pow((3*this.m+2),2)-24*this.m)/(3*Math.sqrt(this.m)-2/Math.sqrt(this.m));
    }
    countZ2() {
        return -Math.sqrt(this.m);
    }
}

//Обработчик изменения данных в поле
function onChangeHandler(e,label,predicate,predicateCondition,z1,z2) {

    let field = e.target;
    let value = field.value;

    field.classList.remove('inValid-field');
    label.textContent = `Введите переменную ${field.getAttribute('data-var-name')}`

    if (predicate(value) && value.length > 0) {
        label.textContent = `Значение должно быть ${predicateCondition}`
        field.classList.add('inValid-field');

        z1.textContent = '';
        z2.textContent = '';
    }
    else if (value.length === 0)
    {
        z1.textContent = '';
        z2.textContent = '';
    }
}

//Обработчик кнопок ОК
function okClickHandler(messageText,inputField,z1,z2,countingClass) {

    //Сообщение снизу
    messageText.style.visibility = 'visible';


    let isInvalidClass = inputField.classList.contains('inValid-field');

    //Если в поле задан стиль сигнализирующий о некорректном значении
    if (isInvalidClass || inputField.value.length <= 0){
        messageText.textContent = isInvalidClass?'*Задана некорректая переменная!':'*Поле не может быть пустым!';
        return;
    }

    messageText.textContent = 'Результат вычислений ниже';

    let task = new countingClass(parseInt(inputField.value));

    let numZ1 = task.countZ1();
    let numZ2 = task.countZ2();

    z1.textContent = `Z1 = ${numZ1.toFixed(3)}`;
    z2.textContent = `Z2 = ${numZ2.toFixed(3)}`;

}

//Обработчик сброса формы
function resetFormHandler(outPutZ1,outPutZ2,bottomLbl,prompt,inputField) {

    //Убираем записи
    outPutZ1.textContent = '';
    outPutZ2.textContent = '';
    bottomLbl.textContent = '';

    //Если в поле задан стиль сигнализирующий о некорректном значении
    if (inputField.classList.contains('inValid-field')) {
        inputField.classList.remove('inValid-field');
        prompt.textContent = `Введите значение переменной ${inputField.getAttribute('data-var-name')}`;
    }
}

//Функция с самовызовом
(function (){


    let loadHandler = function () {

        //region Элементы на формах
        let inputB = $('varB');
        let labelForm1 = $('labelForm1');
        let btnForm1 = $('btnOkForm1');
        let bottomLbl1 = $('inValidForm1');

        let inputX = $('varX');
        let labelForm2 = $('labelForm2');
        let btnForm2 = $('btnOkForm2');
        let bottomLbl2 = $('inValidForm2');

        let inputM = $('varM');
        let labelForm3 = $('labelForm3');
        let btnForm3 = $('btnOkForm3');
        let bottomLbl3 = $('inValidForm3');
        //endregion


        //region Форма 1

        //Блоки вывода
        let Z1_1 = $('form1Z1');
        let Z2_1 = $('form1Z2');

        //Событие изменения данных в поле ввода
        inputB.addEventListener('change',(e) =>
            onChangeHandler(e,labelForm1,(value) => value<=-2 || /\D+/.test(value),' > -2. Только числа',Z1_1,Z2_1));

        //Клик на кнопку формы 1
        btnForm1.addEventListener('click',() =>
            okClickHandler(bottomLbl1,inputB,Z1_1,Z2_1,Task1));

        //При нажатии отмены исчезают все связанные с предыдущим вычислением записи
        document.form1.addEventListener('reset',() => resetFormHandler(Z1_1,Z2_1,bottomLbl1,labelForm1,inputB));

        //endregion

        //region Форма 2

        //Блоки вывода
        let Z1_2 = $('form2Z1');
        let Z2_2 = $('form2Z2');

        inputX.addEventListener('change',(e) =>
            onChangeHandler(e, labelForm2, (value) => value <= 3 || /\D+/.test(value), ' > 3', Z1_2, Z2_2,btnForm2));


        //Клик на кнопку
        btnForm2.addEventListener('click',() =>
            okClickHandler(bottomLbl2, inputX, Z1_2, Z2_2, Task2,btnForm2));

        //При нажатии отмены исчезают все связанные с предыдущим вычислением записи
        document.form2.addEventListener('reset',() => resetFormHandler(Z1_2,Z2_2,bottomLbl2,labelForm2,inputX));


        //endregion

        //region Форма 3

        //Блоки вывода
        let Z1_3 = $('form3Z1');
        let Z2_3 = $('form3Z2');

        inputM.addEventListener('change',(e) => {
            onChangeHandler(e,labelForm3,(value) => value<=0 || /\D+/.test(value),' > 0',Z1_3,Z2_3)
        });

        //Клик на кнопку
        btnForm3.addEventListener('click',() =>
            okClickHandler(bottomLbl3,inputM,Z1_3,Z2_3,Task3));


        //При нажатии отмены исчезают все связанные с предыдущим вычислением записи
        document.form3.addEventListener('reset',() =>  resetFormHandler(Z1_3,Z2_3,bottomLbl3,labelForm3,inputM));

        //endregion


    }//loadHandler
    window.addEventListener('load',loadHandler,false)
})();

