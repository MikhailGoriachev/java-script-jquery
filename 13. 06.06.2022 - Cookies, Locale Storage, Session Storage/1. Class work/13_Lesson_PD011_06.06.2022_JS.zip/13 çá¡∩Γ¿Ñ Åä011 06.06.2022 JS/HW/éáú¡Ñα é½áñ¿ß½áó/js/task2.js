//Заявка
class Claim {
    //Свойства
    constructor(destination, flightNum, passenger, ticketPrice) {
        this.destination = destination;
        this.flightNum = flightNum;
        this.passenger = passenger;
        this.ticketPrice = ticketPrice;
    }


    //region Геттеры и сеттеры

    //region Пункт назаняения
    get destination() {
        return this._destination;
    }

    set destination(value) {
        this._destination = value;
    }
    //endregion

    //region Номер рейса
    get flightNum() {
        return this._number;
    }

    set flightNum(value) {

        this._number = value<0?getRandom(200,900):value;
    }
    //endregion

    //region Фамилия и инициалы пассажира
    get passenger() {
        return this._passenger;
    }

    set passenger(value) {
        this._passenger = value;
    }
    //endregion

    //region Стоимость билета
    get ticketPrice() {
        return this._price;
    }

    set ticketPrice(value) {
        this._price = value<0?getRandom(2500,30000):value;
    }
    //endregion

    //endregion

    //Вывод
    toTableRow (n) {
        return `<div id="d_${n}">
                    <table>
                        <tr><td><span>Пункт назначения: <b>${this._destination}</b></span></td></tr>
                        <tr><td><span>Номер рейса: <b>${this._number}</b></span></td></tr>
                        <tr><td><span>Пассажир: <b>${this._passenger}</b></span></td></tr>
                        <tr><td><span>Стоимость билета: <b>${this._price}</b></span></td></tr>
                    </table>
                </div>`
    }

    //Выделение элемента
    highlightElement(cardId,predicate){
        if (!predicate(this))
            return;

        $(`d_${cardId}`).getElementsByTagName("table")[0].className = "highlightClaim";
        setTimeout(() => this.resetStyle(cardId),10_000);
    }

    //Сброс выделения элемента
    resetStyle(cardId){
        $(`d_${cardId}`).getElementsByTagName("table")[0].classList.remove("highlightClaim");
    }

}

//Управление заявками
class ClaimsView{
    constructor(claimsArr) {
        this.claims = claimsArr;
    }

    //Генерация массива заявок
    static generateClaims() {
        let array = [];

        for (let i = 0; i < 10; i++) {
            array[i] = new Claim(generateDestination(),generateFlightNumber(),generatePerson(),generatePrice())
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(claimsArr) {
        let n = 0;
        let str = claimsArr.reduce((acc,claim) => acc+claim.toTableRow(n++),'');

        return str;
    }
}


//region Сортировки, обработчики

//Упорядочить представление по пунктам назначения
function orderDescByDestination(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c1.destination.localeCompare(c2.destination));
    blockObject.innerHTML = ClaimsView.createMarkup(copy)
    titleObject.innerHTML = `<span>Сортировка массива по пунктам назначения</span>`;
    return copy;
}//orderDescByTemperature

//Упорядочить представление по стоимости билета
function orderByPrice(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c2.ticketPrice-c1.ticketPrice);
    blockObject.innerHTML = ClaimsView.createMarkup(copy)
    titleObject.innerHTML = `<span>Сортировка массива по стоимости билета</span>`;

    return copy;
}//orderByPrice

//Упорядочить представление по стоимости билета
function orderByFlightNum(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c2.flightNum-c1.flightNum);
    blockObject.innerHTML = ClaimsView.createMarkup(copy);
    titleObject.innerHTML = `<span>Сортировка массива по стоимости билета</span>`;

    return copy;
}//orderByFlightNum


//endregion


//Функция с самовызовом
(function (){

    //Массив заявок
    let claimView = new ClaimsView(ClaimsView.generateClaims());

    let mainBlock = $("mainDiv");

    mainBlock.innerHTML = ClaimsView.createMarkup(claimView.claims);


    //region Вставка заголовка
    let title = document.createElement("p");
    title.setAttribute("id", "taskTitle");
    title.setAttribute("class", "title-style");

    title.innerHTML = `<span>Исходный массив</span>`;
    mainBlock.parentNode.insertBefore(title, mainBlock);
    //endregion

    title = $('taskTitle');

    let loadHandler = function () {


        //region Старое задание
        //Последняя сформированная коллекция
        let lastFormedCollection = claimView.claims;

        //Обработчик кнопки вывода исходного массива
        let showDefaultArr = function () {

            mainBlock.innerHTML = ClaimsView.createMarkup(claimView.claims);
            title.innerHTML = `<span>Исходный массив</span>`;
            lastFormedCollection = claimView.claims;
        }

        let showTickets = function (collection) {

            mainBlock.innerHTML = ClaimsView.createMarkup(collection);
        }

        $("defaultArr").addEventListener("click",showDefaultArr,false);

        //region Сортировки

        //Обработчик кнопки сортировки по пункту на назначения
        $("orderByDest").addEventListener("click",() => lastFormedCollection = orderDescByDestination(mainBlock, title,claimView.claims),false);

        //Обработчик кнопки сортировки по стоимости билета
        $("orderByPrice").addEventListener("click",() => lastFormedCollection = orderByPrice(mainBlock, title,claimView.claims),false);

        //Обработчик кнопки сортировки по номеру рейса
        $("orderByFlightN").addEventListener("click",() => lastFormedCollection = orderByFlightNum(mainBlock, title,claimView.claims),false);


        //endregion

        let inputField = $("inputPrice");
        let btnSearch = $("highlightCommand");
        let message = $("messageText");


        //Обект таймера
        let timer = 0;

        //region Изменение подсказки
        //При выходе из поля ввода убираем записи и кнопку

        function focusMouseOutHandler(field) {
            let pattern = new RegExp('[0-9]+')
            let inputValue = field.value;

            //Если поле пустое или состоит из пробелов
            if (inputValue === "" || !pattern.test(inputValue)) {
                message.textContent = '';

                btnSearch.style.visibility = 'hidden';
                btnSearch.disabled = false;
            }

        }

        inputField.addEventListener("focusout",(e) => focusMouseOutHandler(e.target),false);
        inputField.addEventListener("mouseout",(e) => focusMouseOutHandler(e.target),false);

        //endregion

        //region Выделение элементов

        //Выделение элементов по редикату
        let highlightTickets = function (predicate,notFound = "значения не найдены") {

            //Получаем массив дочерних элементов общего блока
            let childNodes = getBlockChildren(mainBlock);

            //Проверка работы предиката
            let isData = 0;

            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {
                let data = getNumFromStr(childNode.getElementsByTagName("span")[3].getElementsByTagName("b")[0].innerHTML)

                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (predicate(data)) {
                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                    isData++;
                }
            }//for

            if (isData<=0)
                message.innerHTML = notFound;

            clearTimeout(timer);

            //После истечения таймера перепишем коллекцию
            timer = setTimeout(() => showTickets(lastFormedCollection),10_000)

        }//highlightTickets

        //Выделение одного элемента
        let highlightSingleTicket = function (ticket) {

            //Получаем массив дочерних элементов общего блока
            let childNodes = [];
            mainBlock.childNodes.forEach(c => {
                if (c.nodeType == 1) {
                    childNodes.push(c);
                }
            });

            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {

                //region Получение полей
                let destination = childNode.getElementsByTagName("span")[0].getElementsByTagName("b")[0].innerHTML;
                let flightNum = getNumFromStr(childNode.getElementsByTagName("span")[1].getElementsByTagName("b")[0].innerHTML);
                let snp = childNode.getElementsByTagName("span")[2].getElementsByTagName("b")[0].innerHTML;
                let ticketPrice = getNumFromStr(childNode.getElementsByTagName("span")[3].getElementsByTagName("b")[0].innerHTML);
                //endregion

                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (ticket.destination === destination &&
                    ticket.flightNum === flightNum &&
                    ticket.passenger === snp &&
                    ticket.ticketPrice === ticketPrice) {

                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                }
            }//for


            //После истечения таймера перепишем коллекцию
            setTimeout(() => showTickets(lastFormedCollection),10_000)



        }//highlightTickets

        //Проверка ввода
        let keyDownHandler = function (e) {

            /*let regExpr = new RegExp('[а-яА-Яa-zA-Z ]');*/
            let regExpr = new RegExp('[0-9]');

            //Флаг enter и backspace
            let enterPressed = e.key.toLowerCase().includes("enter");
            let backSpacePressed = e.key.toLowerCase().includes("backspace");
            let tabPressed = e.key.toLowerCase().includes("tab");

            //Вклюсчаем кнопку
            btnSearch.style.visibility = 'visible';

            //Если есть хоть одна буква - блокировка ввода
            if (!regExpr.test(e.key) && !backSpacePressed && !tabPressed && !enterPressed) {
                message.innerHTML = "введите число"

                btnSearch.disabled = true;

                e.preventDefault();
                return false;
            }

            message.innerHTML = "";
            btnSearch.disabled = false;

        }

        //Обработчик клика на кнопку поиска и выделения элементов
        function highlightClickHandler() {

            let inputValue = inputField.value;

            //Получение введённого значения
            let number = parseInt(inputValue);

            //Переписать массив билетов, чтобы снять выделение
            showTickets(lastFormedCollection);

            highlightTickets((data) => data > number);
        }

        //Блокировка задания любых символов кроме цифр
        inputField.addEventListener("keydown",keyDownHandler,false);

        btnSearch.addEventListener('click',highlightClickHandler,false);

        //endregion
        //endregion

        //region Форма

        //Форма
        let form = document.addForm;

        let fieldset = $('fieldsetForm');
        let fieldsetWidth = fieldset.offsetWidth;

        //Нижнний текст
        let bottomLbl = $('formPrompt');

        //Массив полей вода
        let fields = [];
        for (let i = 0; i < form.elements.length; i++) {
            let element = form.elements[i];
            if (element.type === 'text')
                fields.push(element)
        }


        //Поля
        let destinationField = $('destination');
        let flightNumField = $('flightNum');
        let passengerField = $('passengerSnp');
        let ticketPriceField = $('ticketPrice');



        //Обработчик изменения данных в поле
        function onChangeHandler(e,predicate,ifWrongMessage) {
            //Получаем поле ввода
            let field = e.target;
            let value = field.value;


            //Находим подсказку справа
            let label = field.parentElement.getElementsByTagName('label')[0];

            field.classList.remove('inValid-field');
            label.textContent = `Введите ${field.getAttribute('data-field-name')}`


            if (fieldset.offsetWidth !== fieldsetWidth)
                fieldset.style.width = `${fieldsetWidth}px`;

            if (!predicate(value) && value.length>0) {
                label.textContent = `${ifWrongMessage}`
                field.classList.add('inValid-field');

                fieldset.style.width = `${fieldsetWidth + ifWrongMessage.length*3.85}px`;
            }
        }

        //Обработчик кнопок ОК
        function okClickHandler(bottomLbl,inputFields) {

            //Сообщение снизу
            bottomLbl.style.visibility = 'visible';

            //Невалидна ли форма
            let inValid = false;

            //Находим поля ввода с некорректными значениями
            for (let field of inputFields) {

                let classContains = field.classList.contains('inValid-field');
                let fieldEmpty = field.value.length === 0;

                //Если в поле задан стиль сигнализирующий о некорректном значени или данные отсутвуют
                //Если нет класса, но поле пустое
                inValid = classContains || !classContains && fieldEmpty || inValid;

                console.log(`inValid: ${inValid}`);

            }//for


            //Если есть невалидные поля в форме
            if(inValid) {
                bottomLbl.textContent = '*В данных есть ошибка!';
                return;
            }

            //Создать объект
            let claim = new Claim(
                $('destination').value,
               parseInt($('flightNum').value),
                $('passengerSnp').value,
               parseInt($('ticketPrice').value),
            );

            //Если билет создать не удалось
            if (!claim) {
                bottomLbl.textContent = '*Не удалось создать билет!';
                console.log(`obj:\r\n${claim.destination}\
                \r\n${claim.flightNum}\
                \r\n${claim.passenger}\
                \r\n${claim.ticketPrice}\
                `)
            }

            //Добавление в массивы
            let tickets = claimView.claims
            tickets.push(claim);
            showDefaultArr();
            highlightSingleTicket(tickets[tickets.length-1])

            bottomLbl.textContent = 'Билет успешно добавлен. Элемент выделен синим.';

            //Очистка формы
            setTimeout(() => resetFormHandler(bottomLbl,inputFields),5_000) ;

        }

        //Обработчик сброса формы
        function resetFormHandler(bottomLbl,inputFields) {

            //Убираем запись снизу
            bottomLbl.textContent = '';
            bottomLbl.style.visibility = 'hidden';

            //Находим поля ввода с некорректными значениями
            for (let field of inputFields) {
                if (field.classList.contains('inValid-field')) {
                    field.classList.remove('inValid-field');

                    //Меняем значение в подсказаках на начальное
                    field.parentElement.getElementsByTagName('label')[0].textContent = `Введите ${field.getAttribute('data-field-name')}`;
                    field.value = '';
                }//if
            }//for

        }//resetFormHandler

        //Задание обработчиков на элементы формы
        (function addHandlers() {

            //region Обработчики на изменение данных в поле
            destinationField.addEventListener('change',(e) =>
                onChangeHandler(e,(value) => value.length>=3,'Пункт назначения должен содержать >= 3 символов'));

            flightNumField.addEventListener('change',(e) =>
                onChangeHandler(e,(value)=> parseInt(value)>=100,'Номер рейса должен быть 3-х значным числом'));

            passengerField.addEventListener('change',(e) =>
                onChangeHandler(e,(value)=> value.length>=5 && !/[0-9]/g.test(value),'ФИО должно содержать >= 5 символов без чисел'));

            ticketPriceField.addEventListener('change',(e) =>
                onChangeHandler(e,(value)=> parseInt(value)>=2000 && !/[A-Za-zА-Яа-я]/g.test(value),'Стоимость билета должна быть >= 2 000, только числа'));
            //endregion

            //Добавить билет
            $('btnAdd').addEventListener('click',() => okClickHandler(bottomLbl,fields))

            //Отменить
            form.addEventListener('reset',() => resetFormHandler(bottomLbl,fields))

        })();

        //endregion

    }

    window.addEventListener("load",loadHandler,false);
})();