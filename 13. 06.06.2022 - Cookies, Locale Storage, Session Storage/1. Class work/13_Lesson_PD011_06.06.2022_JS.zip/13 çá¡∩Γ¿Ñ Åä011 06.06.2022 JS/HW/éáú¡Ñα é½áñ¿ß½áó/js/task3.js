//Заявка
class Worker {
    //Свойства
    constructor(id,position,gender,salary,started) {
        this.workerId = id;
        this.workerSNP = generateSNP(gender);
        this.workerPosition = position;
        this.entryYear = started
        this.gender = gender;
        /*console.log(`Пол: ${this._gender}. Задан: ${gender}`);*/
        this.photoFile = this._gender.toLowerCase().includes('муж')?`man_0${id<10?(`0${id}`):(`${id}`)}.jpg`:`woman_0${id<10?(`0${id}`):(`${id}`)}.jpg`;
        this.salary = salary;
    }


    //region Геттеры и сеттеры

    get workerSNP() {
        return this._workerSNP;
    }

    set workerSNP(value) {
        this._workerSNP = value;
    }

    get workerPosition() {
        return this._position;
    }

    set workerPosition(value) {
        this._position = value;
    }

    get entryYear() {
        return this._entryYear;
    }

    set entryYear(value) {
        this._entryYear = value;
    }

    get gender() {
        return this._gender;
    }

    set gender(value) {
        this._gender = value;
    }

    get photoFile() {
        return this._photoFile;
    }

    set photoFile(value) {
        this._photoFile = value;
    }

    get salary() {
        return this._salary;
    }

    set salary(value) {
        this._salary = value;
    }

    //endregion

    //Метод вычисления стада
    get experience(){
        let now = new Date().getFullYear();

        return now - this._entryYear;

    }

    //Вывод
    toTableRow () {
        return `<div float: left id="${this.workerId}">
                    <table>
                        <tr><td><span>ФИО работника: <b>${this._workerSNP}</tr>
                        <tr><td><span>Должность: <b>${this._position}</b></span></td></tr>
                        <tr><td><span>Пол: <b>${this._gender}</tr>
                        <tr><td><span>Год поступления на работу: <b>${this._entryYear}</tr>
                        <tr><td><span>Файл с фотографией: <b>${this._photoFile}</b></span></td></tr>
                        <tr><td><span>Оклад: <b>${this._salary}</b></span></td></tr>
                        <tr><td><span>Стаж (лет): <b>${this.experience}</b></span></td></tr>
                        <tr>
                            <td>
                            <input id="change_${this.workerId}" type="button" value="Изменить">
                            <input id="delete_${this.workerId}" type="button" value="Удалить">
                            </td>
                        </tr>
                    </table>
                </div>`
    }

    equal(worker){

    }

    //Выделение элемента
    highlightElement(cardId,predicate){
        if (!predicate(this))
            return;

        $(`d_${cardId}`).getElementsByTagName("table")[0].className = "highlightClaim";
        setTimeout(() => this.resetStyle(cardId),10_000);
    }

    //Сброс выделения элемента
    resetStyle(cardId){
        $(`d_${cardId}`).getElementsByTagName("table")[0].classList.remove("highlightClaim");
    }

}

//Управление заявками
class WorkersView {
    constructor(workersArr) {
        this.workers = workersArr;
    }

    //Генерация массива заявок
    static generateWorkers() {
        let array = [];

        for (let i = 0; i < 10; i++) {
            array[i] = new Worker(i+1,generatePosition(),getGender(),generateSalary(),generateEntryYear())
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(workersArr) {
        let n = 0;
        let str = workersArr.reduce((acc,worker) => acc+worker.toTableRow(n++),'');

        return str;
    }
}


//region Сортировки, обработчики

//Упорядочить представление фамилиям
function orderBySurname(blockObject, workers) {
    //Копия массива
    let copy = workers.map(c => c).sort((w1,w2) => w1.workerSNP.localeCompare(w2.workerSNP));
    blockObject.innerHTML = WorkersView.createMarkup(copy);
}//orderBySurname

//Упорядочить по должностям
function orderByPositions(blockObject, workers) {
    //Копия массива
    let copy = workers.map(c => c).sort((w1,w2) => w1.workerPosition.localeCompare(w2.workerPosition));
    blockObject.innerHTML = WorkersView.createMarkup(copy);

}//orderByPositions

//Упорядочить по окладу
function orderBySalary(blockObject, workers) {
    //Копия массива
    let copy = workers.map(c => c).sort((w1,w2) => w2.salary - w1.salary);
    blockObject.innerHTML = WorkersView.createMarkup(copy);

}//orderBySalary



//endregion


//Функция с самовызовом
(function (){

    let mainBlock = $('mainDiv');

    //Работники
    let workersView = new WorkersView(WorkersView.generateWorkers());
    let workers = workersView.workers;

    /*mainBlock.innerHTML = WorkersView.createMarkup(workers);*/

    let title = $('taskTitle');

    let loadHandler = function () {

        let inputField = $("inputExperience");
        let btnSearch = $("highlightByExperience");
        let message = $("messageText");
        let lastFormedCollection = workers;

        //Обект таймера
        let timer = 0;

        //Обработчик кнопки вывода исходного массива
        let showDefaultArr = function () {
            mainBlock.innerHTML = WorkersView.createMarkup(workers);
            title.innerHTML = `<span>Исходный массив</span>`;
            lastFormedCollection = workers;

            addOnCardBtnHandlers();
        }
        showDefaultArr();

        //region Сортировки + выделение

        //Обработчик кнопки сортировки по пункту на назначения
        $("orderBySurname").addEventListener("click",() => {

            //Сортировка
            orderBySurname(mainBlock,workers);

            addOnCardBtnHandlers();

            title.innerHTML = `<span>Сортировка по фамилиям работников</span>`;
        },false);

        //Обработчик кнопки выделения работников с мин. зарплатой
        $("minSalary").addEventListener("click",() => {

            //Предварительная сортировка
            orderBySurname(mainBlock,workers);
            addOnCardBtnHandlers();

            let minSalary = Math.min(...workers.map(w => w.salary));

            highlightWorkers((value) => value === minSalary,5);
            title.innerHTML = `<span>Выделение работников с мин. зарплатой</span>`;

        },false);

        //Обработчик кнопки выделения работников с макс. зарплатой
        $("maxSalary").addEventListener("click",() => {

            //Предварительная сортировка
            orderByPositions(mainBlock,workers);
            addOnCardBtnHandlers();

            let maxSalary = Math.max(...workers.map(w => w.salary));

            highlightWorkers((value) => value === maxSalary,5);
            title.innerHTML = `<span>Выделение работников с макс. зарплатой</span>`;

        },false);


        //endregion



        //region Изменение подсказки
        //При выходе из поля ввода убираем записи и кнопку

        function focusMouseOutHandler(field) {
            let pattern = new RegExp('[0-9]+')
            let inputValue = field.value;

            //Если поле пустое или состоит из пробелов
            if (inputValue === "" || !pattern.test(inputValue)) {
                message.textContent = '';

                btnSearch.style.visibility = 'hidden';
                btnSearch.disabled = false;
            }

        }

        //Обработчики на покидание мыши и выход из фокуса
        inputField.addEventListener("focusout",(e) => focusMouseOutHandler(e.target),false);
        inputField.addEventListener("mouseout",(e) => focusMouseOutHandler(e.target),false);

        //endregion

        //region Выделение элементов по стажу

        //Выделение элементов по редикату
        //Field index - индекс поля карточки откуда будут братся данные для предиката
        let highlightWorkers = function (predicate,fieldIndex,notFound = "значения не найдены") {

            //Получаем массив дочерних элементов общего блока
            let childNodes = getBlockChildren(mainBlock);

            //Проверка работы предиката
            let isData = 0;

            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {
                let data = getNumFromStr(childNode.getElementsByTagName("span")[fieldIndex].getElementsByTagName("b")[0].innerHTML)

                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (predicate(data)) {
                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                    isData++;
                }
            }//for

            if (isData<=0)
                message.innerHTML = notFound;

            clearTimeout(timer);

            //После истечения таймера перепишем коллекцию
            timer = setTimeout(showDefaultArr,15_000)

        }//highlightWorkers

        //Выделение одного элемента
        let highlightSingleWorker = function (worker) {

            //Получаем массив дочерних элементов общего блока
            let childNodes = getBlockChildren(mainBlock);

            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {

                //region Получение полей
                let snp = childNode.getElementsByTagName("span")[0].getElementsByTagName("b")[0].innerHTML;
                let workerPosition = childNode.getElementsByTagName("span")[1].getElementsByTagName("b")[0].innerHTML;
                let gender = childNode.getElementsByTagName("span")[2].getElementsByTagName("b")[0].innerHTML;
                let entryYear = getNumFromStr(childNode.getElementsByTagName("span")[3].getElementsByTagName("b")[0].innerHTML);
                let photoFile = childNode.getElementsByTagName("span")[4].getElementsByTagName("b")[0].innerHTML;
                let salary = getNumFromStr(childNode.getElementsByTagName("span")[5].getElementsByTagName("b")[0].innerHTML);
                //endregion

                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (worker.workerSNP === snp &&
                    worker.workerPosition === workerPosition &&
                    worker.gender === gender &&
                    worker.entryYear === entryYear &&
                    worker.photoFile === photoFile &&
                    worker.salary === salary) {

                    clearTimeout(timer);
                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                }
            }//for

        }//highlightWorkers

        //Проверка ввода
        let keyDownHandler = function (e) {

            let regExpr = new RegExp('[0-9]');

            //Флаги нажатия убравляющих клавиш, иначе они также блокируются
            let enterPressed = e.key.toLowerCase().includes("enter");
            let backSpacePressed = e.key.toLowerCase().includes("backspace");
            let tabPressed = e.key.toLowerCase().includes("tab");

            //Вклюсчаем кнопку
            btnSearch.style.visibility = 'visible';

            //Если есть хоть одна буква - блокировка ввода
            if (!regExpr.test(e.key) && !backSpacePressed && !tabPressed && !enterPressed) {
                message.innerHTML = "введите число"

                btnSearch.disabled = true;

                e.preventDefault();
                return false;
            }

            message.innerHTML = "";
            btnSearch.disabled = false;

        }

        //Обработчик клика на кнопку поиска и выделения элементов
        function highlightClickHandler() {

            let inputValue = inputField.value;

            //Получение введённого значения
            let number = parseInt(inputValue);

            //Упорядочить по окладу
            orderBySalary(mainBlock,workers);
            title.innerHTML = `<span>Выделение работников со стажем > ${inputValue}</span>`;

            //Выделить работников по предикату из заданной строки карточки
            highlightWorkers((data) => data > number,6);

            if (message.innerHTML.toLowerCase().includes('не найдены')) {
                showDefaultArr();
                return;
            }

            addOnCardBtnHandlers();
        }

        inputField.addEventListener("keydown",keyDownHandler,false);

        btnSearch.addEventListener('click',highlightClickHandler,false);

        //endregion

        //region Редактировани и удаление
        //Обработчик для кнопки удалить
        function deleteWorkerHandler(e) {
            let button = e.target;
            let parent = button.parentElement;

            //Поиск общего блока.
            while (!parent.tagName.toLowerCase().includes('div') && !/[0-9]+/.test(parent.id))
                parent = parent.parentElement;

            //Получаем id нужного работника из  ID div'a
            let idWorker = parseInt(parent.id);


            let index =  workers.findIndex((w) => w.workerId === idWorker);

            workers.splice(index,1);

            //Изменение идентификаторов оставшихся после удалённой запиисей
            changeIdsAfterDel(workers,index);

            showDefaultArr();

            //Если удаляется редактируемый элемент
            if (parseInt(form.getAttribute('data-selected-worker-id')) === idWorker)
                resetFormHandler(bottomLbl,fields);

        }//deleteWorkerHandler

        //Изменение массива после удаления
        function changeIdsAfterDel(workersCollection,delInd) {

            //Уменьшить все id идущие после удалённого
            for (let i = delInd; i < workersCollection.length; i++) {
                workersCollection[i].workerId--;
            }

        }

        //Обработчик для кнопки удалить
        function editWorkerHandler(e) {
            let button = e.target;
            let parent = button.parentElement;

            //Поиск общего блока.
            while (!parent.tagName.toLowerCase().includes('div') && !/[0-9]+/.test(parent.id))
                parent = parent.parentElement;

            //Получаем id нужного работника из  ID DIV'a
            let idWorker = parseInt(parent.id);

            let index =  workers.findIndex((w) => w.workerId === idWorker);

            changeFormToEditing(workers[index])

            showDefaultArr();

        }//editWorkerHandler
        
        //Задание обработчиков для кнопок удаления и изменения на карточках
        function addOnCardBtnHandlers () {
            for (let i = 1; i <= workers.length; i++) {
                $(`delete_${i}`).addEventListener('click',deleteWorkerHandler,false);
                $(`change_${i}`).addEventListener('click',editWorkerHandler,false);
            }
        };

        //endregion

        //region Форма

        //Форма
        let form = document.addChangeForm;

        let fieldset = $('fieldsetForm');
        let fieldsetWidth = fieldset.offsetWidth;

        //Нижнний текст
        let bottomLbl = $('formPrompt');

        //Кнопка добавить/изменить
        let btnAddChange = $('btnAdd');
        let btnReset = $('resetBtn');


        //Массив ТЕКСТОВЫХ полей вода для итоговой вадилации
        let fields = [];
        for (let i = 0; i < form.elements.length; i++) {
            let element = form.elements[i];

            //Выбираем поля с текстовым вводом
            if (element.type === 'text')
                fields.push(element)
        }


        //Поля формы для задания валидаторов
        let workerSnp = $('workerSnp');
        let workerPosition = $('positionsList');
        let workerGender = $('genderList');
        let entryYear = $('entryYear');
        let photoFile = $('photoFile');
        let salary = $('workerSalary');

        //region Обработчики на форме
        //Обработчик изменения данных в поле
        function onChangeHandler(e,predicate,ifWrongMessage) {
            //Получаем поле ввода
            let field = e.target;
            let value = field.value;


            //Находим подсказку справа
            let label = field.parentElement.getElementsByTagName('label')[0];

            field.classList.remove('inValid-field');
            label.textContent = `Введите ${field.getAttribute('data-field-name')}`


            if (!predicate(value) && value.length>0) {
                label.textContent = `${ifWrongMessage}`
                field.classList.add('inValid-field');
            }
        }

        //region Обработчик кнопок добавления или изменения
        function okClickHandler(bottomLbl,inputFields) {

            //Сообщение снизу
            bottomLbl.style.visibility = 'visible';

            //Невалидна ли форма
            let inValid = false;

            //Находим поля ввода с некорректными значениями
            for (let field of inputFields) {

                let classContains = field.classList.contains('inValid-field');
                let fieldEmpty = field.value.length === 0;

                //Если в поле задан стиль сигнализирующий о некорректном значени или данные отсутвуют
                //Или если нет класса, но поле пустое
                inValid = classContains || !classContains && fieldEmpty || inValid;

            }//for

            //Если есть невалидные поля в форме
            if(inValid) {
                bottomLbl.textContent = '*В введённых данных есть ошибки или пустые поля!';
                return;
            }

            //Если меняем объект
            let changing =  btnAddChange.value.toLowerCase().includes('изменить');

            //region Создание объекта
            //Создать объект работника
            let worker = new Worker(
                changing?parseInt(form.getAttribute('data-selected-worker-id')):
                    workers.length+1,//id - если меняем объект, тогда задаём сущетсвующий id
                workerPosition.value,
                workerGender.value,
                parseInt(salary.value),
                parseInt(entryYear.value),
            );

            //Автогенерируемые поля изменяем отдельно, поскольку в консруткоре происходит их генерация
            worker.workerSNP = workerSnp.value;
            worker.photoFile = photoFile.value;
            //endregion


            //Если билет создать не удалось
            if (!worker) {
                bottomLbl.textContent = '*Не удалось создать билет!';
                console.log(`obj:\r\n${worker.workerId}\
                \r\n${worker.workerSNP}\
                \r\n${worker.workerPosition}\
                \r\n${worker.workerPosition}\
                \r\n${worker.gender}\
                \r\n${worker.salary}\
                \r\n${worker.experience}\
                `)
            }

            //Взависимости от действия поразному работаем с коллекцией
            if (changing)
                changingWorker(worker);
            else
                addingWorker(worker);

        }

        function changingWorker(worker) {
            //Мнеяем запись по индексу
            workers[worker.workerId-1] = worker;

            //Вывод по умолчанию
            showDefaultArr();

            highlightSingleWorker(worker);

            bottomLbl.textContent = 'Работник изменён. Карточка выделена синим.';
            title.innerHTML= `<span>Изменённый работник выделен</span>`

        }
        function addingWorker(worker) {
            //Добавление в массивы. Либо редактирование
            workers.push(worker)

            let temp = [...workers];
            //Выводим массив реверсированно, чтобы сначала были добавленные элементы
            mainBlock.innerHTML = WorkersView.createMarkup(temp.reverse());

            //Добавляем обработчик для возможности удаления
            addOnCardBtnHandlers();
            highlightSingleWorker(workers[workers.length-1]);

            bottomLbl.textContent = 'Работник успешно добавлен. Элемент выделен синим.';
            title.innerHTML= `<span>Добавленные элементы впереди</span>`
        }
        //endregion

        //Обработчик сброса формы
        function resetFormHandler(bottomLbl,inputFields) {

            //Убираем запись снизу
            bottomLbl.textContent = '';
            bottomLbl.style.visibility = 'hidden';
            btnAddChange.value = btnAddChange.value.toLowerCase().includes('изменить')?'Добавить':btnAddChange.value;

            //Находим текстовые поля ввода с некорректными значениями
            for (let field of inputFields) {
                if (field.classList.contains('inValid-field')) {
                    field.classList.remove('inValid-field');

                    //Меняем значение в подсказаках на начальное
                    field.parentElement.getElementsByTagName('label')[0].textContent = `Введите ${field.getAttribute('data-field-name')}`;
                }//if

                if (!field.id.toLowerCase().includes('photo'))
                    field.value = '';
            }//for

            //Меняем имя файла для добавления
            loadPhotoFile(workerGender);

        }//resetFormHandler

        //Заполнение
        function loadDropDown() {
            let positions = generatePositions();

            let str = positions.reduce((acc,position) => acc+`<option>${position}</option>`,'')
            workerPosition.innerHTML = str;

        }

        //Заполнение поля имени файла
        function loadPhotoFile(fieldList) {

            let value = fieldList.value;

            //В зависимости от режима работы формы меняем id
            let id = btnAddChange.value.toLowerCase().includes('изменить')?
                parseInt(form.getAttribute('data-selected-worker-id')):
                workers.length+1;

            photoFile.value = value.toLowerCase().includes('муж')?`man_0${id<10?(`0${id}`):(`${id}`)}.jpg`:`woman_0${id<10?(`0${id}`):(`${id}`)}.jpg`;
        }

        //Задание обработчиков на элементы формы
        (function addHandlers() {

            //Загрузка выпадающего списка должностей
            loadDropDown();

            loadPhotoFile(workerGender);

            //region Текстовые поля

            // Условие предиката: мин 5 символов + отсутвие цифр + заглвная буква в начале
            workerSnp.addEventListener('change',(e) =>
                onChangeHandler(e,
                    (value)=> value.length>=5 && !/[0-9]/g.test(value) && /^[A-ZА-Я]/.test(value)
                    ,'ФИО должно содержать >= 5 символов. Обязательно заглавная бува в начале'
                )
            );

            //Обработчики на изменение данных в поле имени файла.
            photoFile.addEventListener('change',(e) =>
                onChangeHandler(e,
                    (value) => /(\w+)_([0-9]+)\.(jpg|png|jpeg)/.test(value),
                    'Имя файла должно быть вида: \'men_001.(jpg|png|jpeg)\'')
            );

            //Валидация оклада
            salary.addEventListener('change',(e) =>
                onChangeHandler(e,
                    (value) => parseInt(value)>=500 && !/\D+/.test(value),
                    'Зарплата не должна быть <$500. Разрешены только цифры'));

            //Валидация года поступления
            entryYear.addEventListener('change',(e) =>
                onChangeHandler(e,
                    (value) => {
                        let year = parseInt(value)
                         return year >= 2000 && year <= 2021 &&  !/\D+/.test(value)
                    },
                    'Год принятия должен быть между 2000 и 2021'));

            //endregion

            //При изименении пола в выпадающем списке меняем имя файла
            workerGender.addEventListener('change',(e) => loadPhotoFile(e.target),false)

            //Добавить работника
            btnAddChange.addEventListener('click',() => okClickHandler(bottomLbl,fields));

            //Отменить
            /*form.addEventListener('reset',() => resetFormHandler(bottomLbl,fields))*/
            btnReset.addEventListener('click',() => resetFormHandler(bottomLbl,fields),false)

        })();
        //endregion

        //Изменение вида формы для редактирования
        function changeFormToEditing(selectedWorker) {
            btnAddChange.value = 'Изменить';

            //region Запись свойств объекта в поля формы
            workerSnp.value = selectedWorker.workerSNP;

            //Переписываем список для корректного задания selected для нужного элемента
            loadDropDown();

            //Выбранной оставляем должность, которую занимает выбранный работник
            workerPosition.innerHTML = workerPosition.innerHTML.replace(
                `<option>${selectedWorker.workerPosition}</option>`
                ,`<option selected>${selectedWorker.workerPosition}</option>`
            );


            workerGender.innerHTML = workerGender.innerHTML.replace(
                `<option>${selectedWorker.gender}</option>`
                ,`<option selected>${selectedWorker.gender}</option>`
            );

            //Год поступления
            entryYear.value = selectedWorker.entryYear;

            //Файл с фотографией
            photoFile.value = selectedWorker.photoFile;

            //Зарплата
            salary.value = selectedWorker.salary;
            //endregion

            //Передаём id работника в атрибут формы
            form.setAttribute('data-selected-worker-id',selectedWorker.workerId);

            $('detailsForm').setAttribute('open','');

            //Перевод фокуса на форму
            workerSnp.focus();

        }

        //endregion

    }

    window.addEventListener("load",loadHandler,false);
})();