/*
* Функции для работы с массивами в задачах 2 и 3
* */

// заполнение массива arr случайными числами
// в диапазоне значений от [lo, hi]
function fillArray(arr, lo = -10, hi = 10) {
    for (let i = 0; i < arr.length; ++i) {
        let temp = getRand(lo, hi);
        if (Math.abs(temp) < 0.6) temp = 0;
        arr[i] = temp;
    } // for i
} // fillArray


// заполнение массива arr случайными целыми числами
// в диапазоне значений от [lo, hi]
function fillIntArray(arr, lo = -10, hi = 10) {
    for (let i = 0; i < arr.length; ++i) {
        arr[i] = getIntRand(lo, hi);
    } // for i
} // fillIntArray


// вывод массива вещественных чисел в строку таблицы
// с заданной точностью (что исключает использование join())
function toTableRow(arr, prec= 0) {
    return arr.reduce((acc, item) => acc + `<td>${item.toFixed(prec)}</td>`, '<tr>') + '</tr>'
} // toTableRow
