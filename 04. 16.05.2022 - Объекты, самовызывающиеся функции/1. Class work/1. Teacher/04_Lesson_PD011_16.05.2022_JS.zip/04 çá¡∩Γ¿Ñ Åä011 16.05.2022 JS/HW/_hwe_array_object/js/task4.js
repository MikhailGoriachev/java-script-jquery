/*
* Задача 4.
* Спроектировать объект для представления данных о погоде: температура,
* давление, влажность, скорость и направление ветра, графическое отображение
* атмосферных явлений (ясно, облачно, дождь, и т.д. – не более 5 видов явлений).
* Предусмотрите методы для задания вида явления, увеличения давления (максимальное
* значение давления 1200 гПа), вывода объекта в разметку, продемонстрируйте
* работу методов объекта
*  */

let task4Weather = {
    // атмосферные явления (ясно, облачно, дождь, и т.д. – не более 5)
    meteor: {
        name: "",  // название явления
        img: ""    // графическое отображение
    },

    // температура
    temperature: 0,

    // давление,
    pressure: 0,

    // влажность,
    humidity: 0,

    // скорость и направление ветра,
    wind: { speed: 0, direction: ""},

    // задание атмосферного явления
    setView: function(name, img) {
        this.meteor.name = name;
        this.meteor.img = img;
    },

    // увеличение давления
    incPressure: function(value) {
        let newValue = value + this.pressure;

        // давление меняем, только если новое значение
        // в допустимом диапазоне значений [0, 1200]
        if (0 <= newValue && newValue <= 1200)
            this.pressure = newValue;
    },

    // формирование строки с данными объекта для вывода в разметку
    toString: function(row) {
        return `
            <tr>
                <td>${row}</td>
                <td class="align-center">
                    <img src="../images/task4/${this.meteor.img}" width="64" height="64"/><br/>
                   ${this.meteor.name}
                </td>
                <td>${this.temperature}</td>
                <td>${this.pressure}</td>
                <td class="align-center">${this.wind.direction}</td>
                <td>${this.wind.speed}</td>
                <td>${this.humidity}</td>
            </tr>`;
    }
};

let row = 1;

task4Weather.setView("ясно", "sunny.png");
task4Weather.temperature = 35;
task4Weather.pressure = 1012;
task4Weather.wind.direction = 'Ю-З';
task4Weather.wind.speed = 3;
task4Weather.humidity = 36;

document.write(`${task4Weather.toString(row)}`);

row++;
task4Weather.setView("облачно", "cloudly.png");
task4Weather.temperature = 22;
task4Weather.incPressure(100);
task4Weather.wind.direction = 'С-З';
task4Weather.wind.speed = 5;
task4Weather.humidity = 85;

document.write(`${task4Weather.toString(row)}`);

row++;
task4Weather.setView("дождь", "rain.png");
task4Weather.temperature = 21;
task4Weather.incPressure(-150);
task4Weather.wind.direction = 'Ю-В';
task4Weather.wind.speed = 12;
task4Weather.humidity = 100;

document.write(`${task4Weather.toString(row)}`);

row++;
task4Weather.setView("гроза", "thunderstom.png");
task4Weather.temperature = 28;
task4Weather.incPressure(200);
task4Weather.wind.direction = 'С-В';
task4Weather.wind.speed = 15;
task4Weather.humidity = 98;

document.write(`${task4Weather.toString(row)}`);

row++;
task4Weather.setView("снег", "snow.png");
task4Weather.temperature = -5;
task4Weather.incPressure(-50);
task4Weather.wind.direction = 'С';
task4Weather.wind.speed = 12;
task4Weather.humidity = 80;

document.write(`${task4Weather.toString(row)}`);