/*
* Задача 3.
* Спроектировать объект для представления данных о книге: название, автор,
* год издания, цена, изображение обложки.
* Предусмотрите методы для увеличения цены книги на заданное значение
* (не допускайте значений, меньше или равных нулю), увеличения года издания
* на 1 год, задания нового изображения обложки.
* Продемонстрируйте работу методов объекта
* */

let task3Book = {
    // название книги
    title: "",

    // автор
    author: "",

    // год издания,
    published: 1990,

    // цена,
    price: 100,

    // изображение обложки
    cover: "",

    // увеличение года издания на 1 год
    incPublished: function() {
        // присваивание нового значения только если оно <= текущему году
        let newValue = this.published + 1;

        // !!! ВпередиПаровоза detected !!!
        if (newValue <= new Date().getFullYear())
            this.published = newValue;
    },

    // увеличение цены
    incPrice: function(value) {
        let newValue = value + this.price;

        // цену меняем, только если новое значение
        // в допустимом диапазоне значений, т.е. больше 0
        if (newValue > 0)
            this.price = newValue;
    },

    // задание нового изображения обложки
    // (просто задание, без проверок)
    setCover: function(value) {
      this.cover = `<img src='../images/task3/${value}' alt='Изображение обложки'/>`
    },

    // формирование строки с данными объекта для вывода в разметку
    toString: function(row) {
        return `<tr>
                <td>${row}</td>
                <td class="align-left">${this.title}</td>
                <td class="align-left">${this.author}</td>
                <td>${this.published}</td>
                <td>${this.price}</td>
                <td class="align-center">${this.cover}</td>
                </tr>`
    }
};

// демонстрация методов объекта
let row = 1
task3Book.author = 'К. Бейтс';
task3Book.title = 'Изучаем Java';
task3Book.published = 2018;
task3Book.price = 900;
task3Book.setCover('cover1.jpg');

document.write(`${task3Book.toString(row)}`);

row++;
task3Book.incPublished();
task3Book.incPrice(100);
task3Book.setCover('cover1.jpg');

document.write(`${task3Book.toString(row)}`);

row++;
task3Book.incPrice(-100);
task3Book.setCover('cover1.jpg');

document.write(`${task3Book.toString(row)}`);

row++;
task3Book.author = 'Васильев А.Н.';
task3Book.title = 'Программирование на JavaScript';
task3Book.published = 2019;
task3Book.price = 800;
task3Book.setCover('cover2.jpg');

document.write(`${task3Book.toString(row)}`);

row++;
task3Book.author = 'Радченко Н.А.';
task3Book.title = '1С: Предприятие. Практическое пособие разработчика';
task3Book.published = 2012;
task3Book.price = 1200;
task3Book.setCover('cover3.jpg');

document.write(`${task3Book.toString(row)}`);