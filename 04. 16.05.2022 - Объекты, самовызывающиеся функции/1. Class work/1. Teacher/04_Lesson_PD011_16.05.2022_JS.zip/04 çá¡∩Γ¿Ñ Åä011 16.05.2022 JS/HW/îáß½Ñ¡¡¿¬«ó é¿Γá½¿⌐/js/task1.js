/* Функции для решения первой задачи */


const minValue = -5, maxValue = 5, minElems = 8, maxElems = 15;

// Массив для работы
let arr = createIntArray(getRandomInt(minElems, maxElems), minValue, maxValue);

// Случайные числа для диапазона по условию
let a = getRandomInt(minValue, minValue + (maxValue - minValue) / 2);
let b = getRandomInt(minValue + (maxValue - minValue) / 2 + 1, maxValue);
// Проверка вхождения в диапазон
let inRangePredic = (item) => a <= item && item <= b;

function showArray(){
    renderArray(arr, "Массив для обработки:");
}

function point01(){
    // Индекс последнего отрицательного элемента
    let lastNegInd = arr.length - 1 - arr.slice().reverse().findIndex(el => el < 0);
    // Сумма элементов после последнего отрицательного
    let sum = arr.slice(lastNegInd + 1).reduce((acc, val) => acc + val, 0);

    renderArray(arr, "Последний отрицательный элемент выделен:",(item, index) => index === lastNegInd );
    document.write(`<div class="indented"><i>Сумма:&nbsp;&nbsp;</i>${sum}.</div>`);
}

function point02(){
    renderArray(arr, `Элементы со значением в диапазоне [${a},${b}]:`, inRangePredic);

    // Количество элементов по условию
    let count = arr.filter(inRangePredic).length;
    // Произведение элементов по условию
    let prod = count > 0 ? arr.reduce((acc, item) => inRangePredic(item) ? acc * item : acc, 1) : 'элементы отсутствуют'

    document.write(`<div class="indented"><i>Количество:&nbsp;&nbsp;</i>${count}.&nbsp;&nbsp;<i>Произведение:&nbsp;&nbsp;</i>${prod}.</div>`);
}

function point03(){
    // Модули отрицательных элементов возведены в куб
    let resultArr = arr.map(item => item < 0 ? Math.abs(item) ** 3 : item);
    renderArray(resultArr, `Обработанный массив:`);
}

function point04(){
    // Сортировка по условию
    let resultArr = arr.slice().sort(item => inRangePredic(item) ? -1 : 1);

    renderArray(resultArr, `Элементы со значением в диапазоне [${a},${b}] расположены впереди:`, inRangePredic);
}

function point05(){
    // Преобразование и сортировка по условию
    arr = arr.map(item => item > 0 ? (1 / item) : item);
    arr.sort((a,b) => Math.abs(b) - Math.abs(a));

    renderArray(arr, `Обработанный массив:`, null, 2);
}