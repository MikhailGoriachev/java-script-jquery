
function task4(){
    // Набор информации о погодных явлениях
    let climates = {
        cloudy: {
            description: 'Пасмурно',
            img: 'cloudy.svg'
        },
        partlyCloudy: {
            description: 'Облачно',
            img: 'partly-cloudy.svg'
        },
        fair: {
            description: 'Ясно',
            img: 'fair.svg'
        },
        thunder: {
            description: 'Гроза',
            img: 'thunder.svg'
        },
        heavyRain: {
            description: 'Сильный дождь',
            img: 'heavy-rain.svg'
        }
    };

    // Объект представляющий данные о погоде
    let weather = {
        temperature: 20,
        pressure: 739,
        humidity: 62,
        wind: {
            speed: 9,
            direction: 'W'
        },
        climate: climates.cloudy,

        setClimate: function(climate){
            this.climate = climate;
        },
        changeTemperature: function(delta){
            this.temperature += delta;
        },
        changeHumidity: function(delta){
            this.humidity += delta;
            if(this.humidity > 100) this.humidity = 100;
        },
        changePressure: function(delta){
            this.pressure += delta;
            if(this.pressure > 1200) this.pressure = 1200;
        },
        show: function(){
            document.write(`<div class="weather-block left"><img src='../images/weather/${this.climate.img}' alt ="pic" width="75" height="75"/>`);
            document.write(`<div>${this.climate.description}</div>`);
            document.write(`<div>Температура: ${this.temperature}°С</div>`);
            document.write(`<div>Давление: ${this.pressure} мм рт.ст.</div>`);
            document.write(`<div>Влажность: ${this.humidity}%</div>`);
            document.write(`<div>Ветер: ${this.wind.speed} м/с, ${this.wind.direction}</div></div>`);
        }
    }

    weather.show();

    weather.setClimate(climates.fair);
    weather.changeHumidity(-10);
    weather.changeTemperature(10)
    weather.changePressure(12);
    weather.show();

    weather.setClimate(climates.thunder);
    weather.changeTemperature(-5);
    weather.changeHumidity(10);
    weather.changePressure(-25);
    weather.show();

    weather.setClimate(climates.heavyRain);
    weather.changeHumidity(15);
    weather.changeTemperature(-3)
    weather.changePressure(80);
    weather.show();
}