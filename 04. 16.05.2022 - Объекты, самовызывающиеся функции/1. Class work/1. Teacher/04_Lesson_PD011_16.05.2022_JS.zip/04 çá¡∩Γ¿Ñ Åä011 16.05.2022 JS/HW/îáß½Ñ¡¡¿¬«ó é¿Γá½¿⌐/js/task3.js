
function task3(){
    let book = {
        title: '451° по Фаренгейту',
        author: 'Рэй Брэдбери',
        year: 1953,
        price: 250,
        cover: 'book-cover-1.jpg',

        increasePrice: function (delta) {
            if (delta > 0) this.price += delta;
        },
        incrementYear: function () { this.year++ },

        changeCover: function (newCover) { this.cover = newCover },

        show: function () {
            document.write(`<div class="text indented"><img src='../images/${this.cover}' alt="pic" width="100" height="150"/>`);
            document.write(`<div>Название: ${this.title}</div>`);
            document.write(`<div>Автор: ${this.author}</div>`);
            document.write(`<div>Год издания: ${this.year}</div>`);
            document.write(`<div>Цена: ${this.price}</div></div>`);
        }
    }


    document.write('<h2>Исходное состояние объекта:</h2>');
    book.show();

    book.increasePrice(50);
    document.write('<h2>Цена увеличена:</h2>');
    book.show();

    book.incrementYear();
    document.write('<h2>Год увеличен:</h2>');
    book.show();

    book.changeCover('book-cover-2.jpg')
    document.write('<h2>Обложка изменена:</h2>');
    book.show();

}

