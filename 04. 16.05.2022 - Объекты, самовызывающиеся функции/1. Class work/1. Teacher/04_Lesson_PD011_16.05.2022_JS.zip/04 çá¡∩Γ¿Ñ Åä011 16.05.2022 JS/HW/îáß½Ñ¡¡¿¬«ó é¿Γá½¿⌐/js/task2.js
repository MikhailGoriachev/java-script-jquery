/* Функции для решения второй задачи */

function point01(){
    let arr = createArray(getRandomInt(8, 15), -1, 1).map(x => +x.toFixed(1));
    renderArray(arr, "Сгенерированный массив:", null, 2);

    // Оставить только последние вхождения повторяющихся элементов
    arr = arr.filter((value, index, array) => array.lastIndexOf(value) === index)

    renderArray(arr, `Новый массив размерностью ${arr.length}:`, null, 1);
}

function point02(){
    // Разные массивы, т.к. на одних параметрах диапазона вещественных чисел
    // сложно продемонстрировать результат обоих пунктов заданий
    let arr = createArray(getRandomInt(8, 15), -10, 10).map(x => +x.toFixed(1));

    renderArray(arr, "Сгенерированный массив:", null, 2);

    let predic = item => item < 0 && (item & 1) === 1;

    //arr = arr.reduce((acc, item) => acc.concat(predic(item) ? Array(3).fill(item) : item), []);
    arr = arr.flatMap(item => predic(item) ? Array(3).fill(item) : item);

    renderArray(arr, "Отрицательные нечетные элементы утроены:", predic, 1);
}
