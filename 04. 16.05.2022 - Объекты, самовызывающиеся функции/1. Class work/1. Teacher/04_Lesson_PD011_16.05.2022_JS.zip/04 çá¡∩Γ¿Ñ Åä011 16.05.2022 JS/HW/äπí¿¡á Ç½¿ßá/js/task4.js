// Задача 4. Спроектировать объект для представления данных о погоде:
// температура, давление, влажность, скорость и направление ветра,
// графическое отображение атмосферных явлений (ясно, облачно, дождь, и т.д. – не более 5 видов явлений).
// Предусмотрите методы для задания вида явления, увеличения давления (максимальное значение давления 1200 гПа),
// вывода объекта в разметку, продемонстрируйте работу методов объекта
function task4(){
    let weather = {
        temperature: 20,           // температура
        pressure: 1013,            // давление
        humidity: 83,              // влажность
        wind: {
            speed: 4,              // скорость ветра
            direction: "Западный", // направление ветра
        },
        weatherImg: "sunny.gif",   // графическое отображение атмосферного явлений

        // вывод объекта
        show: function (title) {
            document.write(`<div style="float: left"><h3>${title}</h3>`);
            document.write(`<p><img src='../img/${this.weatherImg}' width='100'/><br>`);
            document.write(`<p>Температура: ${this.temperature}&#176;C<br>`);
            document.write(`Давление: ${this.pressure} гПа<br>`);
            document.write(`Влажность: ${this.humidity}%<br>`);
            document.write(`Скорость ветра: ${this.wind.speed} ми/ч<br>`);
            document.write(`Направление ветра: ${this.wind.direction}</p></div>`);
        },

        // смена изображения атмосферного явления
        changeWeatherImg: function (fileName) {
            this.weatherImg = fileName;
        },

        // увеличение давления
        incPressure: function (delta) {
            if(this.pressure + delta > 1200) return;
            this.pressure += delta;
        },
    } // weather

    // демонстрация методов
    weather.show("Исходный объект:");

    // смена изображения атмосферного явления
    weather.changeWeatherImg("rainy.gif");
    weather.show("Смена изображения:");

    weather.changeWeatherImg("storm.gif");
    weather.show("Смена изображения:");

    // увеличение давления
    weather.changeWeatherImg("cloudy.gif");
    let delta = 100;
    weather.incPressure(delta);
    weather.show(`Увеличение давления на ${delta} гПа`);
} // task4