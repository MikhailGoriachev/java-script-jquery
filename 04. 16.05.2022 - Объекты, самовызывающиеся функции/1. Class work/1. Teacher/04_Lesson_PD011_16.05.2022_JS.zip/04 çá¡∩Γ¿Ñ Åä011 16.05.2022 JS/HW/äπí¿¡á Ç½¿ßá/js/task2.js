// удалить из массива arr все одинаковые элементы, оставив их последние вхождения
function deleteElems(arr) {
    for (let i = 0; i < arr.length ; i++) {
        let count = 0;
        arr.forEach(x => count += x === arr[i]?1:0);
        if (count > 1) {
            arr.splice(i--, 1);
        } // if
    }  // for i
} // deleteElems

// утроить (т. е. Повторить трижды) все отрицательные нечетные элементы массива
function insertElems(arr) {
    for (let i = 0; i < arr.length ; i++) {
        if (arr[i] < 0 && (Math.trunc(arr[i]) & 1)) {
            arr.splice(i, 0, arr[i], arr[i]);
            i+=2;
        } // if
    }  // for i
} // deleteElems

function task2(){
    // создать массив заданного размера
    let arr = createArray(getIntRand(8, 13), -2, 2);
    arrayToTable("Исходный массив:", arr);

    // удалить из массива arr все одинаковые элементы, оставив их последние вхождения
    deleteElems(arr);
    arrayToTable(`Массив после удаления, его размер: ${arr.length}`, arr);

    // утроить (т. е. Повторить трижды) все отрицательные нечетные элементы массива
    insertElems(arr);
    arrayToTable("Все отрицательные нечетные элементы утроены:", arr);
} // task2