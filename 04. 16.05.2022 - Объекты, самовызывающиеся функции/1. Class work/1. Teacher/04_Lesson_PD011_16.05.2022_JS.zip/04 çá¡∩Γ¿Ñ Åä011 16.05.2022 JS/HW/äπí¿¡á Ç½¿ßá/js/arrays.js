// формирование массива случайных вещественных чисел
function createArray(n = 10, lo = -10, hi = 10) {
    let arr = [];
    for (let i = 0; i < n; i++) {
        let t = getRand(lo, hi);
        arr.push(Math.abs(t) < 0.6 ? 0 : t);
    } // for i
    return arr;
} // createArray

// формирование массива случайных целых чисел
function createIntArray(n = 10, lo = -10, hi = 10){
    let arr = [];
    for (let i = 0; i < n; i++)
        arr.push(getIntRand(lo, hi));
    return arr;
} // createIntArray

// вывод массива в таблицу
function arrayToTable(title, arr) {
    document.write(`<table>
                        <tr>
                            <th colspan="${arr.length}"> ${title}</th>
                        </tr>
                        <tr>
                            <td>${arr.join('</td><td>')}</td>
                        </tr>
                    </table>`);
} // arrayToTable

