// Задача 3. Спроектировать объект для представления данных о книге: название, автор,
// год издания, цена, изображение обложки. Предусмотрите методы для увеличения цены
// книги на заданное значение (не допускайте значений, меньше или равных нулю),
// увеличения года издания на 1 год, задания нового изображения обложки.
// Продемонстрируйте работу методов объекта
function task3(){
    let book = {
        title: "Преступление и наказание",   // название
        author: "Достоевский Ф.М.",          // автор
        year: 2000,                          // год издания
        price: 1200,                         // цена
        coverImg: "CrimeAndPunishment1.jpg", // изображение обложки

        // вывод объекта
        show: function (title) {
            document.write(`<div style="float: left"><h3>${title}</h3>`);
            document.write(`<p><img src='../img/${this.coverImg}' width='100'/><br>`);
            document.write(`<p>Название: "${this.title}"<br>`);
            document.write(`Автор: ${this.author}<br>`);
            document.write(`Год издания: ${this.year}<br>`);
            document.write(`Цена: ${this.price}</p></div>`);
        },

        // смена изображения обложки
        changeCoverImg: function (fileName) {
            this.coverImg = fileName;
        },

        // увеличение цены
        incPrice: function (delta) {
            if(this.price + delta <= 0) return;
            this.price += delta;
        },

        // увеличение года издания на 1 год
        incYear: function () {
            this.year++;
        },
    } // book

    // демонстрация методов
    book.show("Исходный объект:");

    // увеличение цены
    let delta = 120;
    book.incPrice(delta);
    book.show(`Увеличение цены на ${delta}`);

    // увеличение года издания на 1 год
    book.incYear();
    book.show("Увеличение года издания на 1 год:");

    // смена изображения обложки
    book.changeCoverImg("CrimeAndPunishment2.jpeg");
    book.show("Смена изображения обложки:");
} // task3