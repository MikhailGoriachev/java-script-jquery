//Задача 2. Сформировать массив размера N вещественных чисел(и размер и значения) при каждой загрузке страницы.  
//  •	Удалить из массива все одинаковые элементы, оставив их последние вхождения, 
//      вывести размер полученного массива и его элементы. 
//  •	Утроить(т.е.Повторить трижды) все отрицательные нечетные элементы массива. 



function task2() {
    //создание массива
    let array = createArrDbl(randomInt(10, 15), -10, 10);
    //на массиве целых лучше видна реализация первого пункта
    //let array = createArrInt(randomInt(10, 20), -10, 10);
    let lo = randomInt(-10, -1), hi = randomInt(1, 10);
    showArrDblWithLength(array);

    //первый пункт
    pageWriteLn('Удалить из массива все одинаковые элементы, оставив их последние вхождения, вывести размер полученного массива и его элементы.');
    array = uniqueLastOccurrence(array);
    showArrDblWithLength(array);

    //второй пункт
    pageWriteLn('Утроить(т.е.Повторить трижды) все отрицательные нечетные элементы массива.');
    array = tripleNegative(array);
    showArrDblWithLength(array);
}

//вывод на страницу
function pageWriteLn(str) {
    document.writeln(`<p>${str}</p>`);
}

//удаление дупликатов
function uniqueLastOccurrence(arr) {
    return arr.filter((v, i, a) => a.lastIndexOf(v) === i);
}

//утраиваем в массиве негативные элементы
function tripleNegative(arr) {
    let temp = [];

    arr.forEach(x => x < 0 ? temp.push(x, x, x) : temp.push(x));

    return temp;
}