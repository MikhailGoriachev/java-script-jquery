// Задача 4. Спроектировать объект для представления данных о погоде: температура, давление,
// влажность, скорость и направление ветра, графическое отображение атмосферных явлений(ясно,
// облачно, дождь, и т.д. – не более 5 видов явлений).Предусмотрите методы для задания вида 
// явления, увеличения давления(максимальное значение давления 1200 гПа), вывода объекта в 
// разметку, продемонстрируйте работу методов объекта 


function task4() {
    //создаем объект типа погода
    let weather = createWeather();

    //выводим на страницу
    weather.show();

    pageWriteLn('Меняем вид явления, увеличиваем давление 200.')
    weather.setView('../imgs/weather/sunny.svg');
    weather.pressureUp(200);

    weather.show();
}

//вывод на страницу
function pageWriteLn(str) {
    document.writeln(`<p>${str}</p>`);
}

//генерация объекта погода
function createWeather() {
    return {
        temperature: 15,
        pressure: 750,
        humidity: 10,
        wind: 'З 10ми/ч',
        view: '../imgs/weather/rain.svg',

        //вывод на сайт информации о погоде
        show() {
            document.writeln(`<div class="centre"><img class="cover" src="${this.view}"><img>`);
            document.writeln(`<p><b>Температура:</b> ${this.temperature}</p>`);
            document.writeln(`<p><b>Давление:</b> ${this.pressure}</p>`);
            document.writeln(`<p><b>Влажность:</b> ${this.humidity}</p>`);
            document.writeln(`<p><b>Ветер:</b> ${this.wind}</p></div>`);
        },

        //повышение давления
        pressureUp(value) {
            if (value > 0)
                this.pressure += value
        },

        //задать вид погоды
        setView(path) {
            this.view = path;
        },
    };
}