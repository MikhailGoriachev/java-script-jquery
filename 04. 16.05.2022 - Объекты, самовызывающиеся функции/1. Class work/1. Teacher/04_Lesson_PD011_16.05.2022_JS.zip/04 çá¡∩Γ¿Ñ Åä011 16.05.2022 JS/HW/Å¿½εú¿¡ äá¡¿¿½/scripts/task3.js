// Задача 3. Спроектировать объект для представления данных о книге: название, автор, 
// год издания, цена, изображение обложки.Предусмотрите методы для увеличения цены книги 
// на заданное значение(не допускайте значений, меньше или равных нулю), увеличения года 
// издания на 1 год, задания нового изображения обложки.Продемонстрируйте работу методов объекта   


function task3() {
    //создаем объект типа книга
    let book = createBook();

    //выводим на страницу
    book.show();

    pageWriteLn('Меняем обложку, повышаем стоимость на 200, увеличиваем год издания.')
    book.setCover('../imgs/covers/cover2.gif');
    book.releaseUp();
    book.costUp(200);

    book.show();
}

//вывод на страницу
function pageWriteLn(str) {
    document.writeln(`<p>${str}</p>`);
}

//генерация книги
function createBook() {
    return {
        name: 'Сёгун',
        author: 'Джеймс Клавелл',
        release: 1975,
        cost: 2000,
        cover: '../imgs/covers/cover1.jpg',

        //вывод на сайт информации о книге
        show() {
            document.writeln(`<div class="centre"><img class="cover" src="${this.cover}"><img>`);
            document.writeln(`<p><b>Название:</b> ${this.name}</p>`);
            document.writeln(`<p><b>Автор:</b> ${this.author}</p>`);
            document.writeln(`<p><b>Год издания:</b> ${this.release}</p>`);
            document.writeln(`<p><b>Стоимость:</b> ${this.cost}</p></div>`);
        },

        //повышение цены
        costUp(value) {
            if (value > 0)
                this.cost += value
        },

        //увеличение года издания на 1 год
        releaseUp() {
            this.release++;
        },

        //задать обложку книги
        setCover(path) {
            this.cover = path;
        },
    };
}