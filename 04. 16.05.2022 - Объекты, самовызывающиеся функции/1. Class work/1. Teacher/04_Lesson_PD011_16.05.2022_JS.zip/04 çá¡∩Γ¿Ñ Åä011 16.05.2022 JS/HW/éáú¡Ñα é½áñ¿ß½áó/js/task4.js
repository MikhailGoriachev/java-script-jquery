//Создать представление о погоде
let weatherView = getViewWeather();
weatherView.increase = undefined;

//Вывод объекта
weatherView.show = function () {
    document.write(`
        <table>
            <tr>
                <th>Автмосферное явление</th>
                <th colspan="2">Характеристика</th>
            </tr>
            
            <tr>
                <td rowspan="5" class="weather-type-icon">
                    <img src="../images/weather/${this.typeIcon}" width="150px">
                </td>
            </tr>
            
            <tr>
                <td class="field-names">Температура</td>
                <td><span>${this.temperature}</span></td>
            </tr>
            <tr>
                <td class="field-names">Давление</td>
                <td><span>${this.pressure} гПа.</span></td>
            </tr>
            <tr>
                <td class="field-names">Влажность</td>
                <td><span>${this.humidity}%</span></td>
            </tr>
            <tr>
                <td class="field-names">Ветер</td>
                <td><span>Направление: ${this.windObj.direction}</span>
                <br><span>Скорость: ${this.windObj.speed} м/с.</span>
                </td>
            </tr>
        </table>
    `)
};

//Изменение вида явления
weatherView.changeType = function (newIcon) {
    if (newIcon == undefined)
        return;
    this.typeIcon = newIcon;
}

//Увеличение давления
weatherView.increasePressure = function(delta){
    if (this.pressure+delta>1200 || delta<=0)
        return;
    this.pressure += delta;
}

//Изменение температуры
weatherView.changeTemperature = function (value) {
    if (value < -70 || value > 60 || value == undefined)
        return;
    this.temperature = value;
}

function task() {
    weatherView.show();
    let increament = getRandom(10,150);
    weatherView.changeType("lightning.png");
    weatherView.increasePressure(increament);
    weatherView.changeTemperature(getRandom(27,32))

    document.write(`<p>Запись после изменения атм. явления на грозу и повишения давления на ${increament} гПа.</p>`)

    weatherView.show();
}