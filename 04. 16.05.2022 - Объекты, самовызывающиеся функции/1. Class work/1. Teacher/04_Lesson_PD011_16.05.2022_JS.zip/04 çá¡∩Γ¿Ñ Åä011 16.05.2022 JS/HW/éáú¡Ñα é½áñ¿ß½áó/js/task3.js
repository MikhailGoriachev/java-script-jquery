
//Создать объект
let book = getBook();

//Вывод объекта
book.show = function () {
    document.write(`
        <table>
            <tr>
                <th>Обложка</th>
                <th colspan="2">Описание</th>
            </tr>
            
            <tr>
                <td rowspan="5" class="cell-with-cover">
                    <img src="../images/book-covers/${this.coverFile}" width="150px">
                </td>
            </tr>
            
            <tr>
                <td class="field-names">Название</td>
                <td><span>${this.name}</span></td>
            </tr>
            <tr>
                <td class="field-names">Год издания</td>
                <td><span>${this.year}</span></td>
            </tr>
            <tr>
                <td class="field-names">Автор</td>
                <td><span>${this.author}</span></td>
            </tr>
            <tr>
                <td class="field-names">Стоимость</td>
                <td><span>${this.price} руб.</span></td>
            </tr>
        </table>
    `)
};

//Увеличение цены
book.increasePrice = function (increment) {
    if (increment <= 0)
        return;

    this.price += increment;
}

//Увеличение года издания
book.changePubYear = function (year = 1) {
    if (year <= 0)
        return;
    this.year += year;
}

//Изменение обложки
book.changeCover = function (newPath) {
    if (newPath == undefined)
        return;
    this.coverFile = newPath;
}

function task() {
    book.show();

    let newPrice = getRandom(50,300);
    //Методы для обработки по заданию
    book.increasePrice(newPrice);
    book.changePubYear();
    book.changeCover(getBook().coverFile);


    document.write(`<p>Изменённая запись: увеличена цена на ${newPrice} руб,год написания и заменена обложка</p>`)
    //вывод
    book.show();

}