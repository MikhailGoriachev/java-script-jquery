let arr = generateArray(12,20,-20);

/*Удалить из массива все одинаковые элементы,
оставив их последние вхождения, вывести размер
полученного массива и его элементы.*/

//region Пункт 1
function subTask1() {

    let duplicatedElems = new Array();

    //Запись повторяющихся значений в отдельный массив, для последующего визуального выделения
    for (let elem of arr) {
        if (distinctElemEntries(arr,elem)>1)
            duplicatedElems.push(elem);
    }

    //Вывод строк таблицы
    document.write(`
     <tr>
        <th rowspan="4" class="info-cell">Реализация</th>
    </tr>
    <tr>
        <td class="content-cell">
            Массив до:
            <table>
                <tr>
                    ${toTableRowHighlight(arr,x => duplicatedElems.findIndex(e => e === x)>=0)}
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td class="content-cell">
            Массив после:
            <table>
                <tr>
                    ${toTableRowHighlight(findDuplicated(arr),x => duplicatedElems.findIndex(e => e === x)>=0)}
                </tr>
            </table>
        </td>
    </tr>
    `);

}

//Поиск повторяющихся элементов и создание объекта
function findDuplicated(array) {

    for (let i = 0,counter = 0; i < array.length; i++) {
        let elem = array[i];
        counter = distinctElemEntries(array,elem);
        if (counter>1)
            delDuplicated(array,elem,counter)
    }

    return array;
}

//Поиск количества вхождений
function distinctElemEntries(array,elem) {
    let counter = 0;

    for (let e of array) {
        if (e === elem)
            counter++;
    }

    return counter;
}

//Удаление повторяющихся элементов
function delDuplicated(array,element,count) {
    //Удаление до предпоследнего элемента
    for (let i = 0,ind = -1; i < count-1; i++) {
        ind = array.findIndex(x => x === element);

        if (ind>=0)
            array.splice(ind,1)
    }
}
//endregion

/*Утроить (т. е. Повторить трижды) все отрицательные
нечетные элементы массива.*/

//region Пункт 2
function subTask2() {

    let matchingElements = findOddNegative(arr);

    //Вывод строк таблицы
    document.write(`
     <tr>
        <th rowspan="4" class="info-cell">Реализация</th>
    </tr>
    <tr>
        <td class="content-cell">
            Массив до:
            <table>
                <tr>
                    ${toTableRowHighlight(arr,x => matchingElements.findIndex(e => e === x)>=0)}
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td class="content-cell">
            Массив после:
            <table>
                <tr>
                    ${toTableRowHighlight(treble(arr,matchingElements),x => matchingElements.findIndex(e => e === x)>=0)}
                </tr>
            </table>
        </td>
    </tr>
    `);
}//subtask2

//утраиваем элементы через splice и идём с конца массива

//Поиск нужных элементов
function findOddNegative(arr) {
    let foundElements = new Array();

    for (let elem of arr) {
        if (elem<0 && Math.abs(elem)%2!=0)
            foundElements.push(elem);
    }

    return foundElements;
}

//Обработка по заданию
function treble(array,foundElements) {

    for (let i = array.length-1; i >= 0; i--) {
        let currItem = array[i];

        console.log(`Массив на итерации: ${array}\r\n Текущий элемент: ${currItem}`)

        //Если элемент соответствующий условию существует
        if (foundElements.findIndex(x => x === currItem)>=0)
            array.splice(i,0,currItem,currItem)

    }

    return array;

}
//endregion