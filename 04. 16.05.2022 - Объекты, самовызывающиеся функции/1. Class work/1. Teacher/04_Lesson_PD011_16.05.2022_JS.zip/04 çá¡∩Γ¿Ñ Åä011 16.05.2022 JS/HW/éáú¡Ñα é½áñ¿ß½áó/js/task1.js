let arr = generateArray(10);

/*Вычислить сумму элементов массива, расположенных
после последнего отрицательного элемента */

//region Пункт 1
function subTask1() {
    
    let lastInd = getLatNegativeInd(arr);
    document.write(`
     <tr>
        <th rowspan="4" class="info-cell">Реализация</th>
    </tr>
    <tr>
        <td class="content-cell">
            <table>
                <tr>
                    ${toTableRowHighlight(arr,e => e === arr[lastInd])}
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td class="content-cell">Индекс последнего отрицательно элемента: ${lastInd}</td>
    </tr>
    <tr>
        <td class="content-cell">Сумма после последнего отрицательного: 
        ${getSumAfterInd(arr,lastInd)}</td>
    </tr>
    `);

}

//Поиск суммы
function getSumAfterInd(arr,index) {
    //Подмассив идущий после последнего отрицательного
    let ExtractedArr = arr.slice(index+1,arr.length);

    //Если подмассив состоит из одного элемента: возвращаем этот элемент
    if (ExtractedArr.length == 1 && ExtractedArr[0]>=0)
        return ExtractedArr[0];

    //Поиск суммы
    let sum = ExtractedArr.reduce((acc,elem,) => acc+elem,0);

    return sum>0?sum:`<span>Отрицательный элемент последний</span>`;
}

/*Получение индекса последнего отрицательного элемента*/
function getLatNegativeInd(arr) {

    let index = 0;

    for (let ind in arr) {
        if (arr[ind] < 0)
            index = parseInt(ind);
    }

    return index;
}
//endregion

/*Вычислить количество элементов массива,
имеющих значение из диапазона [a, b] и их произведение*/

//region Пункт 2
function subTask2() {

    let a = getRandom(5,15);
    let b = getRandom(15,70);

    document.write(`
     <tr>
        <th rowspan="4" class="info-cell">Реализация</th>
    </tr>
    <tr>
        <td class="content-cell">
            <table>
                <tr>
                    ${toTableRowHighlight(arr,(e) => e >= a && e <= b)}
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td class="content-cell">Количество элементов в диапазоне <span>[${a},${b}]</span>: 
        ${getSumIf(arr,(x) => x >= a && x <= b)}</td>
    </tr>
    `);
}//subTask2

function getSumIf(arr,predicate) {

    if (arr.length <= 0)
        return `<span>Задан некорректный массив</span>`;
    return arr.filter(elem => predicate(elem)).length;
}
//endregion

/*
Каждый отрицательный элемент массива заменить корнем
кубическим его абсолютного значения
 */

//region Пункт 3
function subTask3() {

    //Массив заменённых значений для граф. выделения
    let changedElems = arr.filter(e => e<0).map(x => Math.cbrt(Math.abs(x)));

    //Вывод строк таблицы
    document.write(`
     <tr>
        <th rowspan="4" class="info-cell">Реализация</th>
    </tr>
    <tr>
        <td class="content-cell">
            Массив до:
            <table>
                <tr>
                    ${toTableRowHighlight(arr,x => x<0)}
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td class="content-cell">
            Массив после:
            <table>
                <tr>
                    ${highlightReplaced(replaceNegative(arr), n => changedElems.findIndex(e => e === n)>=0)}
                </tr>
            </table>
        </td>
    </tr>
    `);
}//subTask3

//Обработка
function replaceNegative(arr) {
    return arr.map(elem => elem<0?Math.cbrt(Math.abs(elem)):elem)

}

//endregion

//Выделение изменённых элементов
function highlightReplaced(arr,predicate){
    return arr.reduce((accumulate,elem) => accumulate + (predicate(elem)?`<td class="highlightElems"><span>${elem.toFixed(2)}</span></td>`:`<td>${elem.toFixed(0)}</td>`),'')
}

/*
Преобразовать массив таким образом,
чтобы в нем сначала располагались элементы, имеющих значение из диапазона [a, b],
а потом — все остальные
*/

//region Пункт 4
function subTask4() {

    let a = getRandom(5,15);
    let b = getRandom(15,70);

    //Предикат проверки вхождения в диапазон
    let predicate = (x) => x >= a && x <= b;

    //Вывод строк таблицы
    document.write(`
     <tr>
        <th rowspan="4" class="info-cell">Реализация</th>
    </tr>
    <tr>
        <td class="content-cell">
          Диапазон значений: от ${a} до ${b}
        </td>
    </tr>
    <tr>
        <td class="content-cell">
            Массив до
            <table>
                <tr>
                    ${toTableRowHighlight(arr,predicate)}
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td class="content-cell">
            Массив после:
            <table>
                <tr>
                    ${toTableRowHighlight(sortArray(arr,predicate),predicate)}
                </tr>
            </table>
        </td>
    </tr>
    `);
}//subTask4

function sortArray(arr,condition) {

    for (let x of arr) {
        console.log(condition(x))
    }
    //Сортировка по предикату.
    return arr.sort((e1,e2)=>condition(e1)&&!condition(e2)?-1:0);
}
//endregion

/*
Каждый элемент массива, больший нуля заменить его обратным значением (1/x),
упорядочить преобразованный массив по убыванию абсолютных значений.
*/

//region Пункт 5
function subTask5() {

    let predicate = (x) => x>0;

    //Вывод строк таблицы
    document.write(`
     <tr>
        <th rowspan="4" class="info-cell">Реализация</th>
    </tr>
    <tr>
        <td class="content-cell">
            Массив до:
            <table>
                <tr>
                    ${toTableRowHighlight(arr,predicate)}
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td class="content-cell">
            Массив после:
            <table>
                <tr>
                    ${highlightReplaced(subTask5Handling(arr,predicate),x => x>0)}
                </tr>
            </table>
        </td>
    </tr>
    `);
}//subTask5

/*Обработка по подзадаче*/
function subTask5Handling(arr,predicate) {

    if (arr.length <= 0)
        return `<span>Задан некорректный массив</span>`;

    let tempArr = arr;

    //Замена значений и сортировка
    return tempArr.map(elem => predicate(elem)?1/elem:elem).sort((n1,n2) => Math.abs(n2)-Math.abs(n1));

}
//endregion