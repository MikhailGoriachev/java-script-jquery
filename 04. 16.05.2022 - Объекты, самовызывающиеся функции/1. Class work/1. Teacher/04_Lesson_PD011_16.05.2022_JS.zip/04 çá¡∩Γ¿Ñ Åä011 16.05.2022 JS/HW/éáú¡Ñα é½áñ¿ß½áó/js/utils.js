
//Создание массива
function generateArray(n,hi = 60,lo = -20) {
    let arr = [];

    //Элементарное заполнение массива
    for (let i = 0;i<n;i++) {
        arr[i] = getRandom(lo,hi);
    }

    return arr;
}

//Вывод массива в ячейки
function toTableRow(arr){
    return arr.reduce((accumulate,elem) => accumulate+`<td>${elem.toFixed(0)}</td>`,'')
}
//Вывод массива в ячейки с выделением определённых элементов
function toTableRowHighlight(arr,predicate){
    return arr.reduce((accumulate,elem) => accumulate + (predicate(elem)?`<td class="highlightElems"><span>${elem}</span></td>`:`<td>${elem}</td>`),'')
}

//Получение случайного значения
function getRandom(lo,hi) {
    return Math.trunc((hi-lo) * Math.random() + lo);
}

//region Задача 3

function getBook() {

    let book1 = {
            name: "Алгоритмы на Java",
            author: "Роберт Седжвик",
            coverFile: "book1.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book2 = {
            name: "Rapid Development",
            author: "Steve McConnell",
            coverFile: "book2.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book3 = {
            name: "Предметно-ориентированное проектирование (DDD)",
            author: "Эрик Эванс",
            coverFile: "book3.jpg",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book4 = {
            name: "Искусство программирования",
            author: "Дональд Кнут",
            coverFile: "book4.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book5 = {
            name: "Жемчужины программирования",
            author: "Джон Бентли",
            coverFile: "book5.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book6 = {
            name: "Алгоритмы. Построение и анализ",
            author: "Томас Х. Кормен",
            coverFile: "book6.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        }

    let books = [book1,book2,book3,book4,book5,book6];

    return books[getRandom(0,books.length)];

}//getBook

function getCoverFile() {
    let files = [

    ];

    return files[getRandom(0,files.length)]
}

//Сгенерировать название книги
function getBookName() {
    let names = [

    ];

    return names[getRandom(0,names.length)]
}
//Сгенерировать автора книги
function getBookName() {
    let authors = [

    ];

    return authors[getRandom(0,authors.length)]
}

function getBookPrice()
{
    return getRandom(500,2200);
}

//Год издания
function getBookPubYear()
{
    return getRandom(1980,2022);
}


//endregion

//region Задача 4

//Сформировать объект представления о погоде
function getViewWeather() {
    let rainfall1 = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
    },
        sunny = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
        typeIcon: "sunny.png"
    },
        partlyCloudy = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
        typeIcon: "partly-cloudy.png"
    },
        rainfall2 = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
    },
        cloudy = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
        typeIcon: "clouds.png"
    }

    //Отображение атмосферного явления задаётся таким образом, поскольку
    //создание в блоке инициализации давало некорректный результат по температуре
    rainfall1.typeIcon = rainfall1.temperature<=0?"snow.png":"rainy.png";
    rainfall2.typeIcon = rainfall2.temperature<=0?"snow.png":rainfall2.temperature>=27?"lightning.png":"rainy.png";

    //Сформировать массив
    let weather = [rainfall2,rainfall1,sunny,cloudy,partlyCloudy];

    return weather[getRandom(0,weather.length)];
}

function generateTemperature() {
    return getRandom(-15,30);
}
function generatePressure() {
    return getRandom(700,1050);
}
function generateHumidity() {
    return getRandom(10,99);
}

//Функция возвращает объект
function generateWind() {

    //Направления ветра
    let windDirections = [
        "северный",
        "северо-восточный",
        "восточный",
        "юго-восточный",
        "южный",
        "юго-западный",
        "западный",
        "северо-западный"
    ];

    return {
        direction: windDirections[getRandom(0, windDirections.length)],
        speed: getRandom(0, 60)
    };
}//generateWind

//endregion