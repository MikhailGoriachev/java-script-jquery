/*
* Задача 3.
* Спроектировать объект для представления данных о книге: название, автор,
* год издания, цена, изображение обложки.
* Предусмотрите методы для увеличения цены книги на заданное значение
* (не допускайте значений, меньше или равных нулю), увеличения года издания
* на 1 год, задания нового изображения обложки.
* Продемонстрируйте работу методов объекта
* */

const task1Book = (function () {

    // инкапсулированный объект для описания книги
    let book = {

        // автор
        author: "",

        // название книги
        title: "",

        // год издания,
        published: 1990,

        // цена,
        price: 100,

        // изображение обложки
        cover: "",
    };

    return {
        // "геттеры" и "сеттеры"
        getTitle: () => book.title,
        setTitle: value => book.title = value,

        getAuthor: () => book.author,
        setAuthor: value => book.author = value,

        getPublished: () => book.published,
        setPublished: value => book.published = value,

        getPrice: () => book.price,
        setPrice: value => book.price = value,

        getCover: () => book.cover,
        setCover: value => book.cover = `<img src='../images/task1/${value}' alt='Изображение обложки' height="128"/>`,

        // задание всех полей объекта
        setup: function(author, title, published, price, cover) {
            this.setTitle(title);
            this.setAuthor(author);
            this.setPublished(published);
            this.setPrice(price);
            this.setCover(cover);
        },

        // увеличение года издания на 1 год
        incPublished: function () {
            // присваивание нового значения только если оно <= текущему году
            let newValue = book.published + 1;

            // !!! ВпередиПаровоза detected !!!
            if (newValue <= new Date().getFullYear())
                book.published = newValue;
        },

        // увеличение цены
        incPrice: function (value) {
            let newValue = value + book.price;

            // цену меняем, только если новое значение
            // в допустимом диапазоне значений, т.е. больше 0
            if (newValue > 0)
                book.price = newValue;
        },

        // формирование строки с данными объекта для вывода в разметку
        toString: function (row) {
            return `<tr>
                <td>${row}</td>
                <td class="align-left">${book.author}</td>
                <td class="align-left">${book.title}</td>
                <td>${book.published}</td>
                <td>${book.price}</td>
                <td class="align-center">${book.cover}</td>
                </tr>`
        }
    }
})();


// самовызывающаяся функция для демонстрации методов объекта
(function () {
    let row = 1
    task1Book.setup('К. Бейтс', 'Изучаем Java', 2018, 900, 'cover1.jpg');
    document.write(`${task1Book.toString(row)}`);

    row++;
    task1Book.incPublished();
    task1Book.incPrice(100);
    task1Book.setCover('cover1.jpg');

    document.write(`${task1Book.toString(row)}`);

    row++;
    task1Book.incPrice(-100);
    task1Book.setCover('cover1.jpg');
    document.write(`${task1Book.toString(row)}`);

    row++;
    task1Book.setup('Васильев А.Н.', 'Программирование на JavaScript', 2019, 800, 'cover2.jpg');
    document.write(`${task1Book.toString(row)}`);

// все сеттеры
    row++;
    task1Book.setAuthor('Радченко Н.А.');
    task1Book.setTitle('1С: Предприятие. Практическое пособие разработчика');
    task1Book.setPublished(2012);
    task1Book.setPrice(1200);
    task1Book.setCover('cover3.jpg');

    document.write(`${task1Book.toString(row)}`);
})();