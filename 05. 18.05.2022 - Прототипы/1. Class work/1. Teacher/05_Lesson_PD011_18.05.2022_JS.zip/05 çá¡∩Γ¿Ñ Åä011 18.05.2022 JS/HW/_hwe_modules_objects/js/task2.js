/*
* Задача 4.
* Спроектировать объект для представления данных о погоде: температура,
* давление, влажность, скорость и направление ветра, графическое отображение
* атмосферных явлений (ясно, облачно, дождь, и т.д. – не более 5 видов явлений).
* Предусмотрите методы для задания вида явления, увеличения давления (максимальное
* значение давления 1200 гПа), вывода объекта в разметку, продемонстрируйте
* работу методов объекта
*  */

const task2Weather = (function(){
    let weather = {
        // атмосферные явления (ясно, облачно, дождь, и т.д. – не более 5)
        meteor: {
            name: "",  // название явления
            img: ""    // графическое отображение
        },

        // температура
        temperature: 0,

        // давление,
        pressure: 0,

        // влажность,
        humidity: 0,

        // скорость и направление ветра,
        wind: {speed: 0, direction: ""},
    };

    return {
        // задание атмосферного явления
        getMeteor: () => weather.meteor,
        setMeteor: (name, img) => {
            weather.meteor.name = name;
            weather.meteor.img = `<img src='../images/task2/${img}' alt='Погодное явление' height="64"/>`;
            console.log(weather.meteor);
        },

        // доступ к температуре
        getTemperature: () => weather.temperature,
        setTemperature: value => weather.temperature = value,

        // доступ к давлению
        getPressure: () => weather.pressure,
        setPressure: value => weather.pressure = value,

        // увеличение давления
        incPressure: function(value) {
            let newValue = value + weather.pressure;

            // давление меняем, только если новое значение
            // в допустимом диапазоне значений [0, 1200]
            if (0 <= newValue && newValue <= 1200)
                weather.pressure = newValue;
        },

        // доступ к влажности
        getHumidity: () => weather.humidity,
        setHumidity: (value) => weather.humidity = value,

        // доступ к параметрам ветра
        getWind: () => weather.wind,
        setWind: (direction, speed) => {
            weather.wind.direction = direction;
            weather.wind.speed = speed;
        },

        // задание всех полей объекта
        setup: function(name, img, temperature, pressure, humidity, direction, speed) {
            this.setMeteor(name, img);
            this.setTemperature(temperature);
            this.setPressure(pressure);
            this.setHumidity(humidity);
            this.setWind(speed, direction);
        },

        // формирование строки с данными объекта для вывода в разметку
        toString: function(row) {
            return `
                <tr>
                    <td>${row}</td>
                    <td class="align-center">${weather.meteor.img}<br/>${weather.meteor.name}</td>
                    <td>${weather.temperature}</td>
                    <td>${weather.pressure}</td>
                    <td class="align-center">${weather.wind.direction}</td>
                    <td>${weather.wind.speed}</td>
                    <td>${weather.humidity}</td>
                </tr>`;
        }
    };
})();


// самовызывающаяся функция для выполнения задачи 2
(function() {
    let row = 1;

    // работа установщика всех полей :)
    task2Weather.setup("ясно", "sunny.png", 35, 1012, 36, 'Ю-З', 3);
    document.write(`${task2Weather.toString(row)}`);

    // демонстрация методов - "сеттеров", метода-модификатора
    row++;
    task2Weather.setMeteor("облачно", "cloudly.png");
    task2Weather.setTemperature(22);
    task2Weather.setHumidity(85);
    task2Weather.setWind('С-З', 5);

    // изменяем давление методом-мутатором
    task2Weather.incPressure(100);
    document.write(`${task2Weather.toString(row)}`);

    // еще пример использования методов модуля
    row++;
    task2Weather.setMeteor("дождь", "rain.png");
    task2Weather.setTemperature(21);
    task2Weather.setWind('Ю-В', 12);
    task2Weather.setHumidity(100);

    // изменяем давление методом-мутатором
    task2Weather.incPressure(-150);
    document.write(`${task2Weather.toString(row)}`);

    // и еще один пример
    row++;
    task2Weather.setup("гроза", "thunderstom.png", 28, 1000, 98, 'С-В', 15);

    // изменяем давление методом-мутатором
    task2Weather.incPressure(115);
    document.write(`${task2Weather.toString(row)}`);

    row++;
    task2Weather.setup("снег", "snow.png", -5, 1100, 80, 'С', 12);

    task2Weather.incPressure(-50);
    document.write(`${task2Weather.toString(row)}`);
})();