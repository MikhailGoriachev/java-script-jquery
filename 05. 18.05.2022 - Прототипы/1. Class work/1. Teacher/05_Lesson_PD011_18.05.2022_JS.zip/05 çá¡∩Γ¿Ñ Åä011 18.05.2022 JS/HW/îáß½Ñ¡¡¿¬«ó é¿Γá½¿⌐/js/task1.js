
const book = (function(){

    let book = {
        title: "",
        author: "",
        cover: "",
        year: 0,
        price: 0,
        amount: 0,
    };

    return {
        getTitle:  function() { return book.title;  },
        getAuthor: function() { return book.author; },
        getCover:  function() { return book.cover;  },
        getYear:   function() { return book.year;   },
        getPrice:  function() { return book.price;  },
        getAmount: function() { return book.amount; },

        setTitle:  function(title)   { book.title = title; },
        setAuthor:  function(author) { book.author = author; },
        setCover:  function(cover)   { book.cover = cover; },
        setYear:   function(year) {
            if(year <= new Date().getFullYear())
                book.year  = year;
            },
        setPrice:  function(price) {
            if(price > 0)
                book.price = price;
            },
        setAmount: function(amount) { book.amount = amount; },

        modifyPrice: function (delta) {
            let newValue = book.price + delta;
            if(newValue > 0) book.price = newValue;
        },

        modifyAmount: function (delta) {
            let newValue = book.amount + delta;
            if(newValue >= 0) book.amount = newValue;
        },

        toHtml: function () {
            return `<div class="indented"><img src='../images/${book.cover}' alt="pic" width="170" height="250"/>
                    <div>Название: ${book.title}</div>
                    <div>Автор: ${book.author}</div>
                    <div>Год издания: ${book.year}</div>
                    <div>Цена: ${book.price}</div>
                    <div>Количество: ${book.amount}</div></div>`;
        },

        render: function(){
            document.write(this.toHtml());
        }
    }
})();


(function task1(){
    book.setTitle('451° по Фаренгейту');
    book.setAuthor('Рэй Брэдбери');
    book.setCover('book-cover-1.jpg');
    book.setYear(1953);
    book.setPrice(250);
    book.setAmount(12);

    book.render();

    book.setCover('book-cover-2.jpg');
    book.modifyAmount(10);
    book.modifyPrice(-50)

    book.render();
})();


