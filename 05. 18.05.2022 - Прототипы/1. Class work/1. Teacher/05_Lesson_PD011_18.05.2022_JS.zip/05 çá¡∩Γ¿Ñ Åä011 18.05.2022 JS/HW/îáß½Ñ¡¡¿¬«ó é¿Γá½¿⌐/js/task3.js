

const task3Module = (function () {

    let sourceString, pointAstr0, pointBstr1, pointBstr2;

    // Удалить последнее вхождение подстроки
    let removeLastOccur = (str, subStr) => {
        let ind = str.lastIndexOf(subStr);
        return str.substring(0, ind) + str.substring(ind + subStr.length);
    };
    // Заменить в каждом слове все последующие вхождения первой буквы
    let replaceAllButFirst = (str, value) => str.split(' ')
        .map(word => word[0] + word.substring(1).replaceAll(word[0], value))
        .join(' ');
    // Обратить порядок букв в словах
    let reverseWordsLetters = (str) => str.split(' ')
        .map(word => word.split('').reverse().join(''))
        .join(' ');
    // Обратить порядок слов в строке
    let reverseWords = (str) => str.split(' ').reverse().join(' ');

    return {
        setSourceString: function(str) { sourceString = str; },
        setPointAstr0: function(str) { pointAstr0 = str; },
        setPointBstr1: function(str) { pointBstr1 = str; },
        setPointBstr2: function(str) { pointBstr2 = str; },

        pointAtoHtml: function(str = sourceString, str0 = pointAstr0){
            return `<div class="indented"><div>Строка: ${str}</div>
                    <div>Удалено последнее вхождение "${str0}": ${removeLastOccur(str, str0)}</div></div>`;
        },

        pointBtoHtml: function(str = sourceString, str1 = pointBstr1, str2 = pointBstr2){
            return `<div class="indented"><div>Строка: ${str}</div>
                        <div>Все вхождения "${str1}" заменены на "${str2}": ${str.replaceAll(str1, str2)}</div></div>`;
        },

        pointCtoHtml: function(str = sourceString){
            return `<div class="indented"><div>Строка: ${str}</div>
                    <div>Обработанная строка: ${replaceAllButFirst(str, '.')}</div></div>`;
        },

        pointDtoHtml: function(str = sourceString){
            return `<div class="indented"><div>Строка: ${str}</div>
                    <div>Обработанная строка: ${reverseWordsLetters(str)}</div></div>`;
        },

        pointEtoHtml: function(str = sourceString){
            return `<div class="indented"><div>Строка: ${str}</div>
                    <div>Обработанная строка: ${reverseWords(str)}</div></div>`;
        },

        renderAll: function(){
            document.write(`<h2>Решение:</h2><ol style="list-style: lower-latin">
                            <li>${this.pointAtoHtml()}</li>
                            <li>${this.pointBtoHtml()}</li>
                            <li>${this.pointCtoHtml()}</li>
                            <li>${this.pointDtoHtml()}</li>
                            <li>${this.pointEtoHtml()}</li></ol>`);
        }
    }
})();


(function task3() {
    task3Module.setSourceString('корабли лавировали лавировали да не вылавировали');
    task3Module.setPointAstr0('вал');
    task3Module.setPointBstr1('лав');
    task3Module.setPointBstr2('пар');
    task3Module.renderAll();
})();