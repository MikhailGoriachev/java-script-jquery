
const weather = (function(){
    let data= {
        temperature: 0,
        pressure: 0,
        humidity: 0,
        wind: {
            speed: 0,
            direction: ''
        },
        climate: {
            description: "",
            img: ""
        }
    };

    return{
        getTemperature:   function() { return data.temperature; },
        getPressure:      function() { return data.pressure; },
        getHumidity:      function() { return data.humidity; },
        getWindSpeed:     function() { return data.wind.speed; },
        getWindDirection: function() { return data.wind.direction; },
        getClimateDesc:   function() { return data.climate.description; },
        getClimateImg:    function() { return data.climate.img; },

        setTemperature:   function(value) { data.temperature = value },
        setPressure:      function(value) { if(value > 0) data.pressure = value; },
        setHumidity:      function(value) { if(value > 0) data.humidity = value },
        setWindSpeed:     function(value) { data.wind.speed = value; },
        setWindDirection: function(value) { data.wind.direction = value; },
        setClimateDesc:   function(value) { data.climate.description = value; },
        setClimateImg:    function(value) { data.climate.img = value; },

        toHtml: function(){
            return `<div class="weather-block"><img src='../images/weather/${data.climate.img}' alt ="pic" width="75" height="75"/>
                    <div>${data.climate.description}</div>
                    <div>Температура: ${data.temperature}°С</div>
                    <div>Давление: ${data.pressure} мм рт.ст.</div>
                    <div>Влажность: ${data.humidity}%</div>
                    <div>Ветер: ${data.wind.speed} м/с, ${data.wind.direction}</div></div>`;
        },

        render: function(){
            document.write(this.toHtml());
        }
    }
})();

const climates = {
    cloudy: {
        description: 'Пасмурно',
        img: 'cloudy.svg'
    },
    partlyCloudy: {
        description: 'Облачно',
        img: 'partly-cloudy.svg'
    },
    fair: {
        description: 'Ясно',
        img: 'fair.svg'
    },
    thunder: {
        description: 'Гроза',
        img: 'thunder.svg'
    },
    heavyRain: {
        description: 'Сильный дождь',
        img: 'heavy-rain.svg'
    }
};



// Демонстрация работы с модулем
(function (){

    // Направления ветра
    const directions = ['C', 'Ю', 'В', 'З', 'Ю-В', 'Ю-З', 'С-В', 'С-З'];
    // Массив ключей погодных явлений
    let climateNames = Object.keys(climates);


    // Генерация и отображение сгенерированных погодных данных
    const nDemos = 5;
    for (let i = 0; i < nDemos; i++) {
        // случайный ключ из погодных явлений
        let climateName = climateNames[getRandomInt(0, climateNames.length - 1)];

        weather.setClimateDesc(climates[climateName].description);
        weather.setClimateImg(climates[climateName].img);
        weather.setTemperature(getRandomInt(10, 40));
        weather.setHumidity(getRandomInt(20, 80));
        weather.setPressure(getRandomInt(600, 900));
        weather.setWindSpeed(getRandomInt(0, 30));
        weather.setWindDirection(directions[getRandomInt(0, directions.length - 1)]);

        weather.render();
    }
})();