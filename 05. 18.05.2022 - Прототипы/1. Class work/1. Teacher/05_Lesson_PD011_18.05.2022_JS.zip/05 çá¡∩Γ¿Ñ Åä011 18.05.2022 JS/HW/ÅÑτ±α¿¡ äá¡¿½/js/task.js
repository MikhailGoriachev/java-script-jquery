const module = (function() {
    const book = {
        author: "В.Голдинг",
        title: "Повелитель мух",
        published: 1967,
        image: "flies.jpg",
        price: 700,
        number: 10,
    };

    return {
        getAuthor(){
            return book.author;
        },
        setAuthor(author) {
            book.author = author;
        },
        setImage(image) {
            book.image = image;
        },
        getTitle() {
            return book.title;
        },
        setTitle(title) {
            book.title = title;
        },
        getPublished() {
            return book.published;
        },
        setPublished(published) {
            book.published = published;
        },
        getPrice() {
            return book.price;
        },
        setPrice(price) {
            book.price = price;
        },
        getNumber() {
            return book.number;
        },
        setNumber(number) {
            book.number = number;
        },
        toHTML() {
            return `<div class="card">
                <div class="image-container"><img src="../images/${book.image}"></div> 
                <p>Автор: ${book.author}</p>
                <p>Название: ${book.title}</p>
                <p>Год издания: ${book.published}</p>
                <p>Цена : ${book.price}</p>
                <p>Количество : ${book.number}</p> 
               </div>`
        }
    };
})();

document.write(module.toHTML());
module.setImage("zara.jpg");
module.setAuthor("Ф.Ницше");
module.setTitle("Так говорил Заратустра");
module.setPublished(1993);
module.setPrice(700);
module.setNumber(10);
document.write(module.toHTML());
module.setImage("kamju.jpg");
module.setAuthor("А.Камю");
module.setTitle("Чума");
module.setPublished(1956);
module.setPrice(870);
module.setNumber(13);
document.write(module.toHTML());
module.setImage("bees.jpg");
module.setAuthor("Э.Юнгер");
module.setTitle("Стеклянные пчелы");
module.setPublished(1957);
module.setPrice(1200);
module.setNumber(5);
document.write(module.toHTML());



