const module = (function() {
    const weather = {
        image: "weather1.jpg",
        temperature: 34,
        pressure: 750,
        humidity: 35,
        windSpeed: 45,
        windDirection : "восток"
    };
    return {
        getImage() {
          return weather.image;
        },
        setImage(image) {
          weather.image = image;
        },
        getTemperature() {
            return weather.temperature;
        },
        setTemperature(temperature) {
            weather.temperature = temperature;
        },
        getPressure() {
            return weather.pressure;
        },
        setPressure(pressure) {
          weather.pressure = pressure;
        },
        getHumidity() {
            return weather.humidity;
        },
        setHumidity(humidity) {
            weather.humidity = humidity;
        },
        getWindSpeed() {
            return weather.windSpeed;
        },
        setWindSpeed(windSpeed) {
            weather.windSpeed = windSpeed;
        },
        getWindDirection() {
            return weather.windDirection;
        },
        setWindDirection(direction) {
            weather.windDirection = direction;
        },

        toHTML() {
              return `<div class="card">
                      <div class="image-container"><img src="../images/${weather.image}"></div>
                      <p>Температура: ${weather.temperature}C </p>
                      <p>Давление: ${weather.pressure}мрт</p>
                      <p>Влажность: ${weather.humidity}%</p>
                      <p>Скорость: ${weather.windSpeed}м/c</p>
                      <p>Направление ветра: ${weather.windDirection}</p>
                   </div>`
        }
    }

} )();

document.write(module.toHTML());
module.setImage("weather2.jpg");
module.setTemperature(23);
module.setPressure(745);
module.setHumidity(34);
module.setWindSpeed(56);
module.setWindDirection("запад");

document.write(module.toHTML());
module.setImage("weather3.jpg");
module.setTemperature(28);
module.setPressure(746);
module.setHumidity(45);
module.setWindSpeed(87);
module.setWindDirection("юг");

document.write(module.toHTML());
module.setImage("weather4.jpg");
module.setTemperature(26);
module.setPressure(755);
module.setHumidity(86);
module.setWindSpeed(100);
module.setWindDirection("север");

document.write(module.toHTML());
module.setTemperature(18);
module.setPressure(756);
module.setHumidity(45);
module.setWindSpeed(90);
module.setWindDirection("северо-восток");
document.write(module.toHTML());

