//Создать представление о погоде
let weatherView = (function () {

    //Данные для замыкания
    let weather = getViewWeather();

    //Создание объекта
    return{

        //region setters & getters

        //region Атмосферное явление
        setWeatherType: function (value) {weather.typeIcon = value},
        getWeatherType: function () {return weather.typeIcon},
        //endregion


        //region Температура
        setTemperature: function (value) {
            if (value < -70 || value > 60)
                return;
            weather.temperature = value;
        },
        getTemperature: function () {return weather.temperature},
        //endregion


        //region Давление
        setPressure: function (value) {
            if (value <= 0 || value > 1200)
                return;
            weather.pressure = value;
        },
        getPressure: function () {return weather.pressure},
        //endregion


        //region Влажность
        setHumidity: function (value) {
            if (value < 0 || value > 100)
                return;
            weather.humidity = value;
        },
        getHumidity: function () {return weather.humidity},
        //endregion


        //region Ветер
        setWind: function (speed,direction) {
            if (speed < 0)
                return;
            weather.windObj.speed = speed;
            weather.windObj.direction = direction;
        },
        getWind: function () {return weather.windObj},
        //endregion

        //endregion

        //Вывод
        show: function () {
            document.write(`
                <table>
                    <tr>
                        <th>Автмосферное явление</th>
                        <th colspan="2">Характеристика</th>
                    </tr>
                    
                    <tr>
                        <td rowspan="5" class="weather-type-icon">
                            <img src="../images/weather/${weather.typeIcon}" width="150px">
                        </td>
                    </tr>
                    
                    <tr>
                        <td class="field-names">Температура</td>
                        <td><span>${weather.temperature}</span></td>
                    </tr>
                    <tr>
                        <td class="field-names">Давление</td>
                        <td><span>${weather.pressure} гПа.</span></td>
                    </tr>
                    <tr>
                        <td class="field-names">Влажность</td>
                        <td><span>${weather.humidity}%</span></td>
                    </tr>
                    <tr>
                        <td class="field-names">Ветер</td>
                        <td><span>Направление: ${weather.windObj.direction}</span>
                        <br><span>Скорость: ${weather.windObj.speed} м/с.</span>
                        </td>
                    </tr>
                </table>
            `)
        }//show
    };
})();//weatherView


//Изменение вида явления
changeType = function (newIcon,view) {
    if (newIcon == undefined)
        return;

    view.setWeatherType(newIcon);
}

//Увеличение давления
increasePressure = function(delta,view){
    let newPressure = view.getPressure()+delta;
    if (newPressure>1200 || delta<=0)
        return;
    view.setPressure(newPressure);
}

//Изменение температуры
changeTemperature = function (value,view) {
    if (value < -70 || value > 60 || value == undefined)
        return;
    view.setTemperature(value)
}

function task() {
    weatherView.show();

    let increment = getRandom(10,150);
    changeType("lightning.png",weatherView);
    increasePressure(increment,weatherView);
    changeTemperature(getRandom(27,32),weatherView)

    document.write(`<p>Запись после изменения атм. явления на грозу и повишения давления на ${increment} гПа.</p>`)

    weatherView.show();
}