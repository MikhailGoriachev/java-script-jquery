
//Модуль книг
let book = (function () {
        //Получить объект со всеми свойствами
        let tempBook = getBook();

        //Создание объекта
        return {

            //region Setters & getters

            //region Название книги
            setName: function (value) {tempBook.name = value},
            getName: function () {return tempBook.name},
            //endregion

            //region Автор
            setAuthor: function (value) {tempBook.author = value},
            getAuthor: function () {return tempBook.author},
            //endregion

            //region Год
            setYear: function (value) {
                //Защита от задания года публикации в будущем времени
                if (value > (new Date()).getFullYear())
                    return;

                tempBook.year = parseInt(value);
            },
            getYear: function () {return parseInt(tempBook.year)},
            //endregion

            //region Обложка
            setCover: function (value) {tempBook.coverFile = value},
            getCover: function () {return tempBook.coverFile},
            //endregion

            //region Стоимость
            setPrice: function (value)   {
                if (value<0)
                    return;
                tempBook.price = value;
            },
            getPrice: function () {return tempBook.price},
            //endregion

            //endregion

            //Вывод
            show: function () {
                document.write(`
                    <table>
                        <tr>
                            <th>Обложка</th>
                            <th colspan="2">Описание</th>
                        </tr>
                        
                        <tr>
                            <td rowspan="5" class="cell-with-cover">
                                <img src="../images/book-covers/${tempBook.coverFile}" width="150px">
                            </td>
                        </tr>
                        
                        <tr>
                            <td class="field-names">Название</td>
                            <td><span>${tempBook.name}</span></td>
                        </tr>
                        <tr>
                            <td class="field-names">Год издания</td>
                            <td><span>${tempBook.year}</span></td>
                        </tr>
                        <tr>
                            <td class="field-names">Автор</td>
                            <td><span>${tempBook.author}</span></td>
                        </tr>
                        <tr>
                            <td class="field-names">Стоимость</td>
                            <td><span>${tempBook.price} руб.</span></td>
                        </tr>
                    </table>
                `)
            }
        };
    })();//book

//region Отдельные методы изменения объекта

//Увеличение цены
increasePrice = function (increment,bookObj) {
    if (increment <= 0)
        return;

    bookObj.setPrice(book.getPrice()+increment);
}

//Увеличение года издания
changePubYear = function (year = 1,bookObj) {
    if (year <= 0)
        return;

    bookObj.setYear(book.getYear()+year)
}

//Изменение обложки
changeCover = function (newPath,bookObj) {
    if (newPath == undefined)
        return;

    bookObj.setCover(newPath);
}

//endregion

//Исполняемая функция
function task() {
    book.show();

    let newPrice = getRandom(50,300),currCover = book.getCover();

    //Изменение записи
    increasePrice(newPrice,book);
    changePubYear(1,book);
    //Замена текущей обложки на похожую (в имени файла не должны содержаться точки)
    changeCover(currCover.substring(0,currCover.indexOf('.'))+'_2.jpg',book);

    document.write(`<p>Изменение записи при помощи сеттеров и геттеров</p>`)
    //вывод
    book.show();
}

