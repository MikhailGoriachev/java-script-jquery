
//Модуль для выполнения обработок
let module = (function () {

    //region Исходные строки
    let strObj = generateStrFirstPart();
    let s = strObj.s,
        s0 = strObj.s0,
        s1 = strObj.s1,s2 = '—',
        strTask3 = 'Методы должны позвполяпть получать и менмятьм свойства объекта данных'.toLowerCase(),
        strTask4 = 'Установку ограничения можно сделать вручную, изменим схему базы данных, либо программно',
        strTask5 = 'Установку ограничения можно сделать вручную, изменим схему базы данных, либо программно';
    //endregion

    return{
        //region Пункт 1
        showTask1Before: function () {
            document.write(`
                   <tr>
                       <th rowspan="4" class="info-cell">Реализация</th>
                   </tr>`);
            document.write(`
                    <tr>
                       <td class="content-cell">
                           <table>
                               <tr>
                                   Начальная строка: <span class="highlightString">${s}</span>
                               </tr>
                           </table>
                       </td>
                   </tr>`);

            document.write(`                   
                   <tr>
                       <td class="content-cell">
                            Подстрока для удаления: <span class="highlightString">${s0}</span>
                       </td>
                   </tr>`);
        },

        showTask1After: function () {
            document.write(`
                   <tr>
                       <td class="content-cell">
                            Обработанная строка: <span class="highlightChangedString">${s}</span>
                       </td>
                   </tr>`);
        },

        removeStrTask1: function () {
            //Если строка не содержит определённой подстроки
            if (!s.includes(s0))
                return;


            let strArr = s.split(' ').filter(str => str.length>0)

            strArr.reverse();

            //Удаляем 1-е вхождение в реверсивном массиве
            for (let i = 0,counter = 0; i < strArr.length; i++) {
                if (strArr[i] === s0) {
                    strArr.splice(i, 1);
                    break;
                }
            }

            //Формируем общую строку из массива подстрок
            s = strArr.reverse().join(' ');
        },//removeStr
        //endregion

        //region Пункт 2
        showBeforeTask2: function () {
            s = strObj.s;
            document.write(`
                   <tr>
                       <th rowspan="5" class="info-cell">Реализация</th>
                   </tr>`);
            document.write(`
                    <tr>
                       <td class="content-cell">
                           <table>
                               <tr>
                                   Начальная строка:  <span class="highlightString">${s}</span>
                               </tr>
                           </table>
                       </td>
                   </tr>`);

            document.write(`                   
                   <tr>
                       <td class="content-cell">
                            Подстрока "S1":  <span class="highlightString">${s1}</span>
                       </td>
                   </tr>`);
            document.write(`                   
                   <tr>
                       <td class="content-cell">
                            Строка для замены "S2":  <span class="highlightString">${s2}</span>
                       </td>
                   </tr>`);
        },

        //Вывод результата обработки
        showAfterTask2: function () {
            document.write(`
                   <tr>
                       <td class="content-cell">
                            Обработанная строка:  <span class="highlightChangedString">${s}</span>
                       </td>
                   </tr>`);
        },

        //Заменить вхождение S1 на S2
        replaceStrTask2: function () {
            //Если строка не содержит определённой подстроки
            if (!s.includes(s1))
                return;

            let strArr = s.split(' ').filter(str => str.length > 0)

            //Заменить вхождение строки
            for (let i = 0; i < strArr.length; i++) {
                if (strArr[i] === s1)
                    strArr.splice(i, 1,s2);
            }

            //Формируем общую строку из массива подстрок
            s = strArr.join(' ');
        },//replaceStr
        //endregion

        //region Пункт 3
        showBeforeTask3: function () {
            document.write(`
                   <tr>
                       <th rowspan="3" class="info-cell">Реализация</th>
                   </tr>`);
            document.write(`
                    <tr>
                       <td class="content-cell">
                           <table>
                               <tr>
                                   Заданная строка: <span class="highlightString">${strTask3}</span>
                               </tr>
                           </table>
                       </td>
                   </tr>`);
        },

        showAfterTask3: function () {
            document.write(`
                   <tr>
                       <td class="content-cell">
                            Обработанная строка: <span class="highlightChangedString">${strTask3}</span>
                       </td>
                   </tr>`);
        },

        //Обработка по заданию: замена вхождений первой буквы на точку
        replaceCharTask3: function () {

            let strArr = strTask3.split(" ").filter(s => s.length>0),
                symbol = '.';

            //Проход по словам
            for (let j = 1; j < strArr.length; j++) {

                let symbArr = strArr[j].split("").filter(s => s.length>0),
                    firstLetter = symbArr[0];

                //Замена символов
                for (let i = 1; i < symbArr.length; i++) {
                    if (symbArr[i] === firstLetter)
                        symbArr[i] = symbol;
                }

                strArr[j] = symbArr.join('');
            }

            strTask3 = strArr.join(' ');

        },//replaceChar
        //endregion

        //region Пункт 4
        showBeforeTask4: function () {
            document.write(`
                   <tr>
                       <th rowspan="3" class="info-cell">Реализация</th>
                   </tr>`);
            document.write(`
                    <tr>
                       <td class="content-cell">
                           <table>
                               <tr>
                                   Заданная строка: <span class="highlightString">${strTask4}</span>
                               </tr>
                           </table>
                       </td>
                   </tr>`);
        },

        showAfterTask4: function () {
            document.write(`
                   <tr>
                       <td class="content-cell">
                            Обработанная строка: <span class="highlightChangedString">${strTask4}</span>
                       </td>
                   </tr>`);
        },

        //Обработка по заданию
        reverseWordsTask4: function () {

            let strArr = strTask4.toLowerCase().split(" ").filter(s => s.length>0);

            //Проход по словам
            for (let j = 0; j < strArr.length; j++) {

                //Получение массива букв
                let symbArr = strArr[j].split("").filter(s => s.length>0);

                //Если слово первое
                if (j==0){
                    symbArr[symbArr.length-1] = symbArr[symbArr.length-1].toUpperCase();
                }

                //Замена порядка букв
                strArr[j] = symbArr.reverse().join('');
            }

            strTask4 = strArr.join(' ');

        },//reverseWords
        //endregion

        //region Пункт 5
        showBeforeTask5: function () {
            document.write(`
                   <tr>
                       <th rowspan="3" class="info-cell">Реализация</th>
                   </tr>`);
            document.write(`
                    <tr>
                       <td class="content-cell">
                           <table>
                               <tr>
                                   Заданная строка: <span class="highlightString">${strTask5}</span>
                               </tr>
                           </table>
                       </td>
                   </tr>`);
        },

        showAfterTask5: function () {
            document.write(`
                   <tr>
                       <td class="content-cell">
                            Обработанная строка: <span class="highlightChangedString">${strTask5}</span>
                       </td>
                   </tr>`);
        },

        //Обработка по заданию
        reverseWordsTask5: function () {

            let strArr = strTask5.split(" ").filter(s => s.length>0);

            strTask5 = strArr.reverse().join(' ');

        }//reverseWords
        //endregion

    };//Module

})();

//region Пункт 1
function subTask1() {
    module.showTask1Before();
    module.removeStrTask1();
    module.showTask1After();

};
//endregion

// region Пункт 2
function subTask2() {

    module.showBeforeTask2();
    module.replaceStrTask2();
    module.showAfterTask2();
}
//endregion//

// region Пункт 3
function subTask3() {

    module.showBeforeTask3();
    module.replaceCharTask3();
    module.showAfterTask3();
}
//endregion

// region Пункт 4
function subTask4() {

    module.showBeforeTask4();
    module.reverseWordsTask4();
    module.showAfterTask4();
}
//endregion

// region Пункт 5
function subTask5() {
    module.showBeforeTask5();
    module.reverseWordsTask5();
    module.showAfterTask5();
}
//endregion