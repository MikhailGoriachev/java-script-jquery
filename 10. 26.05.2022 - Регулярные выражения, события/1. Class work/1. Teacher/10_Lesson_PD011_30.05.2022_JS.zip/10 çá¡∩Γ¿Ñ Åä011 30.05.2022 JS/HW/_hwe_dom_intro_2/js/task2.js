/*
*
* Задача 2.
* Спроектировать иерархию классов для предприятия ремонта бытовой техники.
* Создайте массивы объектов и выполните обработку по заданию.
* Базовый класс – персона (фамилия и инициалы, дата рождения, город
* проживания).
* Производный от базового класс – клиент (дата обращения за услугой, название
* услуги, стоимость услуги).
* Производный от базового класс – мастер (тарифная ставка, дата начала работы,
* признак занятости ремонтом).
* Переопределите методы toString(), equals() для клиента и мастера.
* Создайте массивы клиентов и мастеров (не менее 12 элементов), выводите эти
* массивы в разметку в порядке инициализации.
* По кликам по кнопкам упорядочивайте клиентов при выводе по алфавиту,
* мастеров – по тарифной ставке (порядок в исходном массиве не менять).
* Также предусмотрите кнопки для вывода массивов без упорядочивания.
* По кликам на кнопки выделяйте клиента/клиентов из города Иловайск,
* мастера/мастеров с максимальным тарифом.
* Через 10 с после выполнения команды выводите массивы в исходном порядке,
* без выделения.
* */

// Базовый класс – персона со свойствами:
// фамилия и инициалы, дата рождения, город проживания
class Person {
    constructor(fullName, dateOfBirth, city) {
        this.fullName = fullName;         // фамилия и инициалы
        this.dateOfBirth = dateOfBirth;     // дата рождения
        this.city = city;                   // название города проживания
    } // constructor

    // переопределение метода toString()
    toString() {return `
        <td>${this.fullName}</td>
        <td>${this.dateOfBirth.toLocaleDateString()}</td>
        <td>${this.city}</td>`;
    } // toString

    equals(other) { return
        this.fullName.equals(other.fullName) && this.dateOfBirth === other.dateOfBirth &&
        this.city.equals(other.city);
    }
} // class Person


// Производный от базового класс – клиент со свойствами:
// дата обращения за услугой, название услуги, стоимость услуги.
// Переопределите методы toString(), equals() для клиента
class Client extends Person {
    constructor(fullName, dateOfBirth, city, dateService, nameService, costService) {
        // получение доступа к полям базового класса - унаследовали поля базового класса
        // super(наборПараметровБазовогоКласса)
        super(fullName, dateOfBirth, city);

        // поля производного класса
        this.dateService = dateService;
        this.fullName = fullName;
        this.dateOfBirth = dateOfBirth;
        this.city = city;
        this.nameService = nameService;
        this.costService = costService;
    } // constructor


    // переопределение метода Object
    toString() { return `
        <td>${this.fullName}</td>
        <td>${this.dateOfBirth.toLocaleDateString()}</td>
        <td>${this.city}</td>
        <td>${this.dateService.toLocaleDateString()}</td>
        <td>${this.nameService}</td>
        <td>${this.costService}</td>`;
    } // toString

    // переопределение метода equals
    equals(other) { return
        super.equals(other) && this.dateService === other.dateService &&
        this.costService === other.costService;
    }

    // формирование строки с данными объекта для вывода в разметку
    toTableRow(row) {return `
        <tr id="cln${row}">
        <td>${row}</td>
        <td class="align-left">${this.fullName}</td>
        <td class="align-right">${this.dateOfBirth.toLocaleDateString()}</td>
        <td class="align-left">${this.city}</td>
        <td class="align-right">${this.dateService.toLocaleDateString()}</td>
        <td class="align-left">${this.nameService}</td>
        <td class="align-right">${this.costService}</td>
        </tr>`;
    } // toTableRow

    // для элемента массива формируем идентификатор, находим соответствующую строки таблицы
    // и меняем ее оформление, если на элементе массива сработает предикат
    toTableRowMark(row, predicate) {
        // можно работать с коллекцией классов CSS через свойство classList или напрямую
        // со свойствами стиля
        // predicate(this)?item.classList.add("selected-tr"):item.classList.remove("selected-tr");
        if (predicate(this))
            $("cln" + row).style.backgroundColor = "linen";
    } // toTableRowMark
} // class Client


// Производный от базового класс – мастер со свойствами: тарифная ставка,
// дата начала работы, признак занятости ремонтом.
// Переопределите методы toString(), equals() для мастера.
// tariffRate - тарифная ставка
// startDate - дата начала ремонта
// busy - признак занятости/не занятости ремонтами
class Artisan extends Person{
    constructor(fullName, dateOfBirth, city, tariffRate, startDate, busy) {
        // наследование полей
        super(fullName, dateOfBirth, city);

        // присвоить данные полей мастера
        this.tariffRate = tariffRate;
        this.startDate = startDate;
        this.busy = busy;
    } // constructor

    // методы "класса"
    toString() {return `
        <td>${this.fullName}</td>
        <td>${this.dateOfBirth.toDateString()}</td>
        <td>${this.city}</td>
        <td>${this.tariffRate}</td>
        <td>${this.startDate.toDateString()}</td>
        <td>${this.busy}</td>`;
    } // toString


    // переопределение метода equals
    equals(other) { return
        super.equals(other) && this.tariffRate === other.tariffRate &&
        this.startDate === other.startDate && this.busy === other.busy;
    }


    // формирование строки с данными объекта для вывода в разметку
    toTableRow(row) {return `
        <tr id="art${row}">
        <td>${row}</td>
        <td class="align-left">${this.fullName}</td>
        <td class="align-right">${this.dateOfBirth.toLocaleDateString()}</td>
        <td class="align-left">${this.city}</td>
        <td class="align-right">${this.tariffRate}</td>
        <td class="align-right">${this.startDate.toLocaleDateString()}</td>
        <td class="align-left">${this.busy?"занят":""}</td>
        </tr>`;
    } // toTableRow

    // для элемента массива формируем идентификатор, находим соответствующую строки таблицы
    // и меняем ее оформление, если на элементе массива сработает предикат
    toTableRowMark(row, predicate) {
        // можно работать с коллекцией классов CSS через свойство classList или напрямую
        // со свойствами стиля
        // predicate(this)?item.classList.add("selected-tr"):item.classList.remove("selected-tr");
        if (predicate(this))
            $("art" + row).style.backgroundColor = "linen";
    } // toTableRowMark
} // class Artisan


// класс для работы с коллекциями клиентов и мастеров ремонтная мастерская
class RepairShop {
    constructor(title, clients, artisans) {
        this.title = title;
        this.clients = clients;
        this.artisans = artisans;
    }

    // вывод коллекции в разметку по кликам на кнопки
    show(header) {
        $("title").innerText = header;
        let row = 1;
        $("clients").innerHTML = this.clients.reduce((acc, c) => acc + c.toTableRow(row++), "");

        row = 1;
        $("artisans").innerHTML = this.artisans.reduce((acc, a) => acc + a.toTableRow(row++), "");
    } // show

    // вывод коллекции в разметку по кликам на кнопки
    static show(title, collection, idTbody) {
        $("title").innerText = title;
        let row = 1;
        $(idTbody).innerHTML = collection.reduce((acc, a) => acc + a.toTableRow(row++), "");
    } // show


    // изменение стиля в строках таблицы, для которых сработает предикат
    static showMarked(title, repairShop, predicate, idTBody, timeOut = 10_000) {
        repairShop.show(title);

        let row = 1;
        if (idTBody === "clients")
            repairShop.clients.forEach(c => c.toTableRowMark(row++, predicate));
        else
            repairShop.artisans.forEach(c => c.toTableRowMark(row++, predicate));

        // снятие выделения через 10_000 мс
        setTimeout(() => repairShop.show(title), timeOut);
    } // showMarked

    // сортировка копии массива мастеров по тарифной ставке
    orderArtisansByTariffRate() {
        return [...this.artisans].sort((a1, a2) => a1.tariffRate - a2.tariffRate);
    } // orderByTariffRate

    // сортировка копии массива клиентов по алфавиту
    orderClientsByFullname() {
        return [...this.clients].sort((c1, c2) => c1.fullName.localeCompare(c2.fullName));
    } // orderByTariffRate
} // class RepairShop


// обработчик события загрузки страницы
window.onload = function() {
    // массив клиентов
    let clients = [
        // дата в формате месяц/день/год
        new Client('Иванова О.Л.',  new Date('12/21/2001'), 'Амвросиевка', new Date('4/21/2022'), 'ремонт зонтика', 200),
        new Client('Баранова Е.К.', new Date('1/1/1967'),   'Макеевка',    new Date('4/22/2022'), 'ремонт замка дверного', 2_300),
        new Client('Котова К.Л.',   new Date('2/28/1977'), 'Донецк',       new Date('4/22/2022'), 'ремонт бойлера', 6_200),
        new Client('Хижняк П.В.',   new Date('1/27/2001'),  'Иловайск',    new Date('4/23/2022'), 'ремонт хлебопечки', 900),
        new Client('Кобелев А.Р.',  new Date('11/12/1990'), 'Донецк',      new Date('4/23/2022'), 'ремонт замка дверного', 5_100),
        new Client('Яворский Р.Д.', new Date('9/11/1985'),  'Макеевка',    new Date('4/23/2022'), 'ремонт зонтика', 340),
        new Client('Гревцова С.И.', new Date('8/26/1992'),  'Ясиноватая',  new Date('4/23/2022'), 'ремонт хлебопечки', 700),
        new Client('Дивак С.С.',    new Date('7/30/1989'),  'Иловайск',    new Date('4/24/2022'), 'ремонт бойлера', 4_300),
        new Client('Брегеда Н.А.',  new Date('9/12/1968'),  'Макеевка',    new Date('4/24/2022'), 'ремонт кондиционера', 3_100),
        new Client('Цыбенко Е.А.',  new Date('2/10/1995'),  'Снежное',     new Date('4/24/2022'), 'ремонт холодильника', 1_200),
    ];

    // массив мастеров
    let artisans = [
        new Artisan('Романов Б.Г.',   new Date('7/18/1993'),  'Амвросиевка', 20_000, new Date('4/23/2022'), true),
        new Artisan('Сидорова А.К.',  new Date('3/11/2001'),  'Енакиево',    45_000, new Date('4/23/2022'), false),
        new Artisan('Вожжаев С.В.',   new Date('7/12/1986'),  'Донецк',      32_000, new Date('4/23/2022'), false),
        new Artisan('Швец Д.Ю.',      new Date('6/18/1997'),  'Енакиево',    34_000, new Date('4/23/2022'), false),
        new Artisan('Куренной А.Ю.',  new Date('3/12/1978'),  'Енакиево',    45_000, new Date('4/23/2022'), false),
        new Artisan('Барткова К.И.',  new Date('11/11/2002'), 'Енакиево',    41_000, new Date('4/24/2022'), true),
        new Artisan('Клименко В.В.',  new Date('10/30/1989'), 'Донецк',      40_000, new Date('4/24/2022'), false),
        new Artisan('Грамаков С.И.',  new Date('5/5/1999'),   'Донецк',      35_000, new Date('4/24/2022'), false),
        new Artisan('Дробот И.В.',    new Date('11/30/1987'), 'Донецк',      40_000, new Date('4/25/2022'), true),
        new Artisan('Жиронкина А.В.', new Date('8/8/1996'),   'Макеевка',    36_000, new Date('4/25/2022'), false),
        new Artisan('Головач М.Р.',   new Date('12/28/1999'), 'Ясиноватая',  20_000, new Date('4/25/2022'), true),
    ];

    // формирование массивов клиентов и мастеров
    let repairShop = new RepairShop('Починим все', clients, artisans);

    // начальный вывод данных о ремонтной мастерской
    repairShop.show(`Мастера и клиенты ремонтной мастерской "${repairShop.title}"`);

    // вывод мастеров и клиентов ремонтной мастерской без изменения
    $("btnSrcData").onclick =
        () => repairShop.show(`Мастера и клиенты ремонтной мастерской "${repairShop.title}"`);

    // вывод мастеров и клиентов ремонтной мастерской, мастера упорядочены по возрастанию тарифа
    $("btnOrderArtisans").onclick = () => RepairShop.show(
        `Мастера ремонтной мастерской упорядочены по росту тарифа"${repairShop.title}"`,
        repairShop.orderArtisansByTariffRate(),
        "artisans"
    );

    // вывод мастеров и клиентов ремонтной мастерской, клиенты упорядочены по алфавиту
    $("btnOrderClients").onclick = () => RepairShop.show(
        `Клиенты ремонтной мастерской упорядочены по алфавиту "${repairShop.title}"`,
        repairShop.orderClientsByFullname(),
        "clients"
    );

    // Вывод клиентов ремонтной мастерской с выделением эаписей о клиентах из Иловайска
    $("btnSelectClents").onclick = () => {
        let city = 'Иловайск';
        RepairShop.showMarked(
            `Выделены клиенты ремонтной мастерской "${repairShop.title}" из города ${city}`,
            repairShop, c => c.city === city,
            "clients"
        );
    }

    // Вывод мастеров с максимальной тарифной ставкой
    $("btnSelectArtisans").onclick = () => {
        // получить максимальную тарифную ставку
        let maxTariffRate = Math.max(...repairShop.artisans.map(a=> a.tariffRate));
        RepairShop.showMarked(
            `Выделены мастера ремонтной мастерской "${repairShop.title}" с максимальным тарифом ${maxTariffRate} руб.`,
            repairShop, c => c.tariffRate === maxTariffRate,
            "artisans"
        );
    }
}