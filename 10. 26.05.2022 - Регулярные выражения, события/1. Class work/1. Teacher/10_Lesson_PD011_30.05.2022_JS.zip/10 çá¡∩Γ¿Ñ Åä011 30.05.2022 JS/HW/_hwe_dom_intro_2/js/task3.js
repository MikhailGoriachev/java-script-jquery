/*
* Задача 3
* Реализуйте «светофор» в выделенной части экрана: переключайте цвет области
* по циклу красный – желтый – зеленый, период переключения 3 с, предусмотрите
* кнопки разрешения и запрещения работы «светофора»
* */

window.onload = function() {
    // ссылка на объект, работающий с интервалом
    let intervalHandler;

    // период срабатывания "светофора" в миллисекундах
    const period = 3_000;

    // индекс очередного цвета
    let indexColor = 0;

    // цвета для "светофора"
    let trafficLightColors = ['red', 'yellow','green', 'yellow'];


    // обработчик кнопки запуска анимации
    $("btnStart").onclick = function() {
        // каждый раз запускаем "светофор" с начала цикла, чтобы не было
        // томительной паузы, выводим красный фон, фон начала цикла
        indexColor = 0;
        animateCallback();

        // запуск периодической работы, получение ссылки на объект таймера
        intervalHandler = setInterval(animateCallback, period);
        $("header").innerText = "Анимация работает";
    } // btnStart


    // обработчик кнопки останова анимации
    $("btnStop").onclick = function () {
        // останавливаем таймер, по которому вызывается функция animateCallback
        clearInterval(intervalHandler);

        let header = $("header");
        header.innerText = "Анимация остановлена";
        $("trafficLight").style.backgroundColor = 'transparent';

        // через period миллисекунд после окончания анимации восстановим исходный текст
        // заголовка
        setTimeout(() => header.innerText="Блок для анимации цвета фона - \"светофор\"", period);
    } // btnStop


    // реализация анимации цвета
    function animateCallback() {
        $("trafficLight").style.backgroundColor = trafficLightColors[indexColor++ % trafficLightColors.length];
    } // animateCallback
} // onload