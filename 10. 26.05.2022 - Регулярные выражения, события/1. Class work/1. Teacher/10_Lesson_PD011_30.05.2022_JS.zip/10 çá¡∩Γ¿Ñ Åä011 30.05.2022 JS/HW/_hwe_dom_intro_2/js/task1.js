/*
* Задача 2.
* Спроектировать класс в синтаксисе ES6+ для представления данных о погоде:
* температура, давление, влажность, скорость и направление ветра, графическое
*  отображение атмосферных явлений (ясно, облачно, дождь, и т.д. – не более 5).
*  Определите метод формирования строки для вывода данных в разметку.
* Переопределите метод toString() для простого вывода в консоль.
* Создайте массив данных о погоде за неделю, выведите его на страницу.
* По командам от кнопок выводите данные о погоде, упорядоченные (только
* при выводе, порядок элементов в исходном массиве не менять):
*     по убыванию температуры,
*     по возрастанию давления,
*     по убыванию скорости ветра.
* По командам от кнопок выделяйте самые ветреные и самые тихие дни, дни
* с северным ветром. Выделение должно сниматься через 10 секунд.
* Предусмотрите кнопку для вывода исходного массива погодных явлений,
* без выделений элементов.
* */

class Weather {
    constructor(meteor, temperature, pressure, humidity, wind) {
        // атмосферные явления (ясно, облачно, дождь, и т.д. – не более 5)
        this.meteor = {
            name: meteor.name,
            img: meteor.img,
        };

        // температура
        this.temperature = temperature;

        // давление,
        this.pressure = pressure;

        // влажность,
        this.humidity = humidity;

        // скорость и направление ветра,
        this.wind = {
            speed: wind.speed,
            direction: wind.direction
        };
    } // constructor

    // формирование строки с данными объекта для вывода в разметку
    toTableRow(row) {return `
        <tr id="id${row}">
            <td>${row}</td>
            <td class="align-center"><img src="../images/task2/${this.meteor.img}" height="64" 
                alt="условное изображение погодного явления"/><br/>${this.meteor.name}</td>
            <td>${this.temperature}</td>
            <td>${this.pressure}</td>
            <td class="align-center">${this.wind.direction}</td>
            <td>${this.wind.speed}</td>
            <td>${this.humidity}</td>
        </tr>`;
    } // toTableRow

    // для элемента массива формируем идентификатор, находим соответствующую строки таблицы
    // и меняем ее оформление, если на элементе массива сработает предикат
    toTableRowMark(row, predicate) {
        // можно работать с коллекцией классов CSS через свойство classList или напрямую
        // со свойствами стиля
        // predicate(this)?item.classList.add("selected-tr"):item.classList.remove("selected-tr");
        if (predicate(this))
            $("id" + row).style.backgroundColor = "linen";
    } // toTableRowMark

    // переопределение метода вывода в строку
    toString() {
        return `${this.meteor.name}, ${this.meteor.img}; ${this.temperature} град.; ${this.pressure} гПа;` +
            ` ветер ${this.wind.direction}, ${this.wind.speed} м/с; влажность ${this.humidity}%`
    } // toString
} // class Weather


// коллекция погодных явлений за неделю, обработка погодных явлений по заданию
class WeatherConditions {
    constructor(conditions) {
        this.conditions = conditions;
    }

    // формирование коллекции погодных явлений
    static generate() {
        return [
            new Weather({name: "солнечно", img:"sunny.png"}, 23, 1012, 67, {speed: 5, direction: "Ю-В"}),
            new Weather({name: "дождь", img:"rain.png"}, 18, 988, 89, {speed: 12, direction: "В"}),
            new Weather({name: "дождь", img:"rain.png"}, 7, 899, 98, {speed: 15, direction: "С-В"}),
            new Weather({name: "солнечно", img:"sunny.png"}, 18, 1023, 78, {speed:15, direction: "С"}),
            new Weather({name: "облачно", img:"cloudly.png"}, 13, 1023, 87, {speed: 8, direction: "С"}),
            new Weather({name: "дождь", img:"rain.png"}, 5, 780, 98, {speed: 8, direction: "С-В"}),
            new Weather({name: "снег", img:"snow.png"}, -1, 760, 92, {speed: 5, direction: "С-З"}),
        ];
    } // generate


    // вывод коллекции в разметку по кликам на кнопки
    static show(title, conditions) {
        $("title").innerText = title;
        let row = 1;
        $("result").innerHTML = conditions.reduce((acc, c) => acc + c.toTableRow(row++), "");
    } // show


    // изменение стиля в строках таблицы, для которых сработает предикат
    // и снятие выделения через timeOut мс, по заданию - 10 с или 10_000 мс
    static showMarked(title, conditions, predicate, timeOut = 10_000) {
        // вызов статического метода класса из нестатического метода этого же класса
        WeatherConditions.show(title, conditions);

        let row = 1;
        conditions.forEach(c => c.toTableRowMark(row++, predicate));

        setTimeout(() => WeatherConditions.show("Сведения о погоде за последние 7 дней",
            conditions), timeOut);
    } // showMarked


    // формирование копии коллекции сведений о погоде, упорядоченных
    // по убыванию температуры
    orderByTemperatureDesc() {
        return [...this.conditions].sort((c1, c2) => c2.temperature - c1.temperature);
    } // orderByTemperatureDesc

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по возрастанию давления
    orderByPressure() {
        return [...this.conditions].sort((c1, c2) => c1.pressure - c2.pressure);
    } // orderByPressure

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по убыванию скорости ветра
    orderByWindSpeedDesc() {
        return [...this.conditions].sort((c1, c2) => c2.wind.speed - c1.wind.speed);
    } // orderByWindSpeedDesc

    // получение максимальной скорости ветра
    getMaxWindSpeed() {
        return Math.max(...this.conditions.map(c =>c.wind.speed));
    }

    // получение минимальной скорости ветра
    getMinWindSpeed() {
        return Math.min(...this.conditions.map(c =>c.wind.speed));
    }


} // class WeatherConditions


// назначение обработчиков клика по кнопкам
window.onload = function() {
    // массив погодных явлений, начальный вывод массива погодных явлений
    let weatherConditions = new WeatherConditions(WeatherConditions.generate());
    WeatherConditions.show(
        "Сведения о погоде за последние 7 дней",
        weatherConditions.conditions
    );


    // демонстрация метода toString() при выводе в консоль
    console.log(`${weatherConditions.conditions[0]}`);

    // вывод массива сведений о погоде
    $("btnSrcArray").onclick = () => WeatherConditions.show(
        "Сведения о погоде за последние 7 дней",
        weatherConditions.conditions
    );

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по убыванию температуры
    $("btnOrder1").onclick = () => WeatherConditions.show(
        "Сведения о погоде за последние 7 дней, упорядоченные по убыванию температуры",
        weatherConditions.orderByTemperatureDesc()
    )

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по возрастанию давления, вывод сформированной коллекции
    $("btnOrder2").onclick = () => WeatherConditions.show(
        "Сведения о погоде за последние 7 дней, упорядоченные по возрастанию давления",
         weatherConditions.orderByPressure()
    );

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по убыванию скорости ветра
    $("btnOrder3").onclick = () => WeatherConditions.show(
        "Сведения о погоде за последние 7 дней, упорядоченные по убыванию скорости ветра",
        weatherConditions.orderByWindSpeedDesc()
    );


    // вывод коллекции сведений о погоде, с выделением строк, соответствующих
    // самым тихим дням
    $("btnSelect1").onclick = () => {
        let minSpeed = weatherConditions.getMinWindSpeed();
        WeatherConditions.showMarked(
            "Сведения о погоде за последние 7 дней, выделены самые тихие дни/тихий день",
            weatherConditions.conditions,
            c => c.wind.speed === minSpeed
        );
    };

    // вывод коллекции сведений о погоде, с выделением строк, соответствующих
    // самым ветреным дням
    $("btnSelect2").onclick = () => {
        let maxSpeed = weatherConditions.getMaxWindSpeed();
        WeatherConditions.showMarked(
            "Сведения о погоде за последние 7 дней, выделены самые ветреные дни/ветреный день",
            weatherConditions.conditions,
            c => c.wind.speed === maxSpeed
        );
    };

    // вывод коллекции сведений о погоде, с выделением строк, соответствующих
    // дням с северным ветром
    $("btnSelect3").onclick = () => {

        WeatherConditions.showMarked(
            "Сведения о погоде за последние 7 дней, выделены дни/день с северным ветром",
            weatherConditions.conditions,
            c => c.wind.direction === 'С'
        );
    };
} // window.onload
