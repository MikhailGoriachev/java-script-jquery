
// Хранилище состояний цвета
class LightsState{
    mainColors = ['red', 'green'];
    waitColor = 'yellow';

    constructor() {
        this.current = this.waitColor;
        this.previous = this.mainColors[0];
    }

    next(){
        if(this.current === this.waitColor)
            [this.current, this.previous] = [this.mainColors.filter(c => c !== this.previous)[0], this.current];
        else
            [this.previous, this.current] = [this.current, this.waitColor];
    }
}


window.onload = function(){
    // таймер смены цвета
    let interval;
    // хранилище состояний
    let lightsStates = new LightsState();
    // ссылка на элемент разметки для светофора с одной лампой
    let $lSingle = $('lighter-single');

    // смена цвета
    function switchLights()
    {
        lightsStates.next();
        // смена в одноламповом светофоре
        $lSingle.classList.remove(lightsStates.previous);
        $lSingle.classList.add(lightsStates.current);
        // смена в трёхламповом светофоре
        $(lightsStates.previous).classList.remove('on');
        $(lightsStates.current).classList.add('on');
    }

    // первичная установка
    $(lightsStates.current).classList.add('on');
    $lSingle.classList.add(lightsStates.current);
    interval = setInterval(switchLights, 3000);

    // Обработчики кнопок
    $('lightersOn').onclick = () => interval = setInterval(switchLights, 3000);
    $('lightersOff').onclick = () => clearInterval(interval);
}