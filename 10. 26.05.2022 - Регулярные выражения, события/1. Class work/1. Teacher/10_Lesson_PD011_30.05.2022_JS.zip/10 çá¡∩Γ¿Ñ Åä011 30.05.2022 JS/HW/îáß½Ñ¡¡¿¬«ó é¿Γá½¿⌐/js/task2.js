
// Модуль для работы задания
const Task2 = (function(){
    // конструктор базового объекта - личности
    class Person {
        constructor(id, surnameNP, brithDate, city) {
            // фамилия и инициалы
            this._surnameNP = surnameNP;
            // дата рождения
            this._brithDate = brithDate;
            // город проживания
            this._city = city;

            this._id = id;
        }

        get id() { return this._id; }
        set id(value) { this._id = value; }

        get surnameNP() { return this._surnameNP; }
        set surnameNP(value) { this._surnameNP = value || 'не задано'; }

        get brithDate() { return this._brithDate; }
        set brithDate(value) { this._brithDate = value ?? new Date(2000, 1, 1); }

        get city() { return this._city; }
        set city(value) { this._city = value || 'не задано'; }

        toString(){ return `${this._surnameNP} ${this._brithDate}г.р., г.${this._city}`; }

        tableRowPartial(){
            return `<td class="align-left">${this._surnameNP}</td>
                    <td>${this._brithDate.toLocaleDateString()}</td>
                    <td class="align-left">${this._city}</td>`;
        }

        toTableRow(row){
            return `
            <tr id =${this._id}>
                <td>${row}</td>
                ${this.tableRowPartial()}
            </tr>`;
        }

        equals(other){
            return this._surnameNP === other.surnameNP && this._brithDate === other.brithDate &&
                this._city === other.city;
        }
    }

    // конструктор для объекта клиента
    class Customer extends Person{
        constructor(id, surnameNP, brithDate, city, requestDate, service) {
            super(id, surnameNP, brithDate, city);
            // дата обращения
            this.requestDate = requestDate;
            // услуга - название и стоимость
            this.service = service;
        }

        get requestDate() { return this._requestDate; }
        set requestDate(value) { this._requestDate = value ?? new Date(); }

        get service() { return this._service; }
        set service(value) {
            this._service = {
                name: value?.name || 'не задано',
                price: value?.price >= 0 ? value?.price : 0
            }
        }

        tableRowPartial() {
            return `${super.tableRowPartial()}
                    <td>${this._requestDate.toLocaleDateString()}</td>
                    <td class="align-left">${this._service.name}</td>
                    <td>${this._service.price}</td>`;
        }

        toString(){ return `${super.toString()}. Заявка: ${this._requestDate}, ${this._service.name} ${this._service.price}`; }

        equals(other) {
            return super.equals(other) && this._requestDate === other.requestDate && this._service === other.service;
        }
    }

    // конструктор для объекта мастера
    class Artisan extends Person {
        constructor(id, surnameNP, brithDate, city, laborRate, startDate, state) {
            super(id, surnameNP, brithDate, city);
            this.laborRate = laborRate;
            this.startDate = startDate;
            this.state = state;
        }

        get laborRate() { return this._laborRate; }
        set laborRate(value) { this._laborRate = value > 0 ? value : 1; }

        get startDate() { return this._startDate; }
        set startDate(value) { this._startDate = value ?? new Date(); }

        get state() { return this._state; }
        set state(value) { this._state = value || 'не указано'; }

        tableRowPartial() {
            return `${super.tableRowPartial()}
                    <td>${this._startDate.toLocaleDateString()}</td>
                    <td>${this._laborRate}</td>
                    <td class="align-center">${this._state}</td>`;
        }

        toString(){ return `${super.toString()}.С ${this._startDate}, ставка: ${this._laborRate}%.
         Статус: ${this._state}.`; }

        equals(other) {
            return super.equals(other) && this.startDate === other.startDate && this.laborRate === other.laborRate;
        }
    }

    class RepairShop {
        constructor(customers, artisans) {
            this.customers = customers;
            this.artisans = artisans;
        }

        orderCustomersByName(){
            return [...this.customers].sort((a, b) => a.surnameNP.localeCompare(b.surnameNP));
        }

        orderArtisansByLaborRate(){
            return [...this.artisans].sort((a, b) => a.laborRate - b.laborRate);
        }

        getMaxLaborRateArtisans(){
            let maxLaborRate = Math.max(...this.artisans.map(a => a.laborRate));
            return this.artisans.filter(a => a.laborRate === maxLaborRate);
        }


        customersToTable(caption){ return RepairShop.customersToTable(this.customers, caption = 'Клиенты'); }

        static customersToTable(customers, caption) {
            let table = `<table class="table-customers">
                        <caption>${caption}</caption>
                      <thead><tr>
                        <td>№</td>
                        <td>Фамилия И.О.</td>
                        <td>Дата рождения</td>
                        <td>Город</td>
                        <td>Дата обращения</td>
                        <td>Название услуги</td>
                        <td>Стоимость услуги</td>
                      </tr></thead>`;
            customers.forEach((item, index) => table += item.toTableRow(index + 1));
            table += '</table>';

            return table;
        }

        artisansToTable(caption){ return RepairShop.artisansToTable(this.artisans, caption = 'Мастера'); }

        static artisansToTable(artisans, caption) {
            let table = `<table class="table-artisans">
                        <caption>${caption}</caption>
                      <thead><tr>
                        <td>№</td>
                        <td>Фамилия И.О.</td>
                        <td>Дата рождения</td>
                        <td>Город</td>
                        <td>Работает с</td>
                        <td>Тарифная ставка</td>
                        <td>Статус</td>
                      </tr></thead>`;
            artisans.forEach((item, index) => table += item.toTableRow(index + 1));
            table += '</table>';

            return table;
        }
    }

    return {

        shop: new RepairShop([
            new Customer('c1', "Гущин Ф. А.", new Date('5/11/1986'), 'Донецк', new Date('4/23/2022'),({name: 'замена компрессора', price: 3000 })),
            new Customer('c2', "Симонов Н.А.", new Date('1/30/1973'), 'Горловка',new Date('5/15/2022'),({name: 'замена сливного насоса', price: 700})),
            new Customer('c3', "Молчанов А.А.", new Date('6/9/1994'), 'Макеевка',new Date('5/17/2022'),({name: 'замена ТЭНа', price: 1500})),
            new Customer('c4', "Емельянов Ц.И.", new Date('2/6/1977'), 'Иловайск',new Date('4/26/2022'),({name: 'ремонт платы управления', price: 2500})),
            new Customer('c5', "Беляков К.В.", new Date('8/12/1969'), 'Енакиево',new Date('3/31/2022'),({name: 'ремонт пружины дверцы', price: 1300})),
            new Customer('c6', "Доронин У.И.", new Date('11/14/1989'), 'Донецк',new Date('4/29/2022'),({name: 'замена сливного шланга', price: 1000})),
            new Customer('c7', "Несвитайло Д.П.", new Date('2/7/1999'), 'Ясиноватая',new Date('3/22/2022'),({name: 'заправка хладагентом', price: 1200})),
            new Customer('c8', "Кондратьев М.Ю.", new Date('6/5/1986'), 'Макеевка',new Date('4/14/2022'),({name: 'замена термоизоляции', price: 900})),
            new Customer('c9', "Симонов Ч.В.", new Date('8/22/1991'), 'Горловка',new Date('5/17/2022'),({name: 'очистка дренажной' +
                    ' системы', price: 1000})),
            new Customer('c10', "Тягай С.В.", new Date('9/17/1962'), 'Иловайск',new Date('5/28/2022'),({name: 'замена термостата', price: 2500})),
            new Customer('c11', "Василенко В.Ю.", new Date('4/13/1973'), 'Донецк',new Date('5/11/2022'),({name: 'ремонт блока управления', price: 4000})),
            new Customer('c12', "Дзюба Д.Д.", new Date('12/24/1978'), 'Донецк',new Date('4/14/2022'),({name: 'замена сенсорного датчика', price: 2800})),
        ],[
            new Artisan('a1', "Константинов Д.П.", new Date('1/30/1981'), 'Донецк', 10, new Date('1/18/2016'),'свободен'),
            new Artisan('a2', "Лукин А.В.", new Date('11/21/1984'), 'Макеевка', 15, new Date('5/2/2012'),'занят'),
            new Artisan('a3', "Марков Й.В.", new Date('12/16/1988'), 'Донецк', 20, new Date('4/6/2015'),'свободен'),
            new Artisan('a4', "Несвитайло Р.В.", new Date('6/2/1976'), 'Иловайск', 15, new Date('5/11/2017'),'занят'),
            new Artisan('a5', "Титов П.Ф.", new Date('4/8/1971'), 'Ясиноватая', 10, new Date('3/25/2019'),'свободен'),
            new Artisan('a6', "Анисимов Е.В.", new Date('4/11/1972'), 'Донецк', 25, new Date('2/21/2013'),'занят'),
            new Artisan('a7', "Миклашевский Д.В.", new Date('5/14/1981'), 'Енакиево', 22, new Date('7/22/2016'),'свободен'),
            new Artisan('a8', "Зыков Э.Б.", new Date('6/12/1980'), 'Донецк', 25, new Date('5/7/2016'),'занят'),
            new Artisan('a9', "Комаров С.Л.", new Date('8/25/1968'), 'Макеевка', 10, new Date('7/9/2019'),'занят'),
            new Artisan('a10',"Рогов Э.Э.", new Date('9/22/1966'), 'Донецк', 15, new Date('9/11/2020'),'свободен'),
            new Artisan('a11',"Королёв О.В.", new Date('1/28/1977'), 'Донецк', 20, new Date('10/12/2020'),'занят'),
            new Artisan('a12',"Воронцов И.А.", new Date('3/18/1970'), 'Горловка', 25, new Date('11/11/2017'),'занят'),
        ]),

        customersToTable: function(customers, caption = 'Клиенты') { return RepairShop.customersToTable(customers, caption); },
        artisansToTable: function(artisans, caption = "Мастера") { return RepairShop.artisansToTable(artisans, caption); }
    }
})();


(function(){
    window.onload = function(){
        const delay = 10_000;

        let $c = $('customers');
        let $a = $('artisans');

        $c.innerHTML = Task2.shop.customersToTable();
        $a.innerHTML = Task2.shop.artisansToTable();

        let timerCust;
        let timerArtis;

        // сортировка клиентов
        $('sortCustomersName').onclick = () =>
            $c.innerHTML = Task2.customersToTable(Task2.shop.orderCustomersByName())

        // выделение клиентов
        $('markCustomers').onclick = function(){
            Task2.shop.customers.filter(c => c.city === 'Иловайск').forEach(c => $(c.id).classList.add('hl-row'));
            clearTimeout(timerCust);
            timerCust = setTimeout(() => $c.innerHTML = Task2.shop.customersToTable(), delay);
        }

        // вывести исходные данные клиентов
        $('customersReset').onclick = () => $c.innerHTML = Task2.shop.customersToTable();

        // сортировка мастеров
        $('sortArtisansLabor').onclick = () =>
            $a.innerHTML = Task2.artisansToTable(Task2.shop.orderArtisansByLaborRate());

        // выделение мастеров
        $('markArtisans').onclick = function(){
            Task2.shop.getMaxLaborRateArtisans().forEach(a => $(a.id).classList.add('hl-row'));
            clearTimeout(timerArtis);
            timerCust = setTimeout(() => $a.innerHTML = Task2.shop.artisansToTable(), delay);
        }

        // вывести исходные данные мастеров
        $('artisansReset').onclick = () => $a.innerHTML = Task2.shop.artisansToTable();
    }
})();