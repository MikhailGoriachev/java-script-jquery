// Модуль второй задачи
const Task1 = (function () {
    // Конструктор объекта данных о погоде
    class Weather {
        constructor(t, press, humid, windSpeed, windDirection, climate) {
            this.temperature = t;
            this.pressure = press;
            this.humidity = humid;
            this.wind = {
                speed: windSpeed,
                direction: windDirection
            };
            this.climate = {
                description: climate.description,
                img: climate.img
            }
        }

        toHtml() {
            return `<div class="weather-block"><img src='../images/weather/${this.climate.img}' alt ="pic" width="75" height="75"/>
                    <div>${this.climate.description}</div>
                    <div>Температура: ${this.temperature}°С</div>
                    <div>Давление: ${this.pressure} мм рт.ст.</div>
                    <div>Влажность: ${this.humidity}%</div>
                    <div>Ветер: ${this.wind.speed} м/с, ${this.wind.direction}</div></div>`;
        }

        toString() {
            return `${this.climate.description} 
                Температура: ${this.temperature}°С
                Давление: ${this.pressure} мм рт.ст.
                Влажность: ${this.humidity}%
                Ветер: ${this.wind.speed} м/с, ${this.wind.direction}`;
        }

        static climates = {
            cloudy: {description: 'Пасмурно', img: 'cloudy.svg'},
            partlyCloudy: {description: 'Облачно', img: 'partly-cloudy.svg'},
            fair: {description: 'Ясно', img: 'fair.svg'},
            thunder: {description: 'Гроза', img: 'thunder.svg'},
            heavyRain: {description: 'Сильный дождь', img: 'heavy-rain.svg'}
        };

        // Генерация объекта
        static getRandom() {
            let directions = ['С', 'Ю', 'В', 'З', 'Ю-В', 'Ю-З', 'С-В', 'С-З'];
            let climateNames = Object.keys(Weather.climates);
            let climateName = climateNames[getRandomInt(0, climateNames.length - 1)];
            return new Weather(getRandomInt(15, 30),
                getRandomInt(600, 900),
                getRandomInt(20, 80),
                getRandomInt(0, 30), directions[getRandomInt(0, directions.length - 1)],
                Weather.climates[climateName])
        }
    }

    // Конструктор коллекции прогноза погоды на несколько дней
    class MeteoData {
        constructor(n, days = null) {
            this.days = days ?? [...Array(n)].map((item, index) => ({day: MeteoData.dayNames[index], weather: Weather.getRandom()}));
        }

        static dayNames = [
            {ru: 'Понедельник', en: 'monday'}, {ru: 'Вторник', en: 'tuesday'},
            {ru: 'Среда', en: 'wednesday'}, {ru: 'Четверг', en: 'thursday'},
            {ru: 'Пятница', en: 'friday'}, {ru: 'Суббота', en: 'saturday'},
            {ru: 'Воскресенье', en: 'sunday'}
        ]

        // Копия коллекции, отсортированная по уменьшению температуры
        getSortedByTemperatureDesc() {
            return new MeteoData(0, [...this.days].sort((a, b) => b.weather.temperature - a.weather.temperature));
        }

        // Копия коллекции, отсортированная по увеличению давления
        getSortedByPressure() {
            return new MeteoData(0, [...this.days].sort((a, b) => a.weather.pressure - b.weather.pressure));
        }

        // Копия коллекции, отсортированная по уменьшению скорости ветра
        getSortedByWindSpeedDesc() {
            return new MeteoData(0, [...this.days].sort((a, b) => b.weather.wind.speed - a.weather.wind.speed));
        }

        getWindiestDays() {
            let lowestWind = Math.min(...this.days.map(i => i.weather.wind.speed));
            return this.days.filter(item => item.weather.wind.speed === lowestWind).map(i => i.day.en);
        }

        getCalmDays() {
            let highestWind = Math.max(...this.days.map(i => i.weather.wind.speed));
            return this.days.filter(item => item.weather.wind.speed === highestWind).map(i => i.day.en);
        }

        getNorthWindDays(){
            return this.days.filter(item => item.weather.wind.direction === 'С').map(i => i.day.en)
        }

        toHtml() {
            return this.days.reduce((prev, cur) =>
                prev += `<div class="day" id="${cur.day.en}">
                         <div class="hl"><b>${cur.day.ru}</b></div>
                         ${cur.weather.toHtml()}</div>`, '')
        }
    }

    return {
        // Публичные свойства модуля

        weekData: new MeteoData(7),

        clearHighlights: function(weekForecast, except = ""){
            let highlightes = ['hl-windy', 'hl-calm', 'hl-north' ].filter(i => i !== except);
            this.weekData.days.forEach(i => $(i.day.en).classList.remove(...highlightes));
        },

        switchHighlight: function(elements, style){
            this.clearHighlights(this.weekData, style);
            elements.forEach(i => {
                if($(i).classList.contains(style))
                    $(i).classList.remove(style);
                else $(i).classList.add(style);
            })
        }
    }
})();


window.onload = function () {

    const delay = 10_000;
    let clearTimer;
    let $weather = $('weather');

    // Начальный вывод данных
    $weather.innerHTML = Task1.weekData.toHtml();

    // Назначение обработчиков кнопок

    $('sortByTempDesc').onclick = () =>
        $weather.innerHTML = Task1.weekData.getSortedByTemperatureDesc().toHtml();

    $('sortByPressure').onclick = () =>
        $weather.innerHTML = Task1.weekData.getSortedByPressure().toHtml();

    $('sortByWindDesc').onclick = () =>
        $weather.innerHTML = Task1.weekData.getSortedByWindSpeedDesc().toHtml();


    $('highlightWindy').onclick = () => {
        Task1.switchHighlight(Task1.weekData.getWindiestDays(), 'hl-windy');
        clearTimeout(clearTimer);
        clearTimer = setTimeout(Task1.clearHighlights, delay, Task1.weekData);
    };

    $('highlightCalm').onclick = () => {
        Task1.switchHighlight(Task1.weekData.getCalmDays(), 'hl-calm');
        clearTimeout(clearTimer);
        clearTimer = setTimeout(Task1.clearHighlights, delay, Task1.weekData);
    };

    $('highlightNorthWind').onclick = () => {
        Task1.switchHighlight(Task1.weekData.getNorthWindDays(), 'hl-north');
        clearTimeout(clearTimer);
        clearTimer = setTimeout(Task1.clearHighlights, delay, Task1.weekData);
    };


    $('reset').onclick = () => $weather.innerHTML = Task1.weekData.toHtml();
};

