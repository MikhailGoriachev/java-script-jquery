/*
. Спроектировать класс в синтаксисе ES6+ для представления данных о погоде:
 температура, давление, влажность, скорость и направление ветра,
 графическое отображение атмосферных явлений (ясно, облачно, дождь,
 и т.д. – не более 5). Определите метод формирования строки для вывода
 данных в разметку. Переопределите метод toString() для простого вывода в
 консоль. Создайте массив данных о погоде за неделю, выведите его на страницу.
 По командам от кнопок выводите данные о погоде, упорядоченные (только при
 выводе, порядок элементов в исходном массиве не менять): по убыванию
 температуры, по возрастанию давления, по убыванию скорости ветра. По командам
 от кнопок выделяйте самые ветреные и самые тихие дни, дни с северным ветром.
 Выделение должно сниматься через 10 секунд. Предусмотрите кнопку для вывода
 исходного массива погодных явлений, без выделений элементов.
 */


class Weather {
    constructor(num, temperature, pressure, humidity, wind, weatherImg) {
        this.num = num;                // номер дня недели
        this.temperature = temperature;// температура
        this.pressure = pressure;      // давление
        this.humidity = humidity;      // влажность
        this.wind = {
            speed: wind.speed,         // скорость ветра
            direction: wind.direction, // направление ветра
        };
        this.weatherImg = weatherImg;  // графическое отображение атмосферного явлений
    } // constructor

    // геттеры и сеттеры
    get temperature() { return this._temperature }
    set temperature(value) { this._temperature = value }

    get pressure() { return this._pressure }
    set pressure(value) { this._pressure = value < 1200 ? value : 1000; }

    get humidity() { return this._humidity }
    set humidity(value){ this._humidity = value > 0 ? value : 68; }

    get weatherImg() { return this._weatherImg }
    set weatherImg(value){ this._weatherImg = value }


    // вывод объекта в строку
    toString() {
        return `День ${this.num}: температура: ${this.temperature}&#176;C,
            давление: ${this.pressure} гПа, влажность: ${this.humidity}%, 
            скорость ветра: ${this.wind.speed} ми/ч, направление ветра: ${this.wind.direction}`
    }// toString


    // формирование строки для вывода
    toShow() {
        return `<div class="object-block" id="id${this.num}"><h3>День ${this.num}:</h3><p>       
            <img src='../img/task1/${this.weatherImg}' height='120' alt="pic"/><br>
            Температура: ${this.temperature}&#176;C<br>
            Давление: ${this.pressure} гПа<br>
            Влажность: ${this.humidity}%<br>
            Скорость ветра: ${this.wind.speed} ми/ч<br>
            Направление ветра: ${this.wind.direction}</p></div>`
    } // toShow


    // для элемента массива формируем идентификатор, находим соответствующий блок div
    // и меняем ее оформление
    toShowMark(predicate, num) {
        if (predicate(this))
            $("id" + `${this.num}`).style.backgroundColor = "lightblue";
    } // toShowMark


} // Weather


// коллекция погодных явлений за неделю, обработка погодных явлений по заданию
class WeatherConditions {
    constructor(conditions) {
        this.conditions = conditions;
    }

    // формирование коллекции погодных явлений
    static initialize() {
        return [
            new Weather(1, getRandomInt(20,27),1012,82,{speed:4, direction:"З"}, "sun.png"),
            new Weather(2, getRandomInt(14,17), getRandomInt(1000,1100), getRandomInt(40,100),{speed:7, direction:"З"}, "cumulonimbus.png"),
            new Weather(3, getRandomInt(10,12), getRandomInt(1000,1160), getRandomInt(80,100),{speed:10, direction:"С-В"}, "slight-rain.png"),
            new Weather(4, getRandomInt(8,10),  getRandomInt(1000,1160), getRandomInt(80,100),{speed:10, direction:"С"}, "thunderstorm.png"),
            new Weather(5, getRandomInt(10,12), getRandomInt(1000,1160), getRandomInt(80,100),{speed:10, direction:"В"}, "slight-rain.png"),
            new Weather(6, getRandomInt(14,17), getRandomInt(1000,1100), getRandomInt(40,100),{speed:7, direction:"C-З"}, "cumulonimbus.png"),
            new Weather(7, getRandomInt(20,27),1012,82,{speed:4, direction:"З"}, "sun.png"),
        ];
    } // generate


    // вывод коллекции в разметку по кликам на кнопки
    static show(title, conditions) {
        $("title").innerText = title;
        $("weather").innerHTML = conditions.reduce((acc, c) => acc + c.toShow(), "");
    } // show


    // изменение стиля в строках таблицы, для которых сработает предикат
    static showMarked(title, conditions, predicate) {
        WeatherConditions.show(title, conditions);

        conditions.forEach(c => c.toShowMark(predicate));
    } // showMarked


    // формирование копии коллекции сведений о погоде, упорядоченных
    // по убыванию температуры
    orderByTemperatureDesc() {
        return [...this.conditions].sort((c1, c2) => c2.temperature - c1.temperature);
    } // orderByTemperatureDesc

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по возрастанию давления
    orderByPressure() {
        return [...this.conditions].sort((c1, c2) => c1.pressure - c2.pressure);
    } // orderByPressure

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по убыванию скорости ветра
    orderByWindSpeedDesc() {
        return [...this.conditions].sort((c1, c2) => c2.wind.speed - c1.wind.speed);
    } // orderByWindSpeedDesc

    // получение максимальной скорости ветра
    getMaxWindSpeed() {
        return Math.max(...this.conditions.map(c =>c.wind.speed));
    }

    // получение минимальной скорости ветра
    getMinWindSpeed() {
        return Math.min(...this.conditions.map(c =>c.wind.speed));
    }


} // class WeatherConditions


window.onload = function() {
    // массив погодных явлений, начальный вывод массива погодных явлений
    let weatherConditions = new WeatherConditions(WeatherConditions.initialize());
    WeatherConditions.show(
        "Сведения о погоде за последние 7 дней",
        weatherConditions.conditions
    );


    // демонстрация метода toString() при выводе в консоль
    console.log(`${weatherConditions.conditions[0]}`);

    // вывод массива сведений о погоде
    $("btnShow").onclick = () => WeatherConditions.show(
        "Сведения о погоде за последние 7 дней",
        weatherConditions.conditions
    );

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по убыванию температуры
    $("btnOrder1").onclick = () => WeatherConditions.show(
        "Сведения о погоде за последние 7 дней, упорядоченные по убыванию температуры",
        weatherConditions.orderByTemperatureDesc()
    )

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по возрастанию давления, вывод сформированной коллекции
    $("btnOrder2").onclick = () => WeatherConditions.show(
        "Сведения о погоде за последние 7 дней, упорядоченные по возрастанию давления",
        weatherConditions.orderByPressure()
    );

    // формирование копии коллекции сведений о погоде, упорядоченных
    // по убыванию скорости ветра
    $("btnOrder3").onclick = () => WeatherConditions.show(
        "Сведения о погоде за последние 7 дней, упорядоченные по убыванию скорости ветра",
        weatherConditions.orderByWindSpeedDesc()
    );


    // функция счётчик для снятия выделения по заданию
    function countSelect1(){
        let counter = 0;
        const intervalId = setInterval(() => { $("btnSelect1")
            counter ++;
            if (counter === 5) {
                WeatherConditions.show(
                    "Сведения о погоде за последние 7 дней, выделены самые тихие дни/тихий день",
                    weatherConditions.conditions
                );
                clearInterval(intervalId);
            }
        }, 1000);
    }// countSelect1


    // вывод коллекции сведений о погоде, с выделением строк, соответствующих
    // самым тихим дням
    $("btnSelect1").onclick = () => {
        let minSpeed = weatherConditions.getMinWindSpeed();
        WeatherConditions.showMarked(
            "Сведения о погоде за последние 7 дней, выделены самые тихие дни/тихий день",
            weatherConditions.conditions,
            c => c.wind.speed === minSpeed
        );
        countSelect1();
    };


    // функция счётчик для снятия выделения по заданию
    function countSelect2(){
        let counter = 0;
        const intervalId = setInterval(() => { $("btnSelect2")
            counter ++;
            if (counter === 5) {
                WeatherConditions.show(
                    "Сведения о погоде за последние 7 дней, выделены самые ветреные дни/ветреный день",
                    weatherConditions.conditions
                );
                clearInterval(intervalId);
            }
        }, 1000);
    }// countSelect2

    // вывод коллекции сведений о погоде, с выделением строк, соответствующих
    // самым ветреным дням
    $("btnSelect2").onclick = () => {
        let maxSpeed = weatherConditions.getMaxWindSpeed();
        WeatherConditions.showMarked(
            "Сведения о погоде за последние 7 дней, выделены самые ветреные дни/ветреный день",
            weatherConditions.conditions,
            c => c.wind.speed === maxSpeed
        );
        countSelect2();
    };


    // функция счётчик для снятия выделения по заданию
    function countSelect3(){
        let counter = 0;
        const intervalId = setInterval(() => { $("btnSelect3")
            counter ++;
            if (counter === 10) {
                WeatherConditions.show(
                    "Сведения о погоде за последние 7 дней, выделены дни/день с северным ветром",
                    weatherConditions.conditions
                );
                clearInterval(intervalId);
            }
        }, 1000);
    }// countSelect3

    // вывод коллекции сведений о погоде, с выделением строк, соответствующих
    // дням ссеверным ветром
    $("btnSelect3").onclick = () => {
        WeatherConditions.showMarked(
            "Сведения о погоде за последние 7 дней, выделены дни/день с северным ветром",
            weatherConditions.conditions,
            c => c.wind.direction === "С"
        );
        countSelect3();
    };

} // window.onload