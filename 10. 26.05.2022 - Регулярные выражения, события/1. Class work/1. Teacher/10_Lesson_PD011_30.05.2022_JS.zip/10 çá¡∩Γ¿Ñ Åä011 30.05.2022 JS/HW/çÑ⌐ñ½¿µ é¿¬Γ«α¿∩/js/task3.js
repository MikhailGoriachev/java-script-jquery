// константа для доступа к div элементам
const circles = document.querySelectorAll(".circle");
console.log(circles);

let timerId = setInterval(() =>{
    changeLight()
}, 3000);

let activLight = 0;

function changeLight(){
   circles[activLight].className ='circle';
   // считаем каждый запуск функции
   activLight++;

   if(activLight > 2){
       activLight = 0;
   }

   let currentLight = circles[activLight];
   currentLight.classList.add(currentLight.getAttribute("color"))
}// changeLight

window.onload = function() {
    // назначить обработчики событий
    document.getElementById("btnStop").onclick = cancel;
    document.getElementById("btnStart").onclick = changeLight;
}

function cancel() {
    clearTimeout(timerId);
}