/*
Спроектировать иерархию классов для предприятия ремонта бытовой техники.
Создайте массивы объектов и выполните обработку по заданию. Базовый класс –
персона (фамилия и инициалы, дата рождения, город проживания), производный
от базового класс – клиент (дата обращения за услугой, название услуги,
стоимость услуги), производный от базового класс – мастер (тарифная ставка,
дата начала работы, признак занятости ремонтом). Переопределите методы
toString(), equals() для клиента и мастера. Создайте массивы клиентов и
мастеров (не менее 12 элементов), выводите эти массивы в разметку в порядке
инициализации. По кликам по кнопкам упорядочивайте клиентов при выводе по
алфавиту, мастеров – по тарифной ставке (порядок в исходном массиве не менять).
Также предусмотрите кнопки для вывода массивов без упорядочивания. По кликам
на кнопки выделяйте клиента/клиентов из города Иловайск, мастера/мастеров с
максимальным тарифом. Через 10 с после выполнения команды выводите массивы в
исходном порядке, без выделения.
 */

// Базовый класс, описывающий персону
class Person{
    constructor(num, fullName, yearBirth, city) {
        this.num = num;
        this.fullName = fullName;
        this.yearBirth = yearBirth;
        this.city = city;
    }

    // геттеры и сеттеры
    get fullName() { return this._fullName }
    set fullName(value) { this._fullName = value }

    get yearBirth() {return this._yearBirth;}
    set yearBirth(value) {
        if (value > 0)
            this._yearBirth = value;
    }

    get city() { return this._city }
    set city(value) { this._city = value }

    // переопределение метода toString()
    toString() {
        return `Персона ${this.num}: ФИО: ${this._fullName},
            год рождения: ${this._yearBirth} г., город проживания: ${this._city}`
    }// toString

    toShow() {
        return `<div class="object-block"><h3>Персона ${this.fullName}</h3><p>       
            <br>
            Год рождения: ${this.yearBirth}г.<br>
            Город проживания: ${this.city}<br></div>`
    } // toShow

}// class Person

// Производный класс – клиент
class Client extends Person{
    constructor(num, fullName, yearBirth, city, dateService, nameService, price, avatarImg) {
        super(num, fullName, yearBirth, city);
        this.dateService = dateService;
        this.nameService = nameService;
        this.price = price;
        this.avatarImg = avatarImg;
    }

    // геттеры и сеттеры
    get dateService() { return this._dateService }
    set dateService(value) { this._dateService = value }

    get nameService() { return this._nameService }
    set nameService(value) { this._nameService = value }

    get price() {return this._price;}
    set price(value) {
        if (value > 0)
            this._price = value;
    }

    get avatarImg() { return this._avatarImg }
    set avatarImg(value){ this._avatarImg = value }

    // переопределение метода toString()
    toShow() {
        return `<div class="object-block" id="id${this.num}"><h3>Клиент ${this.num}:</h3><p>
            <img src='../img/task2/${this.avatarImg}' height='120' alt="pic"/><br>
            ФИО: ${this._fullName}<br>
            Год рождения: ${this._yearBirth}г.<br>
            Город проживания: ${this._city}<br>
            Дата обращения: ${this._dateService}<br>
            Название услуги: ${this._nameService}<br>
            Стоимость услуги: ${this._price}</p></div>`
    } // toShow
}// class Client


// Производный класс – мастер
class Master extends Person{
    constructor(num, fullName, yearBirth, city, tariffRate, dateStart, employment, avatarImg) {
        super(num, fullName, yearBirth, city);
        this.tariffRate = tariffRate;
        this.dateStart = dateStart;
        this.employment = employment;
        this.avatarImg = avatarImg;
    }

    // геттеры и сеттеры
    get tariffRate() {return this._tariffRate;}
    set tariffRate(value) {
        if (value > 0)
            this._tariffRate = value;
    }

    get dateStart() { return this._dateStart }
    set dateStart(value) { this._dateStart = value }

    get employment() { return this._employment }
    set employment(value){ this._employment = value }

    get avatarImg() { return this._avatarImg }
    set avatarImg(value){ this._avatarImg = value }

    // переопределение метода toString()
    toShowMaster() {
        return `<div class="object-block" id="id${this.num}"><h3>Мастер ${this.num}:</h3><p>
            <img src='../img/task2/${this.avatarImg}' height='120' alt="pic"/><br>
            ФИО: ${this._fullName}<br>
            Год рождения: ${this._yearBirth}г.<br>
            Город проживания: ${this._city}<br>
            Тарифная ставка: ${this._tariffRate}<br>
            Дата начала работы: ${this._dateStart}<br>
            Занятость ремонтом: ${this._employment}</p></div>`
    } // toShowMaster
}// class Client


// Класс для работы с коллекцией
class RepairEnterprise{
    constructor(repairs, masters) {
        this.repairs = repairs;
        this.masters = masters;
    }

    static initialize(){
        return[
            new Client(1,"Серов В.И.", 1978, "Донецк",
                format(new Date('2022', '5', '28')), "ремонт моноблока", 800, "avatar-1.png"),
            new Client(2,"Кулик В.О.", 1972, "Донецк",
                format(new Date('2022', '5', '22')), "проблемы с загрузкой ОС", 1200, "avatar-2.png"),
            new Client(3,"Ветров С.И.", 1985, "Иловайск",
                format(new Date('2022', '5', '10')), "ремонт звука", 500, "avatar-3.png"),
        ];
    }

    static initializeMaster(){
        return[
            new Master(1,"Богдан С.Ю.",1974, "Макеевка", 450,
                //format(new Date('2022', '5', '25')), Boolean('свободен'), "avatar-1.png"),
                format(new Date('2022', '5', '25')), "свободен", "worker-1.png"),
            new Master(2,"Витько С.Л.",1971, "Макеевка", 600,
                format(new Date('2022', '5', '12')), "занят", "worker-1.png"),
        ];
    }

    // вывод коллекции в разметку по кликам на кнопки
    static show(title, repairs) {
        $("title").innerText = title;
        $("repair").innerHTML = repairs.reduce((acc, c) => acc + c.toShow(), "");
    } // show

    static showMaster(title, masters) {
        $("titlem").innerText = title;
        $("master").innerHTML = masters.reduce((ass, s) => ass + s.toShowMaster(), "");
    } // showMaster


    // упорядочивание клиентов по алфавиту
    orderByFullName() {
        return [...this.repairs].sort(function (c1, c2) {
            let nameA=c1.fullName.toLowerCase(), nameB=c2.fullName.toLowerCase()
            if (nameA < nameB) //сортируем строки по возрастанию
                return -1
            if (nameA > nameB)
                return 1
        })
    } // orderByFullName


    // упорядоченныe элементы по тарифной ставке
    orderByTariff() {
        return [...this.masters].sort((c1, c2) => c1.tariffRate - c2.tariffRate);
    } // orderByTariff

}// class RepairEnterprise


window.onload = function() {
    // массив клиентов, начальный вывод массива клиентов
    let repairEnterprise = new RepairEnterprise(RepairEnterprise.initialize());
    RepairEnterprise.show(
        "Сведения о клиентах ремонтной мастерской",
        repairEnterprise.repairs
    );

    // массив мастеров, начальный вывод массива мастеров
    let masterEnterprise = new RepairEnterprise(RepairEnterprise.initializeMaster());
    RepairEnterprise.showMaster(
        "Сведения о мастерах ремонтной мастерской",
        masterEnterprise.masters
    );

    // вывод массива клиентoв ремонтной мастерской
    $("btnShow").onclick = () => RepairEnterprise.show(
        "Сведения о клиентах ремонтной мастерской",
        repairEnterprise.repairs
    );


    // вывод массива мастеров ремонтной мастерской
    $("btnShowMaster").onclick = () => RepairEnterprise.showMaster(
        "Сведения о мастерах ремонтной мастерской",
        masterEnterprise.masters
    );


    // упорядочивание клиентов по алфавиту
    $("btnOrder1").onclick = () => RepairEnterprise.show(
        "Сведения о клиентах ремонтной мастерской, упорядоченные по ФИО",
        repairEnterprise.orderByFullName()
    );

    // упорядоченные по тарифной ставке
    $("btnOrderTariff").onclick = () => RepairEnterprise.showMaster(
        "Сведения о мастерах ремонтной мастерской, упорядоченные по" +
        " тарифной ставке",
        masterEnterprise.orderByTariff()
    );
} // window.onload


// формат даты
function format(inputDate) {
    let date, month, year;

    date = inputDate.getDate();
    month = inputDate.getMonth() + 1;
    year = inputDate.getFullYear();

    date = date
        .toString()
        .padStart(2, '0');

    month = month
        .toString()
        .padStart(2, '0');

    return `${date}/${month}/${year}`;
}
