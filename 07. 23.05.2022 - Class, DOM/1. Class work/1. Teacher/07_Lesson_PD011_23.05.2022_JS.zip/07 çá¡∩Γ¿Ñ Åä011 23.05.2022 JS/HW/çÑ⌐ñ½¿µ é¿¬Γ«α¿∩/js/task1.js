/*
Задача1.
Разработайте иерархию "классов" для представления объемных фигур.

Разработай методы для вычисления площади поверхности, объема фигуры,
вывода данных по фигуре и сравнения фигур по объему.
!! вывести картинку фигуры !!

Реализуйте "классы" для представления сферы, конуса и цилиндра.

Разместите объекты этих классов в массиве.
Отсортируйте массив по убыванию объемов.
Отсортируйте массив по возрастанию площадей поверхности.
*/


// класс сфера - базовый класс
function Sphere(radius){

    // определения методов и свойств
    // радиус
    this.radius = radius;

    // вычисляемый метод  для объёма
    Sphere.prototype.getVolume = function(){
        return 4 / 3 * Math.PI *(radius * radius * radius);
    }// getVolume


    // вычисляемый метод  для площади
    Sphere.prototype.getArea = function(){
        return 4 * Math.PI * (radius * radius);
    }// getArea


    // переопределение метода toString()
    Sphere.prototype.toString = function() {
        return `<td>
                <img src='../img/sphere.png' alt='pic' height="100" />
                </td>
                <td>${this.radius}</td>
                <td></td><td>${this.getVolume().toFixed(3)}</td>
                <td>${this.getArea().toFixed(3)}</td> `;
    } // toString
}


// класс конус
function Conoid(radius, height){
    Sphere.call(this, radius);

    // высота
    this.hight = height;

    // вычисляемый метод  для объёма
    Conoid.prototype.getVolume = function (){
        return Math.PI * radius * radius * radius / 3;
    }// getVolume


    // вычисляемый метод  для площади
    Conoid.prototype.getArea = function (){
        // вычисление образующей
        let l = Math.sqrt(height * height + radius * radius);
        return Math.PI * radius * l + Math.PI * radius * radius;
    }// getArea

    // переопределение метода toString()
    Conoid.prototype.toString = function() {
        return `<td>
                <img src='../img/conoid.png' alt='pic' height="100" />
                </td>
                <td>${this.radius}</td>               
                <td>${this.hight}</td>
                <td>${this.getVolume().toFixed(3)}</td>                
                <td>${this.getArea().toFixed(3)}</td>`;
    } // toString

}// Conoid


// класс цилиндр
function Cylinder(radius, height){
    Sphere.call(this, radius);

    // высота
    this.hight = height;

    // вычисляемый метод  для объёма
    Cylinder.prototype.getVolume = function (){
        return Math.PI * radius * radius * height;
    }// getVolume


    // вычисляемый метод  для площади
    Cylinder.prototype.getArea = function (){
        return 2 * Math.PI * radius * height;
    }// getArea

    // переопределение метода toString()
    Cylinder.prototype.toString = function() {
        return `<td>
                <img src='../img/cylinder.png' alt='pic' height="100"/>
                </td>
                <td>${this.radius}</td>               
                <td>${this.hight}</td>
                <td>${this.getVolume().toFixed(3)}</td>                
                <td>${this.getArea().toFixed(3)}</td>`;
    } // toString

}// Cylinder

const min = 2, max = 5;

let r1 = getRandom(min, max).toFixed(3);
let r2 = getRandom(min, max).toFixed(3);
let h1 = getRandom(min, max).toFixed(3);
let h2 = getRandom(min, max).toFixed(3);


// массив фигур
function showFigure() {
    let figures = initialize();

    figures.forEach(figure => document.write(`<tr>${figure.toString()}</tr>`));
}

// массив фигур упорядоченный по убыванию объемов
function sortByVolume(){
    let figures = initialize();

    figures.sort(function (a, b) {return (b.getVolume() - a.getVolume())});
    figures.forEach(figure => document.write(`<tr>${figure.toString()}</tr>`));
}

// массив фигур упорядоченный по возрастанию площадей поверхности
function sortByArea(){
    let figures = initialize();

    figures.sort(function (a, b) {return (a.getArea() - b.getArea())});
    figures.forEach(figure => document.write(`<tr>${figure.toString()}</tr>`));
}


function initialize(){
    return [
        new Sphere(r1),
        new Conoid(r1, h1),
        new Cylinder(r1, h1),
        new Sphere(r2),
        new Conoid(r2, h2),
        new Cylinder(r2, h2)
    ];
}