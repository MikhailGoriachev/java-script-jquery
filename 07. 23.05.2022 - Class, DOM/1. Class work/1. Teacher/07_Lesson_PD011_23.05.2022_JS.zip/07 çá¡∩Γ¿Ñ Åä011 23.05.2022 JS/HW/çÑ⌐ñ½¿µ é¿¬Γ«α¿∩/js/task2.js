/*
Задача 2. Создайте класс Vehicle (транспортное средство).
На его основе реализовать классы Plane (самолет), Саг (автомобиль) и Ship (корабль).
•	Классы должны иметь возможность задавать и получать параметры средств
  передвижения (географические координаты, цена, скорость, год выпуска) с
  помощью свойств.
•	Дополнительно для самолета должна быть определена высота, для самолета
  и корабля — количество пассажиров, для корабля — порт приписки.
Создайте массив транспортных средств, состоящий из 2х самолетов,
3х кораблей и 5и автомобилей. В массиве найти:
•	самое старое транспортное средство
•	самое быстрое и самое медленное транспортные средства (может быть найдено
  больше 1 транспортного средства)
 */

// класс Vehicle - базовый класс
class Vehicle{
   constructor(picture,latitude,longitude,price, speed, year) {
       this.coordinates = {
           x : latitude,       // широта
           y : longitude       // долгота
       };
       this.picture = picture; // картинка
       this.price = price;     // цена
       this.speed = speed;     // скорость
       this.year = year;       // год выпуска

   }

    // переопределение метода toString()
    toString = function() {
        return `<td>
                <img src='../img/task2/${this.picture}' alt='pic' height="80" width="80" />
                </td>
                <td>${this.coordinates.x}&#9702 ${this.coordinates.y}&#9702</td>
                <td>${this.price}</td>
                <td>${this.speed}</td>
                <td>${this.year}</td> 
                <td></td><td></td>`;
    } // toString

}// Vehicle

// класс автомобиль
class Car extends Vehicle{

    // переопределение метода toString()
    toString = function() {
        return `<td>
                <img src='../img/task2/${this.picture}' alt='pic' height="80" width="80" />
                </td>                
                <td>${this.coordinates.x}&#176 ${this.coordinates.y}&#176</td>
                <td>${this.price}</td>
                <td>${this.speed}</td>
                <td>${this.year}</td> 
                <td></td><td></td>`;
    } // toString

}// class Car


// класс самолёт
class Plane extends Vehicle{
    constructor(picture,latitude,longitude,price, speed, year, pax, altitude ) {
        super(picture,latitude,longitude,price, speed, year);
        this.altitude = altitude; //высота полёта
        this.pax = pax;           // кол-во пассажиров
    }

    // переопределение метода toString()
    toString = function() {
        return `<td>
                <img src='../img/task2/${this.picture}' alt='pic' height="80" width="80" />
                </td>                
                <td>${this.coordinates.x}&#176 ${this.coordinates.y}&#176</td>                
                <td>${this.price}</td>
                <td>${this.speed}</td>
                <td>${this.year}</td> 
                <td>${this.pax}</td>
                <td>${this.altitude}</td>`;
    } // toString
}// class Plane


// класс корабль
class Ship extends Vehicle{
    constructor(picture,latitude,longitude,price, speed, year, pax, homePort ) {
        super(picture,latitude,longitude,price, speed, year);
        this.homePort = homePort; // порт приписки
        this.pax = pax;           // кол-во пассажиров
    }

    // переопределение метода toString()
    toString = function() {
        return `<td>
                <img src='../img/task2/${this.picture}' alt='pic' height="80" width="80" />
                </td>                
                <td>${this.coordinates.x}&#176 ${this.coordinates.y}&#176</td>                
                <td>${this.price}</td>
                <td>${this.speed}</td>
                <td>${this.year}</td> 
                <td>${this.pax}</td>
                <td>${this.homePort}</td>`;
    } // toString
}// class Ship


// вывод массива по заданию
function showVehicle(){
    let vehicles = initialize();

    vehicles.forEach(vehicle => document.write(`<tr>${vehicle.toString()}</tr>`));


    // самое старое транспортное средство
    let oldVehicle = Math.min(...vehicles.map(n => n.year));


    // найти минимальную скорость в массиве транспортных средств
    let minSpeed =  Math.min(...vehicles.map(n => n.speed));

    // найти максимальную скорость в массиве транспортных средств
    let maxSpeed =  Math.max(...vehicles.map(n => n.speed));


    // вывод статистики
    document.write(`
        <tr>
            <td colspan="7">
                <h3>Статистика по заданию:</h3>
                <ul>
                    <li>Cамое старое транспортное средство: <b>${oldVehicle}г.</b></li>
                    <li>Mинимальная скорость транспортного средства: <b>${minSpeed}км/ч</b></li>
                    <li>Mаксимальная скорость транспортного средства: <b>${maxSpeed}км/ч</b></li>
                </ul>
            </td>
        </tr>`);

}// showVehicle


// поиск минимальной скорости транспортного средства
function showMinSpeed(){
    let vehicles = initialize();

    let minSpeed = vehicles.map((m) => m.speed);
    let mintemp = Math.min(...minSpeed);
    let itemSpeed = vehicles.filter(m => m.speed === mintemp);
    itemSpeed.forEach(vehicle => document.write(`<tr>${vehicle.toString()}</tr>`));
}// showMinSpeed

// инициализация массива транспортных средств
function initialize(){
    return [
        new Car("view-of-car.jpg", -112.3, 95.9, 95000, 40, 2006),
        new Plane("view-of-air.jpg", 22.255, -22.255, 12000000, 900, 2002, 360, 19000),
        new Car("view-of-car.jpg", -110.7, 99.4, 100000, 40, 2018),
        new Ship("view-of-ship.jpg", -114.2, 93.7, 8500000, 20, 1990, 22, "Новоазовск"),
        new Car("view-of-car.jpg", -124.3, 94.9, 95000, 35, 2020),
        new Plane("view-of-air.jpg", 24.256, -24.256, 11500000, 1100, 2006, 360, 14000),
        new Ship("view-of-ship.jpg", -110.2, 95.9, 8000000, 20, 1986, 25, "Ростов-на-Дону"),
        new Car("view-of-car.jpg", -133.5, 99.6, 80000, 20, 2005),
        new Car("view-of-car.jpg", -114.6, 95.2, 125000, 55, 2022),
        new Ship("view-of-ship.jpg", -118.4, 97.2, 12000000, 20, 1997, 25, "Керчь")
    ];
}