// Задача 2. Создайте класс Vehicle (транспортное средство). На его основе реализовать классы Plane (самолет),
// Саг (автомобиль) и Ship (корабль).
//          •	Классы должны иметь возможность задавать и получать параметры средств передвижения
//              (географические координаты, цена, скорость, год выпуска) с помощью свойств.
//          •	Дополнительно для самолета должна быть определена высота, для самолета и корабля
//              — количество пассажиров, для корабля — порт приписки.
//
// Создайте массив транспортных средств, состоящий из 2х самолетов, 3х кораблей и 5и автомобилей. В массиве найти:
//          •	самое старое транспортное средство
//          •	самое быстрое и самое медленное транспортные средства
//              (может быть найдено больше 1 транспортного средства)
//

// класс, описывающий автомобиль (базовый)
// этот класс можно использовать в качестве базового (вместо класса Vehicle),
// так как у него нет дополнительных полей
function Car(coordinates, price, velocity, year, vehicleImg) {
    this.coordinates = {                  // географические координаты
        latitude: coordinates.latitude,
        longitude: coordinates.longitude,
    };
    this.price = price;                   // цена
    this.velocity = velocity;             // скорость
    this.year = year;                     // год выпуска
    this.vehicleImg = vehicleImg;         // графическое отображение транспортного средства

    // геттеры
    Car.prototype.getCoordinates = function (){return this.coordinates;}
    Car.prototype.getPrice = function (){return this.price;}
    Car.prototype.getVelocity = function (){return this.velocity;}
    Car.prototype.getYear = function (){return this.year;}
    Car.prototype.getVehicleImg = function (){return this.vehicleImg;}

    // сеттеры
    Car.prototype.setCoordinates = function (value){
        if (-180 <= value.latitude || value.latitude <= 180)
            this.coordinates.latitude = value.latitude;

        if (-180 <= value.longitude || value.longitude <= 180)
            this.coordinates.longitude = value.longitude;
    } // setCoordinates

    Car.prototype.setPrice = function (value){
        if (value >= 0) this.price = value;
    } // setPrice

    Car.prototype.setVelocity = function (value){
        if (value >= 0) this.velocity = value;
    } // setVelocity

    Car.prototype.setYear = function (value){
        if (value <= new Date().getFullYear())
            this.year = value;
    } // setYear

    Car.prototype.setVehicleImg = function (value){
        this.vehicleImg = value;
    } // setVehicleImg


    // переопределение метода toString()
    Car.prototype.toString = function () {
        return`<div class="object-block"><h3>Автомобиль</h3>
                <img src='../img/task2/${this.vehicleImg}' height='120'/><br><p><br>
                Координаты: ${this.coordinates.latitude};${this.coordinates.longitude}<br>
                Цена: ${this.price} руб.<br>
                Скорость: ${this.velocity} км/ч<br>
                Год выпуска: ${this.year}<br>
                </p></div>`;
    }; // toString
} // Car

// класс, описывающий самолет в иерархии транспортных средств
function Plane(coordinates, price, velocity, year, vehicleImg, altitude, pax) {
    // получение доступа к полям базового класса
    Car.call(this, coordinates, price, velocity, year, vehicleImg);

    // поля производного класса
    this.altitude = altitude;             // высота полета
    this.pax = pax;                       // количество пассажиров

    // геттеры
    Plane.prototype.getAltitude = function (){return this.altitude;}
    Plane.prototype.getPax = function (){return this.pax;}

    // сеттеры
    Plane.prototype.setAltitude = function (value){
        if(value > 0) this.altitude = value;
    }// setAltitude

    Plane.prototype.setPax = function (value){
        if(value >= 0) this.pax = value;
    } // setPax


    // переопределение метода toString()
    Plane.prototype.toString = function () {
        return`<div class="object-block"><h3>Самолет</h3>
                <img src='../img/task2/${this.vehicleImg}' height='120'/><br><p><br>
                Координаты: ${this.coordinates.latitude};${this.coordinates.longitude}<br>
                Цена: ${this.price} руб.<br>
                Скорость: ${this.velocity} км/ч<br>
                Год выпуска: ${this.year}<br>
                Высота полета: ${this.altitude}<br>
                Кол-во пассажиров: ${this.pax}<br>
                </p></div>`;
    }; // toString
} // Plane

// класс, описывающий корабль в иерархии транспортных средств
function Ship(coordinates, price, velocity, year, vehicleImg, homePort, pax) {
    // получение доступа к полям базового класса
    Car.call(this, coordinates, price, velocity, year, vehicleImg);

    // поля производного класса
    this.homePort = homePort;             // порт приписки
    this.pax = pax;                       // количество пассажиров

    // геттеры
    Ship.prototype.getHomePort = function (){return this.homePort;}
    Ship.prototype.getPax = function (){return this.pax;}

    // сеттеры
    Ship.prototype.setHomePort = function (value){
        this.homePort = value;
    }// setHomePort

    Ship.prototype.setPax = function (value){
        if(value >= 0) this.pax = value;
    } // setPax

    // переопределение метода toString()
    Ship.prototype.toString = function () {
        return`<div class="object-block"><h3>Корабль</h3>
                <img src='../img/task2/${this.vehicleImg}' height='120'/><br><p><br>
                Координаты: ${this.coordinates.latitude};${this.coordinates.longitude}<br>
                Цена: ${this.price} руб.<br>
                Скорость: ${this.velocity} км/ч<br>
                Год выпуска: ${this.year}<br>
                Порт приписки: ${this.homePort}<br>
                Кол-во пассажиров: ${this.pax}<br>
                </p></div>`;
    }; // toString
} // Ship

// класс, описывающий транспортную компанию
function TransportCompany(vehicles) {
    this.vehicles = vehicles;     // транспортные средства

    // выбрать самые старые транспортные средства
    TransportCompany.prototype.getOldests = function (){
        // создание массива годов выпуска
        let years = this.vehicles.map(v => v.year);
        return this.vehicles.filter(v => v.year === Math.min(...years));
    } // getOldests

    // выбрать самые медленные транспортные средства
    TransportCompany.prototype.getSlowests = function (){
        // создание массива скоростей
        let velocities = this.vehicles.map(v => v.velocity);
        return this.vehicles.filter(v => v.velocity === Math.min(...velocities));
    } // getSlowests

    // выбрать самые быстрые транспортные средства
    TransportCompany.prototype.getFastests = function (){
        // создание массива скоростей
        let velocities = this.vehicles.map(v => v.velocity);
        return this.vehicles.filter(v => v.velocity === Math.max(...velocities));
    } // getFastests

    // вывод коллекции транспортных средств
    TransportCompany.prototype.show = function (title, vehicles) {
        let res = `<h2>${title}</h2><div class="for-blocks">`;
        vehicles.forEach(v => res +=`${v}`);
        res += '</div><hr>';
        document.write(res);
    }; // show

    // вывод коллекции транспортных средств данной транспортной компании
    TransportCompany.prototype.showThis = function (title){
        this.show(title, this.vehicles);
    } // showThis
} // TransportCompany


// демонстрация методов
(function (){
    let transportCompany = new TransportCompany([
        new Plane({latitude: 23.345,  longitude: -23.345},  13_000_000,  980, 2001, "plane.png", 12_000, 360),
        new Plane({latitude: 123.123, longitude: -123.199}, 38_000_000, 1180, 2017, "plane.png", 19_000, 160),
        new Ship ({latitude: 13.123,  longitude: -13.199},  123_000_000,  60, 1998, "ship.png", "Новороссийск", 460),
        new Ship ({latitude: -93.3,   longitude: -123.9},   89_000_000,   40, 2012, "ship.png", "Керчь"       , 120),
        new Ship ({latitude: -113.3,  longitude: -90.9},    18_000_000,   20, 1995, "ship.png", "Новоазовск"  , 20),
        new Car  ({latitude:-123.3, longitude: 100.9},      30_000,   20, 2012, "car.png"),
        new Car  ({latitude: 113.3, longitude: 101.9},   3_100_000,  120, 2019, "car.png"),
        new Car  ({latitude:-129.3, longitude:   1.6},     230_000,   50, 1995, "car.png"),
        new Car  ({latitude:-132.3, longitude:  22.7},     890_000,   90, 2002, "car.png"),
        new Car  ({latitude:  33.1, longitude:  89.3}, 140_980_000, 1180, 2019, "car.png")
    ]);

    // вывод всех транспортных средств
    transportCompany.showThis("Транспортные средства:");

    // самые старые транспортные средства
    transportCompany.show("Самые старые транспортные средства:", transportCompany.getOldests());

    // самые медленные транспортные средства
    transportCompany.show("Самые медленные транспортные средства:", transportCompany.getSlowests());

    // самые быстрые транспортные средства
    transportCompany.show("Самые быстрые транспортные средства:", transportCompany.getFastests());
})();