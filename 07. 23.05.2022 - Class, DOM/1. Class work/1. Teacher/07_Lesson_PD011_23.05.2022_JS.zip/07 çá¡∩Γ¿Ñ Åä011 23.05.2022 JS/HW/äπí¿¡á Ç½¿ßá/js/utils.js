// генерация случайного вещественного числа
function getRand(lo, hi) {
    return (lo + (hi - lo)*Math.random()).toFixed(3);
} // getRand

// генерация случайного целого числа
function getIntRand(lo, to) {
    return Math.trunc(getRand(lo, to));
} // getIntRand