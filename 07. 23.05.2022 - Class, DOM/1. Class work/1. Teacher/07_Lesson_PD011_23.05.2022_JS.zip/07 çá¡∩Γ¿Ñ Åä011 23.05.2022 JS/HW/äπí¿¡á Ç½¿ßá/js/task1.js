// Задача 1. Разработайте иерархию классов (функций-конструкторов) для представления объемных фигур - сферы,
// конуса и цилиндра. Разработайте методы для вычисления площади поверхности, объема фигуры, вывода данных
// по фигуре и сравнения фигур по объему. Выводите также изображение фигур.
// Сформируйте массив объектов этих классов - по 2 объекта каждого типа.
// Отсортируйте массив по убыванию объемов. Отсортируйте массив по возрастанию площадей поверхности.

// Сфера (базовый класс)
function Sphere(radius, img) {
    this.radius = radius;     // радиус сферы
    this.img = img;           // графическое отображение фигуры

    // метод для вычисления объема сферы
    Sphere.prototype.volume = function () { return 4 / 3 * Math.PI * this.radius * this.radius * this.radius; };

    // метод для вычисления площади поверхности сферы
    Sphere.prototype.area = function () { return 4 * Math.PI * this.radius * this.radius; };

    // метод для сравнения фигур по объему
    Sphere.prototype.equals = function (that) {
        return this.volume() === that.volume();
    } // equals

    // переопределение метода toString()
    Sphere.prototype.toString = function () {
        return`<div class="object-block"><h3>Сфера</h3>
                <img src='../img/task1/${this.img}' height='120'/><br><p><br>
                Радиус: ${this.radius} м<br>
                Площадь: ${this.area().toFixed(3)} м<sup><small>2</small></sup><br>
                Объем: ${this.volume().toFixed(3)} м<sup><small>3</small></sup><br>
                </p></div>`;
    }; // toString
} // Sphere

// Конус (производный класс)
function Cone(radius, height, img) {
    // получение доступа к полям базового класса
    Sphere.call(this, radius, img);

    // поля производного класса
    this.height = height; // высота конуса
    this.l = Math.sqrt(this.radius * this.radius + this.height * this.height); // образующая конуса

    // метод для вычисления объема конуса
    Cone.prototype.volume = function () { return this.height / 3 * Math.PI * this.radius * this.radius; };

    // метод для вычисления площади поверхности конуса
    Cone.prototype.area = function () {
        return Math.PI * this.radius * this.l + Math.PI * this.radius *this.radius;
    };

    // переопределение метода toString()
    Cone.prototype.toString = function () {
        return`<div class="object-block"><h3>Конус</h3>
                <img src='../img/task1/${this.img}' height='120'/><br><p>
                Высота: ${this.height} м<br>
                Радиус: ${this.radius} м<br>
                Площадь: ${this.area().toFixed(3)} м<sup><small>2</small></sup><br>
                Объем: ${this.volume().toFixed(3)} м<sup><small>3</small></sup><br>
                </p></div>`;
    }; // toString
} // Cone

// Цилиндр (производный класс)
function Cylinder(radius, height, img) {
    // получение доступа к полям базового класса
    Sphere.call(this, radius, img);

    // поля производного класса
    this.height = height; // высота цилиндра

    // метод для вычисления объема цилиндра
    Cylinder.prototype.volume = function () { return Math.PI * this.radius * this.radius * this.height; };

    // метод для вычисления площади поверхности цилиндра
    Cylinder.prototype.area = function () {
        return 2 * Math.PI * this.radius * this.radius + 2 * Math.PI * this.radius * this.height;
    };


    // переопределение метода toString()
    Cylinder.prototype.toString = function () {
        return`<div class="object-block"><h3>Цилиндр</h3>
                <img src='../img/task1/${this.img}' height='120'/><br><p>
                Высота: ${this.height} м<br>
                Радиус: ${this.radius} м<br>
                Площадь: ${this.area().toFixed(3)} м<sup><small>2</small></sup><br>
                Объем: ${this.volume().toFixed(3)} м<sup><small>3</small></sup><br>
                </p></div>`;
    }; // toString
} // Cylinder

// демонстрация методов
(function (){
    const lo = 2, hi = 15;
    let figures = [
        new Sphere(getRand(lo, hi), "sphere.png"),
        new Sphere(getRand(lo, hi), "sphere.png"),
        new Cone(getRand(lo, hi), getRand(lo, hi), "cone.png"),
        new Cone(getRand(lo, hi), getRand(lo, hi), "cone.png"),
        new Cylinder(getRand(lo, hi), getRand(lo, hi), "cylinder.png"),
        new Cylinder(getRand(lo, hi), getRand(lo, hi), "cylinder.png"),
    ];

    // вывод
    document.write('<h2>Фигуры в исходном порядке</h2><div class="for-blocks">');
    figures.forEach(f => document.write(`${f}`));
    document.write('</div><hr>');

    // сортировка по убыванию объемов
    figures.sort((x, y) => y.volume() - x.volume());

    // вывод
    document.write('<h2>Фигуры по убыванию объемов</h2><div class="for-blocks">');
    figures.forEach(f => document.write(`${f}`));
    document.write('</div><hr>');

    // сортировка по возрастанию площадей поверхности
    figures.sort((x, y) => x.area() - y.area());

    // вывод
    document.write('<h2>Фигуры по возрастанию площадей</h2><div class="for-blocks">');
    figures.forEach(f => document.write(`${f}`));
    document.write('</div><hr>');
})();