// Сфера - играет роль базового класса
function Sphere(r) {
    // Радиус
    this.r = r;
    this.name = 'Сфера';
    this.img = 'sphere.png';

    // Объем сферы
    Sphere.prototype.getVolume = function () {
        return 4 * Math.PI * this.r ** 3 / 3;
    }

    // Площадь поверхности
    Sphere.prototype.getArea = function () {
        return 4 * Math.PI * this.r * this.r;
    }

    Sphere.prototype.toString = function () {
        return `<div class="indented figure">
                <img src='../images/figures/${this.img}' alt="pic" style="width: 150px;height: 150px "/>
                    <div><div class="hl">${this.name}</div></div>
                    <div><div class="hl">Радиус: </div> ${this.r.toFixed(2)}</div>
                    <div><div class="hl">Объем: </div> ${this.getVolume().toFixed(2)}</div>
                    <div><div class="hl">Площадь поверхности: </div> ${this.getArea().toFixed(2)}</div>
                </div>`;
    }

    Sphere.prototype.toTableRow = function (row) {
        document.write(`
            <tr>
                <td>${row}</td>
                <td class="align-left">${this.name}</td>
                <td><img src='../images/figures/${this.img}' alt="pic" style="width: 150px;height: 150px "/></td>
                <td>${this.r.toFixed(2)}</td>
                <td></td>
                <td>${this.getVolume().toFixed(2)}</td>
                <td>${this.getArea().toFixed(2)}</td>
            </tr>
        `);
    }

    Sphere.prototype.compareTo = function (other) {
        return this.getVolume() - other.getVolume();
    }
}


// Конус
function Cone(r, h) {
    Sphere.call(this, r);
    this.h = h;
    this.name = 'Конус';
    this.img = 'cone.png';

    Cone.prototype.getVolume = function () {
        return Math.PI * this.r * this.r * this.h / 3;
    }

    Cone.prototype.getArea = function () {
        return Math.PI * this.r * (this.r + Math.sqrt(this.r ** 2 + this.h ** 2))
    }

    Cone.prototype.toTableRow = function (row) {
        document.write(`
            <tr>
                <td>${row}</td>
                <td class="align-left">${this.name}</td>
                <td><img src='../images/figures/${this.img}' alt="pic" style="width: 150px;height: 150px "/></td>
                <td>${this.r.toFixed(2)}</td>
                <td>${this.h.toFixed(2)}</td>
                <td>${this.getVolume().toFixed(2)}</td>
                <td>${this.getArea().toFixed(2)}</td>
            </tr>
        `);
    }

    Cone.prototype.toString = function () {
        return `<div class="indented figure">
                <img src='../images/figures/${this.img}' alt="pic" style="width: 150px;height: 150px "/>
                    <div><div class="hl">${this.name}</div></div>
                    <div><div class="hl">Радиус: </div> ${this.r.toFixed(2)}</div>
                    <div><div class="hl">Высота: </div> ${this.h.toFixed(2)}</div>
                    <div><div class="hl">Объем: </div> ${this.getVolume().toFixed(2)}</div>
                    <div><div class="hl">Площадь поверхности: </div> ${this.getArea().toFixed(2)}</div>
                </div>`;
    }
}

Cone.prototype = Object.create(Sphere.prototype);

// Цилиндр
function Cylinder(r, h) {
    Cone.call(this, r, h);
    this.name = 'Цилиндр';
    this.img = 'cylinder.png';

    Cylinder.prototype.getVolume = function () {
        return Math.PI * this.r * this.r * this.h;
    }

    Cylinder.prototype.getArea = function () {
        return 2 * Math.PI * this.r * this.h;
    }
}

Cylinder.prototype = Object.create(Cone.prototype);

// Класс для работы с коллекцией фигур
function Shapes(shapes) {
    this.shapes = shapes;

    this.showShapes = function (prompt) {
        document.write(`
                      <table>
                        <caption>${prompt}</caption>
                      <thead>
                      <tr>
                        <td>№</td>
                        <td>Название</td>
                        <td>Изображение</td>
                        <td>Радиус</td>
                        <td>Высота</td>
                        <td>Объем</td>
                        <td>Площадь поверхности</td>
                      </tr></thead>`);
        shapes.forEach((item, index) => item.toTableRow(index + 1));
        document.write('</table>')
    }

    this.sortByVolumeDesc = function () {
        this.shapes.sort((a, b) => b.compareTo(a));
    }

    this.sortByArea = function () {
        this.shapes.sort((a, b) => a.getArea() - b.getArea());
    }
}


// Демонстрация
(function () {

    let shapes = new Shapes([
        new Sphere(getRandom(1, 10)),
        new Sphere(getRandom(1, 10)),
        new Cone(getRandom(1, 10), getRandom(1, 10),),
        new Cone(getRandom(1, 10), getRandom(1, 10),),
        new Cylinder(getRandom(1, 10), getRandom(1, 10),),
        new Cylinder(getRandom(1, 10), getRandom(1, 10),),
    ]);


    shapes.showShapes('Коллекция фигур:');

    shapes.sortByVolumeDesc();
    shapes.showShapes('Коллекция отсортирована по убыванию объемов:');

    shapes.sortByArea();
    shapes.showShapes('Коллекция отсортирована по возрастанию площадей поверхности:');

})();
