
//region Вариант в синтаксисе class

// Базовый класс, описывающий транспортное средство
class Vehicle {
    constructor(category, {latitude, longitude}, price, velocity, year) {
        this.coordinates = {latitude, longitude};
        this.category = category;
        this.price = price;
        this.velocity = velocity;
        this.year = year;
    }

    get category() {
        return this._category;
    }

    set category(value) {
        this._category = value;
    }

    get coordinates() {
        return this._coordinates;
    }

    set coordinates(value) {
        if ((-180 <= value.latitude || value.latitude <= 180) &&
            (-180 <= value.longitude || value.longitude <= 180))
            this._coordinates = value;
    }

    get price() {
        return this._price;
    }

    set price(value) {
        if (value > 0)
            this._price = value;
    }

    get velocity() {
        return this._velocity;
    }

    set velocity(value) {
        if (value > 0)
            this._velocity = value;
    }

    get year() {
        return this._year;
    }

    set year(value) {
        if (value > 0)
            this._year = value;
    }
}

// Класс описывающий автомобиль
class Car extends Vehicle {
    constructor(category, coordinates, price, velocity, year) {
        super(category, coordinates, price, velocity, year);
    }

    writeTableRow(row) {
        document.write(`
            <tr><td>${row}</td>
            <td class="align-left"><i class="fa-solid fa-car inline"></i> ${this.category}</td>
            <td>${this.coordinates.latitude};${this.coordinates.longitude}</td>
            <td>${this.price}</td>
            <td>${this.velocity}</td>
            <td>${this.year}</td>
            <td></td><td></td></tr>
        `)
    }
}

// Класс описывающий самолет
class Plane extends Vehicle {
    constructor(category, coordinates, price, velocity, year, pax, altitude) {
        super(category, coordinates, price, velocity, year);
        this.pax = pax;
        this.altitude = altitude;
    }

    get altitude() {
        return this._altitude;
    }

    set altitude(value) {
        if (value > 0) this._altitude = value;
    }

    get pax() {
        return this._pax;
    }

    set pax(value) {
        if (value > 0) this._pax = value;
    }

    writeTableRow(row) {
        document.write(`
            <tr><td>${row}</td>
            <td class="align-left"><i class="fa-solid fa-plane"></i> ${this._category}</td>
            <td>${this._coordinates.latitude};${this._coordinates.longitude}</td>
            <td>${this._price}</td>
            <td>${this._velocity}</td>
            <td>${this._year}</td>
            <td>${this._pax}</td>
            <td>${this._altitude}</td></tr>
        `)
    }
}

// Класс описывающий корабль
class Ship extends Vehicle {
    constructor(category, coordinates, price, velocity, year, pax, homePort) {
        super(category, coordinates, price, velocity, year);
        this.pax = pax;
        this.homePort = homePort;
    }

    get homePort() {
        return this._homePort;
    }

    set homePort(value) {
        this._homePort = value;
    }

    get pax() {
        return this._pax;
    }

    set pax(value) {
        if (value > 0) this._pax = value;
    }

    writeTableRow(row) {
        document.write(`
            <tr><td>${row}</td>
            <td class="align-left"><i class="fa-solid fa-ship"></i> ${this._category}</td>
            <td>${this._coordinates.latitude};${this._coordinates.longitude}</td>
            <td>${this._price}</td>
            <td>${this._velocity}</td>
            <td>${this._year}</td>
            <td>${this._pax}</td>
            <td>${this._homePort}</td></tr>
        `)
    }
}
//endregion

//region Вариант в синтаксисе функций-конструкторов
/*
function Vehicle(category, {latitude, longitude}, price, velocity, year) {
    this.coordinates = {latitude, longitude};
    this.category = category;
    this.price = price;
    this.velocity = velocity;
    this.year = year;

    Vehicle.prototype.getCategory = function () {
        return this.category;
    }

    Vehicle.prototype.setCategory = function (value) {
        this.category = value;
    }

    Vehicle.prototype.getCoordinates = function () {
        return this.coordinates;
    }

    Vehicle.prototype.setCoordinates = function (value) {
        if ((-180 <= value.latitude || value.latitude <= 180) &&
            (-180 <= value.longitude || value.longitude <= 180))
            this.coordinates = value;
    }

    Vehicle.prototype.getPrice = function () {
        return this.price;
    }

    Vehicle.prototype.setPrice = function (value) {
        if (value > 0)
            this.price = value;
    }

    Vehicle.prototype.getVelocity = function () {
        return this.velocity;
    }

    Vehicle.prototype.setVelocity = function (value) {
        if (value > 0)
            this.velocity = value;
    }

    Vehicle.prototype.getYear = function () {
        return this.year;
    }

    Vehicle.prototype.setYear = function (value) {
        if (value > 0)
            this.year = value;
    }
}

function Car(category, coordinates, price, velocity, year) {

    Vehicle.call(this, category, coordinates, price, velocity, year);

    Car.prototype.writeTableRow = function (row) {
        document.write(`
            <tr><td>${row}</td>
            <td class="align-left">${this.category}</td>
            <td>${this.coordinates.latitude};${this.coordinates.longitude}</td>
            <td>${this.price}</td>
            <td>${this.velocity}</td>
            <td>${this.year}</td>
            <td></td><td></td></tr>
        `)
    }
}

function Plane(category, coordinates, price, velocity, year, pax, altitude) {
    Vehicle.call(this, category, coordinates, price, velocity, year);
    this.pax = pax;
    this.altitude = altitude;

    Plane.prototype.getAltitude = function () {
        return this.altitude;
    }

    Plane.prototype.setAltitude = function (value) {
        if (value > 0) this.altitude = value;
    }

    Plane.prototype.getPax = function () {
        return this.pax;
    }

    Plane.prototype.setPax = function(value) {
        if (value > 0) this.pax = value;
    }

    Plane.prototype.writeTableRow = function (row) {
        document.write(`
            <tr><td>${row}</td>
            <td class="align-left">${this.category}</td>
            <td>${this.coordinates.latitude};${this.coordinates.longitude}</td>
            <td>${this.price}</td>
            <td>${this.velocity}</td>
            <td>${this.year}</td>
            <td>${this.pax}</td>
            <td>${this.altitude}</td></tr>
        `)
    }
}

function Ship (category, coordinates, price, velocity, year, pax, homePort) {
   Vehicle.call(this, category, coordinates, price, velocity, year)
   this.pax = pax;
   this.homePort = homePort;

    Ship.prototype.getHomePort = function () {
        return this.homePort;
    }

    Ship.prototype.setHomePort = function(value) {
        this.homePort = value;
    }

    Ship.prototype.getPax = function () {
        return this.pax;
    }

    Ship.prototype.setPax = function(value) {
        if (value > 0) this.pax = value;
    }

    Ship.prototype.writeTableRow = function(row) {
        document.write(`
            <tr><td>${row}</td>
            <td class="align-left">${this.category}</td>
            <td>${this.coordinates.latitude};${this.coordinates.longitude}</td>
            <td>${this.price}</td>
            <td>${this.velocity}</td>
            <td>${this.year}</td>
            <td>${this.pax}</td>
            <td>${this.homePort}</td></tr>
        `)
    }
}*/
//endregion

// Класс для работы с коллекцией транспортных средств
class TransportCompany {
    constructor(vehicles) {
        this.vehicles = vehicles;
    }

    // Выбрать самые старые транспортные средства
    getOldest() {
        let minYear = Math.min(...this.vehicles.map(item => item.year));
        return this.vehicles.filter(item => item.year === minYear);
    }

    // Выбрать самые медленные транспортные средства
    getSlowest() {
        let minVelocity = Math.min(...this.vehicles.map(item => item.velocity));
        return this.vehicles.filter(item => item.velocity === minVelocity);
    }

    // Выбрать самые быстрые транспортные средства
    getFastest() {
        let maxVelocity = Math.max(...this.vehicles.map(item => item.velocity));
        return this.vehicles.filter(item => item.velocity === maxVelocity);
    }

    show(prompt) {
        TransportCompany.show(this.vehicles, prompt);
    }

    static show(vehicles, prompt) {
        document.write(`
                      <table>
                      <caption>${prompt}</caption>
                      <thead>
                      <tr>
                        <td>№</td>
                        <td>Категория</td>
                        <td>Координаты</td>
                        <td>Цена, руб</td>
                        <td>Скорость, км/ч</td>
                        <td>Год изг.</td>
                        <td>Кол-во пассаж.</td>
                        <td>Высота полета / порт приписки</td>
                      </tr></thead>`);
        vehicles.forEach((item, index) => item.writeTableRow(index + 1));
        document.write('</table>')
    }
}


// Демонстрация
(function () {

    let company = new TransportCompany([
        new Plane("самолет",
            {latitude: 23.345, longitude: -23.345}, 13_000_000, 980, 2001, 360, 12_000),
        new Plane("самолет",
            {latitude: 123.123, longitude: -123.199}, 38_000_000, 1180, 2017, 160, 19_000),
        new Ship("корабль",
            {latitude: 13.123, longitude: -13.199}, 123_000_000, 60, 1998, 460, "Новороссийск"),
        new Ship("корабль",
            {latitude: -93.3, longitude: -123.9}, 89_000_000, 40, 2012, 120, "Керчь"
        ),
        new Ship("корабль", {latitude: -113.3, longitude: 90.9}, 18_000_000, 20, 1995, 20, "Новоазовск"),
        new Car("автомобиль", {latitude: -123.3, longitude: 100.9}, 30_000, 20, 2012),
        new Car("автомобиль", {latitude: 113.3, longitude: 101.9}, 3_100_000, 120, 2019),
        new Car("автомобиль", {latitude: -129.3, longitude: 1.6}, 230_000, 50, 1998),
        new Car("автомобиль", {latitude: -132.3, longitude: 22.7}, 890_000, 90, 2002),
        new Car("автомобиль", {latitude: 33.1, longitude: 89.3}, 140_980_000, 1180, 2019)
    ]);


    company.show('Список транспортных средств');
    TransportCompany.show(company.getOldest(), 'Самые старые транспортные средства');
    TransportCompany.show(company.getSlowest(), 'Самые медленные транспортные средства');
    TransportCompany.show(company.getFastest(), 'Самые быстрые транспортные средства');
})();
