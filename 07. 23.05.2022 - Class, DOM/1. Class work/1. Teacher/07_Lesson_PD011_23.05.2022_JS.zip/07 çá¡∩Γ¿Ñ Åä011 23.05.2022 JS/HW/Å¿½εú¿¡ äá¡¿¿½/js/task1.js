//  Задача 1. Разработайте иерархию классов(функций - конструкторов)
//  для представления объемных фигур - сферы, конуса и цилиндра.
//  Разработайте методы для вычисления площади поверхности, объема фигуры,
//  вывода данных по фигуре и сравнения фигур по объему.Выводите также
//  изображение фигур. Сформируйте массив объектов этих классов - по 2 объекта каждого типа.
//  Отсортируйте массив по убыванию объемов.Отсортируйте массив по возрастанию площадей поверхности.

//родительский класс
class Figure {
    //конструктор
    constructor(radius, cover) {
        this.radius = radius;
        this.cover = cover;
    }
    //площадь
    getS() {

    };
    //объем
    getV() {

    };
    //вывод на страницу
    show() {

    };
    //сравнение фигур по объему
    equals(figure) {
        return this.getV() === figure.getV() && figure.getV() === this.getV();
    }
}

//сфера
class Sphere extends Figure {
    //конструктор
    constructor(r, cover) {
        super(r, cover);
    }

    //площадь
    getS() {
        return 4 * Math.PI * (this.radius * this.radius);
    }

    //объем
    getV() {
        return 4 * Math.PI * this.radius ** 3 / 3;
    }

    //вывод на страницу
    show() {
        document.writeln(`
            <table style=" width: 600px; border-collapse: collapse; margin: 0 auto 40px;">
                <tr>
                    <td rowspan='5'><img style="width: 200px" src="${this.cover}"></td>
                    <td style="text-align: center"><b>Фигура:</b> Сфера</td>
                </tr>
                <tr><td style="text-align: center"><b>Радиус:</b> ${this.radius}</td></tr>
                <tr><td style="text-align: center"><b>Площадь:</b> ${this.getS().toFixed(2)}</td></tr>
                <tr><td style="text-align: center"><b>Объем:</b> ${this.getV().toFixed(2)}</td></tr>
            </table>
        `);
    }
}

//конус
class Cone extends Figure {
    //конструктор
    constructor(r, h, cover) {
        super(r, cover)
        this.h = h;
    }

    getL() {
        return Math.sqrt(this.radius * this.radius + this.h * this.h);
    }

    //площадь
    getS() {
        return Math.PI * (this.radius * this.radius) + Math.PI * this.radius * this.getL();
    }

    //объем
    getV() {
        return (Math.PI * (this.radius * this.radius) * this.h) / 3;
    }

    //вывод на страницу
    show() {
        document.writeln(`
            <table style=" width: 600px; border-collapse: collapse; margin: 0 auto 40px;">
                <tr>
                    <td rowspan='5'><img style="width: 200px" src="${this.cover}"></td>
                    <td style="text-align: center"><b>Фигура:</b> Конус</td>
                </tr>
                <tr><td style="text-align: center"><b>Радиус:</b> ${this.radius}</td></tr>
                <tr><td style="text-align: center"><b>Площадь:</b> ${this.getS().toFixed(2)}</td></tr>
                <tr><td style="text-align: center"><b>Объем:</b> ${this.getV().toFixed(2)}</td></tr>
            </table>
        `);
    }
}

//цилиндр
class Cylinder extends Cone {
    //конструктор
    constructor(r, h, cover) {
        super(r, h, cover);
    }

    //площадь
    getS() {
        return 2 * Math.PI * (this.radius * this.radius) + 2 * Math.PI * this.radius * this.h;
    }

    //объем
    getV() {
        return Math.PI * (this.radius * this.radius) * this.h;
    }

    //вывод на страницу
    show() {
        document.writeln(`
            <table style=" width: 600px; border-collapse: collapse; margin: 0 auto 40px;">
                <tr>
                    <td rowspan='5'><img style="width: 200px" src="${this.cover}"></td>
                    <td style="text-align: center"><b>Фигура:</b> Цилиндр</td>
                </tr>
                <tr><td style="text-align: center"><b>Радиус:</b> ${this.radius}</td></tr>
                <tr><td style="text-align: center"><b>Площадь:</b> ${this.getS().toFixed(2)}</td></tr>
                <tr><td style="text-align: center"><b>Объем:</b> ${this.getV().toFixed(2)}</td></tr>
            </table>
        `);
    }
}




(function () {
    let array = [
        new Sphere(3, '../imgs/task1/sphere.svg'),
        new Cone(4, 5, '../imgs/task1/cone.svg'),
        new Cylinder(6, 9, '../imgs/task1/cylinder.svg'),
        new Cylinder(3, 8, '../imgs/task1/cylinder.svg'),
        new Cone(5, 8, '../imgs/task1/cone.svg'),
        new Sphere(3, '../imgs/task1/sphere.svg'),
    ];

    //!
    console.log(array[0].equals(array[5]));
    console.log(array[0] === array[5]);

    pageWrite(`<p style="text-align:center; font-size: 20pt"><b>Ваш массив</b></p>`);
    showArr(array);


    pageWrite(`<hr><p style="text-align:center; font-size: 20pt"><b>Сортировка по убыванию V</b></p>`);
    array.sort((a, b) => b.getV() - a.getV());
    showArr(array);

    pageWrite(`<hr><p style="text-align:center; font-size: 20pt"><b>Сортировка по возрастанию S</b></p>`);
    array.sort((a, b) => a.getS() - b.getS());
    showArr(array);

})();

//вывод массива на страницу
function showArr(arr) {
    arr.forEach(x => x.show());
}

//вывод сообщения на страницу
function pageWrite(str) {
    document.write(`${str}`);
}