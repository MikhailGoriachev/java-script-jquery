//рандом целых
function randomInt(lo, hi) {
    const min = Math.ceil(lo);
    const max = Math.floor(hi);
    return Math.trunc(Math.random() * (min - max + 1) + max);
}

//рандом вещественных
function randomDbl(lo, hi) {
    const min = Math.ceil(lo);
    const max = Math.floor(hi);
    return Math.random() * (min - max + 1) + max;
}

//генерация массива целых
function createArrInt(size, lo, hi) {
    let array = [];
    for (let i = 0; i < size; i++)
        array[i] = randomInt(lo, hi);
    return array;
}

//генерация массива вещественных
function createArrDbl(size, lo, hi) {
    let array = [];
    for (let i = 0; i < size; i++)
        array[i] = randomDbl(lo, hi);
    return array;
}

//вывод массива на страницу
function showArr(array) {
    document.write(`<table class="table"><tr>`);
    array.forEach(x => document.write(`<td>${x}</td>`));
    document.write(`</tr></table>`);
}

//вывод массива на страницу
function showArrDbl(array) {
    document.write(`<table class="table"><tr>`);
    array.forEach(x => document.write(`<td>${x.toFixed(1)}</td>`));
    document.write(`</tr></table>`);
}

//вывод массива вещественных с его длинной
function showArrDblWithLength(array) {
    document.write(`<table class="table"><tr>`);
    array.forEach(x => document.write(`<td>${x.toFixed(1)}</td>`));
    document.write(`</tr><tr><td colspan="${array.length}">length = ${array.length}</td></tr></table>`);
}