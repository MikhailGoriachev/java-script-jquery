/*
* Задача 1.
* Разработайте иерархию классов (функций-конструкторов) для представления
* объемных фигур - сферы, конуса и цилиндра. Разработайте методы для
* вычисления площади поверхности, объема фигуры, вывода данных по фигуре
* и сравнения фигур по объему. Выводите также изображение фигур.
* Сформируйте массив объектов этих классов - по 2 объекта каждого типа.
* Отсортируйте массив по убыванию объемов. Отсортируйте массив
* по возрастанию площадей поверхности.
* */

// сфера - играет роль базового класса
function Sphere(r) {
    // радиус
    this.r = r;

    // объем шара
    // https://www-formula.ru/2011-09-21-10-52-47
    Sphere.prototype.getVolume = function() { return 4 * Math.PI * this.r**3 / 3; }

    // площадь поверхности сферы
    // https://www-formula.ru/2011-09-21-04-30-33
    Sphere.prototype.getArea = function() { return  4 * Math.PI * this.r**2; }

    // компаратор для сравнения тел по объему
    Sphere.prototype.compareTo = function(s1, s2) { return s1.getVolume() - s2.getVolume(); }

    // представление объекта в формате HTML
    Sphere.prototype.toTableRow = function(row) { return `
        <tr>
            <td>${row}</td>
            <td class="align-center"><img src="../images/sphere.png" alt="Сфера" width="90"/></td>
            <td class="align-left">r: ${this.r.toFixed(3)}</td>
            <td>${this.getArea().toFixed(3)}</td>
            <td>${this.getVolume().toFixed(3)}</td>
        </tr>`;
    }
} // Sphere


// конус
function Cone(r, h) {
    Sphere.call(this, r);

    // собственное свойство класса - высота конуса
    this.h = h;

    // объём конуса
    // https://www-formula.ru/2011-09-21-10-55-09
    Cone.prototype.getVolume = function () { return Math.PI * this.r**2 * this.h / 3; }

    // площадь поверхности конуса
    // https://www-formula.ru/2011-09-21-04-34-19
    Cone.prototype.getArea = function() { return  Math.PI * this.r * (this.r + Math.sqrt(this.r**2 + this.h**2)); }

    // компаратор для сравнения тел по объему
    Cone.prototype.compareTo = function(s1, s2) { return s1.getVolume() - s2.getVolume(); }

    // для полиморфизма реализуем представление объекта в формате HTML
    // в функции с тем же именем, что и базового класса
    Cone.prototype.toTableRow = function(row) { return `
        <tr>
            <td>${row}</td>
            <td class="align-center"><img src="../images/cone.png" alt="Конус" width="90"/></td>
            <td class="align-left">r: ${this.r.toFixed(3)}; h: ${this.h.toFixed(3)}</td>
            <td>${this.getArea().toFixed(3)}</td>
            <td>${this.getVolume().toFixed(3)}</td>
        </tr>`;
    }
    
} // Cone


// цилиндр 
// https://www-formula.ru/2011-09-21-10-54-43
function Cylinder(r, h) {
    Sphere.call(this, r);

    // собственное свойство класса - высота цилиндра
    this.h = h;

    // объем цилиндра
    // https://www-formula.ru/2011-09-21-10-54-43
    Cylinder.prototype.getVolume = function() { return Math.PI * this.r**2; }

    // площадь поверхности цилиндра
    // https://www-formula.ru/2011-09-21-04-33-30
    Cylinder.prototype.getArea = function() { return 2 * Math.PI * this.r * (this.h + this.r); }

    // компаратор для сравнения тел по объему
    Cylinder.prototype.compareTo = function(s1, s2) { return s1.getVolume() - s2.getVolume(); }

    // для полиморфизма реализуем представление объекта в формате HTML
    // в функции с тем же именем, что и базового класса
    Cylinder.prototype.toTableRow = function(row) { return `
        <tr>
            <td>${row}</td>
            <td class="align-center"><img src="../images/cylinder.png" alt="Цилиндр" width="90"/></td>
            <td class="align-left">r: ${this.r.toFixed(3)}; h: ${this.h.toFixed(3)}</td>
            <td>${this.getArea().toFixed(3)}</td>
            <td>${this.getVolume().toFixed(3)}</td>
        </tr>`;
    }
} // Cylinder

// класс для работы с коллекцией фигур
function Bodies(title, bodies) {
    // название коллекции
    this.title = title;

    // коллекция фигур
    this.bodies = bodies;

    // вывод коллекции фигур в табличном формате
    Bodies.prototype.show = function(title) {
        document.write(`
        <h2>${title}</h2><table>
        <tr>
            <th>№</th>
            <th>Изображение</th>
            <th>Параметры тела</th>
            <th>Площадь поверхности</th>
            <th>Объем</th>
        </tr> `);

        let row = 1;
        this.bodies.forEach(body => document.write(body.toTableRow(row++)));
        document.write('</table>')
    } // show

    // оболочка для сортировки коллекции
    Bodies.prototype.sort = function (compareTo) {
        this.bodies.sort(compareTo);
    } // sort
} // Bodies


// задача на обработку массива классов
(function (){
    // массив объемных тел
    let bodies = [
        new Cone(getIntRand(5, 10), getIntRand(5, 10)),
        new Cone(getIntRand(5, 10), getIntRand(5, 10)),
        new Cylinder(getIntRand(5, 10), getIntRand(5, 10)),
        new Cylinder(getIntRand(5, 10), getIntRand(5, 10)),
        new Sphere(getIntRand(5, 10)),
        new Sphere(getIntRand(5, 10)),
    ];

    let listBodies = new Bodies("Коллеукция объемных тел", bodies);

    // вывод сформированного массива объемных тел
    listBodies.show('Массив объемных тел для обработки');

    // сортировка массива объемных тел по убыванию объемов
    // вывод отсортированного массива объемных тел
    listBodies.sort((b1, b2) => b2.getVolume() - b1.getVolume());
    listBodies.show('Массив объемных тел упорядочен по убыванию объемов');

    // сортировка массива объемных тел по возрастанию площадей поверхности
    // вывод отсортированного массива объемных тел
    listBodies.sort((b1, b2) => b1.getArea() - b2.getArea());
    listBodies.show('Массив объемных тел упорядочен по возрастанию площадей поверхности');
})();
