/*
* Задача 2.
* Создайте класс Vehicle (транспортное средство). На его основе реализовать
* классы Plane (самолет), Саr (автомобиль) и Ship (корабль).
*
* Классы должны иметь возможность задавать и получать параметры средств
* передвижения (географические координаты, цена, скорость, год выпуска)
* с помощью свойств.
*
* Дополнительно для самолета должна быть определена высота, для самолета
* и корабля — количество пассажиров, для корабля — порт приписки
*
* Создайте массив транспортных средств, состоящий из 2х самолетов, 3х кораблей
* и 5и автомобилей. В массиве найти:
*     самое старое транспортное средство
*     самое быстрое и самое медленное транспортные средства (может быть найдено
*     больше 1 транспортного средства)
* */

// вспомогательный класс - географические координаты
function Coordinate(latitude, longitude) {
    this.latitude = latitude;
    this.longitude = longitude;
} // Coordinate


// базовый класс иерархии - транспортное средство
function Vehicle(latitude, longitude, velocity, price, year, image) {
    this.coordinate = new Coordinate(latitude, longitude);

    this.velocity = velocity;
    this.price = price;
    this.year = year;
    this.image = `<i class ="fa ${image} fa-3x"></i>`;

    // вывод в формате строки таблицы - переопределим в производном классе
    Vehicle.prototype.toTableRow = function(row) {}

    // вывод общих ячеек строки таблицы
    Vehicle.prototype.partialTableRow = function(row) { return  `
        <td>${row}</td>
        <td>${this.image}</td>
        <td>${this.coordinate.latitude.toFixed(5)};${this.coordinate.longitude.toFixed(5)}</td>
        <td>${this.velocity.toFixed(2)}</td>
        <td>${this.price.toFixed(2)}</td>
        <td>${this.year}</td>`;
    }
} // Vehicle

// автомобиль
function Car(latitude, longitude, velocity, price, year) {
    Vehicle.call(this, latitude, longitude, velocity, price, year, 'fa-car');

    // вывод в формате строки таблицы
    // this.partialTableRow(row) - пример вызова метода из базового класса :)
    Car.prototype.toTableRow = function(row) {
        return `
        <tr>
            ${this.partialTableRow(row)}
            <td></td>
            <td></td>
        </tr>`;
    }
} // Car

// самолет
// количество пассажиров
// высота полета
function Plane(latitude, longitude, velocity, price, year, passengers, altitude) {
    Vehicle.call(this, latitude, longitude, velocity, price, year, 'fa-plane');

    // количество пассажиров
    this.passengers = passengers;

    // высота полета
    this.altitude = altitude;

    // вывод в формате строки таблицы
    Plane.prototype.toTableRow = function(row) {
        return `
        <tr>
            ${this.partialTableRow(row)}
            <td>${this.passengers}</td>
            <td>${this.altitude}</td>
        </tr>`;
    }
} // Plane

// корабль
// количество пассажиров
// порт приписки
function Ship(latitude, longitude, velocity, price, year, passengers, homePort) {
    Vehicle.call(this, latitude, longitude, velocity, price, year, 'fa-ship');

    // количество пассажиров
    this.passengers = passengers;

    // порт приписки
    this.homePort = homePort;

    // вывод в формате строки таблицы
    Ship.prototype.toTableRow = function (row) {
        return `
        <tr>
            ${this.partialTableRow(row)}
            <td>${this.passengers}</td>
            <td>${this.homePort}</td>
        </tr>`;
    }
} // Ship


// Транспортная компания
function TransportCompany(title, vehicles) {
    // название компании
    this.title = title;

    // коллекция транспортных средств
    this.vehicles = vehicles;

    // вывод коллекции транспортных средств в табличном формате
    TransportCompany.prototype.show = function (vehicles, title) {
        document.write(`
        <h2>${title}</h2><table>
        <tr>
            <th>№</th>
            <th>Вид</th>
            <th>Координаты:<br>широта; долгота</th>
            <th>Скорость,<br>км/ч</th>
            <th>Цена,<br>руб.</th>
            <th>Год выпуска</th>
            <th>Количество<br>пассажиров</th>
            <th>Высота полета (м)<br>Порт приписки</th>
        </tr> `);

        let row = 1;
        vehicles.forEach(vehicle => document.write(vehicle.toTableRow(row++)));
        document.write('</table>')
    } // show

    // самое старое транспортное средство/самые старые транспортные средства
    TransportCompany.prototype.getOldest = function() {
        let minYear = Math.min(...vehicles.map(v => v.year));
        return vehicles.filter(v => v.year === minYear);
    } // getOldest

    // самые быстрые и самые медленные транспортные средства
    TransportCompany.prototype.getFastestsSlowests = function() {
        let maxVelocity = Math.max(...vehicles.map(v => v.velocity));
        let minVelocity = Math.min(...vehicles.map(v => v.velocity));

        let fastests = vehicles.filter(v => v.velocity === maxVelocity);
        let slowests = vehicles.filter(v => v.velocity === minVelocity);
        return [...fastests, ...slowests];
    } // getFastestsSlowests

} // TransportCompany


// Обработка по заданию
(function(){

    // доступ к методам базового класса
    Car.prototype = Object.create(Vehicle.prototype);
    Plane.prototype = Object.create(Vehicle.prototype);
    Ship.prototype = Object.create(Vehicle.prototype);

    // массив объектов по заданию:
    // 2 самолета, 3 корабля и 5 автомобилей
    let vehicles = [
        new Plane(  23.345,   -23.345,  980, 13_000_000, 2001, 360,12_000),
        new Plane( 123.123,  -123.199, 1180, 38_000_000, 2017, 160, 19_000),
        new Ship (  13.123,   -13.199,   60,123_000_000, 1998, 460,"Новороссийск"),
        new Ship ( -93.311,  -123.654,   40,89_000_000, 2012, 120,"Керчь"),
        new Ship (-113.321,    90.871,   20, 18_000_000, 1995, 20,"Новоазовск"),
        new Car  (-123.321,   100.901,   20,     30_000, 2012),
        new Car  ( 113.389,   101.922, 120, 3_100_000, 2019),
        new Car  (-129.355,     1.623,  60,  230_000, 1998),
        new Car  (-132.321,    22.788,   90, 890_000, 2002),
        new Car  (  33.129,    89.387, 1180, 140_980_000, 2019),
    ];

    let transportCompany = new TransportCompany('Эх, прокачу', vehicles);

    // вывод массива объектов
    transportCompany.show(vehicles, 'Массив транспортных средств для обработки');
    // console.log(vehicles);

    // самое старое транспортное средство/самые старые транспортные средства
    transportCompany.show(transportCompany.getOldest(),
        "Cамое старое транспортное средство/Cамые старые транспортные средства");

    // самые быстрые и самые медленные транспортные средства
    transportCompany.show(transportCompany.getFastestsSlowests(),
        'Самые быстрые и самые медленные транспортные средства');
})();