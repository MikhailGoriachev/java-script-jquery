
//Получение случайного значения
function getRandom(lo,hi) {
    return Math.trunc((hi-lo) * Math.random() + lo);
}

//Создание массива фигур
function generateFigures() {
    return [
        new Sphere(getRandom(5,20),'sphere'),
        new Sphere(getRandom(5,20),'sphere'),
        new Cone(getRandom(5,15),getRandom(15,25),getRandom(15,25),'cone'),
        new Cone(getRandom(5,15),getRandom(15,25),getRandom(15,25),'cone'),
        new Cylinder(getRandom(5,15),getRandom(15,25),'cylinder'),
        new Cylinder(getRandom(5,15),getRandom(15,25),'cylinder'),

    ];
}

//Создать массив средств передвижения
function generateVehicles() {

    let arr = [
        new Plane
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(20_000_000,150_000_000),
            getRandom(600,1101),
            getRandom(1995,2022),
            'plane',
            Math.trunc(getRandom(8_000,12_000)/100)*100,//Задание округленной величины
            getRandom(100,500),
        ),
        new Plane
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(20_000_000,150_000_000),
            getRandom(600,1101),
            getRandom(1995,2022),
            'plane',
            Math.trunc(getRandom(8_000,12_000)/100)*100,
            getRandom(100,500),
        ),
        new Ship
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(70_000_000,400_000_000),
            getRandom(20,40),
            getRandom(1995,2022),
            'ship',
            getRandom(1_000,2_000),
            generatePort(),
        ),
        new Ship
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(70_000_000,400_000_000),
            getRandom(20,40),
            getRandom(1995,2022),
            'ship',
            getRandom(1_000,2_000),
            generatePort(),
        ),
        new Ship
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(70_000_000,400_000_000),
            getRandom(20,40),
            getRandom(1995,2022),
            'ship',
            getRandom(1_000,2_000),
            generatePort(),
        ),
        new Car
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(10_000,110_000),
            getRandom(60,200),
            getRandom(1990,2022),
            'car',
        ),
        new Car
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(10_000,110_000),
            getRandom(60,200),
            getRandom(1990,2022),
            'car',
        ),
        new Car
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(10_000,110_000),
            getRandom(60,200),
            getRandom(1990,2022),
            'car',
        ),
        new Car
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(10_000,110_000),
            getRandom(60,200),
            getRandom(1990,2022),
            'car',
        ),
        new Car
        (
            getRandom(2,360),
            getRandom(2,360),
            getRandom(10_000,110_000),
            getRandom(60,200),
            getRandom(1990,2022),
            'car',
        ),
    ];

    return arr;

}//generateVehicles

//Порты приписки
function generatePort() {
    let ports = [
        'Порт Хьюстона',
        'Порт Роттердама',
        'Порт Дампира',
        'Порт Сингапура',
        'Порт Шанхая',
        'Порт Гамбурга',
    ];

    return ports[getRandom(0,ports.length)]
}

//Сокращенная запись стоимости
let convertMoney = function (value) {
    let convertedValue = '';

    if(value >=1000 && value<1_000_000)
        convertedValue = `${(value/1000).toFixed(2)} тыс.`;
    else if(value >1_000_000 && value<1_000_000_000)
        convertedValue = `${(value/1_000_000).toFixed(2)} млн.`;

    return convertedValue;
}