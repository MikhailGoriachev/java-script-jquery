
const task = () => {
    let vehicles = generateVehicles();

    showVehicles('Массив',vehicles);

    showSingleVehicle('Самое старое транспортное средство',findOldest(vehicles));

    let foundVehicles = findSlowestFastest(vehicles);

    showVehicles('Самые быстрые транспортное средство',foundVehicles.fast);
    showVehicles('Самые медленные транспортное средство',foundVehicles.slow);

}

//Вывод массива
function showVehicles(title, arr) {

    document.write(`
    <details>
       <summary>
           <span>${title}</span>
       </summary>
    <table>`);

    arr.forEach(v => document.write(v));

    document.write(`
    </table>
    </details>`);
}
//Вывод скалярного значения
function showSingleVehicle(title, vehicle) {

    document.write(`
    <details>
       <summary>
           <span>${title}</span>
       </summary>
    <table>
    ${vehicle}
    </table>
    </details>`);
}

//Найти самое старое ТС
function findOldest(vehicles) {
    let years = vehicles.map(v => v.prodYear);
    let minYear = Math.min(...years);
    return vehicles[vehicles.findIndex(v => v.prodYear === minYear)];
}

//Найти самое быстрое и медленное ТС
function findSlowestFastest(vehicles) {
    let speeds = vehicles.map(v => v.speed);

    let minSpeed = Math.min(...speeds);
    let maxSpeed = Math.max(...speeds);

    //Объект для записей транспортных средств
    let fastAndSlow = {
        fast: [],
        slow: [],
    }

    //Если скорость ТС == максимальной, то пишем в свойство fast и наоборот.
    for (let vehicle of vehicles) {
        vehicle.speed===maxSpeed?fastAndSlow.fast.push(vehicle):vehicle.speed===minSpeed?fastAndSlow.slow.push(vehicle):0;
    }

    return fastAndSlow;
}

//region Классы
//Базовый класс
function iVehicle(latitude,longitude,price,speed,prodYear,type,img) {

    //region Свойства

    //Географические координаты
    this.coords = {
        latitude: latitude,
        longitude: longitude,
    };

    this.type = type;   // Тип ТС
    this.price = price; //Стоимость
    this.speed = speed; //Скорость
    this.prodYear = prodYear; //год выпуска
    this.img = img; //Картинка характеризующая вид ТС
    //endregion

    //Вывод
    iVehicle.prototype.toString = function () {}


}//iVehicle

//Самолет
function Plane(latitude,longitude,price,speed,prodYear,img,altitude,seats) {
    
    //Передаём контекст и свойства
    iVehicle.call(this,latitude,longitude,price,speed,prodYear,'Самолет',img)
    
    //Высота полета
    this.altitude = altitude;

    //Вместимость
    this.seatsCount = seats;

    //Вывод
    Plane.prototype.toString = function () {
        return `
        <tr  class="separator-style">
            <td rowspan="7" class="image-cell">
                <img src="../images/vehicles/${this.img}.png" alt="">
            </td>
            <td>
                Тип транспорта
            </td>
            <td>
                ${this.type}
            </td>
        </tr>
        <tr>
            <td>
                Гео.координаты
            </td>
            <td>
                ${this.coords.latitude.toFixed(2)}<br>
                ${this.coords.longitude.toFixed(2)}
            </td>
        </tr>
        <tr>
            <td>
                Макс.скорость передвижения
            </td>
            <td>
                ${this.speed} км/ч
            </td>
        </tr>
        <tr>
            <td>
                Потолок
            </td>
            <td>
                ${this.altitude} м
            </td>
        </tr>
        <tr>
             <td>
                 Стоимость
             </td>
             <td>
                 $${convertMoney(this.price)}
             </td>
       </tr>
        <tr>
             <td>
                 Год производства
             </td>
             <td>
                 ${this.prodYear}
             </td>
       </tr>
        <tr>
             <td>
                 Вместимость пассажиров
             </td>
             <td>
                 ${this.seatsCount}
             </td>
       </tr>`
    }

}//Plane

//Автомобиль
function Car(latitude,longitude,price,speed,prodYear,img) {

    //Передаём контекст и свойства
    iVehicle.call(this,latitude,longitude,price,speed,prodYear,'Автомобиль',img)

    //Вывод
    Car.prototype.toString = function () {
        return `
        <tr  class="separator-style">
            <td rowspan="5" class="image-cell">
                <img src="../images/vehicles/${this.img}.png" alt="">
            </td>
            <td>
                Тип транспорта
            </td>
            <td>
                ${this.type}
            </td>
        </tr>
        <tr>
            <td>
                Гео.координаты
            </td>
            <td>
                ${this.coords.latitude.toFixed(2)}<br>
                ${this.coords.longitude.toFixed(2)}
            </td>
        </tr>
        <tr>
            <td>
                Макс.скорость передвижения
            </td>
            <td>
                ${this.speed} км/ч
            </td>
        </tr>
        <tr>
             <td>
                 Стоимость
             </td>
             <td>
                 $${convertMoney(this.price)}
             </td>
       </tr>
        <tr>
             <td>
                 Год производства
             </td>
             <td>
                 ${this.prodYear}
             </td>
       </tr>`
    }

}//Car

//Корабль
function Ship(latitude,longitude,price,speed,prodYear,img,seats,port) {

    //Передаём контекст и свойства
    iVehicle.call(this,latitude,longitude,price,speed,prodYear,'Корабль',img)

    //Порт приписки
    this.homePort = port;

    //Вместимость пассажиров
    this.seatsCount = seats;

    //Вывод
    Ship.prototype.toString = function () {
        return `
        <tr  class="separator-style">
            <td rowspan="7" class="image-cell">
                <img src="../images/vehicles/${this.img}.png" alt="">
            </td>
            <td>
                Тип транспорта
            </td>
            <td>
                ${this.type}
            </td>
        </tr>
        <tr>
            <td>
                Гео.координаты
            </td>
            <td>
                ${this.coords.latitude.toFixed(2)}<br>
                ${this.coords.longitude.toFixed(2)}
            </td>
        </tr>
        <tr>
            <td>
                Макс.скорость передвижения
            </td>
            <td>
                ${this.speed} миль/ч
            </td>
        </tr>
        <tr>
            <td>
                Порт приписки
            </td>
            <td>
                ${this.homePort}
            </td>
        </tr>
        <tr>
             <td>
                 Стоимость
             </td>
             <td>
                 $${convertMoney(this.price)}
             </td>
       </tr>
        <tr>
             <td>
                 Год производства
             </td>
             <td>
                 ${this.prodYear}
             </td>
       </tr>
        <tr>
             <td>
                 Вместимость пассажиров
             </td>
             <td>
                 ${this.seatsCount}
             </td>
       </tr>`
    }

}//Ship

//endregion



