
const task = () => {
    let figures = generateFigures();

    showFigures('Массив',figures)

    figures.sort((f1,f2) => f2.getVolume() - f1.getVolume());
    showFigures('Отсортированный массив по убыванию V',figures)

    figures.sort((f1,f2) => f1.getSquare() - f2.getSquare());
    showFigures('Отсортированный массив по возрастанию S',figures)

}

//Вывод массива
function showFigures(title,arr) {

    document.write(`
    <details>
       <summary>
           <span>${title}</span>
       </summary>
    <table>`);

    arr.forEach(f => document.write(f));

    document.write(`
    </table>
    </details>`);
}

//region Классы
//Базовый класс
function iFigure(icon,radius) {

  this.icon = icon;
  this.radius = radius;

  //Площадь
  iFigure.prototype.getSquare = function () {
  }
  //Объём
  iFigure.prototype.getVolume = function () {
  }

  //Вывод
  iFigure.prototype.toString = function () {
  }

  //Сравнение
  iFigure.prototype.compareTo = function (comparedFigure) {

  }
}//iFigure

//сфера
function Sphere(radius,icon) {

  //Наследуемся от базового класса
  iFigure.call(this,icon,radius);

  //Площадь
  Sphere.prototype.getSquare = function () {
    return 4*Math.PI*this.radius**2;
  }
  //Объём
  Sphere.prototype.getVolume = function () {
    return 4/3*Math.PI*this.radius**3;
  }

  //Вывод
  Sphere.prototype.toString = function () {
    return `
        <tr  class="separator-style">
            <td rowspan="3" class="image-cell">
                <img src="../images/figures/${this.icon}.png" alt="">
            </td>
            <td>
                Радиус
            </td>
            <td>
                ${this.radius}
            </td>
        </tr>
        <tr>
            <td>
                Площадь
            </td>
            <td>
                ${Math.floor(this.getSquare().toFixed(0))}
            </td>
        </tr>
        <tr>
             <td>
                 Объем
             </td>
             <td>
                 ${Math.floor(this.getVolume().toFixed(0))}
             </td>
       </tr>`;
  }//toString

  //Сравнение
  Sphere.prototype.compareTo = function (comparedFigure) {
      return this.getVolume()-comparedFigure.getVolume();
  }

}//Sphere

//Конус
function Cone(radius,height,l,icon) {

  //Наследуемся от базового класса
  iFigure.call(this,icon,radius);

  //region Свойства
  this.height = height;
  this.l = l;

  //endregion

  //Площадь
  Cone.prototype.getSquare = function () {
    return Math.PI*this.radius**2+Math.PI*this.radius*this.l;
  }
  //Объём
  Cone.prototype.getVolume = function () {
    return (Math.PI*this.radius**2)/3*this.height;
  }

  //Вывод
  Cone.prototype.toString = function () {
    return `
        <tr class="separator-style">
            <td rowspan="5" class="image-cell">
                <img src="../images/figures/${this.icon}.png" alt="">
            </td>
            <td>
                Радиус
            </td>
            <td>
                ${this.radius}
            </td>
        </tr>
        <tr>
            <td>
                Высота
            </td>
            <td>
                ${this.height}
            </td>
        </tr>
        <tr>
            <td>
                Образующая
            </td>
            <td>
                ${this.l}
            </td>
        </tr>
        <tr>
            <td>
                Площадь
            </td>
            <td>
                ${this.getSquare().toFixed(0)}
            </td>
        </tr>
        <tr>
             <td>
                 Объем
             </td>
             <td>
                 ${this.getVolume().toFixed(0)}
             </td>
       </tr>`;
  }//toString

  //Сравнение
  Cone.prototype.compareTo = function (comparedFigure) {
      return this.getVolume()-comparedFigure.getVolume();
  }

}//cone

//Цилиндр
function Cylinder(radius,height,icon) {

  //Наследуемся от базового класса (создаём переменные для этого контектса)
  iFigure.call(this,icon,radius);

  //region Свойства
  this.height = height;

  //endregion

  //Площадь
  Cylinder.prototype.getSquare = function () {
    return 2*Math.PI*this.radius**2+2*Math.PI*this.radius*this.height;
  }
  //Объём
  Cylinder.prototype.getVolume = function () {
    return Math.PI*this.radius**2*this.height;
  }

  //Вывод
  Cylinder.prototype.toString = function () {
    return `
        <tr class="separator-style">
            <td rowspan="4" class="image-cell">
                <img src="../images/figures/${this.icon}.png" alt="">
            </td>
            <td>
                Радиус
            </td>
            <td>
                ${this.radius}
            </td>
        </tr>
        <tr>
            <td>
                Высота
            </td>
            <td>
                ${this.height}
            </td>
        </tr>
        <tr>
            <td>
                Площадь
            </td>
            <td>
                ${this.getSquare().toFixed(0)}
            </td>
        </tr>
        <tr>
             <td>
                 Объем
             </td>
             <td>
                 ${this.getVolume().toFixed(0)}
             </td>
       </tr>`;
  }//toString

  //Сравнение
  Cylinder.prototype.compareTo = function (comparedFigure) {
      return this.getVolume()-comparedFigure.getVolume();
  }

}//Cylinder
//endregion



