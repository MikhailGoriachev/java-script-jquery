﻿alert("JavaScript из внешнего файла");

