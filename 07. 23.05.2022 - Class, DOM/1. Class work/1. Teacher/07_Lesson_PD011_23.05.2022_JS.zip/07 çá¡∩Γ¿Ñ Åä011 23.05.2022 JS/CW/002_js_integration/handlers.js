// Обработчик события click - нажатие по кнопке.
function buttonClickHandler1() {
    alert("Кнопка 1 нажата.");
    // document.write("<h3>Кнопка 1 нажата.</h3>");
}

function buttonClickHandler2() {
    alert("Кнопка 2 нажата.");
    // document.write("<h3>Кнопка 2 нажата.</h3>");
}

function buttonClickHandler3() {
    alert("Кнопка 3 нажата.");
    // document.write("<h3>Кнопка 3 нажата.</h3>");
}