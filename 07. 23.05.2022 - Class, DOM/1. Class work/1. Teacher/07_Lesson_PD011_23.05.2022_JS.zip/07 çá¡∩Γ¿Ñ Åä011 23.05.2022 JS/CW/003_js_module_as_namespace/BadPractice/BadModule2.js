﻿var name = "MODULE 2"; // глобальная переменная

function startModule2() {
    document.write(name + "<br />");
}