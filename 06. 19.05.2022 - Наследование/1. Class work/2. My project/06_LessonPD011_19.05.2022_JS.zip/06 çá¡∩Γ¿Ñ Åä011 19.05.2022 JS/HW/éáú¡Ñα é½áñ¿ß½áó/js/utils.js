
//Получение случайного значения
function getRandom(lo,hi) {
    return Math.trunc((hi-lo) * Math.random() + lo);
}

//region Задача 2

function getBook() {

    let book1 = {
            name: "Алгоритмы на Java",
            author: "Роберт Седжвик",
            coverFile: "book1.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book2 = {
            name: "Rapid Development",
            author: "Steve McConnell",
            coverFile: "book2.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book3 = {
            name: "Предметно-ориентированное проектирование (DDD)",
            author: "Эрик Эванс",
            coverFile: "book3.jpg",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book4 = {
            name: "Искусство программирования",
            author: "Дональд Кнут",
            coverFile: "book4.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book5 = {
            name: "Жемчужины программирования",
            author: "Джон Бентли",
            coverFile: "book5.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        },
        book6 = {
            name: "Алгоритмы. Построение и анализ",
            author: "Томас Х. Кормен",
            coverFile: "book6.webp",
            year: getBookPubYear(),
            price: getBookPrice(),
        }

    let books = [book1,book2,book3,book4,book5,book6];

    return books[getRandom(0,books.length)];

}//getBook


function getBookPrice()
{
    return getRandom(500,2200);
}

//Год издания
function getBookPubYear()
{
    return getRandom(1980,2022);
}

//Генерация массива книг
function generateBooks() {
    let books = new Array();
    for (let i = 0,tempBook; i < 10; i++) {
        tempBook = getBook();
        books.push(new Book(tempBook.name,tempBook.author,tempBook.coverFile,tempBook.year,tempBook.price));
    }

    return books;
}

//endregion

//region Задача 3

//Сформировать объект представления о погоде
function getViewWeather() {
    let rainfall1 = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
    },
        sunny = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
        typeIcon: "sunny.png"
    },
        partlyCloudy = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
        typeIcon: "partly-cloudy.png"
    },
        rainfall2 = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
    },
        cloudy = {
        temperature: generateTemperature(),
        pressure: generatePressure(),
        humidity: generateHumidity(),
        windObj: generateWind(),
        typeIcon: "clouds.png"
    }

    //Условное задание отображения иконки осадков
    rainfall1.typeIcon = rainfall1.temperature<=0?"snow.png":"rainy.png";
    rainfall2.typeIcon = rainfall2.temperature<=0?"snow.png":rainfall2.temperature>=27?"lightning.png":"rainy.png";

    //Сформировать массив
    let weather = [rainfall2,rainfall1,sunny,cloudy,partlyCloudy];

    return weather[getRandom(0,weather.length)];
}

function generateTemperature() {
    return getRandom(5,30);
}
function generatePressure() {
    return getRandom(700,1050);
}
function generateHumidity() {
    return getRandom(10,99);
}

//Функция возвращает объект
function generateWind() {

    //Направления ветра
    let windDirections = [
        "С",
        "С-В",
        "В",
        "Ю-В",
        "Ю",
        "Ю-З",
        "З",
        "С-З"
    ];

    return {
        direction: windDirections[getRandom(0, windDirections.length)],
        speed: getRandom(0, 60)
    };
}//generateWind

//Сформировать массив представлений погоды
function generateWeathers() {
    let array = new Array();

    for (let i = 0; i < 7; i++) {
        let w = getViewWeather();
        array[i] = new Weather(w.temperature,w.pressure,w.humidity,w.windObj,w.typeIcon,i)
    }

    return array;
}

//endregion
