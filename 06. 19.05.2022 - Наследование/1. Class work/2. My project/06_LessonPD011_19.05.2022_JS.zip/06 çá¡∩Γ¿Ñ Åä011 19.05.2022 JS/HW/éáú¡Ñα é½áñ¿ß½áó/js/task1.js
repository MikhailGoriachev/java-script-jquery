/*Спроектировать функцию-конструктор без использования прототипов – представление данных о приготовлении хлеба в бытовой хлебопечке: номер программы приготовления, цвет корочки (светлый (1), обычный (2), темный (3)), масса выпекаемого объекта в кг, время старта программы (час и минута).
Методы: начать выпечку, добавить дрожжи, завершить выпечку.
Продемонстрируйте работу методов.*/

function BreadMaker() {

    //Номер программы
    this.progNumber = getRandom(1,1000);

    //Цвет корочки
    this.crustColor = getRandom(1,4);
    
    //Масса в КГ
    this.weight = getRandom(1,3);
    
    //Время старта
    this.startTime = `${(new Date()).getHours()}:${new Date().getMinutes()}`;
    
    this.startBaking = () => `выпечка начата`;
    this.continueBaking = () => 'дрожжи добавлены';
    this.completeBaking = () => `выпечка завершена`;

    this.toString = () => {
        return `
                <table>
                    <tr>
                        <td><span>Цвет корочки:</span></td>
                        <td><span>${this.crustColor==1?'светлый':this.crustColor==2?'обычный':'темный'}</span></td>
                    </tr>
                    <tr>
                        <td><span>Номер программы приготовления:</span></td>
                        <td><span>${this.progNumber}</span></td>
                    </tr>
                    <tr>
                        <td><span>Масса в КГ:</span></td>
                        <td><span>${this.weight} кг</span></td>
                    </tr>
                    <tr>
                        <td><span>Время старта:</span></td>
                        <td><span>${this.startTime}</span></td>
                    </tr>
                    <tr>
                    <td colspan="2" class="empty-cell">Методы</td>
                    </tr>`
    }

}

//Создание объекта
let breadMaker = new BreadMaker();

const task = () => {
  document.write(`
  ${breadMaker}
  <tr>
    <td>Стадия выпечки:</td>
    <td>${breadMaker.startBaking()}</td>
  </tr>
  <tr>
    <td>Стадия выпечки:</td>
    <td>${breadMaker.continueBaking()}</td>
  </tr><tr>
    <td>Стадия выпечки:</td>
    <td>${breadMaker.completeBaking()}</td>
  </tr>
  </table>
  `)
}