//Представление погоды
class Weather {

    //Свойства
    constructor(Temperature, Pressure, Humidity, Wind, Icon,day) {
     this.weatherIcon = Icon;
     this.dayOfWeek = (() => {
         let dayWeek = '';
         switch (day) {
             case 0:
                 dayWeek = 'ПН';
                 break;
             case 1:
                 dayWeek = 'ВТ';
                 break;
             case 2:
                 dayWeek = 'СР';
                 break;
             case 3:
                 dayWeek = 'ЧТ';
                 break;
             case 4:
                 dayWeek = 'ПТ';
                 break;
             case 5:
                 dayWeek = 'СБ';
                 break;
             case 6:
                 dayWeek = 'ВС';
                 break;
         }

         return dayWeek;
     })();
     this.temperature = Temperature;
     this.pressure = Pressure;
     this.humidity = Humidity;
     this.windObj = Wind;
 }


    //Вывод
    toString () {
        return `<div>
                    <table>
                        <tr><td><img class="weather-type-icon" src="../images/weather/${this.weatherIcon}"></td></tr>
                        <tr><td><span>День недели: ${this.dayOfWeek}</span></td></tr>
                        <tr><td><span>Температура: ${this.temperature}</span></td></tr>
                        <tr><td><span>Давление: ${this.pressure}</span></td></tr>
                        <tr><td><span>Влажность: ${this.humidity}%</span></td></tr>
                        <tr>
                        <td>
                            <span>Скорость ветра: ${this.windObj.speed}<br>
                            Нарпавление ветра: ${this.windObj.direction}</span>
                        </td>
                    </table>
                </div>`
    }

    //Компаратор сравнения по температуре
    compareTo (comparedObj) {
        return this.temperature - comparedObj.temperature;
    }

}

function task() {

    //Массив представлений погоды
    let weathers = generateWeathers();

    document.write(`<div class="weather-block">`);
    weathers.forEach(w => document.write(w));
    document.write(`</div>`);

    //Получение объекта
    let foundDays = findDays(weathers);

    document.write(`
        <p>Самый холодный и теплый дни:</p>
        <div class="weather-block">
            ${foundDays.coldestDay}
            ${foundDays.warmestDay}
        </div>
        <p>Количество дождливых дней: <span class="highlightValue">${countRainyDays(weathers)}</span></p>
    `)
}

//Самый холодный и теплый дни недели
function findDays(weatherArr) {

    let temperatureArr = weatherArr.map(w => w.temperature),
        minTemperature = Math.min.apply(null,temperatureArr),
        maxTemperature = Math.max.apply(null,temperatureArr);

    //Возвращаем день недели
    return {
        coldestDay: weatherArr[weatherArr.findIndex(w => w.temperature === minTemperature)],
        warmestDay: weatherArr[weatherArr.findIndex(w => w.temperature === maxTemperature)]
    };
}

//Кол-во дождливых дней
function countRainyDays(weatherArr) {
    return weatherArr.filter(w => (w.weatherIcon.includes('rainy') || w.weatherIcon.includes('lightning'))).length;
}
