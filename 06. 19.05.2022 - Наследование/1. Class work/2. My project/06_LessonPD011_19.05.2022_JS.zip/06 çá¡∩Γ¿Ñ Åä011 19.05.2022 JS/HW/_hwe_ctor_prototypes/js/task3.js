/*
* Задача 3.
* Спроектировать функцию-конструктор (в синтаксисе class) – данные
* о погоде: температура, давление, влажность, скорость и направление
* ветра, графическое отображение атмосферных явлений (ясно, облачно,
* дождь, и т.д. – не более 5 вариантов).
* Предусмотрите метод для вывода данных в разметку.
* Создайте массив данных о погоде за неделю, выведите его на страницу.
* Определите самый теплый и самый холодный дни недели, количество
* дождливых дней.
*  */

class Weather {
    constructor(meteor, temperature, pressure, humidity, wind) {
        // атмосферные явления (ясно, облачно, дождь, и т.д. – не более 5)
        this.meteor = {
            name: meteor.name,
            img: meteor.img,
        };

        // температура
        this.temperature = temperature;

        // давление,
        this.pressure = pressure;

        // влажность,
        this.humidity = humidity;

        // скорость и направление ветра,
        this.wind = {
            speed: wind.speed,
            direction: wind.direction
        };
    } // constructor

    // формирование строки с данными объекта для вывода в разметку
    toTableRow(row) {return `
        <tr>
            <td>${row}</td>
            <td class="align-center"><img src="../images/task3/${this.meteor.img}" height="64" 
                alt="условное изображение погодного явления"/><br/>${this.meteor.name}</td>
            <td>${this.temperature}</td>
            <td>${this.pressure}</td>
            <td class="align-center">${this.wind.direction}</td>
            <td>${this.wind.speed}</td>
            <td>${this.humidity}</td>
        </tr>`;
    } // toString

} // class Weather

// самовызывающаяся функция для выполнения задачи 2
(function() {

    // массив погодных явлений
    let weathers = [
        new Weather({name: "солнечно", img:"sunny.png"}, 23, 1012, 67, {speed: 5, direction: "Ю-В"}),
        new Weather({name: "дождь", img:"rain.png"}, 18, 988, 89, {speed: 12, direction: "В"}),
        new Weather({name: "дождь", img:"rain.png"}, 7, 899, 98, {speed: 15, direction: "С-В"}),
        new Weather({name: "солнечно", img:"sunny.png"}, 18, 1023, 78, {speed:85, direction: "С"}),
        new Weather({name: "облачно", img:"cloudly.png"}, 13, 1023, 87, {speed: 8, direction: "С"}),
        new Weather({name: "дождь", img:"rain.png"}, 5, 780, 98, {speed: 8, direction: "С-В"}),
        new Weather({name: "снег", img:"snow.png"}, -1, 760, 92, {speed: 6, direction: "С-З"}),
    ];

    // вывод статистики по заданию
    // количество дождливых дней
    let rainyDays = weathers.filter(w => w.meteor.name === "дождь").length;

    // массив температур по дням недели
    let temperatures = weathers.map(w => w.temperature);

    // первый самый теплый день недели
    let warmestDay = temperatures.indexOf(Math.max(...temperatures)) + 1;

    // первый самый холодный день недели
    let coldestDay = temperatures.indexOf(Math.min(...temperatures)) + 1;


    // вывод массива данных о погоде в разметку
    let row = 1;
    weathers.forEach(w => document.write(w.toTableRow(row++)));

    // вывод статистики
    document.write(`
        <tr>
            <td colspan="7">
                <h3>Статистика по заданию:</h3>
                <ul>
                    <li>Всего дождливых дней на этой неделе: <b>${rainyDays}</b></li>
                    <li>Первый самый теплый день недели: <b>${warmestDay}</b></li>
                    <li>Первый самый холодный день недели: <b>${coldestDay}</b></li>
                </ul>
            </td>
        </tr>`);

})();