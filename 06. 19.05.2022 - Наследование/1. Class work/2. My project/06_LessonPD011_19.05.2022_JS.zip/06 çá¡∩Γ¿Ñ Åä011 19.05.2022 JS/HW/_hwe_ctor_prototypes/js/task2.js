/*
* Задача 2.
* Спроектировать функцию-конструктор (с использованием прототипов) – данные
* о книге в магазине: автор, название, год издания, изображение обложки, цена
* и количество.
* Разработайте методы (на базе прототипов) для вычисления стоимости книги
* в магазине, формирования разметки для представления данных.
* Создайте массив книг (не более 10), выведите массив на страницу, вычислите
* общую стоимость всех книг магазина, общее количество книг в магазине.
* */

// описание книги в магазине по заданию
function Book(author, title, published, cover, price, quantity) {

    // автор
    this.author = author;

    // название книги
    this.title = title;

    // год издания,
    this.published = published;

    // цена,
    this.price = price;

    // количество книг в магазине
    this.quantity = quantity;

    // изображение обложки
    this.cover = cover;

    // вычисление стоимости книги в магазине
    Book.prototype.getCost = function() {
        return this.price * this.quantity;
    } // getCost


    // формирование строки для вывода в разметку
    Book.prototype.toTableRow = function (row) {return `
        <tr>
            <td>${row}</td>
            <td class="align-center">
                <img src='../images/task2/${this.cover}' alt='Обложка книги' height="128"/>
            </td>
            <td class="align-left">${this.author}</td>
            <td class="align-left">${this.title}</td>
            <td>${this.published}</td>
            <td>${this.price}</td>
            <td>${this.quantity}</td>
            <td>${this.getCost()}</td>
        </tr>`;
    }
}

// магазин с коллекцией книг
function Store(name, books) {
    this.name = name;
    this.books = books;

    // вывод книг магазина
    Store.prototype.showBooks = function() {
        let row = 1;

        document.write('<tbody>');
        books.forEach(book => document.write(book.toTableRow(row++)));
        document.write('</tbody>');
    } // showBooks

    // статистика - общее количество книг в магазине
    Store.prototype.totalBooks = function() {
        return this.books.reduce((acc, book) => acc += book.quantity, 0);
    } // totalBooks

    // статистика - общая стоимость книг в магазине
    Store.prototype.amountBooks = function() {
        return this.books.reduce((acc, book) => acc += book.getCost(), 0);
    } // amountBooks

    // вывод статистики в подвал таблицы
    Store.prototype.showStatistics = function() {
        document.write(`
            <tfoot>
                <tr><th colspan="7" class="align-right">${this.totalBooks()}</th><th>${this.amountBooks()}</th></tr>
            </tfoot>
        `)
    } // showStatistics
} // Store


// самовызывающаяся функция для демонстрации методов объекта
(function () {
    // создание объекта - магазина с массивом книг
    let books = [
        new Book("Бейтс К.", "Изучаем Java", 2018, "cover001.jpg", 900, 3),
        new Book("Васильев А.Н.", "Программирование на JavaScript", 2019, "cover002.jpg",800, 3),
        new Book("Радченко Н.А.", "1С:Предприятие. Практическое пособие разработчика", 2013, "cover003.jpg", 760, 8),
        new Book("Гальярди В.", "Раздельный Django", 2019, "cover004.jpg", 750, 7),
        new Book("Егорова Р.А.", "Создание сайта с Django 3", 2021, "cover005.jpg", 640, 5),
        new Book("Павлов Т.Б.", "Django 2.2 для профессионалов", 2016, "cover006.jpg", 510, 8),
        new Book("Скит Дж.", "C# для профессионалов", 2016, "cover007.jpg", 640, 3),
        new Book("Стиллман Э.", "Изучаем C#", 2017, "cover008.jpg", 830, 11),
        new Book("Васильев А.Н.", "Программирование на C# для начинающих", 2019, "cover009.jpg", 720, 12),
        new Book("Троелсен Э.", "Язык программирования C# 9 и платформа .NET 5", 2021, "cover010.jpg", 1220, 18),
    ];
    let store = new Store('Букинист', books);

    // вывести данные магазина: статистику и список книг
    document.write(`<caption>Книжный магазин "${store.name}"</caption>`);
    store.showStatistics();
    store.showBooks();

})();