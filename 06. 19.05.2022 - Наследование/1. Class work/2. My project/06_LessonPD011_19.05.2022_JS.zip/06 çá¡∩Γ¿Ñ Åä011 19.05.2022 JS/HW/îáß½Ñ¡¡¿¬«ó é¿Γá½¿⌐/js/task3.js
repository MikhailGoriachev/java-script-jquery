
// Функция-конструктор в синтаксисе class для объекта данных о погоде
class Weather {
    constructor(t, press, humid, windSpeed, windDirection, climate) {
        this.temperature = t;
        this.pressure = press;
        this.humidity = humid;
        this.wind = {
            speed: windSpeed,
            direction: windDirection
        };
        this.climate = {
            description: climate.description,
            img: climate.img
        }
    }

    toString() {
        return `<div class="weather-block"><img src='../images/weather/${this.climate.img}' alt ="pic" width="75" height="75"/>
                    <div>${this.climate.description}</div>
                    <div>Температура: ${this.temperature}°С</div>
                    <div>Давление: ${this.pressure} мм рт.ст.</div>
                    <div>Влажность: ${this.humidity}%</div>
                    <div>Ветер: ${this.wind.speed} м/с, ${this.wind.direction}</div></div>`;
    }

    static climates = {
        cloudy: {
            description: 'Пасмурно',
            img: 'cloudy.svg'
        },
        partlyCloudy: {
            description: 'Облачно',
            img: 'partly-cloudy.svg'
        },
        fair: {
            description: 'Ясно',
            img: 'fair.svg'
        },
        thunder: {
            description: 'Гроза',
            img: 'thunder.svg'
        },
        heavyRain: {
            description: 'Сильный дождь',
            img: 'heavy-rain.svg'
        }
    };

    // Генерация объекта
    static getRandom() {
        let directions = ['C', 'Ю', 'В', 'З', 'Ю-В', 'Ю-З', 'С-В', 'С-З'];
        let climateNames = Object.keys(Weather.climates);
        let climateName = climateNames[getRandomInt(0, climateNames.length - 1)];
        return new Weather(getRandomInt(15, 30),
            getRandomInt(600, 900),
            getRandomInt(20, 80),
            getRandomInt(0, 30), directions[getRandomInt(0, directions.length - 1)],
            Weather.climates[climateName])
    }
}

// Демонстрация
(function () {

    // Генерация
    let days = ['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье']
    let week = [...Array(7)].map((item, index) => ({d: days[index], w: Weather.getRandom()}));

    // Самый холодный день(дни) недели
    let lowestT =  Math.min(...week.map(i => i.w.temperature));
    let coolestDay = week.filter(item => item.w.temperature === lowestT).map(i => i.d).join(', ');
    // Самый теплый день(дни) недели
    let highestT = Math.max(...week.map(i => i.w.temperature));
    let warmestDay = week.filter(item => item.w.temperature === highestT).map(i => i.d).join(', ');
    // Количество дождливых дней недели
    let rainyDays = week.filter(i => i.w.climate.description === Weather.climates.heavyRain.description ||
                                     i.w.climate.description === Weather.climates.thunder.description).length;

    // Вывод
    document.write('<div class="indented display-box">');

    week.forEach(item => document.write(`<div><div class="hl"><b>${item.d}</b></div>${item.w.toString()}</div>`));

    document.write(`</div><div class="indented">
            <div><div class="hl">Самый холодный день недели: <b>${coolestDay}</b></div>
            <div><div class="hl">Самый теплый день недели: <b>${warmestDay}</b></div></div>
            <div><div class="hl">Количество дождливых дней: <b>${rainyDays}</b></div></div>
            </div>`);
})();
