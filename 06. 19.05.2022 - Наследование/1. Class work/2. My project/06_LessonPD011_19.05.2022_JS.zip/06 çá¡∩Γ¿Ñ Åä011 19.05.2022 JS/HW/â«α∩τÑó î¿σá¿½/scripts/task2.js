// Задача 2. Книга

//  •	Задача 2. Спроектировать функцию-конструктор (с использованием прототипов) – данные
//      о книге в магазине: автор, название, год издания, изображение обложки, цена и количество.
//      разметки для представления данных. Создайте массив книг (не более 10), выведите массив на
//      Разработайте методы (на базе прототипов) для вычисления стоимости книги в магазине, формирования
//      страницу, вычислите общую стоимость всех книг магазина, общее количество книг в магазине.

// работа по заданию
(function Task1() {
    // объект книги
    let book = new Book('Джон Сонмез', 'Путь программиста', 2016, 'book-path-programmer.jpg', 4000, getIntRand(0, 150));

    // вывод книги
    book.show();

    // изменение полей книги
    book.setTitle('Путь самурая (Хагакурэ)');
    book.setAuthor('Ямамото Цунэтомо');
    book.setCoverView('book-samurai.jpg');
    book.setPrice(5500);
    book.setPubYear(2019);
    book.setAmout(getIntRand(0, 150));

    // вывод книги
    book.show();
})();

// объект - Книга
function Book(
    author = 'Фамилия И.О.',
    title = 'Неизвестная книга',
    pubYear = new Date().getFullYear(),
    coverView = '',
    price = 1,
    amount = 1
) {
    //#region поля объекта

    // автор
    this.author = author;

    // название
    this.title = title;

    // год издания
    this.pubYear = pubYear;

    // фото обложки
    this.coverView = coverView;

    // цена
    this.price = price;

    // количество
    this.amount = amount;

    //#endregion

    // константные значения
    Book.prototype.minPubYear = 1600;
    Book.prototype.minValue = 0;
    Book.prototype.maxValue = 1000000;

    // методы

    //#region Геттеры и сеттеры

    // автор
    Book.prototype.setAuthor = function (author = '') {
        this.author = author.length > 0 ? author : this.author;
    };

    Book.prototype.getAuthor = function () {
        return this.author;
    };

    // название
    Book.prototype.setTitle = function (title = '') {
        this.title = title.length > 0 ? title : this.title;
    };

    Book.prototype.getTitle = function () {
        return this.title;
    };

    // год издания
    Book.prototype.setPubYear = function (pubYear = 0) {
        this.pubYear =
            pubYear >= Book.prototype.minPubYear && pubYear <= new Date().getFullYear() ? pubYear : this.pubYear;
    };

    Book.prototype.getPubYear = function () {
        return this.pubYear;
    };

    // фото обложки
    Book.prototype.setCoverView = function (coverView = '') {
        this.coverView = coverView;
    };

    Book.prototype.getCoverView = function () {
        return this.coverView;
    };

    // цена
    Book.prototype.setPrice = function (price = Book.prototype.minValue) {
        this.price = price >= Book.prototype.minValue && price <= Book.prototype.maxValue ? price : this.price;
    };

    Book.prototype.getPrice = function () {
        return this.price;
    };

    // количество
    Book.prototype.setAmout = function (amount = 0) {
        this.amount = amount >= Book.prototype.minValue && amount <= Book.prototype.maxValue ? amount : this.amount;
    };

    Book.prototype.getAmount = function () {
        return this.amount;
    };

    //#endregion

    //#region Методы

    // вывод книги в разметку
    Book.prototype.show = function () {
        document.write(`<div class="book">
                            <div class="book-image">
                                <img src="../images/${this.coverView}" alt="Изображение книги" />
                            </div>
                            <div class="title"><h3>${this.title}</h3></div>
                            <div>Автор: <span>${this.author}</span></div>
                            <div>Год издания: <span>${this.pubYear}</span></div>
                            <div>Цена: <span>${this.price}</span></div>
                            <div>Количеств: <span>${this.amount}</span></div>
                        </div>`);
    };

    //#endregion
}
