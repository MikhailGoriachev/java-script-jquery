// Задача 3. Данные о погоде

//  •	Задача 3. Спроектировать функцию-конструктор (в синтаксисе class) – данные о погоде: температура,
//      давление, влажность, скорость и направление ветра, графическое отображение атмосферных явлений (ясно,
//      облачно, дождь, и т.д. – не более 5 вариантов). Предусмотрите метод для вывода данных в разметку.
//      Создайте массив данных о погоде за неделю, выведите его на страницу. Определите самый теплый и самый
//      холодный дни недели, количество дождливых дней.

// объект — Данные о погоде
class Weather {
    // конструктор
    constructor(day = 'понедельник', temperature = 0, pressure = 700, humidity = 50, wind = new Wind(), view = '') {
        // #region поля объекта

        // день недели
        this.day = day;

        // температура
        this.temperature = temperature;

        // давление
        this.pressure = pressure;

        // влажность
        this.humidity = humidity;

        // ветер
        this.wind = wind;

        // отображение атмосферного являения
        this.view = view;

        //#endregion
    }
    // константные значения

    //#region Геттеры и сеттеры

    // день недели
    setDay(day = 0) {
        this.day = day;
    }

    getDay() {
        return this.day;
    }

    // температура
    setTemperature(temperature = 0) {
        this.temperature = temperature;
    }

    getTemperature() {
        return this.temperature;
    }

    // давление
    setPressure(pressure = minPressure) {
        this.pressure = pressure;
    }

    getPressure() {
        return this.pressure;
    }

    // влажность
    setHumidity(humidity = minHumidity) {
        this.humidity = humidity;
    }

    getHumidity() {
        return this.humidity;
    }

    // ветер
    setWind(wind = Wind()) {
        this.wind = wind;
    }

    getWind() {
        return this.wind;
    }

    // отображение атмосферного являения
    setView(view = '') {
        this.view = view;
    }

    getView() {
        return this.view;
    }

    //#endregion

    //#region Методы

    // вывод данных в разметку
    show() {
        document.write(`<div class="weather">
                            <div class="text-align-center"><span>${this.day}</span></div>
                            <div class="weather-image">
                                <img src="../images/${this.view}" alt="Изображение явления" />
                            </div>
                            <div>Температура: <span>${this.temperature}&deg;</span></div>
                            <div>Давление: <span>${this.pressure} гПа</span></div>
                            <div>Влажность: <span>${this.humidity}%</span></div>
                            <div>Ветер: <span>${this.wind.toString()}</span></div>
                        </div>`);
    }

    //#endregion
}

// модуль — Ветер
class Wind {
    // конструктор
    constructor(direction = 'С-З', speed = 0) {
        // поля модуля

        // направление
        this.direction = direction;

        // скорость
        this.speed = speed;
    }

    //#region Сеттеры и геттеры

    // направление
    setDirection(direction = '') {
        this.direction = direction.length <= 3 ? direction : this.direction;
    }

    getDirection() {
        return this.direction;
    }

    // скорость
    setSpeed(speed = 1) {
        this.speed = speed > 0 ? speed : this.speed;
    }

    getSpeed() {
        return this.speed;
    }

    //#endregion

    //#region Методы

    // генерация случайных данных
    getRandWind() {
        // массив направлений ветра
        let dir = ['З', 'С-З', 'C', 'С-В', 'В', 'Ю-В', 'Ю', 'Ю-З'];

        // диапазон значений скорости ветра
        let min = 0,
            max = 20;

        return new Wind(dir[getIntRand(0, dir.length)], getIntRand(min, max));
    }

    // вывод данных в строку
    toString() {
        return `${this.speed} м/с, ${this.direction}`;
    }

    //#endregion
}

// работа по заданию
(function Task2() {
    //  Создайте массив данных о погоде за неделю, выведите его на страницу. Определите самый теплый и самый
    //  холодный дни недели, количество дождливых дней.

    // массив объектов погоды
    let data = [
        new Weather('Понедельник'),
        new Weather('Вторник'),
        new Weather('Среда'),
        new Weather('Четверг'),
        new Weather('Пятница'),
        new Weather('Суббота'),
        new Weather('Воскресенье'),
    ];

    // изменение данных полей
    data.forEach((w) => setFieldsRandWeather(w));

    // самый теплый день
    let maxTemp = Math.max(...data.map((w) => w.temperature));

    let warmDay = data[data.findIndex((d) => d.temperature == maxTemp)];

    // самый холодный день
    let minTemp = Math.min(...data.map((w) => w.temperature));

    let coldDay = data[data.findIndex((d) => d.temperature == minTemp)];

    // количесвто дождливых дней
    let countRain = data.reduce((acc, item) => (acc += item.getView().includes('rain.png')), 0);

    // вывод статистики
    document.write(`<h3 class='text-align-center'>Статистика</h3>
                    <p>Cамый теплый день: <b>${warmDay.getDay()}</b></p>
                    <p>Cамый холодный день: <b>${coldDay.getDay()}</b></p>
                    <p>Количесвто дождливых дней: <b>${countRain}</b></p>
                    </div><div class="container">`);

    // вывод
    data.forEach((w) => w.show());

    document.write('</div>');
})();

// изменить данные полей погоды
function setFieldsRandWeather(weather) {
    weather.setTemperature(getIntRand(-10, 11));
    weather.setHumidity(getIntRand(600, 800));
    weather.setPressure(getIntRand(40, 80));
    weather.setView(getViewWeather());
    weather.setWind(new Wind().getRandWind());
}

// получить название файла изображения
function getViewWeather() {
    let files = ['sun.png', 'snow.png', 'rain.png', 'clouds.png'];

    return files[getIntRand(0, files.length)];
}
