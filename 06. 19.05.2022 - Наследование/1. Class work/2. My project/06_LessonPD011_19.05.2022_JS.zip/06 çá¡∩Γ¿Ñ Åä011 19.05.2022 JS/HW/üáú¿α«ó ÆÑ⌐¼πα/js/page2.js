// Спроектировать функцию-конструктор (с использованием прототипов) –
// данные о книге в магазине: автор, название, год издания, изображение обложки, цена и количество.
// Разработайте методы (на базе прототипов) для вычисления стоимости книги в магазине,
// формирования разметки для представления данных.
// Создайте массив книг (не более 10), выведите массив на страницу, вычислите общую стоимость всех книг магазина,
// общее количество книг в магазине.

function Book(title, coverImg, author, year, price, quantity) {
    this.title = title                   // название
    this.coverImg = coverImg;      //  обложка
    this.author = author;         //   автор
    this.year = year;            //    год издания
    this.price = price;         //     цена
    this.quantity = quantity;  //      количество

    // this.setTitle(title);
    // this.setCoverImg(coverImg);
    // this.setAuthor(author);
    // this.setYear(year);
    // this.setPrice(price);
    // this.setQuantity(quantity);

        // вывод объекта
        Book.prototype.toString = function () {
        return `<div class="show-book" ">
                <p><img src='../imgs/page2/${this.coverImg}' width='150'/><br>
                <p><b>Название:</b> "${this.title}"<br>
                <b>Автор:</b> ${this.author}<br>
                <b>Год издания:</b> ${this.year}<br>
                <b>Цена:</b>${this.price}<br>
                <b>Кол-во:</b>${this.quantity}</p></div>`;
        }

        // геттеры и сеттеры для данных модуля:
        // название
        Book.prototype.getTitle = function() {return this.title;}
        Book.prototype.setTitle = function(strTitle) {
        if(isEmpty(strTitle)) return;
            this.title = strTitle;
        }

        // автор
        Book.prototype.getAuthor = function() {return this.author;}
        Book.prototype.setAuthor = function(strAuthor) {
            if(isEmpty(strAuthor)) return;
            this.author = strAuthor;
        }

        // год издания
        Book.prototype.getYear = function() {return this.year;}
        Book.prototype.setYear = function(value) {
            if(value< 1400 || value > new Date().getFullYear()) return;
            this.year = value;
        }

        // цена
        Book.prototype.getPrice = function() {return this.price;}
        Book.prototype.setPrice = function(value) {
            if(value < 0 || value > 1500) return;
            this.price = value;
        }

        // изображение обложки
        Book.prototype.getCoverImg = function() {return this.coverImg;}
        Book.prototype.setCoverImg = function(strCoverImg) {
            if(isEmpty(strCoverImg)) return;
            this.coverImg = strCoverImg;
        }

        // количество
        Book.prototype.getQuantity= function() {return this.quantity;}
        Book.prototype.setQuantity = function(value) {
            if(value < 0 || value > 5000) return;
            this.quantity = value;
        }

}

Book.prototype.getBook = function (){
    let title = [
        ["Казаки","Хаджи-Мурат","После бала","Смерть Ивана Ильича"],           // Лев Толстой
        ["Сказка о медведихе","Марья Шонинг","О народном воспитании","Тазит"], // Александр Пушкин
        ["В ссылки","Сапоги","Студент","Воры"],                                // Антон Чехов
    ]
    let author = ["Лве Толстой", "Александр Пушкин", "Антон Чехов"]
    let idTitle = getIntRand(0,4)
    let idAuthor = getIntRand(0,3)
    let year =  getIntRand(1800, 1923);
    let price = getIntRand(500,2001);
    let quantity = getIntRand(20,101);
    let coverImg = ["1.jpg", "2.jpg", "3.jpg"];
    let idCoverImg = getIntRand(0,3);

    return new Book(title[idAuthor][idTitle], "templateBook" + coverImg[idCoverImg] ,author[idAuthor], year, price, quantity)
}

function task2(){

    const n = 10;
    let books = Array();
    for (let i = 0; i < n; i++) {
        books.unshift(Book.prototype.getBook());
    }

    // TODO: исправить вывод коллекции книг
    books.forEach(item => document.write(`${item}`));

    let totalSum = books.reduce((sum, current) => sum + current.getPrice(),0);
    let totalQuantity =  books.reduce((sum, current) => sum + current.getQuantity(),0);

    document.write(`<p class="p">Общее количество книг: ${totalQuantity}</p>
                    <p class="p">Общая стоимость книг: ${totalSum}`);
}

// метод проверяющий является ли строка пустой, или содержит только пробелы.
function isEmpty(str) {
    return (str.length === 0 || !str.trim());
}