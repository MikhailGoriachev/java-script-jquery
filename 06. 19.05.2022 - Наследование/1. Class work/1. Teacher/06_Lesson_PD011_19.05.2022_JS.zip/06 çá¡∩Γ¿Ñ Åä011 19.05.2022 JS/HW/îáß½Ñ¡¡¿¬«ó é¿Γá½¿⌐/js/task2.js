
// Функция-конструктор для объекта книги
function Book(title, author, cover, year, price, amount){
    this.title = title;
    this.author = author;
    this.cover = cover;
    this.year = year;
    this.price = price;
    this.amount = amount;

    Book.prototype.totalCost = function () {
        return this.price * this.amount;
    }

    Book.prototype.toString = function () {
        return `<div class="book"><img src='../images/books/${this.cover}' alt="pic" style="width: 200px;height: 300px "/>
                    <div><div class="hl">Название:</div> ${this.title}</div>
                    <div><div class="hl">Автор:</div> ${this.author}</div>
                    <div><div class="hl">Год издания:</div> ${this.year}</div>
                    <div><div class="hl">Цена:</div> ${this.price}</div>
                    <div><div class="hl">Количество:</div> ${this.amount}</div>
                    <div><div class="hl">Стоимость:</div> ${this.totalCost()}</div></div>`;
    };
}

// Демонстрация
(function(){
    let books = [
        new Book('451° по Фаренгейту','Рэй Брэдбери', 'cover1.jpg', 1953, 250, 12),
        new Book('Изучаем Java','К. Бейтс', 'cover2.jpg', 2019, 900, 6),
        new Book('451° по Фаренгейту','Рэй Брэдбери', 'cover1.jpg', 1953, 250, 12),
        new Book('Программирование на JavaScript', 'Васильев А.Н.','cover3.jpg', 2019, 800, 8),
        new Book('1С: Предприятие. Практическое пособие разработчика', 'Радченко Н.А.','cover4.jpg', 2012, 1200, 8),
        new Book('Программирование на JavaScript', 'Васильев А.Н.','cover3.jpg', 2019, 800, 8),
        new Book('Изучаем Java','К. Бейтс', 'cover2.jpg', 2019, 900, 6),
        new Book('1С: Предприятие. Практическое пособие разработчика', 'Радченко Н.А.','cover4.jpg', 2012, 1200, 8),
    ];

    // Информация о количестве книг и суммарной стоимости
    let total = books.reduce((prev, cur) =>
        ({amount: prev.amount + cur.amount, costs: prev.costs + cur.totalCost()}), {amount: 0, costs: 0});

    // Вывод
    document.write('<div class="indented display-box">');

    books.forEach(item => document.write(`${item}`));

    document.write(`</div><div class="indented">
            <div><div class="hl">Всего книг:</div> ${total.amount}
            <div><div class="hl">Общая стоимость всех книг:</div> ${total.costs}</div></div>`);

})();