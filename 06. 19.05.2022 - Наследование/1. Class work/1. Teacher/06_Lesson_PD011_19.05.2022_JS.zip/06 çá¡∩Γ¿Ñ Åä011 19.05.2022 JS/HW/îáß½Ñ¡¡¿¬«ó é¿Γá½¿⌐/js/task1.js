// Функция-конструктор для объекта Хлеб
function Bread(programNum){
    this.programNum = programNum;
    this.crustColor = "-";
    this.mass = 0;
    this.startBakingTime = null;

    // Начало выпечки
    this.startBaking = function(){
        this.startBakingTime = new Date();
    }
    // Добавить дрожжи
    this.addYeast = function(){
        switch (this.programNum){
            case 1: this.mass += 0.1; break;
            case 2: this.mass += 0.3; break;
            case 3: this.mass += 0.5;
        }
    }
    // Закончить выпечку
    this.finishBaking = function(){
        switch (this.programNum){
            case 1: this.mass = 0.4;
                this.crustColor = 'светлый';
                break;
            case 2:
                this.mass = 0.7;
                this.crustColor = 'обычный';
                break;
            case 3:
                this.mass = 1.2;
                this.crustColor = 'темный';
        }
    }

    this.toString = function(){
        return `<div class="indented">
                <div><b>Хлеб</b></div>
                <div>Программа: ${this.programNum}</div>
                <div>Время начала выпечки: ${this.startBakingTime?.getHours() ?? '--'}:${this.startBakingTime?.getMinutes() ?? '--'}</div>    
                <div>Цвет корочки: ${this.crustColor}</div>
                <div>Масса: ${this.mass}кг</div>    
                </div>`;
    }
}


// Демонстрация работы методов
(function (){
    let bread = new Bread(getRandomInt(1,3));

    document.write(`<div class="indented">
                <div>Объект хлеба создан:</div>
                ${bread}</div>`);

    bread.startBaking();

    document.write(`<div class="indented">
                <div>Выпечка начата:</div>
                ${bread}</div>`);

    bread.addYeast();

    document.write(`<div class="indented">
                <div>Дрожжи добавлены:</div>
                ${bread}</div>`);

    bread.finishBaking();

    document.write(`<div class="indented">
                <div>Выпечка окончена:</div>
                ${bread}</div>`);
})()