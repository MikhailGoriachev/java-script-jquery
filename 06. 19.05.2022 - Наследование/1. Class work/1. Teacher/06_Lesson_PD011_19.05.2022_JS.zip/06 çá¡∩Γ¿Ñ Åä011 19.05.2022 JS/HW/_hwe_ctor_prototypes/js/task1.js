/*
* Задача 1.
* Спроектировать функцию-конструктор без использования прототипов для
* представления данных о приготовлении хлеба в бытовой хлебопечке:
*     ▬ номер программы приготовления,
*     ▬ цвет корочки (светлый (1), обычный (2), темный (3)),
*     ▬ масса выпекаемого объекта в кг,
*     ▬ время старта программы (час и минута).
* Методы объекта: начать выпечку, добавить дрожжи, завершить выпечку.
* Продемонстрируйте работу методов.
* */

// хлебопечка
function BreadMaker(program, color, mass, startTime) {
    // номер программы
    this.program = program;

    // цвет корочки
    this.color = color;

    // масса выпечки
    this.mass = mass;

    // время старта программы (часы, минуты)
    this.startTime = {
        hour: startTime.hour,
        min : startTime.min
    };

    // состояние хлебопечки
    this.state = "Исправна, выключена";

    // начать выпечку
    this.start = function() {
        this.state = "Старт программы";
    } // start

    // добавить дрожжи
    this.addYest = function() {
        this.state = "Дрожжи добавлены";
    } // addYest

    // завершить выпечку
    this.finish = function() {
        this.state = "Финиш программы";
    } // finish

    // включить хлебопечку
    this.turnOn = function() {
        this.state = "Хлебопечка включена";
    }

    // выключить хлебопечку
    this.turnOff = function() {
        this.state = "Хлебопечка выключена";
    }

    // Вывод в разметку
    this.writeTableRow = function (row) {
        document.write(`
            <tr>
                <td>${row}</td>
                <td class="align-left">${this.program}</td>
                <td class="align-left">${this.color}</td>
                <td>${this.mass}</td>
                <td>${this.startTime.hour}:${this.startTime.min}</td>
                <td class="align-left">${this.state}</td>
            </tr>
        `);
    } // toTableRow

} // BreadMaker

// демонстрация работы методов объекта
(function() {
    let breadMaker = new BreadMaker("Программа 1", "темный", 0.75, {hour: 11, min: 20});

    // вывод сформированного объекта
    let row = 1;
    breadMaker.writeTableRow(row);

    // демонстрация методов объекта
    breadMaker.turnOn();
    breadMaker.writeTableRow(++row);

    breadMaker.start();
    breadMaker.writeTableRow(++row);

    breadMaker.addYest();
    breadMaker.writeTableRow(++row);

    breadMaker.finish();
    breadMaker.writeTableRow(++row);

    breadMaker.turnOff();
    breadMaker.writeTableRow(++row);
})();