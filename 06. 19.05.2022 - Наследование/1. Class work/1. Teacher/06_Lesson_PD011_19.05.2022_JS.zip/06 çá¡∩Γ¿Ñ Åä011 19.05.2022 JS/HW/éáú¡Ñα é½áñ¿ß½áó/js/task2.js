
//Конструктор книг
function Book(Name,Author,Cover,Year,Price) {

    //region Свойства
    this.name = Name;
    this.author = Author;
    this.coverFile = Cover;
    this.year = Year;
    this.price = Price;
    this.amount = getRandom(1,50);
    //endregion

    //Методы
    Book.prototype.countCost = function () { return this.price*this.amount};
    Book.prototype.toString = function () {
        return `<div>
                    <table>
                        <tr><td><img class="book-cover" src="../images/book-covers/${this.coverFile}"></td></tr>
                        <tr><td><span><b>Название</b>: ${this.name}</span></td></tr>
                        <tr><td><span><b>Автор</b>: ${this.author}</span></td></tr>
                        <tr><td><span><b>Год публикации</b>: ${this.year}</span></td></tr>
                        <tr><td><span><b>Цена</b>: ${this.price}</span></tr>
                        <tr><td><span><b>Количество</b>: ${this.amount}</span></td></tr>
                        <tr><td><span>Общая стоимость книг: <b>${this.countCost()}</b></span></td></tr>
                    </table>
                </div>`
    };
}

//Исполняемая функция
function task() {
    //Создание массива
    let books = generateBooks();

    //Вывод
    document.write(`<div class="main-books-block">`)

    books.forEach(b => document.write(b));

    document.write(`</div>`)


    let sumOfPrices = books.reduce((acc,book) => book.countCost()+acc,0),
        booksAmount = books.reduce((acc,book) => book.amount+acc,0);

    document.write(`<p>Стоимость всех книг: <span class="highlightValue">${sumOfPrices}</span>
                <br>Количество книг в магазине: <span class="highlightValue">${booksAmount}</span></p>`)

}

