// Спроектировать функцию-конструктор без использования прототипов – представление данных о
// приготовлении хлеба в бытовой хлебопечке:
// •	номер программы приготовления,
// •	цвет корочки (светлый (1), обычный (2), темный (3)),
// •	масса выпекаемого объекта в кг,
// •	время старта программы (час и минута).
// Методы объекта – начать выпечку, добавить дрожжи, завершить выпечку.
// Продемонстрируйте работу методов.

function BreadMaker(numProgram, crustColor, mass, startTime){
    this.numProg = numProgram;       // номер программы приготовления
    this.crustColor = crustColor;   //  цвет корочки(светлый(1), обычный(2), темный(3))
    this.mass = mass;              //   масса выпекаемого объекта в кг
    this.startTime = startTime;   //    время старта программы (час и минута)
    this.state = false;          //     текущее состояние хлебопечки(false - не выпекает, true - выпекает)
    this.isYeast = false;       //      наличие дрожей в хлебопечке

    // начать выпечку
    this.startBaking = function(){
        let str = (!this.state)?"Выпечка начата!":"Выпечка была запущена ранее";
        if (!this.state)
            this.state = true;
        document.write(`${str}<br>`);
    } // startBaking

    // добавить дрожжи
    this.addYeast = function (){
        this.isYeast = true;
        document.write(`Дрожжи добавлены <br>`)
    } //  addYeast

    // завершить выпечку
    this.stopBaking = function (){
        let str = (this.state)?"Выпечка завершена!":"Выпечка не запущена";
        if (this.state){
            this.state = false;
            // если выпечку завершили, значит продукт готов ==> добавленные дрожжи израсходованы
            this.isYeast = false;
        }
        document.write(`${str}<br>`);
    } // stopBaking

    this.strCrustColor = function (){
        switch (this.crustColor){
            case 1:
                return "светлый";
            case 2:
                return "обычный";
            case 3:
                return "темный";
            default:
                return "неизвестно";
        } // switch
    } // strCrustColor

    this.toString = function (){
        //  Время старта программы: ${this.startTime.hour}ч. ${this.startTime.minute}мин.<br>
        return `<b>Программа приготовления:</b> ${this.numProg}<br>
                <b>Время старта программы:</b> ${this.startTime}<br>
                <b>Масса выпекаемого продукта:</b> ${this.mass} кг.<br> 
                <b>Цвет корочки:</b> ${this.strCrustColor()}<br>
                <b>Дрожжи:</b> ${this.isYeast?"добавлены":"не добавлены"}<br>
                <b>Текущее состояние хлебопечки:</b> ${this.state?"Идет выпечка":"Выпечка не запущена"}<br>`
    } // toString
} // BreadMaker

function Time(hour, minute){
    this.hour = hour;     // час
    this.minute = minute; // минута

    this.toString = function(){
        return `${this.hour}ч. ${this.minute}мин.`
    }
}

// демонстрация методов объекта
function task1 (){
    let time = new Time(12,45);
    let breadMaker = new BreadMaker(2,2,3,time);

    document.write(`<p class="p-script">Исходный объект:</p> ${breadMaker}<br>`);

    breadMaker.startBaking();
    breadMaker.addYeast();

    document.write(`<p class="p-script">Объект после 2 обработок(Запуск выпечки, добавление дрожей):</p> ${breadMaker}<br>`);

    breadMaker.stopBaking()

    document.write(`<p class="p-script">Объект после еще одной обработки(Завершение выпечки):</p> ${breadMaker}<br>`);

}


