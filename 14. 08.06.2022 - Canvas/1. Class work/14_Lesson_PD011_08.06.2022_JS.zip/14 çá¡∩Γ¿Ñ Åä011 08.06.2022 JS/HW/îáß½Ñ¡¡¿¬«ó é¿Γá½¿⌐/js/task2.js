// конструктор объектов заявки на билет
class Ticket {
    constructor(id = 0, {flight = "", destination = ""} = {}, paxFullName = "", price = 0) {

        this._id = id;
        // пункт назначения
        this._destination = destination;
        // номер рейса
        this._flight = flight;
        // фамилия и инициалы пассажира
        this._paxFullName = paxFullName;
        // стоимость билета
        this._price = price;
    }


    get id() { return this._id; }
    set id(value) { this._id = value; }

    get destination() { return this._destination; }
    set destination(value) { this._destination = value || 'не указано'; }

    get flight() { return this._flight; }
    set flight(value) { this._flight = value || 'не указано';}

    get paxFullName() { return this._paxFullName; }
    set paxFullName(value) { this._paxFullName = value || 'не указано'; }

    get price() { return this._price; }
    set price(value) { this._price = value >= 0 ? value : 0; }

    assign(ticket) {
        Object.assign(this, ticket);
        return this;
    }

    toTableRow(row){
        return `<tr id="t${this._id}">
                    <td>${row}</td>
                    <td class="align-left">${this._paxFullName}</td>
                    <td class="align-left">${this._flight}</td>
                    <td class="align-left">${this._destination}</td>
                    <td>${this._price}</td>
                    <td>
                        <button name="editTicket" data-ticket-id="${this._id}" title="Редактирование данных заявки">
                            <i data-ticket-id="${this._id}" id="editTicket" class="fa fa-edit fa-2x"></i></button>
                        <button name="deleteTicket" data-ticket-id="${this._id}" title="Удаление данных заявки">
                            <i data-ticket-id="${this._id}" id="deleteTicket" class="fa fa-remove fa-2x"></i></button>
                    
                </tr>`;
    }
}

// Фабрика генерации заявок на билет
class TicketFactory{
    static generate(amount){
        return [...Array(amount)].map((t,i) =>
            new Ticket(i + 1, this.randomFlightInfo(), this.randomFullName(), getRandomInt(1000, 5_000)));
    }

    static randomFullName(){
        return ["Гущин Ф. А.", "Симонов Н.А.", "Молчанов А.А.", "Емельянов Ц.И.", "Беляков К.В.",
            "Доронин У.И.", "Несвитайло Д.П.", "Кондратьев М.Ю.", "Симонов Ч.В.", "Тягай С.В.",
            "Василенко В.Ю.", "Дзюба Д.Д.", "Константинов Д.П.", "Лукин А.В.", "Марков Й.В.",
            "Несвитайло Р.В.", "Титов П.Ф.", "Анисимов Е.В.", "Миклашевский Д.В.", "Зыков Э.Б.",
            "Комаров С.Л.", "Рогов Э.Э.", "Королёв О.В.", "Воронцов И.А.", "Семенов Р.М.",
            "Дунаев В.Б.",   "Харламова Ю.В.", "Олегова И.В.", "Янковский В.В.", "Абалкин Л.Ж.",
            "Горбовски Д.В.", "Каммерер М.А.", "Романова П.В.",  "Воликова И.А.", "Жукова Р.Б.",
            "Денисова Д.А.", "Соколов Д.В.",   "Лебедев К.К."].random();
    }

    static randomFlightInfo(){
        return[
            {flight: "АФ4567", destination: "Сочи"},                   {flight: "FL91AS", destination: "Геленджик"},
            {flight: "PB9812", destination: "Воронеж"},                {flight: "ALF081", destination: "Берлин"},
            {flight: "PB9231", destination: "Саратов"},                {flight: "AFL002", destination: "Иваново"},
            {flight: "PB1233", destination: "Шарм-эш-Шейх"},           {flight: "FL98AS", destination: "Ростов-на-дону"},
            {flight: "AFL033", destination: "Париж, шарль де-Голль"},  {flight: "АФ9811", destination: "Москва, Внуково"},
            {flight: "АФ0011", destination: "Владивосток"},            {flight: "AFL021", destination: "Париж, Орли"},
            {flight: "АФ9821", destination: "Москва, Домодедово"},     {flight: "PB0911", destination: "Симферополь"},
            {flight: "PB7812", destination: "Ярославль"},              {flight: "PB2271", destination: "Астрахань"}
        ].random();
    }
}

// конструктор объекта управления заявками
class BookOffice {

    constructor(tickets = null) {
        this.tickets = tickets;
    }

    get tickets() { return this._tickets; }
    set tickets(value) {
        this._tickets = value;
        this.saveToLocalStorage();
    }

    // получить заявки по id
    getById(id) {
        return this._tickets.filter(w => +w.id === +id)[0];
    }

    // добавить заявку на билет
    addTicket(flight, destination, paxFullName, price) {
        let id = Math.max(...this._tickets.map(t => t.id)) + 1;

        let ticket = new Ticket(id, {flight, destination}, paxFullName, price);
        this._tickets.push(ticket);

        this.saveToLocalStorage();
        return ticket;
    }

    // изменить данные заявки
    updateTicket(id, fullName, flight, destination, price) {
        let index = this._tickets.findIndex(t => +t.id === +id);

        if(index === -1 )
            return;

        this._tickets[index].paxFullName = fullName;
        this._tickets[index].destination = destination;
        this._tickets[index].flight = flight;
        this._tickets[index].price = price;

        this.saveToLocalStorage();
    }

    // удалить заявку по id
    deleteTicket(id){
        let index = this._tickets.findIndex(w => +w.id === +id);
        if(index > -1)
            this._tickets.splice(index, 1);

        this.saveToLocalStorage();
    }

    // копия коллекции билетов, сортированная по пункту назначения
    orderByDestination() {
        return [...this._tickets].sort((a, b) => a.destination.localeCompare(b.destination));
    }

    // копия коллекции билетов, сортированная по стоимости
    orderByPrice() {
        return [...this._tickets].sort((a, b) => a.price - b.price );
    }

    // копия коллекции билетов, сортированная по рейсу
    orderByFlight() {
        return [...this._tickets].sort((a, b) => a.flight.localeCompare(b.flight));
    }

    // выборка билетов по условию
    selectWhere(predic) {
        return this._tickets.filter(predic);
    }

    toTable(caption) { return BookOffice.toTable(this.tickets, caption); }

    static toTable(tickets, caption = 'Заявки на авиабилеты'){
        let table = `<table class="table-tickets">
                        <caption>${caption}</caption>
                      <thead><tr>
                        <td>№ п/п</td>
                        <td>Фамилия И.О.</td>
                        <td>Номер рейса</td>
                        <td>Пункт назначения</td>
                        <td>Стоимость, р.</td>
                        <td>Управление</td>
                        </tr></thead>`;
        tickets.forEach((t, i) => table += t.toTableRow(i + 1));
        table += '</table>';
        return table;
    }

    saveToLocalStorage() {
        window.localStorage.tickets = JSON.stringify(this._tickets);
    }

    loadFromLocalStorage() {
        this._tickets = BookOffice.loadFromLocalStorage();
    }

    static loadFromLocalStorage() {
        let parsed = JSON.parse(window.localStorage.tickets);
        return [...Array(parsed.length)].map((v, i) => new Ticket().assign(parsed[i]));
    }

}

const keyMap = {
    "KeyQ": orderByDestination,
    "KeyW": orderByPrice,
    "KeyE": orderByFlight,
    "KeyR": markPriceGreater,
    "KeyA": onNewTicket,
    "KeyS": outputSourceData,
}

const Task2 = {
    office: null,
    $tickets: null,
    $ticketForm: null,
    $modalWindow: null,
    delay: 10_000,
    timer: null,
    $inpMarkPrice: null
};

window.addEventListener('load', loadHandler);
function loadHandler() {
    Task2.$modalWindow =  $('modalWindow');
    Task2.$ticketForm = $('ticketForm');
    Task2.$tickets = $('tickets');
    Task2.$inpMarkPrice = $('inpMarkPrice');

    window.addEventListener("click", onClick);
    window.addEventListener("keypress", onKeyPress);
    Task2.$ticketForm.addEventListener("submit", onSubmitTicketForm);
    Task2.$tickets.addEventListener("click", onClickTickets);
    $('btnSortByDest').addEventListener("click", orderByDestination);
    $('btnSortByPrice').addEventListener("click", orderByPrice);
    $('btnSortByFlight').addEventListener("click", orderByFlight);
    $('btnMarkPriceGreater').addEventListener("click", markPriceGreater);
    $("btnSrcData").addEventListener("click", outputSourceData);
    $('closeModal').addEventListener("click", closeModalWindow);
    $('btnNewTicket').addEventListener("click", onNewTicket);

    Task2.office = new BookOffice(!window.localStorage.tickets
        ? TicketFactory.generate(12)
        : BookOffice.loadFromLocalStorage());

    outputSourceData();
}



// сортировка по пункту назначения
function orderByDestination () {
    Task2.$tickets.innerHTML =
        BookOffice.toTable(Task2.office.orderByDestination('Заявки на авиабилеты - отсортированы по пункту' +
        ' назначения'));
}
// сортировка по стоимости
function orderByPrice() {
    Task2.$tickets.innerHTML =
        BookOffice.toTable(Task2.office.orderByPrice('Заявки на авиабилеты - отсортированы по стоимости билета'))
}
// сортировка по рейсу
function orderByFlight() {
    Task2.$tickets.innerHTML =
        BookOffice.toTable(Task2.office.orderByFlight('Заявки на авиабилеты - отсортированы по рейсу'));
}
// вывести исходные данные
function outputSourceData() {
    Task2.$tickets.innerHTML = Task2.office.toTable();
}
// выделение заявок стоимостью более
function markPriceGreater() {
    let value = Task2.$inpMarkPrice.value;
    if(!value) return;

    Task2.office.tickets.forEach(t => $(`t${t.id}`).classList.remove('hl-row'));
    Task2.office.selectWhere(t => t.price > value).forEach(t => $(`t${t.id}`).classList.add('hl-row'));

    clearTimeout(Task2.timer);
    Task2.timer = setTimeout(() => $('tickets').innerHTML = Task2.office.toTable(), Task2.delay);
}

// обработчик нажатия на клавишу
function onKeyPress(e) {
    keyMap[e.code]();
}

// обработчик нажатия кнопки мыши по всей странице
function onClick(e) {
    // "закрытие" модального окна с формой
    if (e.target === Task2.$modalWindow) {
        closeModalWindow();
    }
}

// обработка кликов по таблице с заявками
function onClickTickets(e) {
    if(e.target.id === "editTicket" || e.target.name === "editTicket")
        onEditTicket(e.target.dataset.ticketId);
    if(e.target.id === "deleteTicket" || e.target.name === "deleteTicket")
        onDeleteTicket(e.target.dataset.ticketId);
}
// обработчик добавления заявки
function onSubmitTicketForm(event){
    let fullName = this.fullName.value;
    let flight = this.flight.value;
    let destination = this.destination.value;
    let price = this.price.value;
    let id = this.idTicket.value;

    if(this.submit.value === "Добавить") {
        let ticket = Task2.office.addTicket(flight,destination,fullName,price);
    }

    if(this.submit.value === "Изменить") {
        Task2.office.updateTicket(id, fullName, flight, destination, price);
    }

    $('tickets').innerHTML = Task2.office.toTable();
    Task2.$modalWindow.style.display = "none";
    event.preventDefault();
}

// вызов добавления нового сотрудника
function onNewTicket() {
    clearTicketForm();
    $('formTitle').innerHTML = "Добавить данные о заявке";
    Task2.$ticketForm.submit.value = "Добавить";
    Task2.$modalWindow.style.display = "block";
}

// обработчик удаления заявки
function onDeleteTicket(id) {
    Task2.office.deleteTicket(id);
    $('tickets').innerHTML = Task2.office.toTable();
}

// вызов редактирования данных заявки
function onEditTicket(id) {
    let ticket = Task2.office.getById(id);

    Task2.$ticketForm.fullName.value = ticket.paxFullName;
    Task2.$ticketForm.destination.value = ticket.destination;
    Task2.$ticketForm.flight.value = ticket.flight;
    Task2.$ticketForm.price.value = ticket.price;
    Task2.$ticketForm.idTicket.value = ticket.id;

    $('formTitle').innerHTML = "Изменить данные заявки";
    Task2.$ticketForm.submit.value = "Изменить";

    Task2.$modalWindow.style.display = "block"
}

function clearTicketForm(){
    Task2.$ticketForm.fullName = Task2.$ticketForm.flight =
        Task2.$ticketForm.destination = Task2.$ticketForm.price = String;
}

// спрятать окно с формой
function closeModalWindow() {
    Task2.$modalWindow.style.display = "none";
}



