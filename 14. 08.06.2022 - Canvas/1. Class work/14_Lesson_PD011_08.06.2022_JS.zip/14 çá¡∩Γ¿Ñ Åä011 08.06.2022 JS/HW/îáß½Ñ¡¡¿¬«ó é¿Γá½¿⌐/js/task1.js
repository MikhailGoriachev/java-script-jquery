
//region Вычисления по заданию
function solveVar15(b) {
    let z1 = Math.sqrt((2. * b)  + (2. * Math.sqrt((b * b) - 4))) / (Math.sqrt(b * b - 4) + b + 2);
    let z2 = 1. / Math.sqrt(b + 2.);
    return {z1, z2};
}

function solveVar16(x){
    let z1 = (x * x + 2. * x - 3 + (x + 1) * Math.sqrt(x * x - 9)) / (x * x - 2. * x - 3 + (x - 1) * Math.sqrt(x * x - 9))
    let z2 = Math.sqrt((x + 3) / (x - 3));
    return {z1, z2};
}

function solveVar17(m){
    let z1 = Math.sqrt((3. * m + 2) ** 2 - 24. * m) / (3. * Math.sqrt(m) - 2. / Math.sqrt(m))
    let z2 = -(Math.sqrt(m));
    return {z1, z2};
}
//endregion

const solveMap = { v15: solveVar15, v16: solveVar16, v17: solveVar17 };

// обработчик submit
function submitHandler(event){
    let res = solveMap[this.name](+this.var.value);
    $(`${this.name}-z1`).innerHTML = `z1 = ${res.z1.toFixed(6)}`;
    $(`${this.name}-z2`).innerHTML = `z2 = ${res.z2.toFixed(6)}`;

    setCookie(`${this.name}z1`, res.z1, {'max-age': 259200});
    setCookie(`${this.name}z2`, res.z2, {'max-age': 259200});

    event.preventDefault();
}

// обработчик валидации ввода
function validateInput(){
    let minExclude = this.dataset.valMinExclude;
    let value = this.value;

    this.setCustomValidity("");

    if(isNaN(this.value))
        this.setCustomValidity(`Введите число`);

    if(+(this.value) <= minExclude)
        this.setCustomValidity(`Число должно быть более ${minExclude}`);
}

window.addEventListener('load', loadHandler, false);
function loadHandler() {
    for (const form of document.forms) {
        form.addEventListener("submit", submitHandler, true);
        for (let element of form.elements) {
            if(element.type === "text")
                element.addEventListener("input", validateInput, true);
        }
    }

    ["v15-z1", "v15-z2", "v16-z1", "v16-z2", "v17-z1", "v17-z2"].forEach(s => {
        let value = getCookie(s.replace('-', ''));
        $(s).innerHTML = `${s.substring(4)} = ${value ? parseFloat(value).toFixed(6) : ""}`;
    });

    $('btnClearCookies').addEventListener("click", () => {
        clearCookies();
        alert('Куки очищены');
    });
}

