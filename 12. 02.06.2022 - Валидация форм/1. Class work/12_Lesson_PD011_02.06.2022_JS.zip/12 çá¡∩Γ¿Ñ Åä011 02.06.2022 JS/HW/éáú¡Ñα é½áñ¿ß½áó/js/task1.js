//Заявка
class Claim {
    //Свойства
    constructor(destination, flightNum, passenger, ticketPrice) {
        this.destination = destination;
        this.flightNum = flightNum;
        this.passenger = passenger;
        this.ticketPrice = ticketPrice;
    }


    //region Геттеры и сеттеры

    //region Пункт назаняения
    get destination() {
        return this._destination;
    }

    set destination(value) {
        this._destination = value;
    }
    //endregion

    //region Номер рейса
    get flightNum() {
        return this._number;
    }

    set flightNum(value) {

        this._number = value<0?getRandom(200,900):value;
    }
    //endregion

    //region Фамилия и инициалы пассажира
    get passenger() {
        return this._passenger;
    }

    set passenger(value) {
        this._passenger = value;
    }
    //endregion

    //region Стоимость билета
    get ticketPrice() {
        return this._price;
    }

    set ticketPrice(value) {
        this._price = value<0?getRandom(2500,30000):value;
    }
    //endregion

    //endregion

    //Вывод
    toTableRow (n) {
        return `<div id="d_${n}">
                    <table>
                        <tr><td><span>Пункт назначения: <b>${this._destination}</b></span></td></tr>
                        <tr><td><span>Номер рейса: <b>${this._number}</b></span></td></tr>
                        <tr><td><span>Пассажир: <b>${this._passenger}</b></span></td></tr>
                        <tr><td><span>Стоимость билета: <b>${this._price}</b></span></td></tr>
                    </table>
                </div>`
    }

    //Выделение элемента
    highlightElement(cardId,predicate){
        if (!predicate(this))
            return;

        $(`d_${cardId}`).getElementsByTagName("table")[0].className = "highlightClaim";
        setTimeout(() => this.resetStyle(cardId),10_000);
    }

    //Сброс выделения элемента
    resetStyle(cardId){
        $(`d_${cardId}`).getElementsByTagName("table")[0].classList.remove("highlightClaim");
    }

}

//Управление заявками
class ClaimsView{
    constructor(claimsArr) {
        this.claims = claimsArr;
    }

    //Генерация массива заявок
    static generateClaims() {
        let array = [];

        for (let i = 0; i < 10; i++) {
            array[i] = new Claim(generateDestination(),generateFlightNumber(),generatePerson(),generatePrice())
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(claimsArr) {
        let n = 0;
        let str = claimsArr.reduce((acc,claim) => acc+claim.toTableRow(n++),'');

        return str;
    }
}


//region Сортировки, обработчики

//Упорядочить представление по пунктам назначения
function orderDescByDestination(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c1.destination.localeCompare(c2.destination));

    return () => {
        blockObject.innerHTML = ClaimsView.createMarkup(copy)
        titleObject.innerHTML = `<span>Сортировка массива по пунктам назначения</span>`;
    }
}//orderDescByTemperature

//Упорядочить представление по стоимости билета
function orderByPrice(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c2.ticketPrice-c1.ticketPrice);

    return () => {
        blockObject.innerHTML = ClaimsView.createMarkup(copy)
        titleObject.innerHTML = `<span>Сортировка массива по стоимости билета</span>`;
    }
}//orderByPrice

//Упорядочить представление по стоимости билета
function orderByFlightNum(blockObject,titleObject,claimsArr) {
    //Копия массива
    let copy = claimsArr.map(c => c).sort((c1,c2) => c2.flightNum-c1.flightNum);

    return () => {
        blockObject.innerHTML = ClaimsView.createMarkup(copy)
        titleObject.innerHTML = `<span>Сортировка массива по стоимости билета</span>`;
    }
}//orderByFlightNum


//endregion


//Функция с самовызовом
(function (){

    //Массив заявок
    let claimView = new ClaimsView(ClaimsView.generateClaims());

    let mainBlock = $("mainDiv");

    mainBlock.innerHTML = ClaimsView.createMarkup(claimView.claims);


    //region Вставка заголовка
    let title = document.createElement("p");
    title.setAttribute("id", "taskTitle");
    title.setAttribute("class", "title-style");

    title.innerHTML = `<span>Исходный массив</span>`;
    mainBlock.parentNode.insertBefore(title, mainBlock);
    //endregion

    title = $('taskTitle');

    let loadHandler = function () {


        //Обработчик кнопки вывода исходного массива
        let showDefaultArr = function () {

            collectionHighlight = claimView.claims;

            mainBlock.innerHTML = ClaimsView.createMarkup(claimView.claims);
            title.innerHTML = `<span>Исходный массив</span>`;
        }

        $("defaultArr").addEventListener("click",showDefaultArr,false);

        //region Сортировки

        //Обработчик кнопки сортировки по пункту на назначения
        $("orderByDest").addEventListener("click",orderDescByDestination(mainBlock, title,claimView.claims),false);

        //Обработчик кнопки сортировки по стоимости билета
        $("orderByPrice").addEventListener("click",orderByPrice(mainBlock, title,claimView.claims),false);

        //Обработчик кнопки сортировки по номеру рейса
        $("orderByFlightN").addEventListener("click",orderByFlightNum(mainBlock, title,claimView.claims),false);


        //endregion

        let inputField = $("inputPrice");
        let message = $("messageText");
        let styleDefault = true;


        //region Выделение элементов

        //region Надпись в поле ввода
        inputField.addEventListener("mouseover",(e) => {
            let pattern = new RegExp('[а-яА-Яa-zA-Z]+');
            let inputValue = e.target.value;

            //Если текущее значение в строке ввода - текст
            if (inputValue.search(pattern)>=0){
                e.target.value = ""

                //Меняем цвет текса
                e.target.style.color = 'rgb(21, 21, 21)';
            }

        },false);

        //Задаём подсказку при выходе из поля ввода
        inputField.addEventListener("mouseout",(e) => {
            let pattern = new RegExp('[ ]+')
            let inputValue = e.target.value;

            //Если поле пустое или состоит из пробелов
            if (inputValue === "" || pattern.test(inputValue)) {
                e.target.value = "Введите стоимость"
                e.target.style.color = 'rgb(140, 140, 140)';

                //Снимаем фокус
                e.target.blur()
                message.innerHTML = "";
            }

        },false);

        //endregion

        //Выделение элементов по редикату
        let highlightTickets = function (predicate) {

            //Получаем массив дочерних элементов общего блока
            let childNodes = [];
            mainBlock.childNodes.forEach(c => {
                if (c.nodeType == 1) {
                    childNodes.push(c);
                }
            });

            //Проверка работы предиката
            let isData = 0;

            //Выделяем элементы представления, а не массив
            for (let childNode of childNodes) {
                let data = getNumFromStr(childNode.getElementsByTagName("span")[3].getElementsByTagName("b")[0].innerHTML)

                //Если данные внутри ячейки соответствуют условию, то меняем оформления таблицы
                if (predicate(data)) {
                    childNode.getElementsByTagName("table")[0].className = "highlightClaim";
                    isData++;

                    //Стиль объектов изменён
                    styleDefault = false;

                    //Сообщение
                    message.innerHTML = "подождите, пока выделение спадёт!"

                    setTimeout(() =>
                    {
                        childNode.getElementsByTagName("table")[0].classList.remove("highlightClaim");
                        styleDefault = true;
                        message.innerHTML = "";
                    },10_000);
                }
            }//for

            if (isData<=0)
                message.innerHTML = "значения не найдены"


        }//highlightTickets

        //Проверка ввода
        let keyDownHandler = function (e) {

            let inputValue = e.target.value;

            let regExpr = new RegExp('[а-яА-Яa-zA-Z ]');

            //Флаг enter и backspace
            let enterPressed = e.key.toLowerCase().includes("enter");
            let backSpacePressed = e.key.toLowerCase().includes("backspace");


            //Если есть хоть одна буква - блокировка ввода
            if (regExpr.test(e.key) && !enterPressed && !backSpacePressed) {
                message.innerHTML = "введите число"
                e.preventDefault();
                return;
            }

            //Получение введённого значения
            let number = parseInt(inputValue);


            if (!enterPressed && styleDefault)
                message.innerHTML = "для выделения нажмите enter"
            //Если нажат enter и выделение отключено
            else if (enterPressed && styleDefault)
                //выделение элементов
                highlightTickets((data) => data > number);

        }

        inputField.addEventListener("keydown",keyDownHandler,false)
        //endregion

    }

    window.addEventListener("load",loadHandler,false);
})();