
//Функция с самовызовом
(function (){

    //Блок в котором происходит анимация
    let animationBlock = $('mainDiv')

    let position = {
        left: 15,
        top: 15
    }

    let documentPosition = 0;

    //Объект таймера
    let timer = 0;

    //Направление движения - для замкнутости траектории
    let direction = 0;


    let loadHandler = function () {

        //Анимируемый объект
        let pic = $("pic");
        pic.style.left = `${position.left}px`;
        pic.style.top = `${position.top}px`;


        //region Анимция
        //Начать анимацию
        let startHandler = function () {

            if (timer)
                clearInterval(timer);

            timer = setInterval(() => animation(),10)

        }

        $("startAnimation").addEventListener('click',startHandler,false);

        //Остановить анимацию
        let stopHandler = function () {
            pic.style.position = "relative";
            clearInterval(timer);

            smoothReturn();

        }

        $("stopAnimation").addEventListener('click',stopHandler,false);

        //Аниманиция
        function animation() {

            pic.style.position = "relative";
            pic.style.left = `${position.left}px`;
            pic.style.top = `${position.top}px`;

            //direction - флаг задания направлений
            if (direction >= 0) {
                position.top+=2;
                position.left+=2;
            }
            else{
                position.top-=2;
                position.left-=2;
            }

            if (position.left > 330)
                direction = -1;
            else if (position.left < 15)
                direction = 0;
        }

        //Мягкое возвращение блока
        function smoothReturn() {
            let interval = 0;

            //Изменение положения бока
            function returning() {
                pic.style.left = `${position.left}px`;
                pic.style.top = `${position.top}px`;

                //Пока не будет достигнута нужная позиция
                if (position.left > 15){
                    position.top-=2;
                    position.left-=2;
                    return;
                }

                //Отключить интервальный вызов
                clearInterval(interval);
            }

            interval = setInterval(() => returning(),4);
        }
        //endregion


        function assignMouseHandlers(draggingElem,mouseEvent) {
            if (timer !== 0)
                clearInterval(timer)

            console.log(`На блок назначаются обработчики перемещения`);

            document.addEventListener('mousemove',mouseMoveHandler,false);
            document.addEventListener('mouseup',mouseUpHandler,false);

            //При помощи этого метода удалось запомнить последние до перемещения координаты
            documentPosition = draggingElem.getBoundingClientRect();

            draggingElem.style.position = "absolute";
            draggingElem.style.left = `${documentPosition.x}px`;
            draggingElem.style.top = `${documentPosition.y}px`;

            //Координаты мыши
            let mouseX = mouseEvent.clientX;
            let mouseY = mouseEvent.clientY;

            //Координаты перемещаемого блока
            let elemX = draggingElem.offsetLeft;
            let elemY = draggingElem.offsetTop;


            //Вычисление дельты для создания отступа
            let deltaX = mouseX - elemX;
            let deltaY = mouseY - elemY;

            //Перетаскиваие мыши
            function mouseMoveHandler(e) {
                draggingElem.style.left = `${e.clientX - deltaX}px`;
                draggingElem.style.top =  `${e.clientY - deltaY}px`;

            }
            //Отключение мыши
            function mouseUpHandler() {
                document.removeEventListener('mousemove',mouseMoveHandler,false);
                document.removeEventListener('mouseup',mouseUpHandler,false);
            }

        }

        pic.addEventListener('mousedown',(e) => assignMouseHandlers(e.target,e),false)

        //Возвращение элемента на стартовые координаты
        pic.addEventListener('mouseup',(e) => {
            let element = e.target;
            element.style.left = `${documentPosition.x}px`;
            element.style.top = `${documentPosition.y}px`;
        },false)


    }
    window.addEventListener('load',loadHandler,false)
})();