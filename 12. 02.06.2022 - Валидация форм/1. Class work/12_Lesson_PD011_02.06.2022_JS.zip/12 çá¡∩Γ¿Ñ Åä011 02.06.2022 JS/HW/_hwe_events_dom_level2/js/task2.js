/*
* Задача 3
* Реализуйте анимацию – перемещение произвольного небольшого изображения
* (изображение должно быть фоном блока div) в ограниченном прямоугольнике,
* по замкнутой траектории. Предусмотрите кнопки для запуска и останова движения,
* подберите задержку для равномерного движения изображения.
* */

window.addEventListener('load', loadHandler, false);
function loadHandler() {
    // ссылка на объект, работающий с интервалом
    let intervalHandler;

    // период анимации в миллисекундах
    const period = 30;

    // область вывода для анимации элемента
    let animationArea = $("animationArea");

    // объект для представления позиции изображения
    let position = {
        left: 20,
        top: 10
    }

    // элемент для анимации перемещения
    let sun = $("sun");
    [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];

    // направление движения, начинаем движение вправо
    let direction = 'right';

    // назначить обработчики кликов на кнопки управления анимацией перемещения
    // по замкнутой траектории
    $("btnStart").addEventListener('click', startTrajectoryAnimation, false);
    $("btnStop").addEventListener('click', stopTrajectoryAnimation, false);

    // назначить обработчики кликов по кнопкам управления перемещением
    // в ручном режиме
    $("btnLeft").addEventListener('click', moveLeft, false);
    $("btnRight").addEventListener('click', moveRight, false);
    $("btnUp").addEventListener('click', moveUp, false);
    $("btnDown").addEventListener('click', moveDown, false);

    // назначение обработчика нажатий клавиш
    $("body").addEventListener("keypress", keyPressHandler, true);

    // назначить обработчика события нажатия кнопки мыши - для реализации перетаскивания
    sun.addEventListener("mousedown", dragHandler);

    // обработчик кнопки запуска анимации
    function startTrajectoryAnimation() {
        // останавливаем таймер, по которому вызывается функция animateCallback
        clearInterval(intervalHandler);

        // переместить объект анимации в начальную точку
        position = {left: 20, top: 10};
        [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];
        direction = 'right';

        // запуск периодической работы, получение ссылки на объект таймера
        intervalHandler = setInterval(() => animateMovementClose(), period);
        $("header").innerText = "Анимация работает";
    } // btnStart


    // обработчик кнопки останова анимации
    function stopTrajectoryAnimation() {
        // останавливаем таймер, по которому вызывается функция animateCallback
        clearInterval(intervalHandler);

        let header = $("header");
        header.innerText = "Анимация остановлена";

        // переместить объект анимации в начальную точку
        position = {left: 20, top: 10};
        [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];
        direction = 'right';

        // через period миллисекунд после окончания анимации восстановим исходный текст
        // заголовка
        setTimeout(() => header.innerText="Блок для анимации - перемещение изображения", 5_000);
    } // btnStop


    // реализация анимации перемещения по замкнутой траектории
    // по квадрату
    function animateMovementClose() {

        switch (direction) {
            // движение вправо по горизонтали, по достижении ограничения
            // начинаем движение вниз по вертикали
            case 'right':
                position.left += 5;

                if (position.left >= animationArea.offsetWidth - sun.offsetWidth - 30) {
                    position.left = animationArea.offsetWidth - sun.offsetWidth - 30;
                    direction = 'down';
                } // if
                break;

            // движение влево по горизонтали, по достижении ограничения (левой границы)
            // начинаем движение вверх
            case 'left':
                position.left -= 5;

                if ((position.left <= 20)) {
                    position.left = 20;
                    direction = 'up';
                } // if
                break;

            // движение объекта вверх по вертикали, по достижении верхнего
            // ограничения, начинаем движение вправо
            case 'up':
                position.top -= 5;

                if (position.top <= 10) {
                    position.top = 10;
                    direction = 'right';
                } // if
                break;

            // движение вниз по вертикали, по достижении нижнего ограничения
            // начинаем движение влево по горизонтали
            case 'down':
                position.top += 5;

                if (position.top >= animationArea.offsetHeight - sun.offsetHeight - 20) {
                    position.top = animationArea.offsetHeight - sun.offsetHeight - 20;
                    direction = 'left';
                } // if
                break;
        } // switch

        [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];
    } // animateMovementClose


    // обработчик клика по кнопке перемещения влево
    function moveLeft() {
        position.left -= 20;

        if ((position.left <= 20)) {
            position.left = 20;
        } // if

        [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];
    } // moveLeft


    // обработка клика по кнопке перемещения вправо
    function moveRight() {
        position.left += 20;

        if (position.left >= animationArea.offsetWidth - sun.offsetWidth - 30) {
            position.left = animationArea.offsetWidth - sun.offsetWidth - 30
        } // if

        [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];
    } // moveRight


    // обработчик клика по кнопке перемещения вверх
    function moveUp() {
        position.top -= 20;

        if (position.top <= 10) {
            position.top = 10;
        } // if

        [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];
    } // moveUp


    // обработка клика по кнопке перемещения вниз
    function moveDown() {
        position.top += 20;

        if (position.top >= animationArea.offsetHeight - sun.offsetHeight - 20) {
            position.top = animationArea.offsetHeight - sun.offsetHeight - 20;
        } // if

        [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];
    } // moveDown


    // обработчик нажатия клавиши
    function keyPressHandler(e) {
        switch(e.code) {
            case "KeyA":
                moveLeft();
                break;

            case "KeyD":
                moveRight();
                break;

            case "KeyW":
                moveUp();
                break;

            case "KeyS":
                moveDown();
                break;
        } // switch
    } // KeyPressHandler


    // перетаскивание фигуры - приватный метод модуля, код взят из примера
    // в классной работе
    function dragHandler(event) {
        // координаты мыши в начале перетаскивания.
        let startX = event.clientX,
            startY = event.clientY;

        // начальные координаты элемента, который будет перемещаться.
        let origX = parseInt(sun.style.left),
            origY = parseInt(sun.style.top);

        // разница между координатами мыши и координатами перетаскиваемого элемента
        let deltaX = startX - origX,
            deltaY = startY - origY;

        // Регистрация событий mouseup и mousemove
        document.addEventListener("mousemove", moveHandler, true);
        document.addEventListener("mouseup", upHandler, true);

        // обработчик события перемещения мыши
        function moveHandler(e) {
            // перемещаем элемент с учетом отступа от первоначального клика.
            // не перемещаемся за пределы блока, в котором выполняем анимацию
            let top = e.clientY - deltaY;
            let left = e.clientX - deltaX;

            // собственно учет ограничений
            position.top = 10 <= top && top <= animationArea.offsetHeight - sun.offsetHeight - 20?
                top:position.top;
            position.left = 20 <= left && left <= animationArea.offsetWidth - sun.offsetWidth - 30?
                left:position.left;

            // перемещение объекта
            [sun.style.left, sun.style.top] = [`${position.left}px`, `${position.top}px`];
        } // moveHandler

        // обработчик события отпускания кнопки мыши
        function upHandler(e) {
            document.removeEventListener("mouseup", upHandler, true);
            document.removeEventListener("mousemove", moveHandler, true);
        } // upHandler
    } // dragHandler
} // onload