// конструктор объектов заявки на билет
class Ticket {
    constructor(id, {flight, destination}, paxFullName, price) {

        this._id = id;
        // пункт назначения
        this._destination = destination;
        // номер рейса
        this._flight = flight;
        // фамилия и инициалы пассажира
        this._paxFullName = paxFullName;
        // стоимость билета
        this._price = price;
    }


    get id() { return this._id; }
    set id(value) { this._id = value; }

    get destination() { return this._destination; }
    set destination(value) { this._destination = value || 'не указано'; }

    get flight() { return this._flight; }
    set flight(value) { this._flight = value || 'не указано';}

    get paxFullName() { return this._paxFullName; }
    set paxFullName(value) { this._paxFullName = value || 'не указано'; }

    get price() { return this._price; }
    set price(value) { this._price = value >= 0 ? value : 0; }

    toTableRow(row){
        return `<tr id="${this._id}">
                    <td>${row}</td>
                    <td class="align-left">${this._paxFullName}</td>
                    <td class="align-left">${this._flight}</td>
                    <td class="align-left">${this._destination}</td>
                    <td>${this._price}</td>
                </tr>`;
    }
}

// Фабрика генерации заявок на билет
class TicketFactory{
    static generate(amount){
        return [...Array(amount)].map((t,i) =>
            new Ticket(`t${i + 1}`,this.randomFlightInfo() , this.randomFullName() , getRandomInt(1000, 5_000)));
    }

    static randomFullName(){
        return ["Гущин Ф. А.", "Симонов Н.А.", "Молчанов А.А.", "Емельянов Ц.И.", "Беляков К.В.",
            "Доронин У.И.", "Несвитайло Д.П.", "Кондратьев М.Ю.", "Симонов Ч.В.", "Тягай С.В.",
            "Василенко В.Ю.", "Дзюба Д.Д.", "Константинов Д.П.", "Лукин А.В.", "Марков Й.В.",
            "Несвитайло Р.В.", "Титов П.Ф.", "Анисимов Е.В.", "Миклашевский Д.В.", "Зыков Э.Б.",
            "Комаров С.Л.", "Рогов Э.Э.", "Королёв О.В.", "Воронцов И.А.", "Семенов Р.М.",
            "Дунаев В.Б.",   "Харламова Ю.В.", "Олегова И.В.", "Янковский В.В.", "Абалкин Л.Ж.",
            "Горбовски Д.В.", "Каммерер М.А.", "Романова П.В.",  "Воликова И.А.", "Жукова Р.Б.",
            "Денисова Д.А.", "Соколов Д.В.",   "Лебедев К.К."].random();
    }

    static randomFlightInfo(){
        return[
            {flight: "АФ4567", destination: "Сочи"},                   {flight: "FL91AS", destination: "Геленджик"},
            {flight: "PB9812", destination: "Воронеж"},                {flight: "ALF081", destination: "Берлин"},
            {flight: "PB9231", destination: "Саратов"},                {flight: "AFL002", destination: "Иваново"},
            {flight: "PB1233", destination: "Шарм-эш-Шейх"},           {flight: "FL98AS", destination: "Ростов-на-дону"},
            {flight: "AFL033", destination: "Париж, шарль де-Голль"},  {flight: "АФ9811", destination: "Москва, Внуково"},
            {flight: "АФ0011", destination: "Владивосток"},            {flight: "AFL021", destination: "Париж, Орли"},
            {flight: "АФ9821", destination: "Москва, Домодедово"},     {flight: "PB0911", destination: "Симферополь"},
            {flight: "PB7812", destination: "Ярославль"},              {flight: "PB2271", destination: "Астрахань"}
        ].random();
    }
}

// конструктор объекта управления заявками
class BookOffice {

    constructor(tickets) {
        this._tickets = tickets;
    }

    get tickets() { return this._tickets; }
    set tickets(value) { this._tickets = value; }

    // копия коллекции билетов, сортированная по пункту назначения
    orderByDestination(){
        return [...this._tickets].sort((a, b) => a.destination.localeCompare(b.destination));
    }

    // копия коллекции билетов, сортированная по стоимости
    orderByPrice(){
        return [...this._tickets].sort((a, b) => a.price - b.price );
    }

    // копия коллекции билетов, сортированная по рейсу
    orderByFlight(){
        return [...this._tickets].sort((a, b) => a.flight.localeCompare(b.flight));
    }

    // выборка билетов по условию
    selectWhere(predic){
        return [...this._tickets].filter(predic);
    }

    toTable(caption) { return BookOffice.toTable(this.tickets, caption); }

    static toTable(tickets, caption = 'Заявки на авиабилеты'){
        let table = `<table class="table-tickets">
                        <caption>${caption}</caption>
                      <thead><tr>
                        <td>№ п/п</td>
                        <td>Фамилия И.О.</td>
                        <td>Номер рейса</td>
                        <td>Пункт назначения</td>
                        <td>Стоимость, р.</td>
                        </tr></thead>`;
        tickets.forEach((t, i) => table += t.toTableRow(i + 1));
        table += '</table>';
        return table;
    }
}

window.onload = function(){
    let office = new BookOffice(TicketFactory.generate(12));
    let delay = 10_000;
    let timer;
    let $tickets = $('tickets');
    let $inpPrice = $('inpPrice');
    $tickets.innerHTML = office.toTable();


    // обработка события ввода в input numeric
    $inpPrice.addEventListener("input", (ev) => {
        clearTimeout(timer);
        office.tickets.forEach(t => $(t.id).classList.remove('hl-row'));


        let value = $inpPrice.value;

        if(!value) return;

        office.selectWhere(t => t.price > $('inpPrice').value).forEach(t => $(t.id).classList.add('hl-row'));
        timer = setTimeout(() => $('tickets').innerHTML = office.toTable(), delay);
    }, false);


    // сортировка по пункту назначения
    $('btnSortByDest').onclick = () =>
        $tickets.innerHTML = BookOffice.toTable(office.orderByDestination('Заявки на авиабилеты - отсортированы по пункту назначения'))

    // сортировка по стоимости
    $('btnSortByPrice').onclick = () =>
        $tickets.innerHTML = BookOffice.toTable(office.orderByPrice('Заявки на авиабилеты - отсортированы по стоимости билета'))

    // сортировка по рейсу
    $('btnSortByFlight').onclick = () =>
        $tickets.innerHTML = BookOffice.toTable(office.orderByFlight('Заявки на авиабилеты - отсортированы по рейсу'))

    // вывести исходные данные
    $("btnSrcData").onclick =
        () => $tickets.innerHTML = office.toTable();
}