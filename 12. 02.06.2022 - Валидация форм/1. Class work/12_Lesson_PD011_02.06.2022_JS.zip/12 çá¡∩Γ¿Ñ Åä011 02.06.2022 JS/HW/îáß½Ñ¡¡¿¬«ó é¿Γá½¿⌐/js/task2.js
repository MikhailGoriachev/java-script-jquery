

class MoveController {
    yMax = 79;
    xMax = 83;

    constructor(x, y, direction = this.diagonals[0]) {
        this.x = x;
        this.y = y;
        this.direction = direction;
    }

    // объекты информации о направлениях
    directions = {
        "up"       : {dX:  0, dY: -1, checkBounds: (x, y) => y >= 0,  },
        "down"     : {dX:  0, dY:  1, checkBounds: (x, y) => y <= this.yMax,},
        "left"     : {dX: -1, dY:  0, checkBounds: (x, y) => x >= 0,  },
        "right"    : {dX:  1, dY:  0, checkBounds: (x, y) => x <= this.xMax,},
        "upLeft"   : {dX: -1, dY: -1, checkBounds: (x, y) => x >= 0 && y >= 0,    },
        "upRight"  : {dX:  1, dY: -1, checkBounds: (x, y) => x <= this.xMax && y >= 0,  },
        "downLeft" : {dX: -1, dY:  1, checkBounds: (x, y) => x >= 0 && y <= this.yMax,  },
        "downRight": {dX:  1, dY:  1, checkBounds: (x, y) => x <= this.xMax && y <= this.yMax,},
    };

    // массив ссылок на диагональные направления движения
    diagonals = [this.directions.upLeft,
                 this.directions.upRight,
                 this.directions.downRight,
                 this.directions.downLeft];

    // отталкивание от границы по часовой стрелке
    bounceClockwise(){

        let current = this.diagonals.indexOf(this.direction);
        let next =  current !== -1 ? current + 1 : getRandomInt(0, this.diagonals.length - 1);

        this.direction = this.diagonals[next >= this.diagonals.length ? 0 : next];
    }

    // проверка допустимости движения
    checkNextMove() {
        return this.direction.checkBounds(this.x + this.direction.dX, this.y + this.direction.dY);
    }


    autoMove(){
        // обработка столкновения с границей
        if(!this.checkNextMove())
            this.bounceClockwise();

        this.x += this.direction.dX;
        this.y += this.direction.dY;
    }

    // движение по клавише
    movePressed(key){
        switch (key) {
            case 'w': case 'ц': this.direction = this.directions.up; break;
            case 's': case 'ы': this.direction = this.directions.down; break;
            case 'a': case 'ф': this.direction = this.directions.left; break;
            case 'd': case 'в': this.direction = this.directions.right; break;
            default: return;
        }

        if(this.checkNextMove()){
            this.x += this.direction.dX;
            this.y += this.direction.dY;
        }
    }

}


window.onload = function () {

    // ссылка на объект, работающий с интервалом
    let interval;

    // скорость анимации
    let delay = 15;

    // ссылка на анимируемый элемент разметки
    let $model = $('model');

    let moveController = new MoveController(20, 60);

    function updatePosition(){
        $model.style.left = `${moveController.x}%`;
        $model.style.top = `${moveController.y}%`;
    }

    function animate() {
        moveController.autoMove();
        updatePosition();
    }

    function startAnimation() {
        clearInterval(interval);
        interval = setInterval(animate, delay);
    }


    $('delay').innerHTML = `${delay} мс`;

    // обработчик нажатия клавиш с клавиатур
    document.onkeydown = (e) => {
        clearTimeout(interval);
        moveController.movePressed(e.key.toLowerCase());
        updatePosition();
    }

    $model.addEventListener("mousedown", function (e) {
        drag(this, e);
    })

    function drag(elementToDrag, event) {
        clearTimeout(interval);

        // Регистрация событий mouseup и mousemove
        document.addEventListener("mousemove", moveHandler, true);
        document.addEventListener("mouseup", upHandler, true);

        // координаты мыши в начале перетаскивания.
        let startX = event.clientX,
            startY = event.clientY;

        // начальные координаты элемента, который будет перемещаться.
        let origX = elementToDrag.offsetLeft,
            origY = elementToDrag.offsetTop;

        // разница между координатами мыши и координатами перетаскиваемого элемента.
        let deltaX = startX - origX,
            deltaY = startY - origY;

        // перетаскивание при перемещении мыши
        function moveHandler(e) {
            let parentWidth = elementToDrag.parentElement.clientWidth;
            let parentHeight = elementToDrag.parentElement.clientHeight;


            // перемещаем элемент с учетом отступа от первоначального клика.
            elementToDrag.style.left = `${e.clientX - deltaX}px`;
            elementToDrag.style.top = `${e.clientY - deltaY}px`;


            moveController.x =  parseInt(elementToDrag.style.left) / parentWidth  * 100;
            moveController.y = parseInt(elementToDrag.style.top) / parentHeight  * 100;

        }

        // удаление обработчиков при отпускании кнопки мыши
        function upHandler(e) {
            document.removeEventListener("mouseup", upHandler, true);
            document.removeEventListener("mousemove", moveHandler, true);
        }
    }


    // запуск анимации
     $('btnMoveOn').onclick = () => startAnimation();
    // остановка анимации
     $('btnMoveOff').onclick = () => clearInterval(interval);
    // увеличить задержку
     $('btnDelayUp').onclick = () => {
         delay++;
         $('delay').innerHTML = `${delay} мс`;
         startAnimation();
     };
    // уменьшить задержку
    $('btnDelayDown').onclick = () => {
        if(delay > 0)
            delay--;
        $('delay').innerHTML = `${delay} мс`;
        startAnimation();
    };
}

