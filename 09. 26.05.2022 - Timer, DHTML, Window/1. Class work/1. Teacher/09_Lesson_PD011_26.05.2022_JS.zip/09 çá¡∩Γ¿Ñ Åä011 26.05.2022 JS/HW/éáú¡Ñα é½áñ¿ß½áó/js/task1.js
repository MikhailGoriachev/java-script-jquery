
class Figures{
    constructor(figures) {
        //Коллекция фигур
        this.arrFigures = figures;
    }

    //Генерация фигур
    static generateFigures(){
        return [
            new Sphere(getRandom(5,20),'sphere'),
            new Sphere(getRandom(5,20),'sphere'),
            new Cone(getRandom(5,15),getRandom(15,25),getRandom(15,25),'cone'),
            new Cone(getRandom(5,15),getRandom(15,25),getRandom(15,25),'cone'),
            new Cylinder(getRandom(5,15),getRandom(15,25),'cylinder'),
            new Cylinder(getRandom(5,15),getRandom(15,25),'cylinder'),
            new Cube(getRandom(5,15),'cube'),
            new Cube(getRandom(5,15),'cube'),
        ];
    }

    //Формирование разметки
    static createMarkup(title,arr) {

        let str = `<table> <caption>${title}</caption>`;

        //Строки таблицы
        str += arr.reduce((acc,item) => acc + item.toTableRow(),'')
        str += `</table>`;


        return str;
    }
}

//Вывод в блок
function outputToBlock(blockId,markup) {
    //Вывод разметки в блок
    $(blockId).innerHTML = markup;
}


//region Классы
//Базовый класс
class Figure{

    constructor(radius,icon) {
        this.icon = icon;
        this.radius = radius;
    }

    //region Геттеры и сеттеры
    get icon() {
        return this._icon;
    }

    //Если заданный путь иконки некорректен, тогда установим иконку по умолчнию
    set icon(value) {
        if (typeof value != 'string') {
            this._icon = 'incorrect';
            return;
        }
        this._icon = value;
    }

    get radius() {
        return this._radius;
    }

    //Если значение некорректно - значение по умолчанию
    set radius(value) {
        if (value<=0) {
            this._radius = 5;
            return;
        }
        this._radius = value;
    }
    //endregion

    //Площадь (вычисляемое свойтсво)
    get getSquare() {}

    //Объём (вычисляемое свойтсво)
    get getVolume () {}

    //Вывод
    toTableRow() {}

    //Сравнение
    compareTo(comparedFigure) {}
}//Figure

//сфера
class Sphere extends Figure{
    constructor(radius,icon) {
        super(radius,icon);
    }

    //Площадь (вычисляемое свойтсво)
    get getSquare () {
    return 4*Math.PI*this.radius**2;
  }
    //Объём (вычисляемое свойтсво)
    get getVolume () {
    return 4/3*Math.PI*this.radius**3;
  }

    //Вывод
    toTableRow () {
    return `
        <tr  class="separator-style">
            <td rowspan="3" class="image-cell">
                <img src="../images/figures/${this.icon}.png" alt="">
            </td>
            <td>
                Радиус
            </td>
            <td>
                ${this._radius}
            </td>
        </tr>
        <tr>
            <td>
                Площадь
            </td>
            <td>
                ${this.getSquare.toFixed(0)}
            </td>
        </tr>
        <tr>
             <td>
                 Объем
             </td>
             <td>
                 ${this.getVolume.toFixed(0)}
             </td>
       </tr>`;
  }//toTableRow

    //Сравнение
    compareTo (comparedFigure) {
        return this.getVolume-comparedFigure.getVolume;
    }

}//Sphere

//Конус
class Cone extends Figure{
    constructor(radius,height,l,icon) {
        super(radius,icon);
        this.height = height;
        this.l = l;
    }

    //region Геттеры и сеттеры
    get height() {
        return this._height;
    }

    set height(value) {
        this._height = value<=0?10:value;
    }

    get l() {
        return this._l;
    }

    set l(value) {
        this._l = value<=0?12:value;
    }
    //endregion

    //Площадь (вычисляемое свойтсво)
    get getSquare () {
      return Math.PI*this.radius**2+Math.PI*this.radius*this.l;
    }
    //Объём (вычисляемое свойтсво)
    get getVolume () {
      return (Math.PI*this.radius**2)/3*this.height;
    }

    //Вывод
    toTableRow () {
      return `
          <tr class="separator-style">
              <td rowspan="5" class="image-cell">
                  <img src="../images/figures/${this.icon}.png" alt="">
              </td>
              <td>
                  Радиус
              </td>
              <td>
                  ${this._radius}
              </td>
          </tr>
          <tr>
              <td>
                  Высота
              </td>
              <td>
                  ${this._height}
              </td>
          </tr>
          <tr>
              <td>
                  Образующая
              </td>
              <td>
                  ${this._l}
              </td>
          </tr>
          <tr>
              <td>
                  Площадь
              </td>
              <td>
                  ${this.getSquare.toFixed(0)}
              </td>
          </tr>
          <tr>
               <td>
                   Объем
               </td>
               <td>
                   ${this.getVolume.toFixed(0)}
               </td>
         </tr>`;
    }//toTableRow

    //Сравнение
    compareTo (comparedFigure) {
        return this.getVolume-comparedFigure.getVolume;
    }

}//Сone

//Цилиндр
class Cylinder extends Figure{

    constructor(radius,height,icon) {
        super(radius,icon);
        this.height = height;
    }

    //region Геттеры и сеттеры
    get height() {
        return this._height;
    }

    //Защита от задания некорректного значения
    set height(value) {
        this._height = value<=0?10:value;
    }
    //endregion

    //Площадь (вычисляемое свойтсво)
    get getSquare () {
    return 2*Math.PI*this.radius**2+2*Math.PI*this.radius*this._height;
    }
    //Объём (вычисляемое свойтсво)
    get getVolume() {
    return Math.PI*this.radius**2*this._height;
    }

    //Вывод
    toTableRow() {
    return `
        <tr class="separator-style">
            <td rowspan="4" class="image-cell">
                <img src="../images/figures/${this.icon}.png" alt="">
            </td>
            <td>
                Радиус
            </td>
            <td>
                ${this._radius}
            </td>
        </tr>
        <tr>
            <td>
                Высота
            </td>
            <td>
                ${this._height}
            </td>
        </tr>
        <tr>
            <td>
                Площадь
            </td>
            <td>
                ${this.getSquare.toFixed(0)}
            </td>
        </tr>
        <tr>
             <td>
                 Объем
             </td>
             <td>
                 ${this.getVolume.toFixed(0)}
             </td>
       </tr>`;
  }//toTableRow

    //Сравнение
    compareTo (comparedFigure) {
      return this.getVolume-comparedFigure.getVolume;
  }

}//Cylinder

//Куб
class Cube extends Figure{

    constructor(side,icon) {
        super(side,icon);
    }

    //region Геттеры и сеттеры
    get side() {
        return this._radius;
    }

    //Защита от задания некорректного значения
    set side(value) {
        this._radius = value<=0?10:value;
    }
    //endregion

    //Площадь (вычисляемое свойтсво)
    get getSquare () {
    return this.side ** 3;
    }
    //Объём (вычисляемое свойтсво)
    get getVolume() {
    return 6 * this.side ** 2;
    }

    //Вывод
    toTableRow() {
    return `
        <tr class="separator-style">
            <td rowspan="3" class="image-cell">
                <img src="../images/figures/${this.icon}.png" alt="">
            </td>
            <td>
                Сторна
            </td>
            <td>
                ${this.side}
            </td>
        </tr>
        <tr>
            <td>
                Площадь
            </td>
            <td>
                ${this.getSquare.toFixed(0)}
            </td>
        </tr>
        <tr>
             <td>
                 Объем
             </td>
             <td>
                 ${this.getVolume.toFixed(0)}
             </td>
       </tr>`;
  }//toTableRow

    //Сравнение
    compareTo (comparedFigure) {
      return this.getVolume-comparedFigure.getVolume;
  }

}//Cube

//endregion

//Функция с самовызовом
(function (){

    let figures = new Figures(Figures.generateFigures());
    //Вывод разметки в блок
    outputToBlock("mainDiv", Figures.createMarkup('Исходный массив', figures.arrFigures));

    window.onload = function () {

        //Обработчик кнопки вывода исхоного массива
        $("defaultArr").onclick = function () {

            outputToBlock("mainDiv", Figures.createMarkup('Исходный массив', figures.arrFigures));
        }

        //Отсортированный по убыванию объемов
        $("sortedByV").onclick = function () {
            //Копия массива
            let tempArr = figures.arrFigures.map(f => f);
            tempArr.sort((f1, f2) => f2.getVolume - f1.getVolume);

            //Вывод в разметку блока
            outputToBlock("mainDiv", Figures.createMarkup('Отсортированный массив по убыванию объёмов', tempArr));
        }

        //Отсортированный по возрастанию площадей
        $("sortedByS").onclick = function () {
            //Копия массива
            let tempArr = figures.arrFigures.map(f => f);

            tempArr.sort((f1, f2) => f1.getSquare - f2.getSquare);

            //Вывод в разметку блока
            outputToBlock("mainDiv", Figures.createMarkup('Отсортированный массив по возрастанию площадей', tempArr));

        }

    }
})();