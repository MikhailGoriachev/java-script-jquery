//Представление погоды
class Weather {
    //Свойства
    constructor(temperature, pressure, humidity, wind, icon,day) {
        this.weatherIcon = icon;
        this.dayOfWeek = day;
        this.temperature = temperature;
        this.pressure = pressure;
        this.humidity = humidity;
        this.wind = wind;
    }


    //region Геттеры и сеттеры

    //region Температура
    get temperature() {
        return this._temperature;
    }

    set temperature(value) {
        if (value<-70 || value>70){
            this._temperature = 15;
            return;
        }
        this._temperature = value;
    }
    //endregion

    //region Давление
    get pressure() {
        return this._pressure;
    }

    set pressure(value) {
        if (value<0)
        {
            this._pressure = 0;
            return;
        }
        this._pressure = value;
    }
    //endregion

    //region Влажность
    get humidity() {
        return this._humidity;
    }

    set humidity(value) {
        if (value<0){
            this._humidity = 10;
            return;
        }
        this._humidity = value;
    }
    //endregion

    //region Ветер
    get wind() {
        return this._wind;
    }

    set wind(value) {
        this._wind = value;
    }
    //endregion

    set weatherIcon(value) {
        this._weatherIcon = value;
    }

    //region День недели
    get dayOfWeek() {
        return this._dayOfWeek;
    }

    set dayOfWeek(value) {
        //Если данные некорретны, то задаём понедельник по умолчанию
        this._dayOfWeek = (value <= 0 || value > 7)?getDayOfWeek(1):getDayOfWeek(value);
    }
    //endregion

    //endregion

    //Вывод
    toTableRow (n) {
        return `<div id="d_${n}">
                    <table>
                        <tr><td><img class="weather-type-icon" src="../images/weather/${this._weatherIcon}"></td></tr>
                        <tr><td><span>День недели: <b>${this._dayOfWeek}</b></span></td></tr>
                        <tr><td><span>Температура: <b>${this._temperature}</b></span></td></tr>
                        <tr><td><span>Давление: <b>${this._pressure}</b></span></td></tr>
                        <tr><td><span>Влажность: <b>${this._humidity}</b>%</span></td></tr>
                        <tr>
                        <td>
                            <span>Скорость ветра: <b>${this._wind.speed}</b> м/с</span><br>
                            <span>Нарпавление ветра: <b>${this._wind.direction}</b></span>
                        </td>
                    </table>
                </div>`
    }

    //Выделение элемента
    highlightElement(cardId,predicate){
        if (predicate(this))
            $(`d_${cardId}`).getElementsByTagName("table")[0].className = "highlightDay";
    }

    //Сброс выделения элемента
    resetStyle(cardId){
        $(`d_${cardId}`).getElementsByTagName("table")[0].classList.remove("highlightDay");
    }

}

//Отчет о погоде
class WeatherReport{
    constructor(weathersArr) {
        this.weathers = weathersArr;
    }

    //Генерация массива погод
    static generateWeathers() {
        let array = [];

        for (let i = 0; i < 7; i++) {
            let w = getViewWeather();
            array[i] = new Weather(w.temperature,w.pressure,w.humidity,w.windObj,w.typeIcon,i+1)
        }

        return array;
    }

    //Формирование разметки
    static createMarkup(weatherArr) {
        let n = 0;
        let str = weatherArr.reduce((acc,weather) => acc+weather.toTableRow(n++),'');
        /*weatherArr.forEach(w => str += w.toTableRow());*/
        return str;
    }
}


//region Сортировки, обработчики

//Упорядочить представление по убыванию температуры
function orderDescByTemperature(blockObject,titleObject) {
    return () => {
        //Компаратор: находим блок span под нужным номером и получаем из него строку для парсинга числанаходим блок span под нужным номером и получаем из него строку для парсинга числа
        sortArr(blockObject,(c1,c2) => {
            let t1 = getNumFromStr(c1.getElementsByTagName("span")[1].getElementsByTagName("b")[0].innerHTML);
            let t2 = getNumFromStr(c2.getElementsByTagName("span")[1].getElementsByTagName("b")[0].innerHTML);
            return t2-t1;
        });

        titleObject.innerHTML = `<span>Сортировка представления по убыванию температуры</span>`;
    }
}//orderDescByTemperature

//Упорядочить представление по возрастанию давления
function orderAscByPressure(blockObject,titleObject) {
    return () => {

        //Компаратор: находим блок span под нужным номером и получаем из него строку для парсинга числанаходим блок span под нужным номером и получаем из него строку для парсинга числа
        sortArr(blockObject,(c1,c2) => {
            let p1 = getNumFromStr(c1.getElementsByTagName("span")[2].getElementsByTagName("b")[0].innerHTML);
            let p2 = getNumFromStr(c2.getElementsByTagName("span")[2].getElementsByTagName("b")[0].innerHTML);
            return p1-p2;
        });

        titleObject.innerHTML = `<span>Сортировка представления по возрастанию давления</span>`;
    }
}//orderAscByPressure

//Упорядочить по убыванию скорости ветра
function orderDescByWindSpeed(blockObject,titleObject) {
    return () => {

        //Компаратор: находим блок span под нужным номером и получаем из него строку для парсинга числа
        sortArr(blockObject,(c1,c2) => {
            let ws1 = getNumFromStr(c1.getElementsByTagName("span")[4].getElementsByTagName("b")[0].innerHTML);
            let ws2 = getNumFromStr(c2.getElementsByTagName("span")[4].getElementsByTagName("b")[0].innerHTML);
            return ws2-ws1;
        });

        titleObject.innerHTML = `<span>Сортировка представления по убыванию скорости ветра</span>`;

    }
}//orderDescByWindSpeed

//endregion

//Сортировка и запись представления
function sortArr(mainNode,comparator) {
    //Получаем массив дочерних элементов общего блока
    let childNodes = [];
    mainNode.childNodes.forEach(c => {
        if (c.nodeType == 1)
            childNodes.push(c);
    });

    //Сортировка по компаратору
    childNodes.sort(comparator);

    //Добавление отсортированного массива надзад
    for (let child of childNodes) {
        mainNode.append(child);
    }
}

//Функция с самовызовом
(function (){

    //Массив представлений погоды
    let report = new WeatherReport(WeatherReport.generateWeathers());

    let mainBlock = $("mainDiv");

    mainBlock.innerHTML = WeatherReport.createMarkup(report.weathers);


    //region Вставка заголовка
    let title = document.createElement("p");
    title.setAttribute("id", "taskTitle");
    title.setAttribute("class", "title-style");

    title.innerHTML = `<span>Исходный массив</span>`;
    mainBlock.parentNode.insertBefore(title, mainBlock);
    //endregion

    title = $('taskTitle');

    window.onload = function () {
        //Обработчик кнопки вывода исходного массива
        $("defaultArr").onclick = function () {
            mainBlock.innerHTML = WeatherReport.createMarkup(report.weathers);
            title.innerHTML = `<span>Исходный массив</span>`;
        }

        //region Сортировки

        //Обработчик кнопки сортировки представления по убыванию температуры
        $("orderByT").onclick = orderDescByTemperature(mainBlock, title);

        //Обработчик кнопки сортировки представления по возрастанию давления
        $("orderByP").onclick = orderAscByPressure(mainBlock, title);

        //Обработчик кнопки сортировки представления по убванию скорости ветра
        $("orderByWind").onclick = orderDescByWindSpeed(mainBlock, title);

        //endregion

        //region Выделение

        //Получить самые ветреные дни
        $("highlightTheWindiest").onclick = function () {

            //Поиск максимального значения
            let maxWindSpeed = Math.max(...report.weathers.map(w => w.wind.speed));

            let n = 0;

            //Сброс предыдущих выделений
            report.weathers.forEach(w => w.resetStyle(n++));

            n = 0;

            function predicate(weather) {
                return weather.wind.speed == maxWindSpeed
            }

            //Выделение элемента для которого отработает предикат
            report.weathers.forEach(w => w.highlightElement(n++, predicate));

            title.innerHTML = `<span>Самые ветреные дни</span>`;
        }

        //Получить самые тихие дни
        $("highlightNoWind").onclick = function () {

            //Поиск минимального значения
            let minWindSpeed = Math.min(...report.weathers.map(w => w.wind.speed));

            let n = 0;
            //Сброс предыдущих выделений
            report.weathers.forEach(w => w.resetStyle(n++));

            n = 0;

            function predicate(weather) {
                return weather.wind.speed == minWindSpeed
            }


            //Выделение элемента для которого отработает предикат
            report.weathers.forEach(w => w.highlightElement(n++, predicate));

            title.innerHTML = `<span>Самые тихие дни</span>`;
        }

        //Получить дни с северным ветром
        $("highlightNorthern").onclick = function () {

            let n = 0;
            //Сброс предыдущих выделений
            report.weathers.forEach(w => w.resetStyle(n++));

            n = 0;

            function predicate(weather) {
                return weather.wind.direction.includes("С");
            }

            //Выделение элемента для которого отработает предикат
            report.weathers.forEach(w => w.highlightElement(n++, predicate));

            title.innerHTML = `<span>Дни с северным ветром</span>`;
        }

        //endregion

    }
})();